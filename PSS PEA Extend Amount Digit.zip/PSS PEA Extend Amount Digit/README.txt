Source code
- 128B PEA, Quote validation: at branch pea-spec-init ( https://github.ibm.com/Application-Dev-Intern/PSS/tree/pea-spec-init )
- Modern browser (Upload), 128B PEA, Quote validation: at branch pea-spec ( https://github.ibm.com/Application-Dev-Intern/PSS/tree/pea-spec )



Modified PSS file

New Browser
- PSS/src/java/com/scb/pss/uti/Upload.java
- PSS/web/AtsTxnNew.jsp
- PSS/web/_script/atstxn.js
- PSS/web/_script/atsTransTxnBtSc.js
- PSS/web/_script/atsTransTxnSc.js

Quote validation
- PSS/src/java/com/scb/pss/uti/Upload.java

128B PEA
- PSS/src/java/com/scb/pss/atstxn/control/HashFormat.java
- PSS/src/java/com/scb/pss/uti/ConvertTo80B100M.java
- PSS/src/java/com/scb/pss/uti/Upload.java