/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.scb.pss.uti;

import com.scb.pss.uti.fileUtil;
import com.scb.pss.uti.pssConfig;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

// SAMPLE
//        ConvertTo80B100M c = new ConvertTo80B100M();        
//        c.cvt80B100MControl("128BPOOL", "C:\\test tmp file\\001067_100m.TXT", "C:\\test tmp file\\001067_1000mNew.TXT");
/**
 *
 * @author s45925
 */
public class ConvertTo80B100M {

    Map<String, String> ctlData128Pool;
    Map<String, String> ctlData128PEA;
    Map<String, String> ctlData130MEA;
    Map<String, String> ctlData80_10M;
    Map<String, String> ctlData128TA;
    Map<String, String> ctlData128TOT;
    Map<String, String> tlData128Pool;
    Map<String, String> tlData128PEA;
    Map<String, String> tlData130MEA;
    Map<String, String> tlData128TA;
    Map<String, String> tlData128TOT;
    List<Map<String, String>> resultDtl128Pool;
    List<Map<String, String>> resultDtl128PEA;
    List<Map<String, String>> resultDtl130MEA;
    List<Map<String, String>> resultDtl80_10M;
    List<Map<String, String>> resultDtl128TA;
    List<Map<String, String>> resultDtl128TOT;
    int totRec128Pool;
    double amtRec128Pool;
    int totRec128PEA;
    double amtRec128PEA;
    int totRec130MEA;
    double amtRec130MEA;
    int totRec128TA;
    double amtRec128TA;
    int totRec128TOT;
    double amtRec128TOT;

    public ConvertTo80B100M() {
        InitialVariables();
    }

    public void InitialVariables() {
        ctlData128Pool = new HashMap<String, String>();
        ctlData128PEA = new HashMap<String, String>();
        ctlData130MEA = new HashMap<String, String>();
        ctlData80_10M = new HashMap<String, String>();
        ctlData128TA = new HashMap<String, String>();
        ctlData128TOT = new HashMap<String, String>();
        tlData128Pool = new HashMap<String, String>();
        tlData128PEA = new HashMap<String, String>();
        tlData130MEA = new HashMap<String, String>();
        tlData128TA = new HashMap<String, String>();
        tlData128TOT = new HashMap<String, String>();
        resultDtl128Pool = new ArrayList<Map<String, String>>();
        resultDtl128PEA = new ArrayList<Map<String, String>>();
        resultDtl130MEA = new ArrayList<Map<String, String>>();
        resultDtl80_10M = new ArrayList<Map<String, String>>();
        resultDtl128TA = new ArrayList<Map<String, String>>();
        resultDtl128TOT = new ArrayList<Map<String, String>>();
        totRec128Pool = 0;
        amtRec128Pool = 0;
        totRec128PEA = 0;
        amtRec128PEA = 0;
        totRec130MEA = 0;
        amtRec130MEA = 0;
        totRec128TA = 0;
        amtRec128TA = 0;
        totRec128TOT = 0;
        amtRec128TOT = 0;
    }

    public Boolean cvt80B100MControl(String tmpId, String inPath, String outPath, String compCode) {
        boolean returnValue = false;
        pssConfig pconfig = new pssConfig();
        fileUtil svFile = new fileUtil();
        Scanner inFile = svFile.fileOpenRead(inPath, pconfig.getFileEncode());
        if (tmpId.equals("80B10M")) {

//            System.out.println(new java.util.Date());
            // TODO Call open scanner input and output
            ats80B10MValid(inFile);
            Writer writer = null;

            try {
                File file = new File(outPath);
                writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));

                //control
                writer.write(String.format("%1$8s", ""));//9 space
                writer.write(ctlData80_10M.get("TERM-PAYMENT"));//TERM-PAYMENT
                writer.write(ctlData80_10M.get("COMPANY-CODE"));//COMPANY-CODE
                writer.write(ctlData80_10M.get("COMPANY-NAME"));//COMPANY-NAME
                writer.write(ctlData80_10M.get("APPLY-CODE"));//APPLY-CODE
                writer.write(ctlData80_10M.get("STATUS"));//STATUS
                writer.write(ctlData80_10M.get("EFFECTIVE-DATE"));//EFFECTIVE-DATE
                writer.write(ctlData80_10M.get("TOTAL-RECORD"));//TOTAL-RECORD
                writer.write("0" + ctlData80_10M.get("TOTAL-AMOUNT"));//TOTAL-AMOUNT
                writer.write(ctlData80_10M.get("MEDIA-TYPE"));//MEDIA-TYPE
                writer.write(String.format("%1$8s", ""));//8 space
                writer.write("\n");
                int i = 0;
                //detail
                for (Map<String, String> dtlData80_100M : resultDtl80_10M) {
                    writer.write(dtlData80_100M.get("ACCOUNT NO."));//ACCOUNT NO.
                    writer.write(dtlData80_100M.get("EFFECTIVE-DATE"));//EFFECTIVE-DATE
                    writer.write(dtlData80_100M.get("SIGN"));//SIGN
                    writer.write("00" + dtlData80_100M.get("AMOUNT"));//AMOUNT
                    writer.write(String.format("%1$52s", ""));//52 space
                    writer.write("\n");
                    i++;
                }
                returnValue = true;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (writer != null) {
                        writer.flush();
                        writer.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
//            System.out.println(new java.util.Date());

        } else if (tmpId.equals("128BPOOL")) {
//            System.out.println(new java.util.Date());
            System.out.println("(cvt80B100MControl) 128BPOOL: " + tmpId.equals("128BPOOL") + ", isPEA: " + compCode.equals("001170") + ", !(isPEA): " + !compCode.equals("001170"));
            if (compCode.equals("001170")) {
                ats128BPEAvalid(inFile);
                Writer writer = null;

                try {
                    File file = new File(outPath);
                    writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));

                    //control
                    writer.write(String.format("%1$8s", ""));//8 space
                    writer.write("M");//TERM-PAYMENT
            //                writer.write(ctlData128PEA.get("COMPNO").substring(ctlData128PEA.get("COMPNO").length() - 6));//COMPANY-CODE
                    writer.write(compCode.substring(compCode.length() - 6));//COMPANY-CODE
                    writer.write(String.format("%1$-30s", ctlData128PEA.get("COMPNAME")));//COMPANY-NAME
                    String applCode = resultDtl128PEA.get(0).get("SERVTYPE");//APPLY-CODE
                    if (applCode.equals("01")) {
                        writer.write("D");
                    } else if (applCode.equals("02")) {
                        writer.write("D");
                    } else if (applCode.equals("03")) {
                        writer.write("I");
                    } else if (applCode.equals("04")) {
                        writer.write("X");
                    } else if (applCode.equals("05")) {
                        writer.write("X");
                    } else if (applCode.equals("06")) {
                        writer.write("Z");
                    } else if (applCode.equals("07")) {
                        writer.write("S");
                    } else if (applCode.equals("08")) {
                        writer.write("V");
                    } else if (applCode.equals("09")) {
                        writer.write("X");
                    } else if (applCode.equals("10")) {
                        writer.write("T");
                    } else if (applCode.equals("11")) {
                        writer.write("E");
                    } else if (applCode.equals("12")) {
                        writer.write("W");
                    } else if (applCode.equals("13")) {
                        writer.write("X");
                    } else if (applCode.equals("14")) {
                        writer.write("O");
                    } else if (applCode.equals("15")) {
                        writer.write("1");
                    } else if (applCode.equals("16")) {
                        writer.write("C");
                    } else if (applCode.equals("17")) {
                        writer.write("6");
                    } else if (applCode.equals("99")) {
                        writer.write("X");
                    }
                    writer.write("A");//STATUS
                    writer.write(ctlData128PEA.get("EFFDATE"));//EFFECTIVE-DATE

                    NumberFormat fmTrans = new DecimalFormat("00000");
                    writer.write(fmTrans.format(totRec128PEA));//TOTAL-RECORD
                    fmTrans = new DecimalFormat("00000000000");
                    writer.write(fmTrans.format(amtRec128PEA));//TOTAL-AMOUNT
                    writer.write("T");//MEDIA-TYPE
                    writer.write(String.format("%1$8s", ""));//8 space
                    writer.write("\n");
                    int i = 0;
                    //detail
                    for (Map<String, String> dtlData128PEA : resultDtl128PEA) {
                        writer.write(dtlData128PEA.get("ACCNO"));//ACCOUNT NO.
                        writer.write(ctlData128PEA.get("EFFDATE"));//EFFECTIVE-DATE
                        if (dtlData128PEA.get("TRANSCODE").equals("C")) {//SIGN
                            writer.write("0");
                        } else {
                            writer.write("1");
                        }
                        writer.write(dtlData128PEA.get("AMOUNT"));//AMOUNT
                        writer.write(String.format("%1$50s", ""));//50 space
                        writer.write("\n");
                        i++;
            //                    System.out.println(i);
                    }
                    returnValue = true;
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (writer != null) {
                            writer.flush();
                            writer.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                ats128BPoolvalid(inFile);
                Writer writer = null;

                try {
                    File file = new File(outPath);
                    writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));

                    //control
                    writer.write(String.format("%1$8s", ""));//8 space
                    writer.write("M");//TERM-PAYMENT
    //                writer.write(ctlData128Pool.get("COMPNO").substring(ctlData128Pool.get("COMPNO").length() - 6));//COMPANY-CODE
                    writer.write(compCode.substring(compCode.length() - 6));//COMPANY-CODE
                    writer.write(String.format("%1$-30s", ctlData128Pool.get("COMPNAME")));//COMPANY-NAME
                    String applCode = resultDtl128Pool.get(0).get("SERVTYPE");//APPLY-CODE
                    if (applCode.equals("01")) {
                        writer.write("D");
                    } else if (applCode.equals("02")) {
                        writer.write("D");
                    } else if (applCode.equals("03")) {
                        writer.write("I");
                    } else if (applCode.equals("04")) {
                        writer.write("X");
                    } else if (applCode.equals("05")) {
                        writer.write("X");
                    } else if (applCode.equals("06")) {
                        writer.write("Z");
                    } else if (applCode.equals("07")) {
                        writer.write("S");
                    } else if (applCode.equals("08")) {
                        writer.write("V");
                    } else if (applCode.equals("09")) {
                        writer.write("X");
                    } else if (applCode.equals("10")) {
                        writer.write("T");
                    } else if (applCode.equals("11")) {
                        writer.write("E");
                    } else if (applCode.equals("12")) {
                        writer.write("W");
                    } else if (applCode.equals("13")) {
                        writer.write("X");
                    } else if (applCode.equals("14")) {
                        writer.write("O");
                    } else if (applCode.equals("15")) {
                        writer.write("1");
                    } else if (applCode.equals("16")) {
                        writer.write("C");
                    } else if (applCode.equals("17")) {
                        writer.write("6");
                    } else if (applCode.equals("99")) {
                        writer.write("X");
                    }
                    writer.write("A");//STATUS
                    writer.write(ctlData128Pool.get("EFFDATE"));//EFFECTIVE-DATE

                    NumberFormat fmTrans = new DecimalFormat("00000");
                    writer.write(fmTrans.format(totRec128Pool));//TOTAL-RECORD
                    fmTrans = new DecimalFormat("00000000000");
                    writer.write(fmTrans.format(amtRec128Pool));//TOTAL-AMOUNT
                    writer.write("T");//MEDIA-TYPE
                    writer.write(String.format("%1$8s", ""));//8 space
                    writer.write("\n");
                    int i = 0;
                    //detail
                    for (Map<String, String> dtlData128Pool : resultDtl128Pool) {
                        writer.write(dtlData128Pool.get("ACCNO"));//ACCOUNT NO.
                        writer.write(ctlData128Pool.get("EFFDATE"));//EFFECTIVE-DATE
                        if (dtlData128Pool.get("TRANSCODE").equals("C")) {//SIGN
                            writer.write("0");
                        } else {
                            writer.write("1");
                        }
                        writer.write("0" + dtlData128Pool.get("AMOUNT"));//AMOUNT
                        writer.write(String.format("%1$50s", ""));//50 space
                        writer.write("\n");
                        i++;
    //                    System.out.println(i);
                    }
                    returnValue = true;
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (writer != null) {
                            writer.flush();
                            writer.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
//            System.out.println(new java.util.Date());
        } else if (tmpId.equals("130BMEA")) {
//            System.out.println(new java.util.Date());
            ats130BMEAvalid(inFile);
            Writer writer = null;

            try {
                File file = new File(outPath);
                writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));

                //control
                writer.write(String.format("%1$8s", ""));//8 space
                writer.write("M");//TERM-PAYMENT
                writer.write(compCode.substring(compCode.length() - 6));//COMPANY-CODE
                writer.write(String.format("%1$-30s", ctlData130MEA.get("COMPNAME")));//COMPANY-NAME
                String applCode = resultDtl130MEA.get(0).get("SERVTYPE");//APPLY-CODE
                if (applCode.equals("01")) {
                    writer.write("D");
                } else if (applCode.equals("02")) {
                    writer.write("D");
                } else if (applCode.equals("03")) {
                    writer.write("I");
                } else if (applCode.equals("04")) {
                    writer.write("X");
                } else if (applCode.equals("05")) {
                    writer.write("X");
                } else if (applCode.equals("06")) {
                    writer.write("Z");
                } else if (applCode.equals("07")) {
                    writer.write("S");
                } else if (applCode.equals("08")) {
                    writer.write("V");
                } else if (applCode.equals("09")) {
                    writer.write("X");
                } else if (applCode.equals("10")) {
                    writer.write("T");
                } else if (applCode.equals("11")) {
                    writer.write("E");
                } else if (applCode.equals("12")) {
                    writer.write("W");
                } else if (applCode.equals("13")) {
                    writer.write("X");
                } else if (applCode.equals("14")) {
                    writer.write("O");
                } else if (applCode.equals("15")) {
                    writer.write("1");
                } else if (applCode.equals("16")) {
                    writer.write("C");
                } else if (applCode.equals("17")) {
                    writer.write("6");
                } else if (applCode.equals("99")) {
                    writer.write("X");
                }
                writer.write("A");//STATUS
                writer.write(ctlData130MEA.get("EFFDATE"));//EFFECTIVE-DATE

                NumberFormat fmTrans = new DecimalFormat("00000");
                writer.write(fmTrans.format(totRec130MEA));//TOTAL-RECORD
                fmTrans = new DecimalFormat("00000000000");
                String amtStr = fmTrans.format(amtRec130MEA);
                if (amtStr.length() > 11){
                    amtStr = amtStr.substring(amtStr.length()-11);
                }
//                writer.write(fmTrans.format(amtRec130MEA));//TOTAL-AMOUNT
                writer.write(amtStr);//TOTAL-AMOUNT
                writer.write("T");//MEDIA-TYPE
                writer.write(String.format("%1$8s", ""));//8 space
                writer.write("\n");
                int i = 0;
                //detail
                for (Map<String, String> dtlData130MEA : resultDtl130MEA) {
                    writer.write(dtlData130MEA.get("ACCNO"));//ACCOUNT NO.
                    writer.write(ctlData130MEA.get("EFFDATE"));//EFFECTIVE-DATE
                    if (dtlData130MEA.get("TRANSCODE").equals("C")) {//SIGN
                        writer.write("0");
                    } else {
                        writer.write("1");
                    }
                    writer.write(dtlData130MEA.get("AMOUNT").substring(1));//AMOUNT
                    writer.write(String.format("%1$50s", ""));//50 space
                    writer.write("\n");
                    i++;
//                    System.out.println(i);
                }
                returnValue = true;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (writer != null) {
                        writer.flush();
                        writer.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
//            System.out.println(new java.util.Date());
        } else if (tmpId.equals("128BTT")) {
//            System.out.println(new java.util.Date());
            ats128B2TAvalid(inFile);
            Writer writer = null;

            try {
                File file = new File(outPath);
                writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));

                //control
                writer.write(String.format("%1$8s", ""));//8 space
                writer.write("M");//TERM-PAYMENT
//                writer.write(ctlData128TA.get("ATSBNK-COMPNO-H").substring(ctlData128TA.get("ATSBNK-COMPNO-H").length() - 6));//COMPANY-CODE
                writer.write(compCode.substring(compCode.length() - 6));//COMPANY-CODE
                writer.write(String.format("%1$-30s", ctlData128TA.get("ATSBNK-COMPNAME-H")));//COMPANY-NAME
                String applCode = resultDtl128TA.get(0).get("ATSBNK-SERVTYPE-D");//APPLY-CODE
                if (applCode.equals("01")) {
                    writer.write("D");
                } else if (applCode.equals("02")) {
                    writer.write("D");
                } else if (applCode.equals("03")) {
                    writer.write("I");
                } else if (applCode.equals("04")) {
                    writer.write("X");
                } else if (applCode.equals("05")) {
                    writer.write("X");
                } else if (applCode.equals("06")) {
                    writer.write("Z");
                } else if (applCode.equals("07")) {
                    writer.write("S");
                } else if (applCode.equals("08")) {
                    writer.write("V");
                } else if (applCode.equals("09")) {
                    writer.write("X");
                } else if (applCode.equals("10")) {
                    writer.write("T");
                } else if (applCode.equals("11")) {
                    writer.write("E");
                } else if (applCode.equals("12")) {
                    writer.write("W");
                } else if (applCode.equals("13")) {
                    writer.write("X");
                } else if (applCode.equals("14")) {
                    writer.write("O");
                } else if (applCode.equals("15")) {
                    writer.write("1");
                } else if (applCode.equals("16")) {
                    writer.write("C");
                } else if (applCode.equals("17")) {
                    writer.write("6");
                } else if (applCode.equals("99")) {
                    writer.write("X");
                }
                writer.write("A");//STATUS
                writer.write(ctlData128TA.get("ATSBNK-EFFDATE-H"));//EFFECTIVE-DATE

                NumberFormat fmTrans = new DecimalFormat("00000");
                writer.write(fmTrans.format(totRec128TA));//TOTAL-RECORD
                fmTrans = new DecimalFormat("00000000000");
                writer.write(fmTrans.format(amtRec128TA));//TOTAL-AMOUNT
                writer.write("T");//MEDIA-TYPE
                writer.write(String.format("%1$8s", ""));//8 space
                writer.write("\n");
                int i = 0;
                //detail
                for (Map<String, String> dtlData128TA : resultDtl128TA) {
                    writer.write(dtlData128TA.get("ATSBNK-ACCNO-D"));//ACCOUNT NO.
                    writer.write(ctlData128TA.get("ATSBNK-EFFDATE-H"));//EFFECTIVE-DATE
                    if (dtlData128TA.get("ATSBNK-TRANSCODE-D").equals("C")) {//SIGN
                        writer.write("0");
                    } else {
                        writer.write("1");
                    }
                    writer.write("0" + dtlData128TA.get("ATSBNK-AMOUNT-D"));//AMOUNT
                    writer.write(String.format("%1$50s", ""));//50 space
                    writer.write("\n");
                    i++;
//                    System.out.println(i);
                }
                returnValue = true;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (writer != null) {
                        writer.flush();
                        writer.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
//            System.out.println(new java.util.Date());
        } else if (tmpId.equals("128BTOT")) {
//            System.out.println(new java.util.Date());

            ats128B2TOTvalid(inFile);
            Writer writer = null;

            try {
                File file = new File(outPath);
                writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));

                //control
                writer.write(String.format("%1$8s", ""));//8 space
                writer.write("M");//TERM-PAYMENT
//                writer.write(ctlData128TA.get("ATSBNK-COMPNO-H").substring(ctlData128TA.get("ATSBNK-COMPNO-H").length() - 6));//COMPANY-CODE
                writer.write(compCode.substring(compCode.length() - 6));//COMPANY-CODE
                writer.write(String.format("%1$-30s", ctlData128TOT.get("ATSBNK-COMPNAME-H")));//COMPANY-NAME
                String applCode = resultDtl128TOT.get(0).get("ATSBNK-SERVTYPE-D");//APPLY-CODE
                if (applCode.equals("01")) {
                    writer.write("D");
                } else if (applCode.equals("02")) {
                    writer.write("D");
                } else if (applCode.equals("03")) {
                    writer.write("I");
                } else if (applCode.equals("04")) {
                    writer.write("X");
                } else if (applCode.equals("05")) {
                    writer.write("X");
                } else if (applCode.equals("06")) {
                    writer.write("Z");
                } else if (applCode.equals("07")) {
                    writer.write("S");
                } else if (applCode.equals("08")) {
                    writer.write("V");
                } else if (applCode.equals("09")) {
                    writer.write("X");
                } else if (applCode.equals("10")) {
                    writer.write("T");
                } else if (applCode.equals("11")) {
                    writer.write("E");
                } else if (applCode.equals("12")) {
                    writer.write("W");
                } else if (applCode.equals("13")) {
                    writer.write("X");
                } else if (applCode.equals("14")) {
                    writer.write("O");
                } else if (applCode.equals("15")) {
                    writer.write("1");
                } else if (applCode.equals("16")) {
                    writer.write("C");
                } else if (applCode.equals("17")) {
                    writer.write("6");
                } else if (applCode.equals("99")) {
                    writer.write("X");
                }
                writer.write("A");//STATUS
                writer.write(ctlData128TOT.get("ATSBNK-EFFDATE-H"));//EFFECTIVE-DATE

                NumberFormat fmTrans = new DecimalFormat("00000");
                writer.write(fmTrans.format(totRec128TOT));//TOTAL-RECORD
                fmTrans = new DecimalFormat("00000000000");
                writer.write(fmTrans.format(amtRec128TOT));//TOTAL-AMOUNT
                writer.write("T");//MEDIA-TYPE
                writer.write(String.format("%1$8s", ""));//8 space
                writer.write("\n");
                int i = 0;
                //detail
                for (Map<String, String> dtlData128TOT : resultDtl128TOT) {
                    writer.write(dtlData128TOT.get("ATSBNK-ACCNO-D"));//ACCOUNT NO.
                    writer.write(ctlData128TOT.get("ATSBNK-EFFDATE-H"));//EFFECTIVE-DATE
                    if (dtlData128TOT.get("ATSBNK-TRANSCODE-D").equals("C")) {//SIGN
                        writer.write("0");
                    } else {
                        writer.write("1");
                    }
                    writer.write("0" + dtlData128TOT.get("ATSBNK-AMOUNT-D"));//AMOUNT
                    writer.write(String.format("%1$50s", ""));//50 space
                    writer.write("\n");
                    i++;
//                    System.out.println(i);
                }
                returnValue = true;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (writer != null) {
                        writer.flush();
                        writer.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
//            System.out.println(new java.util.Date());
        } else {
            System.out.println("Error Template ID");
        }
        return returnValue;
    }

    public void ats80B10MValid(Scanner inFile) {
        String rdData;
//        String NL = System.getProperty("line.separator");
        Integer lineCount = 1;
        Integer ctlCount = 0;
        Integer dtlCount = 0;

        //specific length of substringdata
        Integer[][] ctlFmTo = new Integer[11][2];
        ctlFmTo[0][0] = 0; //filler1
        ctlFmTo[0][1] = 9;
        ctlFmTo[1][0] = 9;//termpay
        ctlFmTo[1][1] = 10;
        ctlFmTo[2][0] = 10;//compcode
        ctlFmTo[2][1] = 16;
        ctlFmTo[3][0] = 16;//compname
        ctlFmTo[3][1] = 46;
        ctlFmTo[4][0] = 46;//appCode
        ctlFmTo[4][1] = 47;
        ctlFmTo[5][0] = 47;//status
        ctlFmTo[5][1] = 48;
        ctlFmTo[6][0] = 48;//effdate
        ctlFmTo[6][1] = 54;
        ctlFmTo[7][0] = 54;//totrec
        ctlFmTo[7][1] = 59;
        ctlFmTo[8][0] = 59;//totamt
        ctlFmTo[8][1] = 69;
        ctlFmTo[9][0] = 69;//media type
        ctlFmTo[9][1] = 70;
        ctlFmTo[10][0] = 70;//filler2
        ctlFmTo[10][1] = 77;

        String[] ctlName = {"SPACE1", "TERM-PAYMENT", "COMPANY-CODE", "COMPANY-NAME",
            "APPLY-CODE", "STATUS", "EFFECTIVE-DATE", "TOTAL-RECORD",
            "TOTAL-AMOUNT", "MEDIA-TYPE", "SPACE2"};

        Integer[][] dtlFmTo = new Integer[5][2];
        dtlFmTo[0][0] = 0;//accno
        dtlFmTo[0][1] = 10;

        dtlFmTo[1][0] = 10;//effdate
        dtlFmTo[1][1] = 16;

        dtlFmTo[2][0] = 16;//sign
        dtlFmTo[2][1] = 17;

        dtlFmTo[3][0] = 17;//amount
        dtlFmTo[3][1] = 26;

        dtlFmTo[4][0] = 26;//filler1
        dtlFmTo[4][1] = 77;

        String[] dtlName = {"ACCOUNT NO.", "EFFECTIVE-DATE", "SIGN", "AMOUNT", "SPACE"};

        String[] ctlRec = new String[11];
        String[] dtlRec;

        Map<String, String> dtlData80_100M;

        // 1st is control record to identify the number of error record and this is debit or credit transaction that host can know;
        while (inFile.hasNextLine()) {
            rdData = inFile.nextLine();
            if (lineCount == 1) {
                ctlCount++;

                for (int i = 0; i <= ctlRec.length - 1; i++) {
                    try {
                        ctlData80_10M.put(ctlName[i], rdData.substring(ctlFmTo[i][0], ctlFmTo[i][1]));
                    } catch (IndexOutOfBoundsException ex) {
                        ctlData80_10M.put(ctlName[i], rdData.substring(ctlFmTo[i][0]));
                    }
                }
            } else {
                //DETAIL RECORD OF 80B10M
                if (rdData.trim().length() != 0) {
                    dtlCount++;
                    dtlRec = new String[5];
                    dtlData80_100M = new HashMap<String, String>();

                    for (int i = 0; i <= dtlRec.length - 1; i++) {
//                        System.out.println(rdData.length());
                        try {
                            dtlData80_100M.put(dtlName[i], rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                        } catch (IndexOutOfBoundsException ex) {
                            dtlData80_100M.put(dtlName[i], rdData.substring(dtlFmTo[i][0]));
                        } catch (Exception ex) {
                            System.out.println(ex.toString());
                        }

                    }
                    resultDtl80_10M.add(dtlData80_100M);
                }
            }
            lineCount++;
        }
    }

    public void ats80B100MValid(Scanner inFile) {
        StringBuilder text = new StringBuilder();
        String rdData;
//        String NL = System.getProperty("line.separator");
        Integer lineCount = 1;
        Integer ctlCount = 0;
        Integer dtlCount = 0;

        //specific length of substringdata
        Integer[][] ctlFmTo = new Integer[11][2];
        ctlFmTo[0][0] = 0; //filler1
        ctlFmTo[0][1] = 8;
        ctlFmTo[1][0] = 8;//termpay
        ctlFmTo[1][1] = 9;
        ctlFmTo[2][0] = 9;//compcode
        ctlFmTo[2][1] = 15;
        ctlFmTo[3][0] = 15;//compname
        ctlFmTo[3][1] = 45;
        ctlFmTo[4][0] = 45;//appCode
        ctlFmTo[4][1] = 46;
        ctlFmTo[5][0] = 46;//status
        ctlFmTo[5][1] = 47;
        ctlFmTo[6][0] = 47;//effdate
        ctlFmTo[6][1] = 53;
        ctlFmTo[7][0] = 53;//totrec
        ctlFmTo[7][1] = 58;
        ctlFmTo[8][0] = 58;//totamt
        ctlFmTo[8][1] = 69;
        ctlFmTo[9][0] = 69;//media type
        ctlFmTo[9][1] = 70;
        ctlFmTo[10][0] = 70;//filler2
        ctlFmTo[10][1] = 77;

        Integer[][] dtlFmTo = new Integer[5][2];
        dtlFmTo[0][0] = 0;//accno
        dtlFmTo[0][1] = 10;

        dtlFmTo[1][0] = 10;//effdate
        dtlFmTo[1][1] = 16;

        dtlFmTo[2][0] = 16;//sign
        dtlFmTo[2][1] = 17;

        dtlFmTo[3][0] = 17;//amount
        dtlFmTo[3][1] = 28;

        dtlFmTo[4][0] = 28;//filler1
        dtlFmTo[4][1] = 78;



        String[] ctlRec = new String[11];
        String[] dtlRec;
//        List<String> dtlListRec = new ArrayList();
        ArrayList<String[]> ats80B100Mdata = new ArrayList<String[]>();

        // 1st is control record to identify the number of error record and this is debit or credit transaction that host can know;
        while (inFile.hasNextLine()) {
            rdData = inFile.nextLine();
            if (lineCount == 1) {
                ctlCount++;

                for (int i = 0; i <= ctlRec.length - 1; i++) {
                    try {
                        ctlRec[i] = rdData.substring(ctlFmTo[i][0], ctlFmTo[i][1]);
                    } catch (IndexOutOfBoundsException ex) {
                        ctlRec[i] = rdData.substring(ctlFmTo[i][0]);
                    }
                }
                ats80B100Mdata.add(ctlRec);
            } else {
                //DETAIL RECORD OF 80B10M
//                System.out.println(rdData);
                if (rdData.trim().length() != 0) {
                    dtlCount++;
                    dtlRec = new String[5];

                    for (int i = 0; i <= dtlRec.length - 1; i++) {
//                        System.out.println(rdData.length());
                        try {
                            dtlRec[i] = rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]);
                        } catch (IndexOutOfBoundsException ex) {
                            dtlRec[i] = rdData.substring(dtlFmTo[i][0]);
                        }

                    }
                    ats80B100Mdata.add(dtlRec);
                }
            }

//            System.out.println(rdData);
            lineCount++;
        }

//        System.out.println(ats80B100Mdata.get(0)[2]); //array

//        System.out.println(ats80B100Mdata.size());
    }

    public void ats128BPoolvalid(Scanner inFile) {
        String rdData;
//        String NL = System.getProperty("line.separator");
        Integer lineCount = 1;
        Integer ctlCount = 0;
        Integer dtlCount = 0;
        Integer tlCount = 0;

        Integer[][] ctlFmTo = new Integer[7][2];
        ctlFmTo[0][0] = 0;
        ctlFmTo[0][1] = 1;//rectype
        ctlFmTo[1][0] = 1;
        ctlFmTo[1][1] = 7;//seqno
        ctlFmTo[2][0] = 7;
        ctlFmTo[2][1] = 10;//bankcode
        ctlFmTo[3][0] = 10;
        ctlFmTo[3][1] = 20;//compno
        ctlFmTo[4][0] = 20;
        ctlFmTo[4][1] = 45;//compname
        ctlFmTo[5][0] = 45;
        ctlFmTo[5][1] = 51;//effdate
        ctlFmTo[6][0] = 51;
        ctlFmTo[6][1] = 128;//filler

        String[] ctlName = {"RECTYPE", "SEQNO", "BANKCODE", "COMPNO", "COMPNAME", "EFFDATE", "FILLER"};

        Integer[][] dtlFmTo = new Integer[10][2];
        dtlFmTo[0][0] = 0;
        dtlFmTo[0][1] = 1;//rectype
        dtlFmTo[1][0] = 1;
        dtlFmTo[1][1] = 7;//seqno
        dtlFmTo[2][0] = 7;
        dtlFmTo[2][1] = 10;//bankcode
        dtlFmTo[3][0] = 10;
        dtlFmTo[3][1] = 20;//accno
        dtlFmTo[4][0] = 20;
        dtlFmTo[4][1] = 21;//transcode
        dtlFmTo[5][0] = 21;
        dtlFmTo[5][1] = 31;//amount
        dtlFmTo[6][0] = 31;
        dtlFmTo[6][1] = 33;//servtype
        dtlFmTo[7][0] = 33;
        dtlFmTo[7][1] = 34;//status
        dtlFmTo[8][0] = 34;
        dtlFmTo[8][1] = 93;//refno
        dtlFmTo[9][0] = 93;
        dtlFmTo[9][1] = 128;//name

        String[] dtlName = {"RECTYPE", "SEQNO", "BANKCODE", "ACCNO", "TRANSCODE",
            "AMOUNT", "SERVTYPE", "STATUS", "REFNO", "NAME"};

        Integer[][] tlFmTo = new Integer[13][2];
        tlFmTo[0][0] = 0;
        tlFmTo[0][1] = 1;//rectype
        tlFmTo[1][0] = 1;
        tlFmTo[1][1] = 7;//seqno
        tlFmTo[2][0] = 7;
        tlFmTo[2][1] = 10;//bankcode
        tlFmTo[3][0] = 10;
        tlFmTo[3][1] = 20;//compno
        tlFmTo[4][0] = 20;
        tlFmTo[4][1] = 27;//nodrtrans
        tlFmTo[5][0] = 27;
        tlFmTo[5][1] = 40;//totdramt
        tlFmTo[6][0] = 40;
        tlFmTo[6][1] = 47;//nocrtrans
        tlFmTo[7][0] = 47;
        tlFmTo[7][1] = 60;//totcramt
        tlFmTo[8][0] = 60;
        tlFmTo[8][1] = 67;//norejdrtran
        tlFmTo[9][0] = 67;
        tlFmTo[9][1] = 80;//totrejdramt
        tlFmTo[10][0] = 80;
        tlFmTo[10][1] = 87;//norejcrtran
        tlFmTo[11][0] = 87;
        tlFmTo[11][1] = 100;//totrejcramt
        tlFmTo[12][0] = 100;
        tlFmTo[12][1] = 128;//filler

        String[] tlName = {"RECTYPE", "SEQNO", "BANKCODE", "COMPNO", "NO-DRTRANS",
            "TOT-DRAMT", "NO-CRTRANS", "TOT-CRAMT", "NOREJ-DRTRANS", "TOTREJ-DRAMT",
            "NOREJ-CRTRANS", "TOTREJ-CRAMT", "FILLER"};


        String[] ctlRec = new String[7];
        String[] tlRec = new String[13];
        String[] dtlRec;
        Map<String, String> dtlData128Pool;

        // 1st is control record to identify the number of error record and this is debit or credit transaction that host can know;
        while (inFile.hasNextLine()) {
            try {
                rdData = inFile.nextLine();

                if (rdData.substring(0, 1).equals("H")) { //control record
                    for (int i = 0; i <= ctlRec.length - 1; i++) {
                        try {
                            ctlData128Pool.put(ctlName[i], rdData.substring(ctlFmTo[i][0], ctlFmTo[i][1]));
                        } catch (IndexOutOfBoundsException ex) {
                            ctlData128Pool.put(ctlName[i], rdData.substring(ctlFmTo[i][0]));
                        }
                    }
                    ctlCount++;
                } else if (rdData.substring(0, 1).equals("D")) { //detail record
                    totRec128Pool++;
                    dtlRec = new String[10];
                    dtlData128Pool = new HashMap<String, String>();
                    for (int i = 0; i <= dtlRec.length - 1; i++) {

//                    if (lineCount >1510 ){
//                        System.out.println("LINE " + lineCount + " Data " + rdData);
//                        System.out.println("I >> " + i);
////                        System.out.println(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
//                    }

                        try {
                            dtlData128Pool.put(dtlName[i], rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                            if (i == 5) {
                                amtRec128Pool += Double.parseDouble(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                            }
                        } catch (IndexOutOfBoundsException ex) {
                            dtlData128Pool.put(dtlName[i], rdData.substring(dtlFmTo[i][0]));
                        }
                    }
                    resultDtl128Pool.add(dtlData128Pool);
                    dtlCount++;
                } else if (rdData.substring(0, 1).equals("T")) { //tail record
                    for (int i = 0; i <= tlRec.length - 1; i++) {
                        try {
                            tlData128Pool.put(tlName[i], rdData.substring(tlFmTo[i][0], tlFmTo[i][1]));
                        } catch (IndexOutOfBoundsException ex) {
                            tlData128Pool.put(tlName[i], rdData.substring(tlFmTo[i][0]));
                        }
                    }
                    tlCount++;
                }
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
                System.out.println(lineCount);
            }
//            System.out.println(rdData);

            lineCount++;
        }
    }
    
    public void ats128BPEAvalid(Scanner inFile) {
        String rdData;
//        String NL = System.getProperty("line.separator");
        Integer lineCount = 1;
        Integer ctlCount = 0;
        Integer dtlCount = 0;
        Integer tlCount = 0;

        Integer[][] ctlFmTo = new Integer[7][2];
        ctlFmTo[0][0] = 0;
        ctlFmTo[0][1] = 1;//rectype
        ctlFmTo[1][0] = 1;
        ctlFmTo[1][1] = 7;//seqno
        ctlFmTo[2][0] = 7;
        ctlFmTo[2][1] = 10;//bankcode
        ctlFmTo[3][0] = 10;
        ctlFmTo[3][1] = 20;//compno
        ctlFmTo[4][0] = 20;
        ctlFmTo[4][1] = 45;//compname
        ctlFmTo[5][0] = 45;
        ctlFmTo[5][1] = 51;//effdate
        ctlFmTo[6][0] = 51;
        ctlFmTo[6][1] = 128;//filler

        String[] ctlName = {"RECTYPE", "SEQNO", "BANKCODE", "COMPNO", "COMPNAME", "EFFDATE", "FILLER"};

        Integer[][] dtlFmTo = new Integer[10][2];
        dtlFmTo[0][0] = 0;
        dtlFmTo[0][1] = 1;//rectype
        dtlFmTo[1][0] = 1;
        dtlFmTo[1][1] = 7;//seqno
        dtlFmTo[2][0] = 7;
        dtlFmTo[2][1] = 10;//bankcode
        dtlFmTo[3][0] = 10;
        dtlFmTo[3][1] = 20;//accno
        dtlFmTo[4][0] = 20;
        dtlFmTo[4][1] = 21;//transcode
        dtlFmTo[5][0] = 21;
        dtlFmTo[5][1] = 32;//amount
        dtlFmTo[6][0] = 32;
        dtlFmTo[6][1] = 34;//servtype
        dtlFmTo[7][0] = 34;
        dtlFmTo[7][1] = 35;//status
        dtlFmTo[8][0] = 35;
        dtlFmTo[8][1] = 94;//refno
        dtlFmTo[9][0] = 94;
        dtlFmTo[9][1] = 128;//name

        String[] dtlName = {"RECTYPE", "SEQNO", "BANKCODE", "ACCNO", "TRANSCODE",
            "AMOUNT", "SERVTYPE", "STATUS", "REFNO", "NAME"};

        Integer[][] tlFmTo = new Integer[13][2];
        tlFmTo[0][0] = 0;
        tlFmTo[0][1] = 1;//rectype
        tlFmTo[1][0] = 1;
        tlFmTo[1][1] = 7;//seqno
        tlFmTo[2][0] = 7;
        tlFmTo[2][1] = 10;//bankcode
        tlFmTo[3][0] = 10;
        tlFmTo[3][1] = 20;//compno
        tlFmTo[4][0] = 20;
        tlFmTo[4][1] = 27;//nodrtrans
        tlFmTo[5][0] = 27;
        tlFmTo[5][1] = 40;//totdramt
        tlFmTo[6][0] = 40;
        tlFmTo[6][1] = 47;//nocrtrans
        tlFmTo[7][0] = 47;
        tlFmTo[7][1] = 60;//totcramt
        tlFmTo[8][0] = 60;
        tlFmTo[8][1] = 67;//norejdrtran
        tlFmTo[9][0] = 67;
        tlFmTo[9][1] = 80;//totrejdramt
        tlFmTo[10][0] = 80;
        tlFmTo[10][1] = 87;//norejcrtran
        tlFmTo[11][0] = 87;
        tlFmTo[11][1] = 100;//totrejcramt
        tlFmTo[12][0] = 100;
        tlFmTo[12][1] = 128;//filler

        String[] tlName = {"RECTYPE", "SEQNO", "BANKCODE", "COMPNO", "NO-DRTRANS",
            "TOT-DRAMT", "NO-CRTRANS", "TOT-CRAMT", "NOREJ-DRTRANS", "TOTREJ-DRAMT",
            "NOREJ-CRTRANS", "TOTREJ-CRAMT", "FILLER"};


        String[] ctlRec = new String[7];
        String[] tlRec = new String[13];
        String[] dtlRec;
        Map<String, String> dtlData128PEA;

        // 1st is control record to identify the number of error record and this is debit or credit transaction that host can know;
        while (inFile.hasNextLine()) {
            try {
                rdData = inFile.nextLine();

                if (rdData.substring(0, 1).equals("H")) { //control record
                    for (int i = 0; i <= ctlRec.length - 1; i++) {
                        try {
                            ctlData128PEA.put(ctlName[i], rdData.substring(ctlFmTo[i][0], ctlFmTo[i][1]));
                        } catch (IndexOutOfBoundsException ex) {
                            ctlData128PEA.put(ctlName[i], rdData.substring(ctlFmTo[i][0]));
                        }
                    }
                    ctlCount++;
                } else if (rdData.substring(0, 1).equals("D")) { //detail record
                    totRec128PEA++;
                    dtlRec = new String[10];
                    dtlData128PEA = new HashMap<String, String>();
                    for (int i = 0; i <= dtlRec.length - 1; i++) {

//                    if (lineCount >1510 ){
//                        System.out.println("LINE " + lineCount + " Data " + rdData);
//                        System.out.println("I >> " + i);
////                        System.out.println(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
//                    }

                        try {
                            dtlData128PEA.put(dtlName[i], rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                            if (i == 5) {
                                System.out.println("(ats128BPEAvalid) rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]): " + rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1])); 
                                System.out.println("(ats128BPEAvalid) Double.parseDouble(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1])): " + Double.parseDouble(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]))); 
                                amtRec128PEA += Double.parseDouble(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                            }
                        } catch (IndexOutOfBoundsException ex) {
                            dtlData128PEA.put(dtlName[i], rdData.substring(dtlFmTo[i][0]));
                        }
                    }
                    resultDtl128PEA.add(dtlData128PEA);
                    dtlCount++;
                } else if (rdData.substring(0, 1).equals("T")) { //tail record
                    for (int i = 0; i <= tlRec.length - 1; i++) {
                        try {
                            tlData128PEA.put(tlName[i], rdData.substring(tlFmTo[i][0], tlFmTo[i][1]));
                        } catch (IndexOutOfBoundsException ex) {
                            tlData128PEA.put(tlName[i], rdData.substring(tlFmTo[i][0]));
                        }
                    }
                    tlCount++;
                }
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
                System.out.println(lineCount);
            }
//            System.out.println(rdData);

            lineCount++;
        }
    }

    public void ats130BMEAvalid(Scanner inFile) {
        String rdData;
//        String NL = System.getProperty("line.separator");
        Integer lineCount = 1;
        Integer ctlCount = 0;
        Integer dtlCount = 0;
        Integer tlCount = 0;

        Integer[][] ctlFmTo = new Integer[7][2];
        ctlFmTo[0][0] = 0;
        ctlFmTo[0][1] = 1;//rectype
        ctlFmTo[1][0] = 1;
        ctlFmTo[1][1] = 7;//seqno
        ctlFmTo[2][0] = 7;
        ctlFmTo[2][1] = 10;//bankcode
        ctlFmTo[3][0] = 10;
        ctlFmTo[3][1] = 20;//compno
        ctlFmTo[4][0] = 20;
        ctlFmTo[4][1] = 45;//compname
        ctlFmTo[5][0] = 45;
        ctlFmTo[5][1] = 51;//effdate
        ctlFmTo[6][0] = 51;
        ctlFmTo[6][1] = 128;//filler

        String[] ctlName = {"RECTYPE", "SEQNO", "BANKCODE", "COMPNO", "COMPNAME", "EFFDATE", "FILLER"};

        Integer[][] dtlFmTo = new Integer[10][2];
        dtlFmTo[0][0] = 0;
        dtlFmTo[0][1] = 1;//rectype
        dtlFmTo[1][0] = 1;
        dtlFmTo[1][1] = 7;//seqno
        dtlFmTo[2][0] = 7;
        dtlFmTo[2][1] = 10;//bankcode
        dtlFmTo[3][0] = 10;
        dtlFmTo[3][1] = 20;//accno
        dtlFmTo[4][0] = 20;
        dtlFmTo[4][1] = 21;//transcode
        dtlFmTo[5][0] = 21;
        dtlFmTo[5][1] = 33;//amount
        dtlFmTo[6][0] = 33;
        dtlFmTo[6][1] = 35;//servtype
        dtlFmTo[7][0] = 35;
        dtlFmTo[7][1] = 36;//status
        dtlFmTo[8][0] = 36;
        dtlFmTo[8][1] = 95;//refno
        dtlFmTo[9][0] = 95;
        dtlFmTo[9][1] = 130;//name

        String[] dtlName = {"RECTYPE", "SEQNO", "BANKCODE", "ACCNO", "TRANSCODE",
            "AMOUNT", "SERVTYPE", "STATUS", "REFNO", "NAME"};

        Integer[][] tlFmTo = new Integer[13][2];
        tlFmTo[0][0] = 0;
        tlFmTo[0][1] = 1;//rectype
        tlFmTo[1][0] = 1;
        tlFmTo[1][1] = 7;//seqno
        tlFmTo[2][0] = 7;
        tlFmTo[2][1] = 10;//bankcode
        tlFmTo[3][0] = 10;
        tlFmTo[3][1] = 20;//compno
        tlFmTo[4][0] = 20;
        tlFmTo[4][1] = 27;//nodrtrans
        tlFmTo[5][0] = 27;
        tlFmTo[5][1] = 40;//totdramt
        tlFmTo[6][0] = 40;
        tlFmTo[6][1] = 47;//nocrtrans
        tlFmTo[7][0] = 47;
        tlFmTo[7][1] = 60;//totcramt
        tlFmTo[8][0] = 60;
        tlFmTo[8][1] = 67;//norejdrtran
        tlFmTo[9][0] = 67;
        tlFmTo[9][1] = 80;//totrejdramt
        tlFmTo[10][0] = 80;
        tlFmTo[10][1] = 87;//norejcrtran
        tlFmTo[11][0] = 87;
        tlFmTo[11][1] = 100;//totrejcramt
        tlFmTo[12][0] = 100;
        tlFmTo[12][1] = 128;//filler

        String[] tlName = {"RECTYPE", "SEQNO", "BANKCODE", "COMPNO", "NO-DRTRANS",
            "TOT-DRAMT", "NO-CRTRANS", "TOT-CRAMT", "NOREJ-DRTRANS", "TOTREJ-DRAMT",
            "NOREJ-CRTRANS", "TOTREJ-CRAMT", "FILLER"};

        
        String[] ctlRec = new String[7];
        String[] tlRec = new String[13];
        String[] dtlRec;
        Map<String, String> dtlData130MEA;

        // 1st is control record to identify the number of error record and this is debit or credit transaction that host can know;
        while (inFile.hasNextLine()) {
            try {
                rdData = inFile.nextLine();

                if (rdData.substring(0, 1).equals("H")) { //control record
                    for (int i = 0; i <= ctlRec.length - 1; i++) {
                        try {
                            ctlData130MEA.put(ctlName[i], rdData.substring(ctlFmTo[i][0], ctlFmTo[i][1]));
                        } catch (IndexOutOfBoundsException ex) {
                            ctlData130MEA.put(ctlName[i], rdData.substring(ctlFmTo[i][0]));
                        }
                    }
                    ctlCount++;
                } else if (rdData.substring(0, 1).equals("D")) { //detail record
                    totRec130MEA++;
                    dtlRec = new String[10];
                    dtlData130MEA = new HashMap<String, String>();
                    for (int i = 0; i <= dtlRec.length - 1; i++) {

//                    if (lineCount >1510 ){
//                        System.out.println("LINE " + lineCount + " Data " + rdData);
//                        System.out.println("I >> " + i);
////                        System.out.println(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
//                    }

                        try {
                            dtlData130MEA.put(dtlName[i], rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                            if (i == 5) {
                                amtRec130MEA += Double.parseDouble(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                            }
                        } catch (IndexOutOfBoundsException ex) {
                            dtlData130MEA.put(dtlName[i], rdData.substring(dtlFmTo[i][0]));
                        }
                    }
                    resultDtl130MEA.add(dtlData130MEA);
                    dtlCount++;
                } else if (rdData.substring(0, 1).equals("T")) { //tail record
                    for (int i = 0; i <= tlRec.length - 1; i++) {
                        try {
                            tlData130MEA.put(tlName[i], rdData.substring(tlFmTo[i][0], tlFmTo[i][1]));
                        } catch (IndexOutOfBoundsException ex) {
                            tlData130MEA.put(tlName[i], rdData.substring(tlFmTo[i][0]));
                        }
                    }
                    tlCount++;
                }
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
                System.out.println(lineCount);
            }
//            System.out.println(rdData);

            lineCount++;
        }
    }

    public void ats128B2TAvalid(Scanner inFile) {
        //ats file128b for format TA & TTnT
        String rdData;
//        String NL = System.getProperty("line.separator");
        Integer lineCount = 1;
        Integer ctlCount = 0;
        Integer dtlCount = 0;
        Integer tlCount = 0;

        Integer[][] ctlFmTo = new Integer[7][2];
        ctlFmTo[0][0] = 0;
        ctlFmTo[0][1] = 1;//rectype
        ctlFmTo[1][0] = 1;
        ctlFmTo[1][1] = 7;//seqno
        ctlFmTo[2][0] = 7;
        ctlFmTo[2][1] = 10;//bankcode
        ctlFmTo[3][0] = 10;
        ctlFmTo[3][1] = 20;//compno
        ctlFmTo[4][0] = 20;
        ctlFmTo[4][1] = 45;//compname
        ctlFmTo[5][0] = 45;
        ctlFmTo[5][1] = 51;//effdate
        ctlFmTo[6][0] = 51;
        ctlFmTo[6][1] = 128;//filler

        String[] ctlName = {"ATSBNK-RECTYPE-H", "ATSBNK-SEQNO-H", "ATSBNK-BANKCODE-H",
            "ATSBNK-COMPNO-H", "ATSBNK-COMPNAME-H", "ATSBNK-EFFDATE-H", "FILLER"};

        Integer[][] dtlFmTo = new Integer[13][2];
        dtlFmTo[0][0] = 0;
        dtlFmTo[0][1] = 1;//rectype
        dtlFmTo[1][0] = 1;
        dtlFmTo[1][1] = 7;//seqno
        dtlFmTo[2][0] = 7;
        dtlFmTo[2][1] = 10;//bankcode
        dtlFmTo[3][0] = 10;
        dtlFmTo[3][1] = 20;//accno
        dtlFmTo[4][0] = 20;
        dtlFmTo[4][1] = 21;//transcode
        dtlFmTo[5][0] = 21;
        dtlFmTo[5][1] = 31;//amount
        dtlFmTo[6][0] = 31;
        dtlFmTo[6][1] = 33;//servtype
        dtlFmTo[7][0] = 33;
        dtlFmTo[7][1] = 34;//status
        dtlFmTo[8][0] = 34;
        dtlFmTo[8][1] = 37;//area code
        dtlFmTo[9][0] = 37;
        dtlFmTo[9][1] = 44;//teleno
        dtlFmTo[10][0] = 44;
        dtlFmTo[10][1] = 50;//serv date
        dtlFmTo[11][0] = 50;
        dtlFmTo[11][1] = 93;//tot data
        dtlFmTo[12][0] = 93;
        dtlFmTo[12][1] = 128;//name

        String[] dtlName = {"ATSBNK-RECTYPE-D", "ATSBNK-SEQNO-D", "ATSBNK-BANKCODE-D",
            "ATSBNK-ACCNO-D", "ATSBNK-TRANSCODE-D", "ATSBNK-AMOUNT-D", "ATSBNK-SERVTYPE-D",
            "ATSBNK-STATUS-D", "ATSBNK-AREA-CODE", "ATSBNK-TELE-NO", "ATSBNK-SERV-DATE",
            "ATSBNK-TOT-DATA", "ATSBNK-NAME-D"};

        Integer[][] tlFmTo = new Integer[13][2];
        tlFmTo[0][0] = 0;
        tlFmTo[0][1] = 1;//rectype
        tlFmTo[1][0] = 1;
        tlFmTo[1][1] = 7;//seqno
        tlFmTo[2][0] = 7;
        tlFmTo[2][1] = 10;//bankcode
        tlFmTo[3][0] = 10;
        tlFmTo[3][1] = 20;//compno
        tlFmTo[4][0] = 20;
        tlFmTo[4][1] = 27;//nodrtrans
        tlFmTo[5][0] = 27;
        tlFmTo[5][1] = 40;//totdramt
        tlFmTo[6][0] = 40;
        tlFmTo[6][1] = 47;//nocrtrans
        tlFmTo[7][0] = 47;
        tlFmTo[7][1] = 60;//totcramt
        tlFmTo[8][0] = 60;
        tlFmTo[8][1] = 67;//norejdrtran
        tlFmTo[9][0] = 67;
        tlFmTo[9][1] = 80;//totrejdramt
        tlFmTo[10][0] = 80;
        tlFmTo[10][1] = 87;//norejcrtran
        tlFmTo[11][0] = 87;
        tlFmTo[11][1] = 100;//totrejcramt
        tlFmTo[12][0] = 100;
        tlFmTo[12][1] = 128;//filler

        String[] tlName = {"ATSBNK-RECTYPE-T", "ATSBNK-SEQNO-T", "ATSBNK-BANKCODE-T",
            "ATSBNK-COMPNO-T", "ATSBNK-NO-DRTRANS-T", "ATSBNK-TOT-DRAMT-T",
            "ATSBNK-NO-CRTRANS-T", "ATSBNK-TOT-CRAMT-T", "ATSBNK-NOREJ-DRTRANS-T",
            "ATSBNK-TOTREJ-DRAMT-T", "ATSBNK-NOREJ-CRTRANS-T", "ATSBNK-TOTREJ-CRAMT-T", "FILLER"};

        String[] ctlRec = new String[7];
        String[] tlRec = new String[13];
        String[] dtlRec;
        Map<String, String> dtlData128TA;

        // 1st is control record to identify the number of error record and this is debit or credit transaction that host can know;
        while (inFile.hasNextLine()) {
            rdData = inFile.nextLine();
            if (rdData.substring(0, 1).equals("H")) { //control record
                for (int i = 0; i <= ctlRec.length - 1; i++) {
                    try {
                        ctlData128TA.put(ctlName[i], rdData.substring(ctlFmTo[i][0], ctlFmTo[i][1]));
                    } catch (IndexOutOfBoundsException ex) {
                        ctlData128TA.put(ctlName[i], rdData.substring(ctlFmTo[i][0]));
                    }
                }
                ctlCount++;
            } else if (rdData.substring(0, 1).equals("D")) { //detail record
                totRec128TA++;
                dtlRec = new String[13];
                dtlData128TA = new HashMap<String, String>();
                for (int i = 0; i <= dtlRec.length - 1; i++) {
                    try {
                        dtlData128TA.put(dtlName[i], rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                        if (i == 5) {
                            amtRec128TA += Double.parseDouble(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                        }
                    } catch (IndexOutOfBoundsException ex) {
                        dtlData128TA.put(dtlName[i], rdData.substring(dtlFmTo[i][0]));
                    }
                }
                resultDtl128TA.add(dtlData128TA);
                dtlCount++;
            } else if (rdData.substring(0, 1).equals("T")) { //tail record
                for (int i = 0; i <= tlRec.length - 1; i++) {
                    try {
                        tlData128TA.put(tlName[i], rdData.substring(tlFmTo[i][0], tlFmTo[i][1]));
                    } catch (IndexOutOfBoundsException ex) {
                        tlData128TA.put(tlName[i], rdData.substring(tlFmTo[i][0]));
                    }
                }
                tlCount++;
            }
//            System.out.println(rdData);
            lineCount++;
        }
    }

    public void ats128B2TOTvalid(Scanner inFile) {
        //ats file128b for format TOT
        String rdData;
//        String NL = System.getProperty("line.separator");
        Integer lineCount = 1;
        Integer ctlCount = 0;
        Integer dtlCount = 0;
        Integer tlCount = 0;

        Integer[][] ctlFmTo = new Integer[8][2];
        ctlFmTo[0][0] = 0;
        ctlFmTo[0][1] = 1;//rectype
        ctlFmTo[1][0] = 1;
        ctlFmTo[1][1] = 7;//seqno
        ctlFmTo[2][0] = 7;
        ctlFmTo[2][1] = 10;//bankcode
        ctlFmTo[3][0] = 10;
        ctlFmTo[3][1] = 20;//compno
        ctlFmTo[4][0] = 20;
        ctlFmTo[4][1] = 45;//compname
        ctlFmTo[5][0] = 45;
        ctlFmTo[5][1] = 51;//effdate
        ctlFmTo[6][0] = 51;
        ctlFmTo[6][1] = 118;//filler
        ctlFmTo[7][0] = 118;
        ctlFmTo[7][1] = 128;//compno

        String[] ctlName = {"ATSBNK-RECTYPE-H", "ATSBNK-SEQNO-H", "ATSBNK-BANKCODE-H",
            "FILLER", "ATSBNK-COMPNAME-H", "ATSBNK-EFFDATE-H", "FILLER", "ATSBNK-COMPNO-H"};

        Integer[][] dtlFmTo = new Integer[16][2];
        dtlFmTo[0][0] = 0;
        dtlFmTo[0][1] = 1;//rectype
        dtlFmTo[1][0] = 1;
        dtlFmTo[1][1] = 7;//seqno
        dtlFmTo[2][0] = 7;
        dtlFmTo[2][1] = 10;//bankcode
        dtlFmTo[3][0] = 10;
        dtlFmTo[3][1] = 13;//BRno
        dtlFmTo[4][0] = 13;
        dtlFmTo[4][1] = 20;//accno
        dtlFmTo[5][0] = 20;
        dtlFmTo[5][1] = 21;//transcode
        dtlFmTo[6][0] = 21;
        dtlFmTo[6][1] = 31;//amount
        dtlFmTo[7][0] = 31;
        dtlFmTo[7][1] = 33;//servtype
        dtlFmTo[8][0] = 33;
        dtlFmTo[8][1] = 34;//status
        dtlFmTo[9][0] = 34;
        dtlFmTo[9][1] = 37;//area code
        dtlFmTo[10][0] = 37;
        dtlFmTo[10][1] = 44;//teleno
        dtlFmTo[11][0] = 44;
        dtlFmTo[11][1] = 50;//serv date
        dtlFmTo[12][0] = 50;
        dtlFmTo[12][1] = 80;//tot data
        dtlFmTo[13][0] = 80;
        dtlFmTo[13][1] = 83;//brno beta
        dtlFmTo[14][0] = 83;
        dtlFmTo[14][1] = 93;//accno
        dtlFmTo[15][0] = 93;
        dtlFmTo[15][1] = 128;//name

        String[] dtlName = {"ATSBNK-RECTYPE-D", "ATSBNK-SEQNO-D", "ATSBNK-BANKCODE-D",
            "ATSBNK-BRNO-D", "ATSBNK-FILLER-D", "ATSBNK-TRANSCODE-D", "ATSBNK-AMOUNT-D",
            "ATSBNK-SERVTYPE-D", "ATSBNK-STATUS-D", "ATSBNK-AREA-CODE", "ATSBNK-TELE-NO",
            "ATSBNK-SERV-DATE", "ATSBNK-TOT-DATA", "ATSBNK-BRNO-BETAS", "ATSBNK-ACCNO-D", "ATSBNK-NAME-D"};

        Integer[][] tlFmTo = new Integer[13][2];
        tlFmTo[0][0] = 0;
        tlFmTo[0][1] = 1;//rectype
        tlFmTo[1][0] = 1;
        tlFmTo[1][1] = 7;//seqno
        tlFmTo[2][0] = 7;
        tlFmTo[2][1] = 10;//bankcode
        tlFmTo[3][0] = 10;
        tlFmTo[3][1] = 20;//compno
        tlFmTo[4][0] = 20;
        tlFmTo[4][1] = 27;//nodrtrans
        tlFmTo[5][0] = 27;
        tlFmTo[5][1] = 40;//totdramt
        tlFmTo[6][0] = 40;
        tlFmTo[6][1] = 47;//nocrtrans
        tlFmTo[7][0] = 47;
        tlFmTo[7][1] = 60;//totcramt
        tlFmTo[8][0] = 60;
        tlFmTo[8][1] = 67;//norejdrtran
        tlFmTo[9][0] = 67;
        tlFmTo[9][1] = 80;//totrejdramt
        tlFmTo[10][0] = 80;
        tlFmTo[10][1] = 87;//norejcrtran
        tlFmTo[11][0] = 87;
        tlFmTo[11][1] = 100;//totrejcramt
        tlFmTo[12][0] = 100;
        tlFmTo[12][1] = 128;//filler

        String[] tlName = {"ATSBNK-RECTYPE-T", "ATSBNK-SEQNO-T", "ATSBNK-BANKCODE-T",
            "ATSBNK-COMPNO-T", "ATSBNK-NO-DRTRANS-T", "ATSBNK-TOT-DRAMT-T", "ATSBNK-NO-CRTRANS-T",
            "ATSBNK-TOT-CRAMT-T", "ATSBNK-NOREJ-DRTRANS-T", "ATSBNK-TOTREJ-DRAMT-T",
            "ATSBNK-NOREJ-CRTRANS-T", "ATSBNK-TOTREJ-CRAMT-T", "FILLER"};

        String[] ctlRec = new String[8];
        String[] tlRec = new String[13];
        String[] dtlRec;
        Map<String, String> dtlData128TOT;

        // 1st is control record to identify the number of error record and this is debit or credit transaction that host can know;
        while (inFile.hasNextLine()) {
            rdData = inFile.nextLine();
            if (rdData.substring(0, 1).equals("H")) { //control record
                for (int i = 0; i <= ctlRec.length - 1; i++) {
                    try {
                        ctlData128TOT.put(ctlName[i], rdData.substring(ctlFmTo[i][0], ctlFmTo[i][1]));
                    } catch (IndexOutOfBoundsException ex) {
                        ctlData128TOT.put(ctlName[i], rdData.substring(ctlFmTo[i][0]));
                    }
                }
                ctlCount++;
            } else if (rdData.substring(0, 1).equals("D")) { //detail record
                totRec128TOT++;
                dtlRec = new String[16];
                dtlData128TOT = new HashMap<String, String>();
                for (int i = 0; i <= dtlRec.length - 1; i++) {
                    try {
                        dtlData128TOT.put(dtlName[i], rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                        if (i == 6) {

                            amtRec128TOT += Double.parseDouble(rdData.substring(dtlFmTo[i][0], dtlFmTo[i][1]));
                        }
                    } catch (IndexOutOfBoundsException ex) {
                        dtlData128TOT.put(dtlName[i], rdData.substring(dtlFmTo[i][0]));
                    }
                }
                resultDtl128TOT.add(dtlData128TOT);
                dtlCount++;
            } else if (rdData.substring(0, 1).equals("T")) { //tail record
                for (int i = 0; i <= tlRec.length - 1; i++) {
                    try {
                        tlData128TOT.put(tlName[i], rdData.substring(tlFmTo[i][0], tlFmTo[i][1]));
                    } catch (IndexOutOfBoundsException ex) {
                        tlData128TOT.put(tlName[i], rdData.substring(tlFmTo[i][0]));
                    }
                }
                tlCount++;
            }
            lineCount++;
        }
    }
}
