/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.scb.pss.atstxn.control;

import com.scb.pss.atstxn.service.txnService;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author s37976
 */
public class HashFormat {

    public String FileCompcode = "";
    public int FileTxn = 0;
    public long FileAmt = 0;
    public int FileTxnInv = 0;
    public long FileAmtInv = 0;
    public int FileTxnRead = 0;
    public long FileAmtRead = 0;
    public String FileEffDate = "";
    public String ErrorCd = "";
    public String ErrorDesc = "";
    public String FileAppCode = "";
    public String compHelpFg = "";
    public String compHelpApp = "";
    public Map<String, String> appCodeMap = null;
    public Map<String, String> mediaTypeMap = null;
    public boolean overOneThousandMillion = false;

    public HashFormat() {
        txnService txnSv = new txnService();
        appCodeMap = txnSv.getAppCode();
        mediaTypeMap = txnSv.getSysParamByGp("MDTYPE");

    }

    public boolean validFormat80B10M(BufferedReader br, boolean validSameDte) throws IOException {
//public boolean validFormat80B10M(RemoveBlankLine br,boolean validSameDte) throws IOException {
        String strLine = null;
        int numLine = 1;
        String strEffDate = "";
        String dcType = "";
//        System.out.println(compHelpFg + ">>>"+compHelpApp);
        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                if (numLine >= 2) {
                    strLine = strLine.trim();
                    if (strLine.length() != 0) {
                        if (strLine.length() > 80) {
                            ErrorCd = "10";
                            ErrorDesc = "File Detail Record Length > 80";
                            return false;
                        } // Check Detail Length
                        if (isNumber(strLine.substring(0, 10)) == false) {

                            ErrorDesc = "Line " + strLine + " : Account " + strLine.substring(0, 10) + " is not A Number";
//                            System.out.println(ErrorDesc);
                            return false;
                        } // Check Account No

                        if (strEffDate.equalsIgnoreCase(strLine.substring(10, 16)) == false) {
                            if (validSameDte) {
                                ErrorCd = "07";
                                ErrorDesc = "Line " + strLine + " : Wrong Effective Date ";
                                return false;
                            } else {
                                if (isValidDate(strLine.substring(10, 16)) == false) {
                                    // data is not a date
                                    ErrorCd = "21";
                                    ErrorDesc = " Date is not in calendar ";
                                    return false;
                                } // Check EffDate
                            }
                        } // Check EffDate
                        if (Integer.valueOf(strLine.substring(14, 16)) > 50) {
                            ErrorCd = "05";
                            ErrorDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.  ";
                            return false;
                        } // Check EffDate

                        if (!strLine.substring(16, 17).equals(dcType)) {
                            ErrorCd = "22";
                            return false;
                        } // Check Sign


//                        if (!strLine.substring(69,70 ).equals(dcType) ) {
//                            ErrorCd="22";
//                            return false;
//                        } // Check Sign
                        if (isNumber(strLine.substring(17, 26)) == false) {
                            ErrorCd = "13";
                            ErrorDesc = "Line " + strLine + " : Amount " + strLine.substring(17, 26) + " is not A Number";
                            return false;
                        } else {
                            if (Double.valueOf(strLine.substring(17, 26)) == 0) {
                                ErrorCd = "14";
                                return false;
                            }
                        }// Check Amount
                        numLine++;
                    }
                } else if (numLine == 1) {
                    //100M
//                    String termType = strLine.substring(8, 9);
//                    if (!((termType.equalsIgnoreCase("M")) || (termType.equalsIgnoreCase("H")) || (termType.equalsIgnoreCase("W")))) {
//                        ErrorDesc = "File Term Type " + termType + " is Wrong ";
//                        return false;
//                    }
                    //Invalid File Format : Term Payment M/H/W Only

                    String termType = strLine.substring(9, 10);
                    if (!((termType.equalsIgnoreCase("M")) || (termType.equalsIgnoreCase("H")) || (termType.equalsIgnoreCase("W")))) {

//                        if (strLine.substring(8,9).equalsIgnoreCase("M"))

                        ErrorDesc = "File Term Type " + termType + " is Wrong ";
                        return false;

                    }
                    //Invalid File Format : Check Compcode
                    if (isNumber(strLine.substring(10, 16)) == false) {
                        ErrorDesc = "Comp Code " + strLine.substring(10, 16) + " is Not a Number ";
                        return false;
                    }

                    //V 2012-09-21
                    if (isThai(strLine)) {
//                        ErrorDesc = "Control record has thai character: "+strLine;
                        ErrorDesc = "ไม่สามารถส่งข้อมูลได้เนื่องจากชื่อบริษัทเป็นภาษาไทย";
                        return false;
                    }

                    String AppCode = strLine.substring(46, 47);
                    if (compHelpFg.equals("B")) {
                        FileAppCode = compHelpApp;
                    } else {
                        FileAppCode = AppCode;
                    }
//                    if (!((AppCode.equalsIgnoreCase("D"))
//                            || (AppCode.equalsIgnoreCase("B"))
//                            || (AppCode.equalsIgnoreCase("S"))
//                            || (AppCode.equalsIgnoreCase("1"))
//                            || (AppCode.equalsIgnoreCase("W"))
//                            || (AppCode.equalsIgnoreCase("4"))
//                            || (AppCode.equalsIgnoreCase("I"))
//                            || (AppCode.equalsIgnoreCase("Z"))
//                            || (AppCode.equalsIgnoreCase("G"))
//                            || (AppCode.equalsIgnoreCase("T"))
//                            || (AppCode.equalsIgnoreCase("6"))
//                            || (AppCode.equalsIgnoreCase("P"))
//                            || (AppCode.equalsIgnoreCase("C"))
//                            || (AppCode.equalsIgnoreCase("X"))
//                            || (AppCode.equalsIgnoreCase("E"))
//                            || (AppCode.equalsIgnoreCase("0")))) {
//                        ErrorDesc = "File App Code " + AppCode + " is Wrong ";
//                        return false;
//                    }
                    if (appCodeMap.get(FileAppCode) == null) {
                        ErrorDesc = "File App Code " + AppCode + " is Wrong ";
                        return false;
                    } else {
                        if (appCodeMap.get(FileAppCode).equals("C")) {
                            dcType = "0";
                        } else if (appCodeMap.get(FileAppCode).equals("D")) {
                            dcType = "1";
                        } else {
                            ErrorDesc = "Debit/Credit type is invalid";
                            return false;
                        }
                    }

                    if (strLine.substring(47, 48).equalsIgnoreCase("A") == false) {
                        ErrorDesc = "File Status " + strLine.substring(47, 48) + " is not Equal A ";
                        return false;
                    } // Invalid File Format : Status != A
                    if (isNumber(strLine.substring(48, 54)) == false) {
                        ErrorCd = "08";
                        ErrorDesc = " ข้อมูลวันที่ไม่ถูกต้อง ";
                        return false;
                    } //Eff date
                    if (isNumber(strLine.substring(54, 59)) == false) {
                        ErrorDesc = "File Transaction Number is Not a Number ";
                        return false;
                    } // Check File Txn
                    if (isNumber(strLine.substring(59, 69)) == false) {
                        ErrorDesc = "File Amount is Not a Number ";
                        return false;
                    } // Check File Amt

                    if (mediaTypeMap.get(strLine.substring(69, 70)).equals(null)) {
                        ErrorDesc = "ไม่สามารถส่งข้อมูลได้ เนื่องจาก Media type ไม่มี";
//                            ErrorDesc = "Media type of control record is mismatch [column:70]";
                        return false;
                    }

                    strEffDate = strLine.substring(48, 54);
                    FileEffDate = strLine.substring(48, 54);

                    if (Integer.valueOf(strLine.substring(52, 54)) > 50) {
                        ErrorCd = "05";
                        ErrorDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.  ";
                        return false;
                    } // Check EffDate


                    if (isValidDate(strLine.substring(48, 54)) == false) {
                        // data is not a date
                        ErrorCd = "21";
                        ErrorDesc = " Date is not in calendar ";
                        return false;
                    } // Check EffDate


                    numLine++;
                } else {
                    System.out.println("Class HashFormat Method genHashF80B_10M(Error): File is not Data");
                }
            }
            br.close();
//            System.out.println("Close br validFormat80 \n");

        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            System.out.println(ex.getMessage());
            br.close();
            return false;
//            System.out.println("Close br validFormat80 exception \n");
        } catch (Exception ex) {
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            System.out.println(ex.getMessage());
            return false;
        } finally {
            br.close();
//            System.out.println("Close br validFormat80 finally \n");
        }

        return true;
    }

    public boolean validFormat80B100M(BufferedReader br, boolean validSameDte) throws IOException {
//public boolean validFormat80B100M(RemoveBlankLine br,boolean validSameDte) throws IOException {
//        System.out.println(compHelpFg + ">>>"+compHelpApp);
        String strLine = null;
        int numLine = 1;
        String strEffDate = "";
        String dcType = "";
        String lastLineData = "";
        try {
            //Read File Line By Line

            while ((strLine = br.readLine()) != null) {

                if (numLine >= 2) {
                    strLine = strLine.trim();
                    if (strLine.length() != 0) {
                        if (strLine.length() > 80) {
                            ErrorCd = "10";
                            ErrorDesc = "File Detail Record Length > 80";
                            return false;
                        } // Check Detail Length
                        if (isNumber(strLine.substring(0, 10)) == false) {

                            ErrorDesc = "Line " + strLine + " : Account " + strLine.substring(0, 10) + " is not A Number";
//                             System.out.println(ErrorDesc);
                            return false;
                        } // Check Account No
                        if (strEffDate.equalsIgnoreCase(strLine.substring(10, 16)) == false) {
                            if (validSameDte) {
                                ErrorCd = "07";
                                ErrorDesc = "Line " + strLine + " : Wrong Effective Date ";
                                return false;
                            } else {
                                if (isValidDate(strLine.substring(10, 16)) == false) {
                                    // data is not a date
                                    ErrorCd = "21";
                                    ErrorDesc = " Date is not in calendar ";
                                    return false;
                                } // Check EffDate
                            }
                        } // Check EffDate
                        if (Integer.valueOf(strLine.substring(14, 16)) >= 50) {
                            ErrorCd = "05";
                            ErrorDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.  ";
                            return false;
                        } // Check EffDate
                        if (!strLine.substring(16, 17).equals(dcType)) {
                            ErrorCd = "22";
                            return false;
                        } // Check Sign
                        if (isNumber(strLine.substring(17, 28)) == false) {
                            ErrorCd = "13";
                            ErrorDesc = "Line " + strLine + " : Amount " + strLine.substring(17, 28) + " is not A Number";
                            return false;
                        } else {
                            if (Double.valueOf(strLine.substring(17, 28)) == 0) {
                                ErrorCd = "14";
                                return false;
                            }
                        } // Check Amount
                        numLine++;
                    }

                } else if (numLine == 1) {
                    //Invalid File Format : Term Payment M/H/W Only
                    String termType = strLine.substring(8, 9);
                    if (!((termType.equalsIgnoreCase("M")) || (termType.equalsIgnoreCase("H")) || (termType.equalsIgnoreCase("W")))) {
                        ErrorDesc = "File Term Type " + termType + " is Wrong ";
                        return false;
                    }
                    if (isNumber(strLine.substring(9, 15)) == false) {
                        ErrorDesc = "Comp Code " + strLine.substring(9, 15) + " is Not a Number ";
                        return false;
                    } //Invalid File Format : Check Compcode
                    //V 2012-09-21
                    if (isThai(strLine)) {
                        ErrorDesc = "Control record has thai character: " + strLine;
                        ErrorDesc = "ไม่สามารถส่งข้อมูลได้เนื่องจากชื่อบริษัทเป็นภาษาไทย";
                        return false;
                    }

                    //Invalid File Format : Check Compcode
                    String AppCode = strLine.substring(45, 46);
//                    FileAppCode = AppCode;
                    if (compHelpFg.equals("B")) {
                        FileAppCode = compHelpApp;
                    } else {
                        FileAppCode = AppCode;
                    }

                    if (appCodeMap.get(FileAppCode) == null) {
                        ErrorDesc = "File App Code " + AppCode + " is Wrong ";
                        return false;
                    } else {
                        if (appCodeMap.get(FileAppCode).equals("C")) {
                            dcType = "0";
                        } else if (appCodeMap.get(FileAppCode).equals("D")) {
                            dcType = "1";
                        } else {
                            ErrorDesc = "Debit/Credit type is invalid";
                            return false;
                        }
                    }
                    if (strLine.substring(46, 47).equalsIgnoreCase("A") == false) {
                        ErrorDesc = "File Status " + strLine.substring(46, 47) + " is not Equal A ";
                        return false;
                    } // Invalid File Format : Status != A
                    if (isNumber(strLine.substring(47, 53)) == false) {
                        ErrorCd = "08";
                        ErrorDesc = " ข้อมูลวันที่ไม่ถูกต้อง ";
                        return false;
                    } //Eff date
                    if (isNumber(strLine.substring(53, 58)) == false) {
                        ErrorDesc = "File Transaction Number is Not a Number ";
                        return false;
                    } // Check File Txn

                    if (isNumber(strLine.substring(58, 69)) == false) {
                        ErrorDesc = "File Amount is Not a Number ";
                        return false;
                    } // Check File Amt

                    //V 2012-09-21
                    if (mediaTypeMap.get(strLine.substring(69, 70)).equals(null)) {
//                            ErrorDesc = "Media type of control record is mismatch [column:70]";
                        ErrorDesc = "ไม่สามารถส่งข้อมูลได้ เนื่องจาก Media type ไม่มี";
                        return false;
                    }

                    strEffDate = strLine.substring(47, 53);
                    FileEffDate = strLine.substring(47, 53);
                    if (Integer.valueOf(strLine.substring(51, 53)) > 50) {
                        ErrorCd = "05";
                        ErrorDesc = " ข้อมูลวันที่โอนเงินเป็นปี พ.ศ. ";
                        return false;
                    }

                    if (isValidDate(strLine.substring(47, 53)) == false) {
                        // data is not a date
                        ErrorCd = "21";
                        ErrorDesc = " Date is not in calendar ";
                        return false;

                    } // Check EffDate

                    numLine++;
                } else {
                    System.out.println("Class HashFormat Method genHashF80B_10M(Error): File is not Data");
                }
            }
            br.close();

//            System.out.println("Close br validFormat80B100M \n");
        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            br.close();
            return false;
//            System.out.println("Close br validFormat80 exception \n");
        } catch (Exception ex) {
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
        } finally {
            br.close();
//            System.out.println("Close br validFormat80B100M finally \n");
        }

        return true;
    }

    public boolean validFormat128BTOT(BufferedReader br, boolean validSameDte) throws IOException {
//public boolean validFormat128BTOT(RemoveBlankLine br,boolean validSameDte) throws IOException {
        String strLine = null;
        int numLine = 1;
        String strEffDate = "";

        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
//                System.out.println(numLine);
                if (numLine >= 2) { // Detail Section
                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D

                        if (strLine.length() > 128) {

                            ErrorCd = "10";
                            ErrorDesc = "File Detail Record Length > 128";
                            return false;
                        } // Check Detail Length = 128

                        if (isNumber(strLine.substring(1, 7)) == false) {
                            ErrorDesc = "Line " + strLine + " : Wrong Sequence";
                            return false;
                        } // Check SEQNO

                        if (isNumber(strLine.substring(7, 10)) == false) {
                            ErrorDesc = "Line " + strLine + " : Wrong BankCode";
                            return false;
                        } // Check BANKCODE

                        if (isNumber(strLine.substring(21, 31)) == false) {
                            ErrorDesc = "Line " + strLine + " : Amount " + strLine.substring(21, 31) + " is not A Number";
                            return false;
                        } else {

                            if (Double.valueOf(strLine.substring(21, 31)) == 0) {
                                ErrorCd = "14";
                                return false;
                            }
                        } // Check Amount

                        if (isNumber(strLine.substring(31, 33)) == false) {
                            ErrorDesc = "Line " + strLine + " : ServType " + strLine.substring(31, 33) + " is not A Number";
                            return false;
                        } // Check ServType

                        if (isNumber(strLine.substring(83, 93)) == false) {
                            ErrorCd = "13";
                            ErrorDesc = "Line " + strLine + " : Account " + strLine.substring(83, 93) + " is not A Number";
                            return false;
                        } // Check AccountNo

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        if (strLine.length() > 128) {
                            ErrorCd = "10";
                            ErrorDesc = "File Tail Record Length > 128";
                            return false;
                        } // Check Tail Length <= 128
//                        if (isNumber(strLine.substring(1, 7)) == false) {
//                            ErrorDesc = "Line " + strLine + " : Wrong Sequence";
//                            return false;
//                        } // Check SEQNO
//                        if (isNumber(strLine.substring(7, 10)) == false) {
//                            ErrorDesc = "Line " + strLine + " : Wrong BankCode";
//                            return false;
//                        } // Check BANKCODE
//                        if (isNumber(strLine.substring(10, 20)) == false) {
//                            return false;
//                        } // Check CompNo
//
//                        if (isNumber(strLine.substring(20, 27)) == false) {
//                            return false;
//                        } // Check Total Txn
//                        if (isNumber(strLine.substring(27, 40)) == false) {
//                            return false;
//                        } // Check Total Amt
//                        if (isNumber(strLine.substring(40, 47)) == false) {
//                            return false;
//                        } // Check Total Txn
//                        if (isNumber(strLine.substring(47, 60)) == false) {
//                            return false;
//                        } // Check Total Amt

                    } else {
                        return false;
                    }

                    numLine++;

                } else if (numLine == 1) { // Header Section
                    if (strLine.length() > 128) {
                        ErrorCd = "10";
                        ErrorDesc = "File Header Record Length > 128";
                        return false;
                    } // Check Header Length <= 128
                    if (strLine.substring(0, 1).equalsIgnoreCase("H") == false) {
                        ErrorDesc = "Line " + strLine + " : Header is not equal H";
                        return false;
                    } // Check RECTYPE = H
                    if (strLine.substring(1, 7).equalsIgnoreCase("000001") == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Sequence";
                        return false;
                    } // Check SEQNO
                    if (isNumber(strLine.substring(7, 10)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong BankCode";
                        return false;
                    } // Check BANKCODE
                    if (isNumber(strLine.substring(45, 51)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Effective Date";
                        return false;
                    } // Check Effdate + Valid Date in Calendar
//                    if (isNumber(strLine.substring(118, 128)) == false){ return false; } // Check CompCode
                    FileEffDate = strLine.substring(45, 51);
                    if (Integer.valueOf(strLine.substring(49, 51)) >= 50) {
                        ErrorCd = "05";
                        ErrorDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.  ";
                        return false;
                    }
                    if (isValidDate(strLine.substring(45, 51)) == false) {
                        // data is not a date
                        ErrorCd = "21";
                        ErrorDesc = " Date is not in calendar ";
                        return false;
                    } // Check EffDate
                    numLine++;

                } else {
                    System.out.println("Class HashFormat Method genHashF80B_10M(Error): File is not Data");

                }
            }
            br.close();
//            System.out.println("END OF FILE");
//            System.out.println("Close br validFormat128BTOT \n");

        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";

            System.out.println(ex.getMessage());
            br.close();
            return false;
//            System.out.println("Close br validFormat80 exception \n");
        } catch (Exception ex) {
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            System.out.println(ex.getMessage());
            return false;
        } finally {
            br.close();
//            System.out.println("Close br validFormat128BTOT \n");
        }

        return true;
    }

    public boolean validFormat128BTT(BufferedReader br, boolean validSameDte) throws IOException {
//public boolean validFormat128BTT(RemoveBlankLine br,boolean validSameDte) throws IOException {
        String strLine = null;
        int numLine = 1;
        String strEffDate = "";

        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                if (numLine >= 2) { // Detail Section
                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D
                        if (strLine.length() > 128) {
                            ErrorCd = "10";
                            ErrorDesc = "File Detail Record Length > 128";
                            return false;
                        } // Check Detail Length = 128
                        if (isNumber(strLine.substring(1, 7)) == false) {
                            ErrorDesc = "Line " + strLine + " : Wrong Sequence";
                            return false;
                        } // Check SEQNO
                        if (isNumber(strLine.substring(7, 10)) == false) {
                            ErrorDesc = "Line " + strLine + " : Wrong BankCode";
                            return false;
                        } // Check BANKCODE
                        if (isNumber(strLine.substring(10, 20)) == false) {
                            ErrorCd = "13";
                            ErrorDesc = "Line " + strLine + " : Account " + strLine.substring(10, 20) + " is not A Number";
                            return false;
                        } // Check AccountNo
                        if (isNumber(strLine.substring(21, 31)) == false) {
                            ErrorDesc = "Line " + strLine + " : Amount " + strLine.substring(21, 31) + " is not A Number";
                            return false;
                        } else {
                            if (Double.valueOf(strLine.substring(21, 31)) == 0) {
                                ErrorCd = "14";
                                return false;
                            }
                        } // Check Amount
                        if (isNumber(strLine.substring(31, 33)) == false) {
                            ErrorDesc = "Line " + strLine + " : ServType " + strLine.substring(31, 33) + " is not A Number";
                            return false;
                        } // Check ServType

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        if (strLine.length() > 128) {
                            ErrorCd = "10";
                            ErrorDesc = "File Tail Record Length > 128";
                            return false;
                        } // Check Tail Length <= 128
//                        if (isNumber(strLine.substring(1, 7)) == false) {
//                            ErrorDesc = "Line " + strLine + " : Wrong Sequence";
//                            return false;
//                        } // Check SEQNO
//                        if (isNumber(strLine.substring(7, 10)) == false) {
//                            ErrorDesc = "Line " + strLine + " : Wrong BankCode";
//                            return false;
//                        } // Check BANKCODE
//                        if (isNumber(strLine.substring(10, 20)) == false) {
//                            return false;
//                        } // Check CompNo
//
//                        if (isNumber(strLine.substring(20, 27)) == false) {
//                            return false;
//                        } // Check Total Txn
//                        if (isNumber(strLine.substring(27, 40)) == false) {
//                            return false;
//                        } // Check Total Amt
//                        if (isNumber(strLine.substring(40, 47)) == false) {
//                            return false;
//                        } // Check Total Txn
//                        if (isNumber(strLine.substring(47, 60)) == false) {
//                            return false;
//                        } // Check Total Amt

                    } else {
                        return false;
                    }

                    numLine++;

                } else if (numLine == 1) { // Header Section
                    if (strLine.length() > 128) {
                        ErrorCd = "10";
                        ErrorDesc = "File Header Record Length > 128";
                        return false;
                    } // Check Header Length <= 128
                    if (strLine.substring(0, 1).equalsIgnoreCase("H") == false) {
                        ErrorDesc = "Line " + strLine + " : Header is not equal H";
                        return false;
                    } // Check RECTYPE = H
                    if (strLine.substring(1, 7).equalsIgnoreCase("000001") == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Sequence";
                        return false;
                    } // Check SEQNO
                    if (isNumber(strLine.substring(7, 10)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong BankCode";
                        return false;
                    } // Check BANKCODE
//                    if (isNumber(strLine.substring(10, 20)) == false){ return false; } // Check CompNo
                    if (isNumber(strLine.substring(45, 51)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Effective Date";
                        return false;
                    } // Check Effdate + Valid Date in Calendar

                    FileEffDate = strLine.substring(45, 51);
                    if (Integer.valueOf(strLine.substring(49, 51)) >= 50) {
                        ErrorCd = "05";
                        ErrorDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.  ";
                        return false;
                    }

                    if (isValidDate(strLine.substring(45, 51)) == false) {
                        // data is not a date
                        ErrorCd = "21";
                        ErrorDesc = " Date is not in calendar ";
                        return false;
                    } // Check EffDate

                    numLine++;

                } else {
                    System.out.println("Class HashFormat Method genHashF80B_10M(Error): File is not Data");

                }

            }
            br.close();

//            System.out.println("Close br validFormat128BTT \n");

        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
//            System.out.println("Close br validFormat80 exception \n");
        } catch (Exception ex) {
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
        } finally {
            br.close();
//            System.out.println("Close br validFormat128BTT finally \n");
        }

        return true;
    }

    public boolean validFormat128BPOOL(BufferedReader br, boolean validSameDte) throws IOException {
//public boolean validFormat128BPOOL(RemoveBlankLine br,boolean validSameDte) throws IOException {
        String strLine = null;
        int numLine = 1;
        String strEffDate = "";
        int endline;

        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {

                if (numLine >= 2) { // Detail Section and Tail Section

                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D
                        if (strLine.length() > 128) {
                            ErrorCd = "10";
                            System.out.println(numLine);
                            ErrorDesc = "File Detail Record Length > 128";
                            return false;
                        } // Check Detail Length = 128
                        if (isNumber(strLine.substring(1, 7)) == false) {
                            ErrorDesc = "Line " + numLine + " : Wrong Sequence";
                            return false;
                        } // Check SEQNO
                        if (isNumber(strLine.substring(7, 10)) == false) {
                            ErrorDesc = "Line " + numLine + " : Wrong BankCode";
                            return false;
                        } // Check BANKCODE
                        if (isNumber(strLine.substring(10, 20)) == false) {
                            ErrorCd = "13";
                            ErrorDesc = "Line " + numLine + " : Account " + strLine.substring(10, 20) + " is not A Number";
                            return false;
                        } // Check AccountNo
                        if (isNumber(strLine.substring(21, 31)) == false) {
                            ErrorDesc = "Line " + numLine + " : Amount " + strLine.substring(21, 31) + " is not A Number";
                            return false;
                        } else {
                            if (Double.valueOf(strLine.substring(21, 31)) == 0) {
                                ErrorCd = "14";
                                return false;
                            }
                        } // Check Amount
                        if (isNumber(strLine.substring(31, 33)) == false) {
                            ErrorDesc = "Line " + numLine + " : ServType " + strLine.substring(31, 33) + " is not A Number";
                            return false;
                        } // Check ServType

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        if (strLine.length() > 128) {
                            ErrorCd = "10";
                            ErrorDesc = "File Tail Record Length > 128";
                            return false;
                        } // Check Tail Length <= 128
//                        if (isNumber(strLine.substring(1, 7)) == false) {
//                            ErrorDesc = "Line " + numLine + " : Wrong Sequence";
//                            return false;
//                        } // Check SEQNO
//                        if (isNumber(strLine.substring(7, 10)) == false) {
//                            ErrorDesc = "Line " + numLine + " : Wrong BankCode";
//                            return false;
//                        } // Check BANKCODE
//                        if (isNumber(strLine.substring(10, 20)) == false) {
//                            return false;
//                        } // Check CompNo
//
//                        if (isNumber(strLine.substring(20, 27)) == false) {
//                            return false;
//                        } // Check Total Txn
//                        if (isNumber(strLine.substring(27, 40)) == false) {
//                            return false;
//                        } // Check Total Amt
//                        if (isNumber(strLine.substring(40, 47)) == false) {
//                            return false;
//                        } // Check Total Txn
//                        if (isNumber(strLine.substring(47, 60)) == false) {
//                            return false;
//                        } // Check Total Amt

                    } else {
                        return false;
                    }

                    numLine++;

                } else if (numLine == 1) { // Header Section
                    if (strLine.length() > 128) {
                        ErrorCd = "10";
                        ErrorDesc = "File Header Record Length > 128";
                        return false;
                    } // Check Header Length <= 128
                    if (strLine.substring(0, 1).equalsIgnoreCase("H") == false) {
                        ErrorDesc = "Line " + strLine + " : Header is not equal H";
                        return false;
                    } // Check RECTYPE = H
                    if (strLine.substring(1, 7).equalsIgnoreCase("000001") == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Sequence";
                        return false;
                    } // Check SEQNO
                    if (isNumber(strLine.substring(7, 10)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong BankCode";
                        return false;
                    } // Check BANKCODE
//                    if (isNumber(strLine.substring(10, 20)) == false){ return false; } // Check CompCode
                    if (isNumber(strLine.substring(45, 51)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Effective Date";
                        return false;
                    } // Check Effdate + Valid Date in Calendar

                    FileEffDate = strLine.substring(45, 51);
                    if (Integer.valueOf(strLine.substring(49, 51)) >= 50) {
                        ErrorCd = "05";
                        ErrorDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.  ";
                        return false;
                    }

                    if (isValidDate(strLine.substring(45, 51)) == false) {
                        // data is not a date
                        ErrorCd = "21";
                        ErrorDesc = " Date is not in calendar ";
                        return false;
                    } // Check EffDate
                    numLine++;

                } else {
                    System.out.println("Class HashFormat Method genHashF80B_10M(Error): File is not Data");

                }

            }
            br.close();
//            System.out.println("Close br validFormat128BPOOL \n");

        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
//            System.out.println("Close br validFormat80 exception \n");
        } catch (Exception ex) {
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
        } finally {
            br.close();
//            System.out.println("Close br validFormat128BPOOL finally \n");
        }

        return true;
    }
    
    public boolean validFormat128BPEA(BufferedReader br, boolean validSameDte) throws IOException {
        String strLine = null;
        int numLine = 1;
        String strEffDate = "";
        int endline;

        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {

                if (numLine >= 2) { // Detail Section and Tail Section

                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D
                        if (strLine.length() > 128) {
                            ErrorCd = "10";
                            System.out.println(numLine);
                            ErrorDesc = "File Detail Record Length > 128";
                            return false;
                        } // Check Detail Length = 128
                        if (isNumber(strLine.substring(1, 7)) == false) {
                            ErrorDesc = "Line " + numLine + " : Wrong Sequence";
                            return false;
                        } // Check SEQNO
                        if (isNumber(strLine.substring(7, 10)) == false) {
                            ErrorDesc = "Line " + numLine + " : Wrong BankCode";
                            return false;
                        } // Check BANKCODE
                        if (isNumber(strLine.substring(10, 20)) == false) {
                            ErrorCd = "13";
                            ErrorDesc = "Line " + numLine + " : Account " + strLine.substring(10, 20) + " is not A Number";
                            return false;
                        } // Check AccountNo
                        if (isNumber(strLine.substring(21, 32)) == false) {
                            ErrorDesc = "Line " + numLine + " : Amount " + strLine.substring(21, 32) + " is not A Number";
                            return false;
                        } else {
                            if (Double.valueOf(strLine.substring(21, 32)) == 0) {
                                ErrorCd = "14";
                                return false;
                            }
                        } // Check Amount
                        if (isNumber(strLine.substring(32, 34)) == false) {
                            ErrorDesc = "Line " + numLine + " : ServType " + strLine.substring(32, 34) + " is not A Number";
                            return false;
                        } // Check ServType

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        if (strLine.length() > 128) {
                            ErrorCd = "10";
                            ErrorDesc = "File Tail Record Length > 128";
                            return false;
                        } // Check Tail Length <= 128

                    } else {
                        return false;
                    }

                    numLine++;

                } else if (numLine == 1) { // Header Section
                    if (strLine.length() > 128) {
                        ErrorCd = "10";
                        ErrorDesc = "File Header Record Length > 128";
                        return false;
                    } // Check Header Length <= 128
                    if (strLine.substring(0, 1).equalsIgnoreCase("H") == false) {
                        ErrorDesc = "Line " + strLine + " : Header is not equal H";
                        return false;
                    } // Check RECTYPE = H
                    if (strLine.substring(1, 7).equalsIgnoreCase("000001") == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Sequence";
                        return false;
                    } // Check SEQNO
                    if (isNumber(strLine.substring(7, 10)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong BankCode";
                        return false;
                    } // Check BANKCODE
//                    if (isNumber(strLine.substring(10, 20)) == false){ return false; } // Check CompCode
                    if (isNumber(strLine.substring(45, 51)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Effective Date";
                        return false;
                    } // Check Effdate + Valid Date in Calendar

                    FileEffDate = strLine.substring(45, 51);
                    if (Integer.valueOf(strLine.substring(49, 51)) >= 50) {
                        ErrorCd = "05";
                        ErrorDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.  ";
                        return false;
                    }

                    if (isValidDate(strLine.substring(45, 51)) == false) {
                        // data is not a date
                        ErrorCd = "21";
                        ErrorDesc = " Date is not in calendar ";
                        return false;
                    } // Check EffDate
                    numLine++;

                } else {
                    System.out.println("Class HashFormat Method genHashF80B_10M(Error): File is not Data");

                }

            }
            br.close();
//            System.out.println("Close br validFormat128BPOOL \n");

        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
//            System.out.println("Close br validFormat80 exception \n");
        } catch (Exception ex) {
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
        } finally {
            br.close();
//            System.out.println("Close br validFormat128BPOOL finally \n");
        }

        return true;
    }
    
    public boolean validFormat130BMEA(BufferedReader br, boolean validSameDte) throws IOException {
//public boolean validFormat128BPOOL(RemoveBlankLine br,boolean validSameDte) throws IOException {
        String strLine = null;
        int numLine = 1;
        String strEffDate = "";
        int endline;

        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {

                if (numLine >= 2) { // Detail Section and Tail Section

                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D
                        if (strLine.length() > 130) {
                            ErrorCd = "10";
                            System.out.println(numLine);
                            ErrorDesc = "File Detail Record Length > 130";
                            return false;
                        } // Check Detail Length = 128
                        if (isNumber(strLine.substring(1, 7)) == false) {
                            ErrorDesc = "Line " + numLine + " : Wrong Sequence";
                            return false;
                        } // Check SEQNO
                        if (isNumber(strLine.substring(7, 10)) == false) {
                            ErrorDesc = "Line " + numLine + " : Wrong BankCode";
                            return false;
                        } // Check BANKCODE
                        if (isNumber(strLine.substring(10, 20)) == false) {
                            ErrorCd = "13";
                            ErrorDesc = "Line " + numLine + " : Account " + strLine.substring(10, 20) + " is not A Number";
                            return false;
                        } // Check AccountNo
                        if (isNumber(strLine.substring(21, 33)) == false) {
                            ErrorDesc = "Line " + numLine + " : Amount " + strLine.substring(21, 33) + " is not A Number";
                            return false;
                        } else {
                            if (Double.valueOf(strLine.substring(21, 33)) == 0) {
                                ErrorCd = "14";
                                return false;
                            }
                        } // Check Amount
                        if (isNumber(strLine.substring(33, 35)) == false) {
                            ErrorDesc = "Line " + numLine + " : ServType " + strLine.substring(33, 35) + " is not A Number";
                            return false;
                        } // Check ServType

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        if (strLine.length() > 128) {
                            ErrorCd = "10";
                            ErrorDesc = "File Tail Record Length > 128";
                            return false;
                        }
                    } else {
                        return false;
                    }

                    numLine++;

                } else if (numLine == 1) { // Header Section
                    if (strLine.length() > 128) {
                        ErrorCd = "10";
                        ErrorDesc = "File Header Record Length > 128";
                        return false;
                    } // Check Header Length <= 128
                    if (strLine.substring(0, 1).equalsIgnoreCase("H") == false) {
                        ErrorDesc = "Line " + strLine + " : Header is not equal H";
                        return false;
                    } // Check RECTYPE = H
                    if (strLine.substring(1, 7).equalsIgnoreCase("000001") == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Sequence";
                        return false;
                    } // Check SEQNO
                    if (isNumber(strLine.substring(7, 10)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong BankCode";
                        return false;
                    } // Check BANKCODE
//                    if (isNumber(strLine.substring(10, 20)) == false){ return false; } // Check CompCode
                    if (isNumber(strLine.substring(45, 51)) == false) {
                        ErrorDesc = "Line " + strLine + " : Wrong Effective Date";
                        return false;
                    } // Check Effdate + Valid Date in Calendar

                    FileEffDate = strLine.substring(45, 51);
                    if (Integer.valueOf(strLine.substring(49, 51)) >= 50) {
                        ErrorCd = "05";
                        ErrorDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.  ";
                        return false;
                    }

                    if (isValidDate(strLine.substring(45, 51)) == false) {
                        // data is not a date
                        ErrorCd = "21";
                        ErrorDesc = " Date is not in calendar ";
                        return false;
                    } // Check EffDate
                    numLine++;

                } else {
                    System.out.println("Class HashFormat Method genHashF80B_10M(Error): File is not Data");

                }

            }
            br.close();
//            System.out.println("Close br validFormat128BPOOL \n");

        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
//            System.out.println("Close br validFormat80 exception \n");
        } catch (Exception ex) {
            ErrorCd = "999";
            ErrorDesc = "Line:" + numLine + " ข้อมูลมีปัญหา : " + strLine + "  ";
            return false;
        } finally {
            br.close();
//            System.out.println("Close br validFormat128BPOOL finally \n");
        }

        return true;
    }
//    BufferedReader

    public int genHashF80B_10M(BufferedReader br) throws IOException {
//public int genHashF80B_10M(RemoveBlankLine br) throws IOException {
        String strLine = null;
        String strAcc = null;
        String strAmt = null;
        String strSign = null;
        String strAppCode = null;
        String dtlEff = null;

        int numLine = 1;
        int hash = 0;
        try {

            while ((strLine = br.readLine()) != null) {
                int Z = 0;
                if (numLine >= 2) {

                    strLine = strLine.trim();
                    if (strLine.length() != 0) {
                        strAcc = strLine.substring(0, 10);
                        dtlEff = strLine.substring(10, 16);
                        strSign = strLine.substring(16, 17);
                        strAmt = strLine.substring(17, 26);

//                        if (isValidAccount(strAcc) && isCorrectSign(strSign, strAppCode) 
//                                && (strSign.equalsIgnoreCase("1") || strSign.equalsIgnoreCase("0") )) {
                        if (isValidAccount(strAcc)
                                && (strSign.equalsIgnoreCase("1") || strSign.equalsIgnoreCase("0"))) {
                            Calculator cal = new Calculator();
                            Z = cal.HashCalculate(strAcc, strAmt);
                            hash = (hash + Z) % 1000000;
                        } else {
//                            System.out.println("ACCOUNT NO REJECT :" +strAcc);
                            FileAmtInv = FileAmtInv + Long.parseLong(strAmt);
                            FileTxnInv++;
                        }

                        FileAmtRead = FileAmtRead + Long.parseLong(strAmt);


                        numLine++;
                    }
                } else if (numLine == 1) {
//                    System.out.println("--------------------Line 1----------------------------");
                    FileCompcode = strLine.substring(10, 16);
                    FileTxn = Integer.parseInt(strLine.substring(54, 59));
                    FileAmt = Long.parseLong(strLine.substring(59, 69));
                    strAppCode = strLine.substring(46, 47);
                    numLine++;
                } else {
                    System.out.println("Class HashFormat Method genHashF80B_10M(Error): File is not Data");
                }
            }
            FileTxnRead = numLine - 2;
            br.close();

        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            br.close();

        } finally {
            br.close();

        }

        return hash;
    }

    public int genHashF80B_100M(BufferedReader br) throws IOException {
//    public int genHashF80B_100M(RemoveBlankLine br) throws IOException {

        String strLine = null;
        String strAcc = null;
        String strAmt = null;
        String strSign = null;
        String strAppCode = null;
        String strEffDate = null;
        int numLine = 1;
        int hash = 0;
        try {
            //        int eidx = 1;
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                // Print the content on the console
                int Z = 0;
                if (numLine >= 2) {
//                    System.out.println("--------------------Line " + numLine + "----------------------------");
                    strLine = strLine.trim();
                    if (strLine.length() != 0) {
                        //                    System.out.println("-----------------" + strLine + "-------------------------");
                        strAcc = strLine.substring(0, 10);
                        strEffDate = strLine.substring(10, 16);
                        strSign = strLine.substring(16, 17);
                        strAmt = strLine.substring(17, 28);

                        // Check Account Check Sign & AppCode
//                        if (isValidAccount(strAcc) && isCorrectSign(strSign, strAppCode) 
//                                && (strSign.equalsIgnoreCase("1") || strSign.equalsIgnoreCase("0"))) {
                        if (isValidAccount(strAcc)
                                && (strSign.equalsIgnoreCase("1") || strSign.equalsIgnoreCase("0"))) {
                            Calculator cal = new Calculator();
                            Z = cal.HashCalculate(strAcc, strAmt);
                            hash = (hash + Z) % 1000000;
                        } else {

                            FileAmtInv = FileAmtInv + Long.parseLong(strAmt);
                            FileTxnInv++;
                        }

                        FileAmtRead = FileAmtRead + Long.parseLong(strAmt);
                        numLine++;
                    }
                } else if (numLine == 1) {
//                    System.out.println("--------------------Line 1----------------------------");
                    FileCompcode = strLine.substring(9, 15);
                    FileTxn = Integer.parseInt(strLine.substring(53, 58));
                    FileAmt = Long.parseLong(strLine.substring(58, 69));
                    strAppCode = strLine.substring(45, 46);

                    numLine++;
                } else {
                    System.out.println("-----------------HashFormat(genHashF100M/Error) : File is not Data---------------------");
                }
            }
            FileTxnRead = numLine - 2;

            br.close();
//            System.out.println("Close br genHash80B100M");
//            System.out.println("--------------------Line " + numLine + "----------------------------");
//            System.out.println("++++++++++++++++++++++++++HashCode: " + hash + "++++++++++++++++++++++++++++");
        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            br.close();
//            System.out.println("Close br genHash80B100M");
        } catch (Exception ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            br.close();
        } finally {
            br.close();
//            System.out.println("Close br genHash80B100M finally ");
        }

        return hash;
    }

    public int genHashF128B(BufferedReader br) throws IOException {
//        public int genHashF128B(RemoveBlankLine br) throws IOException {
        // Gen Hash for 128BPOOL & 128BTTNT

        String strLine = null;
        String strAcc = null;
        String strAmt = null;
        int numLine = 1;
        int hash = 0;
        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                // Print the content on the console
                int Z = 0;
                if (numLine >= 2) {
                    strLine = strLine.trim();
                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D
                        strAcc = strLine.substring(10, 20);
                        strAmt = strLine.substring(21, 31);

                        if (isValidAccount(strAcc) == false) {
                            FileAmtInv = FileAmtInv + Long.parseLong(strAmt);
                            FileTxnInv++;
                        }

                        FileAmtRead = FileAmtRead + Long.parseLong(strAmt);

                        Calculator cal = new Calculator();
                        Z = cal.HashCalculate(strAcc, strAmt);
                        hash = (hash + Z) % 1000000;

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        FileTxn = Integer.parseInt(strLine.substring(20, 27));
                        FileAmt = Long.parseLong(strLine.substring(27, 40));
                    }
                    numLine++;

                } else if (numLine == 1) {
                    // Header Process
                    FileCompcode = strLine.substring(10, 20);
                    numLine++;

                } else {
                    System.out.println("-----------------HashFormat(genHashF128B/Error) : File is not Data---------------------");
                }
            }
            FileTxnRead = numLine - 3;

            br.close();
//            System.out.println("Close br genHash128B");
//            System.out.println("--------------------Line " + numLine + "----------------------------");
//            System.out.println("++++++++++++++++++++++++++HashCode: " + hash + "++++++++++++++++++++++++++++");
        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            br.close();
//            System.out.println("Close br genHash128B");
        } finally {
            br.close();
//            System.out.println("Close br genHash128B finally ");
        }

        return hash;
    }
    
    public int genHashF128B_PEA(BufferedReader br) throws IOException {
//        public int genHashF128B(RemoveBlankLine br) throws IOException {
        // Gen Hash for 128BPOOL & 128BTTNT

        String strLine = null;
        String strAcc = null;
        String strAmt = null;
        int numLine = 1;
        int hash = 0;
        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                // Print the content on the console
                int Z = 0;
                if (numLine >= 2) {
                    strLine = strLine.trim();
                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D
                        strAcc = strLine.substring(10, 20);
                        strAmt = strLine.substring(21, 32);

                        if (isValidAccount(strAcc) == false) {
                            FileAmtInv = FileAmtInv + Long.parseLong(strAmt);
                            FileTxnInv++;
                        }

                        FileAmtRead = FileAmtRead + Long.parseLong(strAmt);

                        Calculator cal = new Calculator();
                        Z = cal.HashCalculate(strAcc, strAmt);
                        hash = (hash + Z) % 1000000;

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        FileTxn = Integer.parseInt(strLine.substring(20, 27));
                        FileAmt = Long.parseLong(strLine.substring(27, 40));
                    }
                    numLine++;

                } else if (numLine == 1) {
                    // Header Process
                    FileCompcode = strLine.substring(10, 20);
                    numLine++;

                } else {
                    System.out.println("-----------------HashFormat(genHashF128B_PEA/Error) : File is not Data---------------------");
                }
            }
            FileTxnRead = numLine - 3;

            br.close();
//            System.out.println("Close br genHash128B");
//            System.out.println("--------------------Line " + numLine + "----------------------------");
//            System.out.println("++++++++++++++++++++++++++HashCode: " + hash + "++++++++++++++++++++++++++++");
        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            br.close();
//            System.out.println("Close br genHash128B");
        } finally {
            br.close();
//            System.out.println("Close br genHash128B finally ");
        }

        return hash;
    }

    public int genHashF130B_MEA(BufferedReader br) throws IOException {
//        public int genHashF128B(RemoveBlankLine br) throws IOException {
        // Gen Hash for 128BPOOL & 128BTTNT
        String strLine = null;
        String strAcc = null;
        String strAmt = null;
        BigDecimal limitAmount = new BigDecimal(1000000000);
        overOneThousandMillion=false;
        int numLine = 1;
        int hash = 0;
        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                // Print the content on the console
                int Z = 0;
                if (numLine >= 2) {
                    strLine = strLine.trim();
                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D
                        strAcc = strLine.substring(10, 20);
                        strAmt = strLine.substring(21, 33);
                        
                        if ((new BigDecimal(strAmt)).divide(new BigDecimal("100")).compareTo(limitAmount) > 0){ //>= 1,000,000,000
                            overOneThousandMillion = true;
                            System.out.println("LINE " + strLine + "\n"+ strAmt);
                        }

                        if (isValidAccount(strAcc) == false) {
                            FileAmtInv = FileAmtInv + Long.parseLong(strAmt);
                            FileTxnInv++;
                        }

                        FileAmtRead = FileAmtRead + Long.parseLong(strAmt);

                        Calculator cal = new Calculator();
                        Z = cal.HashCalculate(strAcc, strAmt);
                        hash = (hash + Z) % 1000000;

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        FileTxn = Integer.parseInt(strLine.substring(20, 27));
                        FileAmt = Long.parseLong(strLine.substring(27, 40));
                    }
                    numLine++;

                } else if (numLine == 1) {
                    // Header Process
                    FileCompcode = strLine.substring(10, 20);
                    numLine++;

                } else {
                    System.out.println("-----------------HashFormat(genHashF130B_MEA/Error) : File is not Data---------------------");
                }
            }
            FileTxnRead = numLine - 3;

            br.close();
//            System.out.println("Close br genHash128B");
//            System.out.println("--------------------Line " + numLine + "----------------------------");
//            System.out.println("++++++++++++++++++++++++++HashCode: " + hash + "++++++++++++++++++++++++++++");
        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            br.close();
//            System.out.println("Close br genHash128B");
        } finally {
            br.close();
//            System.out.println("Close br genHash128B finally ");
        }

        return hash;
    }

    public int genHashF128B_TOT(BufferedReader br) throws IOException {
//        public int genHashF128B_TOT(RemoveBlankLine br) throws IOException {
        String strLine = null;
        String strAcc = null;
        String strAmt = null;
        int numLine = 1;
        int hash = 0;
        try {
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                // Print the content on the console
                int Z = 0;
                if (numLine >= 2) {
                    strLine = strLine.trim();
                    if (strLine.substring(0, 1).equalsIgnoreCase("D")) {
                        // Check Detail RECTYPE = D
                        strAcc = strLine.substring(83, 93);
                        strAmt = strLine.substring(21, 31);

                        if (isValidAccount(strAcc) == false) {
                            FileAmtInv = FileAmtInv + Long.parseLong(strAmt);
                            FileTxnInv++;
                        }

                        FileAmtRead = FileAmtRead + Long.parseLong(strAmt);

                        Calculator cal = new Calculator();
                        Z = cal.HashCalculate(strAcc, strAmt);
                        hash = (hash + Z) % 1000000;

                    } else if (strLine.substring(0, 1).equalsIgnoreCase("T")) {
                        // Check Tail RECTYPE = T
                        FileTxn = Integer.parseInt(strLine.substring(20, 27));
                        FileAmt = Long.parseLong(strLine.substring(27, 40));
                    }
                    numLine++;

                } else if (numLine == 1) {
                    // Header Process
                    FileCompcode = strLine.substring(118, 128);
                    numLine++;

                } else {
                    System.out.println("-----------------HashFormat(genHashF128B_TOT/Error) : File is not Data---------------------");
                }
            }
            FileTxnRead = numLine - 3;

            br.close();
//            System.out.println("Close br genHash128BTOT");
//            System.out.println("--------------------Line " + numLine + "----------------------------");
//            System.out.println("++++++++++++++++++++++++++HashCode: " + hash + "++++++++++++++++++++++++++++");
        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
            br.close();
//            System.out.println("Close br genHash128BTOT");
        } finally {
            br.close();
//            System.out.println("Close br genHash128BTOT finally ");
        }

        return hash;
    }

    public int findFormat(BufferedReader br) {
//public int findFormat(RemoveBlankLine br) {
        String strLine = null;
        int numLine = 1;
        int typeFormat = 0;

        try {

            while ((strLine = br.readLine()) != null && numLine <= 2) {
                // Print the content on the console
                if (numLine >= 2) {
//                    System.out.println("--------------------Line " + numLine + "----------------------------");
                    strLine = strLine.trim();
                    String[] strSplit = strLine.split("  ");
//                    System.out.println(strSplit[0]);
//                    System.out.println(strSplit[0].length());
                    if (strSplit[0].length() == 26) {
                        typeFormat = 10; // layout 80 byte 10m
                    } else if (strSplit[0].length() == 28) {
                        typeFormat = 100; // layout 80 byte 100m
                    } else if (strSplit[0].length() >= 29 && strSplit[0].length() <= 128) {
                        typeFormat = 128; // layout 128 byte
                    } else if (strSplit[0].length() <= 10 && strSplit[0].length() >= 1) {
                        typeFormat = 707; // layout of TOT Company
                    }
                    numLine++;
                } else if (numLine == 1) {
//                    System.out.println("--------------------Line 1----------------------------");
                    numLine++;
                } else {
                    System.out.println("-----------------HashFormat(findFormat/Error) : File is not Data---------------------");
                }
            }
            br.close();
        } catch (IOException ex) {
            Logger.getLogger(HashFormat.class.getName()).log(Level.SEVERE, null, ex);
        }

        return typeFormat;
    }

    private boolean isValidAccount(String account) {
        String tmpVal = "432765432";

//        account = "1112865588";

        boolean isValidate = false;
        String tmpCheck = "";
        String tmp_digitCheck = "";
        int total_checkDigit = 0;
        int result_digit = 0;
        int result = 0;

        if (account.trim().length() == 10) {

            // Check Zero Account
            if (!account.equalsIgnoreCase("0000000000")) {
                // Check Account Type
                String b1kType = account.substring(0, 3);
                int ib1kType = Integer.parseInt(b1kType);
                // B1K Type
                if ((ib1kType > 400) && (ib1kType < 470)) {
                    // Check Digit
                    for (int i = 0; i < account.trim().length(); i++) {
                        if (i == 9) {
                            tmp_digitCheck = account.substring(i, i + 1);
                        } else {
                            int tmpNumber = 0;
                            tmpNumber = Integer.parseInt(account.substring(i, i + 1)) * Integer.parseInt(tmpVal.substring(i, i + 1));
                            if (tmpNumber >= 10) {
                                String tmp = String.valueOf(tmpNumber);
                                tmpCheck = tmp.substring(1, 2);
                            } else {
                                tmpCheck = String.valueOf(tmpNumber);
                            }
                            total_checkDigit = total_checkDigit + Integer.parseInt(tmpCheck);
                        }
                    }
                    result_digit = total_checkDigit % 10;
                    result = 10 - result_digit;
                    if (result == 10) {
                        if (tmp_digitCheck.equals("0")) {
                            isValidate = true;
                        } else {
//                                System.out.println("Validate ACC Fail:" + account);
                        }
                    } else {
                        if (tmp_digitCheck.equals(String.valueOf(result))) {
                            isValidate = true;
                        } else {
//                                System.out.println("Validate ACC Fail:" + account);
                        }
                    }

                } else {
                    // Normal Account Type
                    String AccType = account.substring(3, 4);

                    int iAccType = Integer.parseInt(AccType);

                    if ((iAccType == 2) || (iAccType == 3) || (iAccType == 4) || (iAccType == 5) || (iAccType == 6)) {
                        // Check Digit
                        for (int i = 0; i < account.trim().length(); i++) {
                            if (i == 9) {
                                tmp_digitCheck = account.substring(i, i + 1);
                            } else {
                                int tmpNumber = 0;
                                tmpNumber = Integer.parseInt(account.substring(i, i + 1)) * Integer.parseInt(tmpVal.substring(i, i + 1));
                                if (tmpNumber >= 10) {
                                    String tmp = String.valueOf(tmpNumber);
                                    tmpCheck = tmp.substring(1, 2);
                                } else {
                                    tmpCheck = String.valueOf(tmpNumber);
                                }
                                total_checkDigit = total_checkDigit + Integer.parseInt(tmpCheck);
                            }
                        }

                        result_digit = total_checkDigit % 10;
                        result = 10 - result_digit;
                        if (result == 10) {
                            if (tmp_digitCheck.equals("0")) {
                                isValidate = true;
                            } else {
//                                System.out.println("Validate ACC Fail:" + account);
                            }
                        } else {

                            if (tmp_digitCheck.equals(String.valueOf(result))) {
                                isValidate = true;
                            } else {
//                                System.out.println("Validate ACC Fail:" + account);
                            }
                        }
                    }

                }

            }

        }

        return isValidate;
    }

    public boolean isNumber(String str) {
        return str.matches("^[0-9]+$");
    }

    public boolean isThai(String str) {
        return !str.matches("^[^ก-๙]+$");
    }

    public boolean isCorrectSign(String strSign, String strAppCode) {
        boolean isCorrect = false;

        if (strSign.equalsIgnoreCase("0")) {
            if ((strAppCode.equalsIgnoreCase("D"))
                    || (strAppCode.equalsIgnoreCase("I"))
                    || (strAppCode.equalsIgnoreCase("P"))
                    || (strAppCode.equalsIgnoreCase("Z"))
                    || (strAppCode.equalsIgnoreCase("6"))) {

                isCorrect = true;
            }

        } else if (strSign.equalsIgnoreCase("1")) {
            if ((strAppCode.equalsIgnoreCase("C"))
                    || (strAppCode.equalsIgnoreCase("S"))
                    || (strAppCode.equalsIgnoreCase("G"))
                    || (strAppCode.equalsIgnoreCase("X"))
                    || (strAppCode.equalsIgnoreCase("1"))
                    || (strAppCode.equalsIgnoreCase("4"))
                    || (strAppCode.equalsIgnoreCase("0"))
                    || (strAppCode.equalsIgnoreCase("W"))
                    || (strAppCode.equalsIgnoreCase("E"))
                    || (strAppCode.equalsIgnoreCase("T"))) {

                isCorrect = true;
            }
        }

        return isCorrect;
    }

    public boolean isValidDate(String inDate) {

        //i nput format is ddMMyy
        if (inDate == null) {
            return false;
        }

        //set the format to use as a constructor argument
        SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyy");
        if (inDate.trim().length() != dateFormat.toPattern().length()) {
            return false;
        }

        dateFormat.setLenient(false);

        try {
            //parse the inDate parameter
            dateFormat.parse(inDate.trim());
        } catch (ParseException pe) {
            return false;
        }
        return true;
    }
}
