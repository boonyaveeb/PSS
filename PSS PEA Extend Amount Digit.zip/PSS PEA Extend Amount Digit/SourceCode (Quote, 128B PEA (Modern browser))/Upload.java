/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.scb.pss.uti;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.scb.pss.atstxn.control.HashFormat;
import com.scb.pss.atstxn.service.txnService;
import com.scb.pss.output.control.Database;

import java.io.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.Scanner;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author cansin
 */
public class Upload extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    private String FileName = "";
    private String FilePath = "";
    private String FileTmpID = "";
    private String Result = "1";
    private String ResultDesc = "";
    private long FileSize = 0;
    private int FileTxn = 0;
    private long FileAmt = 0;
    private int FileTxnInv = 0;
    private long FileAmtInv = 0;
    private int FileTxnRead = 0;
    private long FileAmtRead = 0;
    private int HashcodeCal = 0;
    private String FileEffDate = "";
    private String entryBr = "";
//    private static final String ENCODING = "x-iso-8859-11";
//    private static final String ENCODING = "MS874";
    String ENCODING = pssUti.getEncode("PSS2EN1");

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/xml;charset=UTF-8");
        
        PrintWriter out = response.getWriter();
        StringBuilder listXml = new StringBuilder();
        listXml.append("<response>");
        String entryId = "";

        try {
            boolean blFIle = false;
            /**
             * Parse request using MultiparRequest since it is a multipart/form-data
             * throws IOException if request is not multipart
             *
             * So, if form is not yet submitted Upload servlet will show upload.jsp as response
             * if form is submitted Upload servlet will process the request at upload() function
             */
            pssConfig pssCf = new pssConfig();
            int updFileSize = Integer.valueOf(pssCf.getAtstxnUldSize());  //4MB
            MultipartRequest multipartRequest = new MultipartRequest(request, pssCf.getAtstxnUldTmpPath(), updFileSize, new DefaultFileRenamePolicy());
            String hashcode = multipartRequest.getParameter("hashcode");
//            MultipartRequest multi =        new MultipartRequest(req, ".", 5 * 1024 * 1024);
            File f = null;
            // For renew Session
            HttpSession session = request.getSession();
            Enumeration files = multipartRequest.getFileNames();
            entryBr = (String) session.getAttribute("loginBrID");
            while (files.hasMoreElements()) {
                String name = (String) files.nextElement();
                String filename = multipartRequest.getFilesystemName(name);
                String type = multipartRequest.getContentType(name);
                f = multipartRequest.getFile(name);

                if (f != null) {
                    blFIle = true;
                    if (f.length() == 0) {
                        Result = "2";// file not found        
                        ResultDesc = mapErrDesc("16", "file not found");
                        return;
                    } 
                    
                    // Validate the file content for quotes
                    if (isContainsQuotes(new FileInputStream(f))) {
                        Result = "2"; // File contains quotes
                        ResultDesc = mapErrDesc("99", "Upload file มีตัวอักษร ' \" กรุณาลบออก ระบบไม่สามารถดำเนินการต่อได้");
                        return;
                    }
                } else {
                    Result = "2";// file not found        
                    ResultDesc = mapErrDesc("02", "file not found");
                    return;
                }

            }




            entryId = (String) session.getAttribute("userName");
            if (entryId == null) {
                Result = "99"; //session is null
                ResultDesc = mapErrDesc("17", "session time out");
                return;
            }

//            FileTmpID = multipartRequest.getParameter("parsetmpid");
            FileTmpID = multipartRequest.getParameter("parseowntmpid");
            FileSize = f.length();
            FileName = f.getName();




            File dirToMove = new File(pssCf.getAtstxnUldPath());
//            FilePath = dirToMove.toString();
            FilePath = pssCf.getAtstxnUldPath();
            fileUtil svFile = new fileUtil();
            String NewFileName = entryId + "_" + svFile.getFileRefKey().toString() + ".txt";
            if (!copyFileToTmp(f, dirToMove, NewFileName)) {
                Result = "03";
                ResultDesc = mapErrDesc("18", "Copy file error");
                return;
            }

            //check CRCRLF
            if (pssUti.getSingleSysParam("VALCRLF", "CRLF").equals("Y")) {
                svFile.findCrCrLfnLfEof(FilePath + "/" + NewFileName);
                if (svFile.isOutCrCrLf()) {
                    Result = "03";
                    ResultDesc = mapErrDesc("99", "การขึ้นบรรทัดใหม่ของข้อมูลมีปัญหา");
                    return;
                }

                if (!svFile.outLfEof) {
                    Result = "03";
                    ResultDesc = mapErrDesc("99", "ข้อมูลบรรทัดสุดท้ายมีปัญหา");
                    return;
                }
            }
//            findCrCrLfnLfEof
//            if ( svFile.findCrCrLfEOL(FilePath+"/"+NewFileName)){
//                Result="03";
//                ResultDesc = mapErrDesc("99", "Line of data has a problem");
//                return;
//               }
//            isChr10ofEof


            String retEffDate = "";
            Boolean verHash = false;

            verHash = chkHashCode(NewFileName, FilePath, multipartRequest);

            if (!Result.equals("1")) {
                return;
            }

            //Set Response Message

            if (verHash == true) {
                Result = "1";
                retEffDate = "20" + FileEffDate.substring(4, 6) + "-" + FileEffDate.substring(2, 4) + "-" + FileEffDate.substring(0, 2);
            } else {
                Result = "2";
                ResultDesc = "Check Hash ผิดพลาด";
                return;
            }

            //uploaded info
            listXml.append("<hashcode>" + hashcode + "</hashcode>");
            listXml.append("<UploadedFileName>" + FileName + "</UploadedFileName>");
            listXml.append("<FileName>" + NewFileName + "</FileName>");
            listXml.append("<FileTmpID>" + FileTmpID + "</FileTmpID>");
            listXml.append("<HashcodeCal>" + HashcodeCal + "</HashcodeCal>");
            listXml.append("<FileSize>" + FileSize + "</FileSize>");
            listXml.append("<FileAmt>" + FileAmt + "</FileAmt>");
            listXml.append("<FileTxn>" + FileTxn + "</FileTxn>");
            listXml.append("<FileAmtInv>" + FileAmtInv + "</FileAmtInv>");
            listXml.append("<FileTxnInv>" + FileTxnInv + "</FileTxnInv>");
            listXml.append("<FileAmtRead>" + FileAmtRead + "</FileAmtRead>");
            listXml.append("<FileTxnRead>" + FileTxnRead + "</FileTxnRead>");
            listXml.append("<FileEffDate>" + retEffDate + "</FileEffDate>");

        } catch (IOException ex) {
            Result = "2";
            ResultDesc = mapErrDesc("999", "IOException error");
            ex.printStackTrace();
//            displayUpload(request, response);   
        } catch (Exception ex) {
            Result = "E99";
            ResultDesc = mapErrDesc("999", "Exception error");
            ex.printStackTrace();
//                ResultDesc = "Exception error:" + ex.getMessage();
        } finally {
//            System.out.println("Dispatch");
            listXml.append("<Success>" + Result + "</Success>");
            listXml.append("<ResultDesc>" + ResultDesc + "</ResultDesc>");
            listXml.append("</response>");

            out.print("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" );
            out.print(listXml);
            out.flush();
            out.close();
        }
    }
    
    private boolean isContainsQuotes(InputStream fileContent) {
        Scanner scanner = new Scanner(fileContent);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.contains("'") || line.contains("\"")) {
                return true; // File contains single quotes or double quotes
            }
        }
        return false; // File doesn't contain single quotes or double quotes
    }

    private boolean copyFileToTmp(File srcFile, File destDir, String fileName) throws Exception {
        boolean move = false;
        File fileToMove = new File(destDir, fileName);

        move = srcFile.renameTo(fileToMove);
        return move;
    }

    private boolean chkHashCode(String newFileName, String servletPath, MultipartRequest multipartRequest) throws IOException {

        boolean chk = false;
        int generateHash = 0;
        String tmpid = "", parsecompcode = "", parsecomptype = "", parsecustcomp = "";
        String owntmpid = "", ownappcode = "";
        String parseappcode = "";
        boolean bdCompFg = false, validSmDte = false;
        boolean over1000m = false;
        //parsecomptype
        //parsecustcomp
//        Map<String,String> resultMt=new HashMap<String,String>();
        //Read Temp File
        try {
            FileInputStream fstream = new FileInputStream(servletPath + "/" + newFileName);
            DataInputStream in = new DataInputStream(fstream);

//        InputStreamReader i = new InputStreamReader(in);
//        System.out.println("Read Encoding = " + i.getEncoding());

            HashFormat hc = new HashFormat();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, ENCODING));
//            RemoveBlankLine br = new RemoveBlankLine(new InputStreamReader(in, ENCODING));

            parsecompcode = multipartRequest.getParameter("parsecompcode");
            parseappcode = multipartRequest.getParameter("parseappcode");
            parsecomptype = multipartRequest.getParameter("parsecomptype");
            parsecustcomp = multipartRequest.getParameter("parsecustcomp");

            tmpid = multipartRequest.getParameter("parsetmpid");
            owntmpid = multipartRequest.getParameter("parseowntmpid");
            ownappcode = multipartRequest.getParameter("parseownappcode");

            if (parsecomptype.equals("B")) {
                hc.compHelpFg = "B";
                hc.compHelpApp = ownappcode;
                if (!tmpid.equals(owntmpid)) {
                    Result = "2";
                    ResultDesc = "Template file : ของ ลูกค้าไม่ตรงกับ Compcode ช่วย";
                    return chk;
                }
            }

            txnService txSv = new txnService();
            bdCompFg = txSv.isBDComp(parsecompcode);


            validSmDte = !bdCompFg;
//            System.out.println(bdCompFg);
//            System.out.println(validSmDte);
//        int fmat = hc.findFormat(br);

            // Validate upload format file

            String getHash = multipartRequest.getParameter("hashcode");
            if (tmpid.equalsIgnoreCase("80B10M")) {
                // validate format of 80B10M
                if (hc.validFormat80B10M(br, validSmDte) == true) {
//                    br = new BufferedReader(new InputStreamReader(new FileInputStream(servletPath + "/" + newFileName), ENCODING));
                    br = new BufferedReader(new InputStreamReader(new FileInputStream(servletPath + "/" + newFileName), ENCODING));
                    generateHash = hc.genHashF80B_10M(br);
                } else {
                    Result = "2";
                    ResultDesc = mapErrDesc(hc.ErrorCd, hc.ErrorDesc);

                    return chk;
                }

            } else if (tmpid.equalsIgnoreCase("80B100M")) {
                if (hc.validFormat80B100M(br, validSmDte) == true) {

                    br = new BufferedReader(new InputStreamReader(new FileInputStream(servletPath + "/" + newFileName), ENCODING));
                    generateHash = hc.genHashF80B_100M(br);

                } else {
                    Result = "2";
                    ResultDesc = mapErrDesc(hc.ErrorCd, hc.ErrorDesc);
//                System.out.println("WRONG FORMAT !!!");
                    return chk;
                }

            } else if (tmpid.equalsIgnoreCase("128BPOOL")) {
                System.out.println("isPEA: " + parsecompcode.equalsIgnoreCase("001170"));

                if (parsecompcode.equalsIgnoreCase("001170")) {
                    if (hc.validFormat128BPEA(br, validSmDte)) {
                        System.out.println("validFormat128BPEA: true");
                        br = new BufferedReader(new InputStreamReader(new FileInputStream(servletPath + "/" + newFileName), ENCODING));
                        generateHash = hc.genHashF128B_PEA(br);
                        Result = "1";
                        chk = true;
                    } else {
                        Result = "2";
                        ResultDesc = mapErrDesc(hc.ErrorCd, hc.ErrorDesc);
                        return chk;
                    }
                } else if (hc.validFormat128BPOOL(br, validSmDte) == true) {
                    System.out.println("validFormat128BPOOL: true");
                    br = new BufferedReader(new InputStreamReader(new FileInputStream(servletPath + "/" + newFileName), ENCODING));
                    generateHash = hc.genHashF128B(br);
//                    generateHash = 0;
                    Result = "1";
                    chk = true;
                } else {
                    Result = "2";
                    ResultDesc = mapErrDesc(hc.ErrorCd, hc.ErrorDesc);
//                System.out.println("WRONG FORMAT !!!");
                    return chk;
                }
//                        System.out.println(hc.ErrorDesc);
            } else if (tmpid.equalsIgnoreCase("130BMEA")) {
                if (hc.validFormat130BMEA(br, validSmDte) == true) {
                    br = new BufferedReader(new InputStreamReader(new FileInputStream(servletPath + "/" + newFileName), ENCODING));
                    generateHash = hc.genHashF130B_MEA(br);
//                    generateHash = 0;
                    Result = "1";
                    chk = true;
                } else {
                    Result = "2";
                    ResultDesc = mapErrDesc(hc.ErrorCd, hc.ErrorDesc);
//                System.out.println("WRONG FORMAT !!!");
                    return chk;
                }
//                        System.out.println(hc.ErrorDesc);
            } else if (tmpid.equalsIgnoreCase("128BTT")) {
                if (hc.validFormat128BTT(br, validSmDte) == true) {
                    br = new BufferedReader(new InputStreamReader(new FileInputStream(servletPath + "/" + newFileName), ENCODING));
                    generateHash = hc.genHashF128B(br);
                    generateHash = 0;
                    Result = "1";
                    chk = true;
                } else {
                    Result = "2";
                    ResultDesc = mapErrDesc(hc.ErrorCd, hc.ErrorDesc);
//                System.out.println("WRONG FORMAT !!!");
                    return chk;
                }

            } else if (tmpid.equalsIgnoreCase("128BTOT")) {
                if (hc.validFormat128BTOT(br, validSmDte) == true) {
                    br = new BufferedReader(new InputStreamReader(new FileInputStream(servletPath + "/" + newFileName), ENCODING));
                    generateHash = hc.genHashF128B_TOT(br);
                    generateHash = 0;
                    Result = "1";
                    chk = true;
                } else {
                    Result = "2";
                    ResultDesc = mapErrDesc(hc.ErrorCd, hc.ErrorDesc);
//                System.out.println("WRONG FORMAT !!!");
                    return chk;
                }
            }
            
            if(hc.overOneThousandMillion){
                Result = "2";
                ResultDesc = " ยอดเงินใน Detail Record มีมูลค่าเกิน 1,000,000,000 บาท ไม่สามารถทำรายการได้!!!";
                return false;
            }

            FileTxn = hc.FileTxn;
            FileAmt = hc.FileAmt;
            FileTxnInv = hc.FileTxnInv;
            FileAmtInv = hc.FileAmtInv;
            FileTxnRead = hc.FileTxnRead;
            FileAmtRead = hc.FileAmtRead;
            FileEffDate = hc.FileEffDate;
            HashcodeCal = generateHash;

//            System.out.println("#############Branch Entry"+entryBr);
//            if (FileAmtRead >= 1000000000) {
            List<String> lsOc = pssUti.getOC1000M();
            for (String t : lsOc) {
                if (t.equals(entryBr)) {
                    over1000m = true;

                }
            }
//            }
            
            // Validate CTL Amount
            if (!validCtrlAmt(tmpid, FileAmt, FileAmtRead, over1000m)) {
                Result = "2";
                ResultDesc = " ยอดเงินใน Control Record ไม่ตรงกับผลรวมของ Detail Record !!!";
                return false;
            } else {
                FileAmt = FileAmtRead;
            }

//            if (FileAmt != FileAmtRead) {
//                //Edit 2012-07-16
//                if (tmpid.equalsIgnoreCase("80B10M")){
//                    if (!(FileAmtRead >= 100000000 && over1000m)) {
//                        Result = "2";
//                        ResultDesc = " ยอดเงินใน Control Record ไม่ตรงกับผลรวมของ Detail Record !!!";
//                        return false;
//                    }else{
//                        FileAmt = FileAmtRead;
//                    }
//                }else{
//                    if (!(FileAmtRead >= 1000000000 && over1000m)) {
//                        Result = "2";
//                        ResultDesc = " ยอดเงินใน Control Record ไม่ตรงกับผลรวมของ Detail Record !!!";
//                        return false;
//                    }else{
//                        FileAmt = FileAmtRead;
//                    }
//                }
//            }

            // Validate Read Transaction
            if (FileTxnRead < 100000) {
                if (FileTxn != FileTxnRead) {
                    Result = "2";
                    ResultDesc = "Total Transaction in file and read does not equal !!!";
                    return false;
                }
            }


            //Change no need to compare HASH Just show to information 
            // 128B Type don't need to Check CompCode & HashCode
            if (tmpid.equalsIgnoreCase("80B10M") || tmpid.equalsIgnoreCase("80B100M")) {

                if (!parsecomptype.equals("B")) {
                    // Check App Code
                    txnService txnSv = new txnService();
                    Map<String, String> crossAppComp = txnSv.getSysParamByGp("CRSAPP");
                    txnSv = null;
                    //update file cross app code between profile and appcode in uploaded file
                    if (crossAppComp.get(parsecompcode) == null) {
                        if (!parseappcode.equalsIgnoreCase(hc.FileAppCode)) {
                            Result = "2";
                            ResultDesc = mapErrDesc("19", "app code error");
                            return chk;
                        }
                    }
                }
                // Check Company Code
                //20120604 --> add more sub compcode

                if (!parsecompcode.equalsIgnoreCase(hc.FileCompcode)) {
                    if (parsecomptype.equalsIgnoreCase("B")) {
                        if (!parsecustcomp.equalsIgnoreCase(hc.FileCompcode)) {
                            Result = "2";
                            ResultDesc = mapErrDesc("20", "comp code not match");
                            return chk;
                        }
                    } else {
                        Result = "2";
                        ResultDesc = mapErrDesc("20", "comp code not match");
                        return chk;
                    }
                }

                //20120604
                //New module : To convert file comp code to cust comp code
                if (parsecomptype.equalsIgnoreCase("B")) {
                    if (!parsecompcode.equalsIgnoreCase(hc.FileCompcode)) {
                        chgCompCodeInFile(servletPath + "/" + newFileName, parsecompcode, tmpid, ownappcode);
//                        chgCompCodeInFile( servletPath + "/" + newFileName,parsecustcomp,parsecompcode);
                    }
                }


//                //Check HashCode                
//                int parseGethash = Integer.parseInt(getHash);
////                System.out.println("USER HASH :: " + getHash + " Parse Hash"  + parseGethash);
////                System.out.println("SYS HASH :: " + generateHash  );
//                
////                        if (parseGethash == 5555) { // Overwrite HashCode                
//                if (parseGethash == Integer.valueOf(getByPassHash())) { // Overwrite HashCode
//                    Result = "1";
//                    chk = true;
//                } else {
//                    if (generateHash == parseGethash) {
//                        Result = "1";
//                        chk = true;
//                    } else {
//                        Result = "2";
//                        ResultDesc = mapErrDesc("15", "Hash total not match");
//                    }
//                }

                Result = "1";
                chk = true;
            }

            //Close the input stream
            in.close();
            fstream.close();
        } catch (Exception ex) {
            System.out.println("Error" + ex.getMessage());
        } finally {
//            System.out.println(ResultDesc);
        }

        return chk;
    }

    private Boolean validCtrlAmt(String iTmpId, Long ctlAmt, Long txnAmt, Boolean ovrFlag) {
        Boolean output = true;
        // 1: ctrl amt not equal then valid other
        if (!ctlAmt.equals(txnAmt)) {
            //2: overide flag is true then allow to valid txn read amount
            if (ovrFlag) {
                //3: allow only over length of ctl amt
                if (iTmpId.equalsIgnoreCase("80B10M")) {
                    if (!(txnAmt >= 100000000)) {
                        output = false;
                    }
                } else {
                    if (!(txnAmt >= 1000000000)) {
                        output = false;
                    }
                }
            } else {
                output = false;
            }
        }
        return output;
    }

    private void chgCompCodeInFile(String fileName, String nComp, String tmpId, String nApp) {
//        servletPath + "/" + newFileName
        File f = new File(fileName);

        FileInputStream fs = null;
        InputStreamReader in = null;
        BufferedReader br = null;

        StringBuffer sb = new StringBuffer();

        String textinLine;

        try {
            fs = new FileInputStream(f);
            in = new InputStreamReader(fs);
            br = new BufferedReader(in);

            while (true) {
                textinLine = br.readLine();
                if (textinLine == null) {
                    break;
                }
                sb.append(textinLine);
                sb.append("\n");
            }
//            String textToEdit1 = oComp;
//            int cnt1 = sb.indexOf(textToEdit1);
//            System.out.println("intstart " + cnt1);
            if (tmpId.equals("80B10M")) {
                sb.replace(10, 16, nComp);
                sb.replace(46, 47, nApp);
//                sb.replace(cnt1, cnt1 + textToEdit1.length(), nComp);
            } else if (tmpId.equals("80B100M")) {
                sb.replace(9, 15, nComp);
                sb.replace(45, 46, nApp);
            }


            fs.close();
            in.close();
            br.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            FileWriter fstream = new FileWriter(f);
            BufferedWriter outobj = new BufferedWriter(fstream);
            outobj.write(sb.toString());
            outobj.close();

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private String mapErrDesc(String errCd, String othDesc) {
        String errDesc = "";
        if (errCd.equals("01")) {
            errDesc = "ยอดเงินใน Control record ไม่ตรงกับผลรวมของ Detail record";
        } else if (errCd.equals("02")) {
            errDesc = "ข้อมูลเป็นไฟล์เปล่า (ไม่มีข้อมูลโอนเงิน)";
        } else if (errCd.equals("03")) {
            errDesc = "ข้อมูลมีแต่ Control ไม่มี detail";
        } else if (errCd.equals("04")) {
            errDesc = "ข้อมูลรายการสุดท้าย มีขยะ";
        } else if (errCd.equals("05")) {
            errDesc = "ข้อมูลวันที่โอนเงินเป็นปี พ.ศ.";
        } else if (errCd.equals("06")) {
            errDesc = "ข้อมูลเป็นวันที่ย้อนหลัง";
        } else if (errCd.equals("07")) {
            errDesc = "ข้อมูลวันที่โอนเงินใน Control ไม่ตรงกับใน Detail";
        } else if (errCd.equals("08")) {
            errDesc = "ข้อมูลในส่วนวันที่โอนเงินผิด format";
        } else if (errCd.equals("09")) {
            errDesc = "ข้อมูล Sign ไม่สัมพันธ์กับ Application Code";
        } else if (errCd.equals("10")) {
            errDesc = "Format ผิดมีความยาวเกินกว่าที่กำหนด" + othDesc;;
        } else if (errCd.equals("11")) {
            errDesc = "Format ไม่ถูกต้อง";
        } else if (errCd.equals("12")) {
            errDesc = "เลขที่บัญชีไม่ถูกต้อง";
        } else if (errCd.equals("13")) {
            errDesc = "เลขที่บัญชีไม่ครบ 10 หลัก" + othDesc;
        } else if (errCd.equals("14")) {
            errDesc = "มีรายการโอนเงินเป็น 0 ";
        } else if (errCd.equals("15")) {
            errDesc = "Hash total ไม่ถูกต้อง";
        } else if (errCd.equals("16")) {
            errDesc = "ไม่พบ File ที่ทำการ Upload ";
        } else if (errCd.equals("17")) {
            errDesc = "Session time out !! ";
        } else if (errCd.equals("18")) {
            errDesc = "ระบบ Copy file ไม่สมบูรณ์ ";
        } else if (errCd.equals("19")) {
            errDesc = " Application Code ไม่ตรงกับ ข้อมูล ";
        } else if (errCd.equals("20")) {
            errDesc = " Comp Code ไม่ตรงกับ ข้อมูล ";
        } else if (errCd.equals("21")) {
            errDesc = " วันที่ไม่ถูกต้องตามปฏิทิน ";
        } else if (errCd.equals("22")) {
            errDesc = " เครื่องหมาย Sign ไม่ตรงกับ App Code ที่ลงทะเบียนไว้ ";
        } else {
            errDesc = othDesc;
        }

        return errDesc;
    }

    public String getByPassHash() {
        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;
        String SQLStr = "";
        String result = "";
        try {
            conn = Database.getConnection();
            stmt = conn.createStatement();
            SQLStr = "SELECT param_value FROM PSS_system_param where param_gp='BYHASH' and param_id='BYHASH1' ";
            rs = stmt.executeQuery(SQLStr);
            if (rs != null) {
                while (rs.next()) {
                    result = rs.getString("param_value").trim();
                }

            }


        } catch (SQLException ex) {
            ex.printStackTrace();
            result = "";
        } catch (Exception ex) {
            ex.printStackTrace();
            result = "";
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                    stmt = null;
                }
                if (rs != null) {
                    rs.close();
                    rs = null;
                }
                Database.destroyConnection(conn);
            } catch (Exception ex) {
                ex.printStackTrace();
                result = "";
            }
            return result;
        }


    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
