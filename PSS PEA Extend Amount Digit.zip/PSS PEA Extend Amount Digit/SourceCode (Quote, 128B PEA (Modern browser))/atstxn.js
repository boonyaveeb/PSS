var tmOut;

// Add trim functionality to the string.
if (typeof String.prototype.trim !== 'function') {
    String.prototype.trim = function() {
        return this.replace(/^\s+|\s+$/g, ''); 
    };
}

// Parse the XML string to be the js object
function parseXMLString(xmlString) {
    var result = {};
    var tagMatches = xmlString.match(/<([^>]+)>([^<]*)<\/\1>|<([^\/]+)\/>/g);
    
    if (tagMatches) {
        for (var i = 0; i < tagMatches.length; i++) {
            var match = tagMatches[i].match(/<([^>]+)>([^<]*)<\/\1>|<([^\/]+)\/>/);
            if (match) {
                var tagName = match[1] || match[3].trim();
                var tagValue = match[2] || '';
                result[tagName] = tagValue;
            }
        }
    }
    return result;
}

// Upload form submit button onclick
function onUploadHandler() {
    if (uploadProgress()) {  // Validate result
        var uploadForm = document.getElementsByName("upload")[0];

        if (window.ActiveXObject) {  // IE
            // Add a callback to handle the response when the upload is complete
            document.getElementById("upload_target").onload = function() {
                var uploadedIframe = document.frames["upload_target"];

                var response = uploadedIframe.document.body.innerText;
                
                var xml = parseXMLString(response)
        
                stopUpload(xml.UploadedFileName, xml.FileName, xml.FileTmpID,
                    xml.Success, xml.ResultDesc, xml.hashcode, xml.HashcodeCal,
                    xml.FileSize, xml.FileAmt, xml.FileTxn, xml.FileAmtInv,
                    xml.FileTxnInv, xml.FileAmtRead, xml.FileTxnRead, xml.FileEffDate
                )
                    
            };
            
            uploadForm.target = "upload_target";
            uploadForm.submit();

        } else {  // FF, Chrome, Edge
            var formData = new FormData(uploadForm);

            // Upload post request with XHR
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState==4 && xhr.status == 200) {                
                    var xml = xhr.responseXML;
                    stopUpload(
                        xml.getElementsByTagName("UploadedFileName")[0].textContent,
                        xml.getElementsByTagName("FileName")[0].textContent,
                        xml.getElementsByTagName("FileTmpID")[0].textContent,
                        xml.getElementsByTagName("Success")[0].textContent,
                        xml.getElementsByTagName("ResultDesc")[0].textContent,
                        xml.getElementsByTagName("hashcode")[0].textContent,
                        xml.getElementsByTagName("HashcodeCal")[0].textContent,
                        xml.getElementsByTagName("FileSize")[0].textContent,
                        xml.getElementsByTagName("FileAmt")[0].textContent,
                        xml.getElementsByTagName("FileTxn")[0].textContent,
                        xml.getElementsByTagName("FileAmtInv")[0].textContent,
                        xml.getElementsByTagName("FileTxnInv")[0].textContent,
                        xml.getElementsByTagName("FileAmtRead")[0].textContent,
                        xml.getElementsByTagName("FileTxnRead")[0].textContent,
                        xml.getElementsByTagName("FileEffDate")[0].textContent
                    );
                }
            };
            xhr.open("post", uploadForm.getAttribute("action"), true);
            xhr.send(formData);
        }
    }
}

function getCompDetailHelp(){

   
    // Call Ajax
    if (window.ActiveXObject){// IE
        xhr=new ActiveXObject("Microsoft.XMLHTTP");
    }else{ // FF,Chrome
        xhr=new XMLHttpRequest();
    }

    if (document.getElementById("compcode").value == '0') {
        document.getElementById("atsservice").value = '';
        document.getElementById("appcode").value = '';
        //        document.getElementById("compname").value = '';
        document.getElementById("comptype").value = '';
        document.getElementById("dcrefundac").value = '';
        document.getElementById("autocreditfg").value = '';
        document.getElementById("ddmancrac").value = '';
        document.getElementById("autorefundfg").value = '';
        document.getElementById("inputformat").value = '';
        document.getElementById("parsetmpid").value = '';
        document.getElementById("parseappcode").value = '';
        document.getElementById("batchtype").value = '';
//        document.getElementById("divcustcompcode").style.display = 'none';
        document.getElementById("divloadcompdetail").style.display = 'none';
    } else {
        //        document.getElementById("divloadcompdetail").style.visibility = 'visible';
        document.getElementById("divloadcompdetail").style.display = '';

        //2. Prepare CallBack
        xhr.onreadystatechange= function(){
            if (xhr.readyState==4 && xhr.status == 200){
                //4. Get Response
                var xml = xhr.responseXML;

                var ps = xml.getElementsByTagName("compdetail");

                for (var i = 0; i < ps.length;i++){

                    var appcode = ps[i].getElementsByTagName("appcode")[0].firstChild.nodeValue;
                    //                    var compname = ps[i].getElementsByTagName("compname")[0].firstChild.nodeValue;
                    var comptype = ps[i].getElementsByTagName("comptype")[0].firstChild.nodeValue;
                    var drcrtype = ps[i].getElementsByTagName("drcrtype")[0].firstChild.nodeValue;
                    //                var batchtype = ps[i].getElementsByTagName("batchtype")[0].firstChild.nodeValue;
                    var autocreditac = ps[i].getElementsByTagName("autocreditac")[0].firstChild.nodeValue;
                    var autocreditfg = ps[i].getElementsByTagName("autocreditfg")[0].firstChild.nodeValue;
                    var autorefundac = ps[i].getElementsByTagName("autorefundac")[0].firstChild.nodeValue;
                    var autorefundfg = ps[i].getElementsByTagName("autorefundfg")[0].firstChild.nodeValue;
                    var inputformat = ps[i].getElementsByTagName("inputformat")[0].firstChild.nodeValue;
                    var batchtype = ps[i].getElementsByTagName("batchtype")[0].firstChild.nodeValue;
                    var bdcomp = ps[i].getElementsByTagName("bdcomp")[0].firstChild.nodeValue;

                    document.getElementById("atsservice").value = drcrtype
                    document.getElementById("appcode").value = appcode;
                    document.getElementById("parseappcode").value = appcode;
//                    document.getElementById("compname").value = compname;
//                    document.getElementById("comptype").value = comptype;
                    document.getElementById("comptype").value = "B";

                    // Credit
                    if (drcrtype == 'C') {
                        
                        document.getElementById("autorefundfg").value = autorefundfg;
                        document.getElementById("dcrefundac").value = autorefundac;
                        //                        alert(autorefundfg + " - " + autocreditac.length);
                    }
                    
                   
                    //                    if (autorefundfg == 'Y') {
                    //                        document.getElementById("dcrefundac").value = '9999999999';
                    //                        document.getElementById("lblAutoTransfer").style.display = '';
                    //                        document.getElementById("lblBranchHandle").style.display = 'none';
                    //                        document.getElementById("lblHOHandle").style.display = 'none';
                    //                    } else {
                    //                        if (autocreditac != '' ){
                    //                            alert('Credit Account Not Null');
                    //                            document.getElementById("dcrefundac").value = autocreditac;
                    //                            document.getElementById("lblAutoTransfer").style.display = 'none';
                    //                            document.getElementById("lblBranchHandle").style.display = 'none';
                    //                            document.getElementById("lblHOHandle").style.display = '';
                    //                        } else {
                    //                            alert('Credit Account Null');
                    //                            document.getElementById("lblAutoTransfer").style.display = 'none';
                    //                            document.getElementById("lblBranchHandle").style.display = '';
                    //                            document.getElementById("lblHOHandle").style.display = 'none';
                    //                        }
                    //                    }
                    

                    // Debit
                    if (drcrtype == 'D') {
                        alert(autocreditac);
                        document.getElementById("autocreditfg").value = autocreditfg;
                        document.getElementById("ddmancrac").value = autocreditac;
                        //                        alert(autocreditfg + " - " + autorefundac.length );
                    }
                    
                    
                    //                    alert("text " + autorefundac + "text");
                    //                    if (autocreditfg == 'Y') {
                    //                        document.getElementById("ddmancrac").value = '9999999999';
                    //                        document.getElementById("lblAutoTransfer").style.display = '';
                    //                        document.getElementById("lblBranchHandle").style.display = 'none';
                    //                        document.getElementById("lblHOHandle").style.display = 'none';
                    //                    } else {
                    //                        if (autorefundac != null ){
                    //                            alert('Debit Account Not Null');
                    //                            document.getElementById("ddmancrac").value = autorefundac;
                    //                            document.getElementById("lblAutoTransfer").style.display = 'none';
                    //                            document.getElementById("lblBranchHandle").style.display = 'none';
                    //                            document.getElementById("lblHOHandle").style.display = '';
                    //                        } else {
                    //                            alert('Debit Account Null');
                    //                            document.getElementById("lblAutoTransfer").style.display = 'none';
                    //                            document.getElementById("lblBranchHandle").style.display = '';
                    //                            document.getElementById("lblHOHandle").style.display = 'none';
                    //                        }
                    //                    }
                    

                    //                    alert(inputformat);
                    
                    document.getElementById("inputformat").value = inputformat;
                    document.getElementById("parsetmpid").value = inputformat;
                    
                    document.getElementById("batchtype").value = batchtype;
                    document.getElementById("bdcomp").value = bdcomp;

                    //set readonly menu
                    document.getElementById("appcode").readOnly = true;
                    //                    document.getElementById("compname").readOnly = true;
                    document.getElementById("comptype").readOnly = true;
                    document.getElementById("inputformat").readOnly = true;

//                    if (document.getElementById("comptype").value == 'B') {
//                        document.getElementById("divcustcompcode").style.display = '';
//                    } else {
//                        document.getElementById("divcustcompcode").style.display = 'none';
//                    }

                    AtsServiceSetup(drcrtype);
                    document.getElementById("dd").disabled = true;
                    document.getElementById("dc").disabled = true;

                }
                document.getElementById("divloadcompdetail").style.display = 'none';
            }
        }
        //3. Send request
        var compcode = document.getElementById("custcompcode").value;

        xhr.open("post","AtsTxnNewAjax",true);
        xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        xhr.send("compcode="+compcode + "&key=" + Math.random());
    }
    
    
}
function getCompDetail(){

     document.getElementsByName("roundtype").item(0).checked=true;
    document.getElementsByName("samedaytime").item(0).disabled = true;
        document.getElementById("batchtype").disabled = false;
    // Call Ajax
    if (window.ActiveXObject){// IE
        xhr=new ActiveXObject("Microsoft.XMLHTTP");
    }else{ // FF,Chrome
        xhr=new XMLHttpRequest();
    }

    if (document.getElementById("compcode").value == '0') {
        document.getElementById("atsservice").value = '';
        document.getElementById("appcode").value = '';
        //        document.getElementById("compname").value = '';
        document.getElementById("comptype").value = '';
        document.getElementById("dcrefundac").value = '';
        document.getElementById("autocreditfg").value = '';
        document.getElementById("ddmancrac").value = '';
        document.getElementById("autorefundfg").value = '';
        document.getElementById("inputformat").value = '';
        document.getElementById("parsetmpid").value = '';
        document.getElementById("parseowntmpid").value = '';
        document.getElementById("parseappcode").value = '';
        document.getElementById("parseownappcode").value = '';
        document.getElementById("batchtype").value = '';
        document.getElementById("divcustcompcode").style.display = 'none';
        document.getElementById("divloadcompdetail").style.display = 'none';
    } else {
        //        document.getElementById("divloadcompdetail").style.visibility = 'visible';
        document.getElementById("divloadcompdetail").style.display = '';

        //2. Prepare CallBack
        xhr.onreadystatechange= function(){
            if (xhr.readyState==4 && xhr.status == 200){
                //4. Get Response
                var xml = xhr.responseXML;

                var ps = xml.getElementsByTagName("compdetail");

                for (var i = 0; i < ps.length;i++){

                    var appcode = ps[i].getElementsByTagName("appcode")[0].firstChild.nodeValue;
                    //                    var compname = ps[i].getElementsByTagName("compname")[0].firstChild.nodeValue;
                    var comptype = ps[i].getElementsByTagName("comptype")[0].firstChild.nodeValue;
                    var drcrtype = ps[i].getElementsByTagName("drcrtype")[0].firstChild.nodeValue;
                    //                var batchtype = ps[i].getElementsByTagName("batchtype")[0].firstChild.nodeValue;
                    var autocreditac = ps[i].getElementsByTagName("autocreditac")[0].firstChild.nodeValue;
                    var autocreditfg = ps[i].getElementsByTagName("autocreditfg")[0].firstChild.nodeValue;
                    var autorefundac = ps[i].getElementsByTagName("autorefundac")[0].firstChild.nodeValue;
                    var autorefundfg = ps[i].getElementsByTagName("autorefundfg")[0].firstChild.nodeValue;
                    var inputformat = ps[i].getElementsByTagName("inputformat")[0].firstChild.nodeValue;
                    var batchtype = ps[i].getElementsByTagName("batchtype")[0].firstChild.nodeValue;
                    var bdcomp = ps[i].getElementsByTagName("bdcomp")[0].firstChild.nodeValue;

                    document.getElementById("atsservice").value = drcrtype
                    document.getElementById("appcode").value = appcode;
                    document.getElementById("parseappcode").value = appcode;
                    document.getElementById("parseownappcode").value = appcode;
                    //                    document.getElementById("compname").value = compname;
                    document.getElementById("comptype").value = comptype;

                    // Credit
                    if (drcrtype == 'C') {
                        document.getElementById("autorefundfg").value = autorefundfg;
                        document.getElementById("dcrefundac").value = autorefundac;
                        //                        alert(autorefundfg + " - " + autocreditac.length);
                    }
                    
                   
                    //                    if (autorefundfg == 'Y') {
                    //                        document.getElementById("dcrefundac").value = '9999999999';
                    //                        document.getElementById("lblAutoTransfer").style.display = '';
                    //                        document.getElementById("lblBranchHandle").style.display = 'none';
                    //                        document.getElementById("lblHOHandle").style.display = 'none';
                    //                    } else {
                    //                        if (autocreditac != '' ){
                    //                            alert('Credit Account Not Null');
                    //                            document.getElementById("dcrefundac").value = autocreditac;
                    //                            document.getElementById("lblAutoTransfer").style.display = 'none';
                    //                            document.getElementById("lblBranchHandle").style.display = 'none';
                    //                            document.getElementById("lblHOHandle").style.display = '';
                    //                        } else {
                    //                            alert('Credit Account Null');
                    //                            document.getElementById("lblAutoTransfer").style.display = 'none';
                    //                            document.getElementById("lblBranchHandle").style.display = '';
                    //                            document.getElementById("lblHOHandle").style.display = 'none';
                    //                        }
                    //                    }
                    

                    // Debit
                    if (drcrtype == 'D') {
                        document.getElementById("autocreditfg").value = autocreditfg;
                        document.getElementById("ddmancrac").value = autocreditac;
                        //                        alert(autocreditfg + " - " + autorefundac.length );
                    }
                    
                    
                    //                    alert("text " + autorefundac + "text");
                    //                    if (autocreditfg == 'Y') {
                    //                        document.getElementById("ddmancrac").value = '9999999999';
                    //                        document.getElementById("lblAutoTransfer").style.display = '';
                    //                        document.getElementById("lblBranchHandle").style.display = 'none';
                    //                        document.getElementById("lblHOHandle").style.display = 'none';
                    //                    } else {
                    //                        if (autorefundac != null ){
                    //                            alert('Debit Account Not Null');
                    //                            document.getElementById("ddmancrac").value = autorefundac;
                    //                            document.getElementById("lblAutoTransfer").style.display = 'none';
                    //                            document.getElementById("lblBranchHandle").style.display = 'none';
                    //                            document.getElementById("lblHOHandle").style.display = '';
                    //                        } else {
                    //                            alert('Debit Account Null');
                    //                            document.getElementById("lblAutoTransfer").style.display = 'none';
                    //                            document.getElementById("lblBranchHandle").style.display = '';
                    //                            document.getElementById("lblHOHandle").style.display = 'none';
                    //                        }
                    //                    }
                    
                    document.getElementById("inputformat").value = inputformat;
                    document.getElementById("parsetmpid").value = inputformat;
                    document.getElementById("parseowntmpid").value = inputformat;
                    document.getElementById("batchtype").value = batchtype;
                    document.getElementById("bdcomp").value = bdcomp;

                    //set readonly menu
                    document.getElementById("appcode").readOnly = true;
                    //                    document.getElementById("compname").readOnly = true;
                    document.getElementById("comptype").readOnly = true;
                    document.getElementById("inputformat").readOnly = true;

                    if (document.getElementById("comptype").value == 'B') {
                        document.getElementById("divcustcompcode").style.display = '';
                    } else {
                        document.getElementById("divcustcompcode").style.display = 'none';
                    }

                    AtsServiceSetup(drcrtype);
                    document.getElementById("dd").disabled = true;
                    document.getElementById("dc").disabled = true;

                }
                document.getElementById("divloadcompdetail").style.display = 'none';
            }
        }
        //3. Send request
        var compcode = document.getElementById("compcode").value;

        xhr.open("post","AtsTxnNewAjax",true);
        xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
        xhr.send("compcode="+compcode + "&key=" + Math.random());
    }
    
    
}


function getRoundTime(){
    if (window.ActiveXObject){// IE
        xhr=new ActiveXObject("Microsoft.XMLHTTP");
    }else{ // FF,Chrome
        xhr=new XMLHttpRequest();
    }

    //2. Prepare CallBack
    xhr.onreadystatechange= function(){
        if (xhr.readyState==4 && xhr.status == 200){

            //4. Get Response
            var result = document.getElementById("samedaytime");
            result.options.length=0;

            var xml  = xhr.responseXML;
            var ps = xml.getElementsByTagName("drcrtime");

            if (ps.length > 0) {
                for (var i = 0; i < ps.length;i++){
                    var roundtime = ps[i].getElementsByTagName("roundtime")[0].firstChild.nodeValue

                    if (i==0) {
                        result.options[i]=new Option(roundtime,'0'); // insert data to combo box
                    } else {
                        result.options[i]=new Option(roundtime,roundtime); // insert data to combo box
                    }
                    
                }
                
                //                document.getElementById("divLoadingSameday").style.visibility = 'hidden';
                document.getElementById("divLoadingSameday").style.display = 'none';
                
            } else {
                alert("Cannot Load Roundtime");
            }
        }
    }

    //3. Send request

    //    document.getElementById("divLoadingSameday").style.visibility = 'visible';
    document.getElementById("divLoadingSameday").style.display = '';

    var effdate = document.getElementById("effdate").value;
    if (document.getElementById("dd").checked == true){
        atsservice = "D";
    } else {
        atsservice = "C";
    }
    //    var atsservice = document.getElementById("atsservice").value;
    //    var roundtype = document.getElementById("roundtype").value;
    if (document.getElementById("sd").checked == true) {
        roundtype = "S";
    }

    xhr.open("post","AtsTxnAjaxGetTime",true);
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
    xhr.send("effdate="+effdate + "&atsservice="+atsservice+"&roundtype="+roundtype+"&key=" + Math.random());
}

function AtsServiceSetup(drcrtype){

    //    alert(drcrtype);
    if (drcrtype == 'D') {
        //Direct Debit
        document.getElementById("dd").checked = true;

        document.getElementById("dcdrdate").disabled = true;
        document.getElementById("dcdebitday").disabled = true;
        document.getElementById("dcrefundac").disabled = true;
        document.getElementById("autorefundfg").disabled = true;
        document.getElementById("dcdrac").disabled = true;
        document.getElementById("dcchqbank").disabled = true;
        document.getElementById("feeib").disabled = true;
        document.getElementById("feeir").disabled = true;
        document.getElementById("feeother").disabled = true;
        document.getElementById("ddmancrac").disabled = false;
        document.getElementById("autocreditfg").disabled = false;

        document.getElementById("lbleffdateDD").style.display = '';
        document.getElementById("lbleffdateDC").style.display = 'none';
        document.getElementById("divDD").style.display = '';
        document.getElementById("divDC").style.display = 'none';
        document.getElementById("divDDDetail").style.display = '';
        document.getElementById("divDCDetail").style.display = 'none';

        if (document.getElementById("autocreditfg").value == 'Y') {
            document.getElementById("ddmancrac").value = '9999999999';
            document.getElementById("lblAutoTransfer").style.display = '';
            document.getElementById("lblBranchHandle").style.display = 'none';
            document.getElementById("lblHOHandle").style.display = 'none';
        } else {
            if (document.getElementById("ddmancrac").value.length != 1 ){ // เพราะ XML Return Chr(13)
                //                alert('Debit Account Not Null' + document.getElementById("ddmancrac").value.length);
                //                document.getElementById("ddmancrac").value = autorefundac;
                document.getElementById("lblAutoTransfer").style.display = 'none';
                document.getElementById("lblBranchHandle").style.display = 'none';
                document.getElementById("lblHOHandle").style.display = '';
            } else {
                //                alert('Debit Account Null');
                document.getElementById("ddmancrac").value = '0000000000';
                document.getElementById("lblAutoTransfer").style.display = 'none';
                document.getElementById("lblBranchHandle").style.display = '';
                document.getElementById("lblHOHandle").style.display = 'none';
            }
        }

    } else {
        //Direct Credit
        document.getElementById("dc").checked = true;

        document.getElementById("dcdrdate").disabled = false;
        document.getElementById("dcdebitday").disabled = false;
        document.getElementById("dcrefundac").disabled = false;
        document.getElementById("autorefundfg").disabled = false;
        document.getElementById("dcdrac").disabled = false;
        document.getElementById("dcchqbank").disabled = false;
        document.getElementById("feeib").disabled = false;
        document.getElementById("feeir").disabled = false;
        document.getElementById("feeother").disabled = false;
        document.getElementById("ddmancrac").disabled = true;
        document.getElementById("autocreditfg").disabled = true;

        document.getElementById("lbleffdateDD").style.display = 'none';
        document.getElementById("lbleffdateDC").style.display = '';
        document.getElementById("divDD").style.display = 'none';
        document.getElementById("divDC").style.display = '';
        document.getElementById("divDDDetail").style.display = 'none';
        document.getElementById("divDCDetail").style.display = '';

        if (document.getElementById("autorefundfg").value == 'Y') {
            document.getElementById("dcrefundac").value = '9999999999';
            document.getElementById("lblAutoTransfer").style.display = '';
            document.getElementById("lblBranchHandle").style.display = 'none';
            document.getElementById("lblHOHandle").style.display = 'none';
        } else {
            
            if (document.getElementById("dcrefundac").value.length != 1 ){ // เพราะ XML Return Chr(13)
                //                alert('Credit Account Not Null' + document.getElementById("dcrefundac").value.length);
                //                document.getElementById("dcrefundac").value = autocreditac;
                document.getElementById("lblAutoTransfer").style.display = 'none';
                document.getElementById("lblBranchHandle").style.display = 'none';
                document.getElementById("lblHOHandle").style.display = '';
            } else {
                //                alert('Credit Account Null');
                document.getElementById("dcrefundac").value = '0000000000';
                document.getElementById("lblAutoTransfer").style.display = 'none';
                document.getElementById("lblBranchHandle").style.display = '';
                document.getElementById("lblHOHandle").style.display = 'none';
            }
        }

    }

}

function RoundTypeSetup(){

    if (document.getElementsByName("roundtype").item(0).checked == true) {
        //Batch
        document.getElementsByName("samedaytime").item(0).disabled = true;
        document.getElementById("batchtype").disabled = false;

    } else {
        //Same Day
        if (document.getElementById("effdate").value != '') {
            document.getElementsByName("samedaytime").item(0).disabled= false;
            document.getElementById("batchtype").disabled = true;
            getRoundTime();
        } else {
            alert ("กรุณาเลือก effective date");
            document.getElementsByName("roundtype").item(0).checked = true
        }
        
    }
}

// Validate Mandatory Field
function validateField(){

    if (document.getElementById('objective').value == '0'){
        alert("กรุณาเลือก Objective");
        document.getElementById('objective').focus();
        return false;
    }

    if (document.getElementById('compcode').value == '0'){
        alert("กรุณาเลือก Company Code");
        document.getElementById('compcode').focus();
        return false;
    }

    if (document.getElementById('effdate').value == ''){
        alert("กรุณาเลือก Effective Date");
        document.getElementById('effdate').focus();
        return false;
    }

    //Check Select SameDay Time
    if (document.getElementsByName("roundtype").item(1).checked == true){
        if (document.getElementById('samedaytime').value == '0'){
            alert("กรุณาเลือกเวลาการทำรายการ");
            document.getElementById('samedaytime').focus();
            return false;
        }
    }

    var atsdesc = document.getElementById('atsdesc').value;
    if (atsdesc == '') {
        atsdesc = '0';
    }


    document.getElementById("totalfeeamt").value = removeCommas(document.getElementById("totalfeeamt").value); // Remove Comma for Insert into DB
    //    alert("fee : " + document.getElementById("totalfeeamt").value);
    if (isNaN(removeCommas(document.getElementById("totalfeeamt").value))){
        alert("กรุณากรอกยอดค่าธรรมเนียม");
        document.getElementById("totalfeeamt").focus();
        return false;
    }

    document.getElementById("sumamt").value = removeCommas(document.getElementById("sumamt").value); // Remove Comma for Insert into DB
    //    alert("Amount : " + document.getElementById("sumamt").value);
    if (isNaN(removeCommas(document.getElementById("sumamt").value))){
        alert("กรุณากรอกยอดเงินโอน");
        document.getElementById("sumamt").focus();
        return false;
    }

    if (isNaN(document.getElementById("sumtxn").value)){
        alert("กรุณากรอกจำนวนรายการ");
        document.getElementById("sumtxn").focus();
        return false;
    }

    if (document.getElementById("nofile").value > 0) {
        //        alert("Have Upload Files");
        var fileeff = document.getElementsByName("FILEEFFDATE[]");
        var getEffdate = document.getElementById("effdate").value;

        for (var i = 0 ; i < fileeff.length ; i++){
            getFileEffdate = fileeff[i].value;
            //            alert("Validate : " + getEffdate + " - " + getFileEffdate);
            if (chkBackDate(getFileEffdate, getEffdate) == "1"){
                var backdateCompcode = document.getElementById("bdcomp").value;
                if (backdateCompcode.length == 1){
                    alert("Compcode : " + backdateCompcode + " ไม่สามารถทำรายการย้อนหลังได้");
                    return false;
                } 
            } else if (chkBackDate(getFileEffdate, getEffdate) == "2"){
                alert("ระบุวันที่ทำรายการ ไม่ตรงกับข้อมูล !!!");
//                alert("ไม่สามารถทำรายการวันที่ทำรายการกับวันที่ของในไฟล์ไม่ตรงกัน");
                return false;
            }
        }
        
    }

    document.AtsNewTxnForm.submit();

}

function resetPage(){
    window.location = "./AtsTxnNewServlet"
}

function resetCancelPage(){
    window.location = "./AtsTxnViewCancel.jsp"
}
function resetApprovePage(){
    window.location = "./AtsTxnViewApprove.jsp"
}
function resetRevisePage(){
    window.location = "./AtsTxnViewRevise.jsp"
}

// For Add & Remove File List
function uploadProgress(){
    
    document.getElementById("upfile").disabled=true;
    var hashcode = document.getElementById('hashcode').value;
//      tmOut=setTimeout("TestDelay();", 6000);

    if (document.getElementById('comptype').value == 'B') {
        var parseComp = document.getElementById('custcompcode').value;
//        document.getElementById("parsecompcode").value = parseComp; // Parse Compcode for check
        document.getElementById("parsecompcode").value =document.getElementById('compcode').value;
        document.getElementById("parsecustcomp").value = document.getElementById('custcompcode').value; // Parse Compcode for check
        document.getElementById("parsecomptype").value = 'B'; // Parse Compcode for check        
    } else {
        var parseComp = document.getElementById('compcode').value;
        document.getElementById("parsecompcode").value = parseComp; // Parse Compcode for check
        document.getElementById("parsecomptype").value =document.getElementById('comptype').value; // Parse Compcode for check        
    }
    

//    if ((document.getElementById('inputformat').value == '80B10M') || (document.getElementById('inputformat').value == '80B100M')) {
//        if (hashcode == ''){
//            alert("กรุณาใส่ hash total !!!");
//            return false;
//        } else {
//            document.getElementById("divLoadingProgress").style.display = '';
//            document.getElementById("Insert").disabled = true;
//            document.getElementById("lblWarning").style.display = 'none';
//            tmOut=setTimeout("UpdTimeout();", 60000);    
////            alert(tmOut);
//            return true;
//        }
//    } else {
        if (document.getElementById('hashcode').value == '') {            
            document.getElementById('hashcode').value = "0";
        }
        //document.getElementById("divLoadingProgress").style.display = '';
        document.getElementById("Insert").disabled = true;
        document.getElementById("lblWarning").style.display = 'none';
        tmOut=setTimeout("UpdTimeout();", 60000);    
        return true;
//    }

}
function UpdTimeout(){
        
        alert("การติดต่อสื่อสารขัดข้อง");
        window.location="./index.jsp"
}
function addFileList(UploadFilename,Filename,FileTmpId, HashCode, CalHashCode
    , FileSize, FileAmt, FileTxn, FileAmtInv, FileTxnInv, FileAmtRead, FileTxnRead, FileEffDate) {
    // Add ID for div
    var ni = document.getElementById('fileDiv');
    var numi = document.getElementById('numfileValue');
    var num = (document.getElementById('numfileValue').value -1) + 2;
    var showHash = CalHashCode;
    numi.value = num;

    if (!document.getElementById("fileInfo")) {
        var fileInfo = document.createElement('div');
        fileInfo.setAttribute('id', "fileInfo");
        document.forms["AtsNewTxnForm"].appendChild(fileInfo);
    }
    
    var newdiv = document.createElement('div');
    var divIdName = 'fileList' + num;
    var newdivInfo = document.createElement('div');
    var divInfoIdName = 'fileInfoList' + num;

    if (FileTmpId != "80B10M" && FileTmpId != "80B100M"){
        showHash=" ";        
    }else{
        showHash= "  <b> Hash Code:</b> " + showHash + " <font class='errText'> ** กรุณาตรวจสอบ Hash Code </font>"
        
    }
        
    
    newdiv.setAttribute('id', divIdName);
    newdivInfo.setAttribute('id', divInfoIdName);
    newdiv.innerHTML =
        //        '<input type="button" name="'+divIdName+'" value="ยกเลิกไฟล์" onclick=\'removeFileList("'+divIdName+`, `+divInfoIdName+'")\'>'
    " <b>File:</b>" + UploadFilename + showHash;
    newdivInfo.innerHTML =
        '<input type="hidden" name="FILEtmp" value="'+ Filename +'">'
        + '<input type="hidden" name="FILENAME[]" value="'+ Filename +'">'
        + '<input type="hidden" name="FILETMPID[]" value="'+ FileTmpId +'">'
        + '<input type="hidden" name="USERHASHCODE[]" value="'+ HashCode +'">'
        + '<input type="hidden" name="CALHASHCODE[]" value="'+ CalHashCode +'">'
        + '<input type="hidden" name="FILESIZE[]" value="'+ FileSize +'">'
        + '<input type="hidden" name="FILEAMT[]" value="'+ FileAmt +'">'
        + '<input type="hidden" name="FILETXN[]" value="'+ FileTxn +'">'
        + '<input type="hidden" name="FILEAMTINV[]" value="'+ FileAmtInv +'">'
        + '<input type="hidden" name="FILETXNINV[]" value="'+ FileTxnInv +'">'
        + '<input type="hidden" name="FILEAMTREAD[]" value="'+ FileAmtRead +'">'
        + '<input type="hidden" name="FILETXNREAD[]" value="'+ FileTxnRead +'">'
        + '<input type="hidden" name="FILEEFFDATE[]" value="'+ FileEffDate +'">';

    ni.appendChild(newdiv);
    document.getElementById("fileInfo").appendChild(newdivInfo);

    var filenum=document.getElementsByName("FILENAME[]");
    document.getElementById('nofile').value = filenum.length;

    //Set Readonly to summary Txn & Amt
    document.getElementById("sumamt").readOnly = true;
    document.getElementById("sumtxn").readOnly = true;

    //    var txni = document.getElementById('sumtxn');
    //    var txn = (document.getElementById('sumtxn').value -1) + 1 + FileTxn;
    //    txni.value = txn;
    //
    //    var amti = document.getElementById('sumamt');
    //    var amt = (document.getElementById('sumamt').value -1) + 1 + FileAmt;
    //    amti.value = amt;

    getElements();

}

function removeFileList(divNum, divInfoNum){
    var d = document.getElementById('fileDiv');
    var dInfo = document.getElementById('fileInfo');
    var olddiv = document.getElementById(divNum);
    var olddivInfo = document.getElementById(divInfoNum);
    d.removeChild(olddiv);
    dInfo.removeChild(olddivInfo);

    var filenum=document.getElementsByName("FILENAME[]");
    document.getElementById('nofile').value = filenum.length;

    getElements();

    if (filenum.length == 0){
        document.getElementById("sumamt").readOnly = false;
        document.getElementById("sumtxn").readOnly = false;
    }
    
}

function startUpload(){
    //    document.getElementById('f1_upload_process').style.visibility = 'visible';
    document.getElementById('f1_upload_process').style.display = '';
    return true;
}

function stopUpload(uploadfilename,filename,filetmpid,success,resultdesc,hashcode,calhashcode,filesize,fileamt,filetxn
                        ,fileamtinv,filetxninv,fileamtread,filetxnread,fileeffdate){
//        alert(tmOut)
//    clearTimeout(tmOut);    
   
    //    alert(tmOut);
    //document.getElementById("divLoadingProgress").style.display = 'none';
    clearTimeout(tmOut)

    if (success != null) {
        
        //        alert("Filename = " + filename);
        //        alert("Result = " + success);
        //        if (filename != null) {
                
        if (success == "1"){
            alert("Upload File เรียบร้อย");
            addFileList(uploadfilename,filename,filetmpid,hashcode,calhashcode,filesize,fileamt,filetxn,fileamtinv
                ,filetxninv,fileamtread,filetxnread,fileeffdate);

            document.getElementById("Insert").disabled = false;
            document.getElementById("lblWarning").style.display = ''
        } else {
            alert("ไม่สามารถ upload File ได้เนื่องจาก : " + resultdesc);
            if (document.getElementById("octype").value == 'B'){
                document.getElementById("Insert").disabled = true;
                document.getElementById("lblWarning").style.display = 'none'
            }
        }
        //        } else {
        //            alert("ตายห่าน !!!");
        //        }

        //        if (success == 1){
        //            document.getElementById('result').innerHTML = '<span class="msg">The file was uploaded successfully!<\/span><br/><br/>';
        //        } else {
        //            document.getElementById('result').innerHTML =
        //            '<span class="emsg">There was an error during file upload!<\/span><br/><br/>';
        //        }
        //        document.getElementById('f1_upload_process').style.visibility = 'hidden';

        document.getElementById('hashcode').value = '';
        document.getElementById('uploaded').value = '';
        
        
        //        document.getElementById("Insert").disabled = false;
        
        //return true;
    }
 

}

function getElements(){
    var x = document.getElementsByName("FILENAME[]");
    var txni = document.getElementsByName('FILETXN[]');
//    var amti = document.getElementsByName('FILEAMT[]');
    var amti = document.getElementsByName('FILEAMTREAD[]');
    
//    FileAmtRead
    var sumtxn = 0;
    var sumamt = 0;

    for (var i = 0 ; i < x.length ; i++){
        //        alert(x.item(i).value);
        sumtxn = sumtxn + (txni.item(i).value - 1) + 1;
        sumamt = sumamt + (amti.item(i).value - 1 + 1);

    }

    sumamt = ((sumamt + 1 - 1) / 100).toFixed(2); // to Format Number

    document.getElementById('sumtxn').value = sumtxn;

    document.getElementById('sumamt').value = sumamt;
    showFormatNumber(document.getElementById('sumamt'));
    
    if (document.getElementById("octype").value == 'B'){
        if (x.length > 0) {
            document.getElementById("Insert").disabled = false;
            document.getElementById("lblWarning").style.display = '';
        } else {
            document.getElementById("Insert").disabled = true;
            document.getElementById("lblWarning").style.display = 'none';
        }
    }
    
}

function testDeleteAll(){
    var x=document.getElementsByName("FILENAME[]");

    for (var i = 0 ; i < x.length ; i++){
        alert(x.item(i).value);
    }

}

function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

//function removeCommas(field){
//    var result = field.value.replace(",", "")
//
//    alert("result = " + result);
//    field.value =result;
//
//}

function removeCommas(strNum){
    var result = strNum.split(',').join('');
    return result;

}


function showFormatNumber(field) {
    // Remove Comma First
    var test = removeCommas(field.value);

    // Change Format
    var result = (test -1 + 1).toFixed(2);
    field.value = addCommas(result);

}

//function showFormatNumber(field) {
//
//    var result = (field.value -1 + 1).toFixed(2);
//    field.value = result;
//
//}

function numbersonlyInt(myfield, e, dec)
{
    var key;
    var keychar;

    if (window.event)
        key = window.event.keyCode;
    else if (e)
        key = e.which;
    else
        return true;
    keychar = String.fromCharCode(key);

    // control keys
    if ((key==null) || (key==0) || (key==8) ||
        (key==9) || (key==13) || (key==27) )
        return true;

    // numbers
    else if ((("0123456789").indexOf(keychar) > -1))
        return true;

    // decimal point jump
    else if (dec && (keychar == "."))
    {
        myfield.form.elements[dec].focus();
        return false;
    }
    else
        return false;
}

function numbersonlyDecimal(myfield, e, dec)
{
    var key;
    var keychar;

    if (window.event)
        key = window.event.keyCode;
    else if (e)
        key = e.which;
    else
        return true;
    keychar = String.fromCharCode(key);

    // control keys
    if ((key==null) || (key==0) || (key==8) ||
        (key==9) || (key==13) || (key==27) || (key==46))
        return true;

    // numbers
    else if ((("0123456789").indexOf(keychar) > -1))
        return true;
    
    else
        return false;
}

function ValidateKeyPress(myfield, e, dec)
{
    var key;
    var keychar;

    if (window.event)
        key = window.event.keyCode;
    else if (e)
        key = e.which;
    else
        return true;
    keychar = String.fromCharCode(key);

    // control keys
    if ((key==null) || (key==0) || (key==8) ||
        (key==9) || (key==13) || (key==27) || (key==46) || (key==32))
        return true;

    else if (((key >= 65) && (key <= 90)) || ((key >= 97) && (key <= 122)))
    // Thai || ((key >= 161) && (key <=250))
        return true;
    
    // numbers
    else if ((("0123456789").indexOf(keychar) > -1))
        return true;

    else
        return false;
}


function chkBackDate (FileDate, EffDate){

    //    alert (FileDate + " - " + EffDate);
//    FileDate = "2012-02-10";
//    EffDate = "2012-02-10";

    var YYYY = parseInt(FileDate.substring(0, 4));
    var MM = parseInt(FileDate.substring(5,7)) - 1;
    var DD = parseInt(FileDate.substring(8, 10));

    var eYYYY = parseInt(EffDate.substring(0, 4));
    var eMM = parseInt(EffDate.substring(5,7)) - 1;
    var eDD = parseInt(EffDate.substring(8, 10));

    var x=new Date();
    x.setFullYear(YYYY,MM,DD);
    
    var y=new Date();
    y.setFullYear(eYYYY,eMM,eDD);

//    alert(x + " - " + y);

    if (x < y) {
//        alert("Back Date");
        return "1";
    } else if (x > y) {
//        alert("Tomorrow");
        return "2";
    } else {
//        alert("Today");
        return "0";
    }
}

function enaBtn(enaFlag){
    document.getElementById("upfile").disabled=enaFlag;
    
}
//function testGet(){
//    var FileDate = document.getElementById("effdate").value;
//    var YYYY = parseInt(FileDate.substring(0, 4));
//    var MM = parseInt(FileDate.substring(5,7)) - 1;
//    var DD = parseInt(FileDate.substring(8, 10));
//
//    alert(FileDate + " - " + YYYY + " - " + MM + " - " + DD);
//}

//            function addElement() {
//
//                var ni = document.getElementById('myDiv');
//                var numi = document.getElementById('theValue');
//                var num = (document.getElementById('theValue').value -1)+ 2;
//                numi.value = num;
//
//                var newdiv = document.createElement('div');
//                var divIdName = 'my'+num+'Div';
//
//                newdiv.setAttribute('id',divIdName);
//                newdiv.innerHTML = 'Element Number '+num+' has been added! <a href=\'#\' onclick=\'removeElement("'+divIdName+'")\'>Remove the div "'+divIdName+'"</a>';
//                ni.appendChild(newdiv);
//            }
//
//            function removeElement(divNum) {
//                var d = document.getElementById('myDiv');
//                var olddiv = document.getElementById(divNum);
//                d.removeChild(olddiv);
//            }



