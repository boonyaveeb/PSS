var dtCh= "-";
var minYear=1900;
var maxYear=2100;



function transferData(effDate,dcType,roundTm,sumAmt,sumTxn,sumRef,entryId){
        var msg;    
  msg="คุณต้องการส่งรายการ ใช่หรือไม่?"
    if (msg!=""){
        if (!confirm(msg)){
            return;             
        }
    }
    var tabDetail=document.getElementById("tbDtl");
    var tbodyDetail=tabDetail.getElementsByTagName("tbody");
    var allRefNo="";
    
//      alert(tbodyDetail[0].childNodes[0].childNodes[0].childNodes[0].nodeValue);
      
    for (var i =0;i<tbodyDetail.length ;i++){//loop tr        
        var findTr = tbodyDetail[i].childNodes; //tr
        for (var j=0;j<findTr.length;j++){
            if (tbodyDetail[i].childNodes[j].childNodes[0].childNodes[0].checked){
                
                if (allRefNo == ""){                
                    allRefNo += tbodyDetail[i].childNodes[j].childNodes[1].childNodes[0].nodeValue;
                }else{
                    allRefNo += "," + tbodyDetail[i].childNodes[j].childNodes[1].childNodes[0].nodeValue;
                }
            }
        }
        
    }
    
    if (allRefNo==""){
               alert("กรุณาเลือกรายการที่ต้องการ Transfer");
        return ;

        
    }


if (window.ActiveXObject){// IE
        xhr=new ActiveXObject("Microsoft.XMLHTTP");
    }else{ // FF,Chrome
        xhr=new XMLHttpRequest();
    }

    //2. Prepare CallBack
    xhr.onreadystatechange= function(){
        if (xhr.readyState==4 && xhr.status == 200){
            //4. Get Response
            var resText = xhr.responseText;
            if (resText == "true"){                
                alert ('Transfer รายการร ประจำวันที่' + effDate + ' รอบเวลา' + roundTm + ' เรียบร้อย');
            }else{
                alert ('ไม่สามารถ Transfer รายการได้');
            }
            viewData('2',effDate,dcType,roundTm);
        }
    }
    
    //3. Send request
    xhr.open("post","confirmTrnTxnCtl",true);
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
    xhr.send("bsType=S&effDate="+effDate+ "&entryId="+entryId+"&dcType="+dcType+ "&roundTm="
        +roundTm+"&refno="+ allRefNo +"&sumAmt="+ sumAmt +"&sumTxn="+ sumTxn+"&sumRef="+ sumRef+"&key=" + Math.random());
}


function InitialPosData(effDate,dcType,roundTm,sumAmt,sumTxn,sumRef,entryId){
        var msg;    
  msg="คุณต้องการตั้งยอดรายการ ใช่หรือไม่?"
    if (msg!=""){
        if (!confirm(msg)){
            return;             
        }
    }
    var tabDetail=document.getElementById("tbDtl");
    var tbodyDetail=tabDetail.getElementsByTagName("tbody");
    var allRefNo="";
    
//      alert(tbodyDetail[0].childNodes[0].childNodes[0].childNodes[0].nodeValue);
      
    for (var i =0;i<tbodyDetail.length ;i++){//loop tr        
        var findTr = tbodyDetail[i].childNodes; //tr
        for (var j=0;j<findTr.length;j++){
            if (tbodyDetail[i].childNodes[j].childNodes[0].childNodes[0].checked){
                
                if (allRefNo == ""){                
                    allRefNo += tbodyDetail[i].childNodes[j].childNodes[1].childNodes[0].nodeValue;
                }else{
                    allRefNo += "," + tbodyDetail[i].childNodes[j].childNodes[1].childNodes[0].nodeValue;
                }
            }
        }
        
    }
    
    if (allRefNo==""){
               alert("กรุณาเลือกรายการที่ต้องการ ตั้งยอด");
        return ;

        
    }


if (window.ActiveXObject){// IE
        xhr=new ActiveXObject("Microsoft.XMLHTTP");
    }else{ // FF,Chrome
        xhr=new XMLHttpRequest();
    }

    //2. Prepare CallBack
    xhr.onreadystatechange= function(){
        if (xhr.readyState==4 && xhr.status == 200){
            //4. Get Response
            var resText = xhr.responseText;
            if (resText == "true"){                
                alert ('ตั้งยอด รายการร ประจำวันที่' + effDate + ' รอบเวลา' + roundTm + ' เรียบร้อย');
            }else{
                alert ('ไม่สามารถ ตั้งยอด รายการได้');
            }
            viewData('2',effDate,dcType,roundTm);
        }
    }
    
    //3. Send request
    xhr.open("post","confirmTrnIniTxnCtl",true);
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
    xhr.send("bsType=S&effDate="+effDate+ "&entryId="+entryId+"&dcType="+dcType+ "&roundTm="
        +roundTm+"&refno="+ allRefNo +"&sumAmt="+ sumAmt +"&sumTxn="+ sumTxn+"&sumRef="+ sumRef+"&key=" + Math.random());
}

function addrec(xxxx){
    //GET REFNO to find and delete it
    var tabDetail=document.getElementById("tableDetail").getElementsByTagName("tbody")[0];
    var tbDetail = tabDetail.getElementsByTagName("tr");



    for (var i =0;i < tbDetail.length;i++){//loop tr
        var tdDetail = tbDetail[i].getElementsByTagName("td");
        if (xxxx == tdDetail[1].childNodes[0].nodeValue){            
            alert("fun fun" + xxxx);
            //todo update pss_ats_txn and insert into pss_confirm_txn;
        }
                
    }
    
}

//function confirmTxn(refNo,entryId){
//    
//    if (window.ActiveXObject){// IE
//        xhr=new ActiveXObject("Microsoft.XMLHTTP");
//    }else{ // FF,Chrome
//        xhr=new XMLHttpRequest();
//    }
//
//    //2. Prepare CallBack
//    xhr.onreadystatechange= function(){
//        if (xhr.readyState==4 && xhr.status == 200){
//            //4. Get Response
//            //        var result = document.getElementById("roundtime");
//            //          result.options.length=0
//            var xml  = xhr.responseText;
//            if (xml== 'true'){
//                delRec(refNo);
//            }else{
//                alert('ยืนยันรายการมีปัญหา');
//            }  
//        }
//    }
//    
//    xhr.open("post","confirmTxnCtl",true);
//    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
//    xhr.send("refno="+refNo+"&entryId="+entryId+"&key=" + Math.random());
//}

function delRec(refNo){
    //GET REFNO to find and delete it
    var tabDetail=document.getElementById("tbSum").getElementsByTagName("tbody")[0];
    var tbDetail = tabDetail.getElementsByTagName("tr");


//    alert(tbDetail.length);
    for (var i =0;i < tbDetail.length;i++){//loop tr
        var tdDetail = tbDetail[i].getElementsByTagName("td");
        if (refNo == tdDetail[1].childNodes[0].nodeValue){            // compare refNo
            tabDetail.removeChild(tbDetail[i]);
            
//            rmNode.getParentNode().removeChild(rmNode);

            alert("fun fun" + xxxx);
            return;
//            alert(tdDetail[1].childNodes[0].nodeValue);
//            alert("fdfafa"+tdDetail[1].childNodes[0].nodeValue);
        }
                
    }
    
   
}
function delRecAll(){


    var tabDetail=document.getElementById("tbSum");
    var tbodyDetail=tabDetail.getElementsByTagName("tbody");

    for (var i =tbodyDetail.length-1 ;i >=0;i--){//loop tr


        tabDetail.removeChild(tbodyDetail[i]);
    }
    
    var tabDetail=document.getElementById("tbDtl");
    var tbodyDetail=tabDetail.getElementsByTagName("tbody");

    for (var i =tbodyDetail.length-1 ;i >=0;i--){//loop tr


        tabDetail.removeChild(tbodyDetail[i]);
    }
   
}

function viewData(fm,effdatein,dctypein,roundtmin,entryId){

    delRecAll();
    var dcType="";
    var roundTm="";
    var effDate="";
    if (fm=='2'){
        effDate = effdatein;
        roundTm = roundtmin;
        dcType=dctypein;
        
    }else{
        effDate=document.getElementsByName("txteffDate").item(0).value;
 
        //        alert(document.getElementsByName("chkDC").checked.value);
        
        //    var dcType=document.getElementsByName("chkDC");
        for (var i=0; i < document.getElementsByName("chkDC").length;i++){
            if (document.getElementsByName("chkDC")[i].checked){
                dcType=document.getElementsByName("chkDC")[i].value;
            }
        }
    
        for (var i=0; i < document.getElementsByName("chkRdTm").length;i++){
            if (document.getElementsByName("chkRdTm")[i].checked){
                roundTm=document.getElementsByName("chkRdTm")[i].value;
            }
        }
    }
    
    if (window.ActiveXObject){// IE
        xhr=new ActiveXObject("Microsoft.XMLHTTP");
    }else{ // FF,Chrome
        xhr=new XMLHttpRequest();
    }

    //2. Prepare CallBack
    xhr.onreadystatechange= function(){
        if (xhr.readyState==4 && xhr.status == 200){
            //4. Get Response
            
            var table = document.getElementById("tbSum");
            var tbody = document.createElement("tbody");
            var xml  = xhr.responseXML;
            var ps = xml.getElementsByTagName("atscfsumtxn");
            if (ps.length == 0){
              alert("ไม่พบข้อมูลที่ค้นหา")  
                return;
            }                            
            for (var i = 0; i < ps.length;i++){
                var newTr=document.createElement("tr");
                var nodeTd = new Array(8);
                //        var newTd=document.createElement("td");
                var nodeText =new Array(8);

                var sumAmt="",sumTxn="",sumRef="";
//                var refno="";
//                    refno=ps[i].getElementsByTagName("refno")[0].firstChild.nodeValue;
                
   
                
                nodeText[0]=document.createTextNode(ps[i].getElementsByTagName("effdate")[0].firstChild.nodeValue);
                nodeText[1]=document.createTextNode(ps[i].getElementsByTagName("samedaytime")[0].firstChild.nodeValue);
                nodeText[2]=document.createTextNode(ps[i].getElementsByTagName("atsservice")[0].firstChild.nodeValue);                                
                nodeText[3]=document.createTextNode(ps[i].getElementsByTagName("sumtxn")[0].firstChild.nodeValue);
                nodeText[4]=document.createTextNode(ps[i].getElementsByTagName("sumamt")[0].firstChild.nodeValue);
                nodeText[5]=document.createTextNode(ps[i].getElementsByTagName("ctbrno")[0].firstChild.nodeValue);
                nodeText[6]=document.createTextNode(ps[i].getElementsByTagName("ctcompcode")[0].firstChild.nodeValue);
                nodeText[7]=document.createTextNode(ps[i].getElementsByTagName("ctrefno")[0].firstChild.nodeValue);
                
                sumTxn=nodeText[3].nodeValue.toString();
                sumAmt=nodeText[4].nodeValue.toString();
                sumRef= nodeText[7].nodeValue.toString();
                
                var confirmBtn = document.createElement("input");                    
                confirmBtn.setAttribute("type", "button");
                confirmBtn.setAttribute("value", "Transfer");
                confirmBtn.onclick = new Function("transferData('"+effDate+"','"+dcType+"','"+roundTm+"','"+sumAmt+"','"+sumTxn+"','"+sumRef+"','"+entryId+"')");
                var confirmTd = document.createElement("td")
                confirmTd.setAttribute("bgColor", "#e4e3e3");
                confirmTd.appendChild(confirmBtn);
                newTr.appendChild(confirmTd); // add button
                
                var confirmBtn = document.createElement("input");                    
                confirmBtn.setAttribute("type", "button");
                confirmBtn.setAttribute("value", "Update ข้อมูลเพื่อบันทึก GL");
                confirmBtn.onclick = new Function("InitialPosData('"+effDate+"','"+dcType+"','"+roundTm+"','"+sumAmt+"','"+sumTxn+"','"+sumRef+"','"+entryId+"')");
                var confirmTd = document.createElement("td")
                confirmTd.setAttribute("bgColor", "#e4e3e3");
                confirmTd.appendChild(confirmBtn);
                newTr.appendChild(confirmTd); // add button
                
                var confirmBtn = document.createElement("input");                    
                confirmBtn.setAttribute("type", "button");
                confirmBtn.setAttribute("value", "ตรวจสอบFile");
                confirmBtn.onclick = new Function("ValidLine()");
                var confirmTd = document.createElement("td")
//                confirmTd.setAttribute("bgcolor", "#e4e3e3");
                confirmTd.setAttribute("bgColor", "#e4e3e3");
                confirmTd.appendChild(confirmBtn);
                newTr.appendChild(confirmTd); // add button
                
                for (var j=0;j<nodeTd.length;j++){
                    nodeTd[j] = document.createElement("td");
                    nodeTd[j].setAttribute("className", "tableDetail"); //for IE
                    nodeTd[j].setAttribute("class", "tableDetail"); //for FF
                    nodeTd[j].appendChild(nodeText[j]);
                    
                    newTr.appendChild(nodeTd[j]);
                    
                }
//                 var detailBtn = document.createElement("input");                    
//                detailBtn.setAttribute("type", "button");
//                detailBtn.setAttribute("value", "Detail");
//                detailBtn.onclick = new Function("detailDisplay()");
//                var detailTd = document.createElement("td")
//                detailTd.appendChild(detailBtn);
//                newTr.appendChild(detailTd); // add button

                tbody.appendChild(newTr);
//                table.tBodies[0].appendChild(newTr);    
                table.appendChild(tbody)
            
            }
            
            var tbDtl = document.getElementById("tbDtl");
            var tbody = document.createElement("tbody");            
            var ps = xml.getElementsByTagName("atscftxn");
            
            tbDtl.insertBefore((tbody),null);
                            
            for (var i = 0; i < ps.length;i++){
                var newTr=document.createElement("tr");
                
                tbody.insertBefore(newTr, null);
                
                var cfStat="";
                var nodeTd = new Array(20);
                var nodeText =new Array(20);
                cfStat=ps[i].getElementsByTagName("refstat")[0].firstChild.nodeValue;
                nodeText[0]=document.createTextNode(ps[i].getElementsByTagName("refno")[0].firstChild.nodeValue);
                nodeText[1]=document.createTextNode(ps[i].getElementsByTagName("compcode")[0].firstChild.nodeValue);
                nodeText[2]=document.createTextNode(ps[i].getElementsByTagName("txnbrid")[0].firstChild.nodeValue);
                nodeText[3]=document.createTextNode(ps[i].getElementsByTagName("effdate")[0].firstChild.nodeValue);
                nodeText[4]=document.createTextNode(ps[i].getElementsByTagName("atsservice")[0].firstChild.nodeValue);
                nodeText[5]=document.createTextNode(ps[i].getElementsByTagName("roundtype")[0].firstChild.nodeValue);
                nodeText[6]=document.createTextNode(ps[i].getElementsByTagName("batchtime")[0].firstChild.nodeValue);
                nodeText[7]=document.createTextNode(ps[i].getElementsByTagName("samedaytime")[0].firstChild.nodeValue);
                nodeText[8]=document.createTextNode(ps[i].getElementsByTagName("appvcode")[0].firstChild.nodeValue);
                nodeText[9]=document.createTextNode(ps[i].getElementsByTagName("resultflag")[0].firstChild.nodeValue);
                nodeText[10]=document.createTextNode(ps[i].getElementsByTagName("filetmpid")[0].firstChild.nodeValue);                               
                nodeText[11]=document.createTextNode(ps[i].getElementsByTagName("sumtxn")[0].firstChild.nodeValue);
                nodeText[12]=document.createTextNode(ps[i].getElementsByTagName("sumamt")[0].firstChild.nodeValue);
                nodeText[13]=document.createTextNode(ps[i].getElementsByTagName("confirmid")[0].firstChild.nodeValue);
                nodeText[14]=document.createTextNode(ps[i].getElementsByTagName("confirmdate")[0].firstChild.nodeValue);
                nodeText[15]=document.createTextNode(ps[i].getElementsByTagName("confirmtime")[0].firstChild.nodeValue);                
                
//                nodeText[14]=document.createTextNode(ps[i].getElementsByTagName("fileamt")[0].firstChild.nodeValue);
//                nodeText[15]=document.createTextNode(ps[i].getElementsByTagName("filetxn")[0].firstChild.nodeValue);
                nodeText[16]=document.createTextNode(ps[i].getElementsByTagName("fileamtinval")[0].firstChild.nodeValue);                               
                nodeText[17]=document.createTextNode(ps[i].getElementsByTagName("filetxninval")[0].firstChild.nodeValue);
                nodeText[18]=document.createTextNode(ps[i].getElementsByTagName("fileamtread")[0].firstChild.nodeValue);
                nodeText[19]=document.createTextNode(ps[i].getElementsByTagName("filetxnread")[0].firstChild.nodeValue);
                
                

//                <th class="thDisplay">Amt</th>
//                                <th class="thDisplay">Txn No</th>
//                                <th class="thDisplay">Invalid TOT Amt</th>
//                                <th class="thDisplay">Invalid Txn No</th>
//                                <th class="thDisplay">File TOT Amt</th>
//                                <th class="thDisplay">File Txn No</th>
//                alert(cfStat);
//    var confirmBtn = document.createElement("input");                    
//                confirmBtn.setAttribute("type", "button");
//                confirmBtn.setAttribute("value", "Transfer");
//                confirmBtn.onclick = new Function("transferData('"+effDate+"','"+dcType+"','"+roundTm+"','"+sumAmt+"','"+sumTxn+"','"+sumRef+"')");
//                var confirmTd = document.createElement("td")
//                confirmTd.appendChild(confirmBtn);
//                newTr.appendChild(confirmTd); // add button
// <input type="checkbox" name="fdf" value="ON" />

                var chkInput= document.createElement("input");
                chkInput.setAttribute("type", "checkbox");
                chkInput.setAttribute("value", "OFF");
//                chkInput.setAttribute("value", "ON");
                if (cfStat=="W"){
                    chkInput.setAttribute("checked", "true");
                    chkInput.setAttribute("defaultChecked", "defaultChecked");
                }
                
                var chkTd = document.createElement("td")
                chkTd.setAttribute("bgcolor", "#e4e3e3");
                chkTd.appendChild(chkInput);
                newTr.appendChild(chkTd); // add button
//                background-color:#e4e3e3;
                for (var j=0;j<nodeTd.length;j++){
                    
                    nodeTd[j] = document.createElement("td");
                   
                    nodeTd[j].setAttribute("className", "tableDetailTrn"); //for IE
                    nodeTd[j].setAttribute("class", "tableDetailTrn"); //for FF
                    if (j==11 || j==12 || j==16 || j==17 || j==18 || j==19){
                        nodeTd[j].setAttribute("align", "right");                         
                    }
                    //align 
                    if (cfStat=="S"){                        
                        nodeTd[j].setAttribute("bgColor", "#99ff99");
                    }else{
                        nodeTd[j].setAttribute("bgColor", "#e4e3e3");
                    }
                    
//                  
                    newTr.appendChild(nodeTd[j]);
                    nodeTd[j].appendChild(nodeText[j]);
                    
                    
                    
                }

//                tbody.appendChild(newTr);
//                tbDtl.appendChild(tbody)
            
            }
           
//            window.setTimeout('viewData()',10000);

        }
        
        
       
    }
    //3. Send request
 

    xhr.open("post","confirmTrnInqCtl",true);
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
    xhr.send("bsType=S&effDate="+effDate+ "&dcType="+dcType+ "&roundTm="+roundTm+"&key=" + Math.random());
}

function ValidLine(){
    var msg;    
    msg="คุณต้องการ เช็คจำนวนรายการ ใช่หรือไม่?"
    if (msg!=""){
        if (!confirm(msg)){
            return;             
        }
    }
    var tabDetail=document.getElementById("tbDtl");
    var tbodyDetail=tabDetail.getElementsByTagName("tbody");
    var allRefNo="";
    
    //      alert(tbodyDetail[0].childNodes[0].childNodes[0].childNodes[0].nodeValue);
      
    for (var i =0;i<tbodyDetail.length ;i++){//loop tr        
        var findTr = tbodyDetail[i].childNodes; //tr
        for (var j=0;j<findTr.length;j++){
            if (tbodyDetail[i].childNodes[j].childNodes[0].childNodes[0].checked){
                
                if (allRefNo == ""){                
                    allRefNo += tbodyDetail[i].childNodes[j].childNodes[1].childNodes[0].nodeValue;
                }else{
                    allRefNo += "," + tbodyDetail[i].childNodes[j].childNodes[1].childNodes[0].nodeValue;
                }
            }
        }
        
    }
    
    if (allRefNo==""){
        alert("กรุณาเลือกรายการที่ต้องการ ตรวจสอบ");
        return ;

        
    }
    mywindow = window.open("confirmTrnTxnValidCtl?refno="+allRefNo+"&key=" + Math.random()
        , "mywindow", "location=no,status=1,scrollbars=1,resizable=yes,  width=900,height=500");
    mywindow.title ="รายการที่มียอดซ้ำ"
    mywindow.focus();
}
function stopFeed(t){
    window.clearTimeout(t);
    
}






