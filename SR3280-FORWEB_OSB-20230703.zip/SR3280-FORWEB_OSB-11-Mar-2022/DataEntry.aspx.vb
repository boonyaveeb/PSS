Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data
Imports System.Data.Common
Imports System.Data.Odbc
Imports System.Data.DataTable
Imports System.Data.DataSet
Imports System.Data.Odbc.OdbcConnection
Imports System.Data.DataRow
Imports System.Web.Services.WebMethodAttribute
Imports System.Data.Common.DbTransaction
Imports System.Web.UI.HtmlControls.HtmlTextArea
Imports System.Web.UI.HtmlTextWriter
Imports System.Web.UI.WebControls.TreeView
Imports System.Web.HttpRequest

Partial Class EntryTrnToFOR
    Inherits System.Web.UI.Page

    Dim strSql As String
    Dim dtPayment As New DataTable
    Dim strMsg As String
    Dim cs As ClientScriptManager = Page.ClientScript
    Dim csname1 As String = "PopupScript"
    Dim cstext1 As String
    Dim cstype As Type = Me.GetType()
    Dim dr As DataRow
    Dim dtAddInqRate As New DataTable '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
    Dim strProdName As String = System.Configuration.ConfigurationManager.AppSettings.Item("appNameProd").ToString()
    '2010-11-10 R53060089 Tom : Interface with Sierra (FX) 
    Dim gUserid As String, gSession As String, gRqUId As String
    Private AppName As String = System.Configuration.ConfigurationManager.AppSettings.Item("appName").ToString()
    Dim dtSumRateInfo As New DataTable
    Dim dtInqRate As New DataTable

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        '2012-11-05 R55040057 Tom Start: Support new organize
        txtItscCd.BackColor = Drawing.Color.LightGray
        txtItscName.BackColor = Drawing.Color.LightGray
        'If Trim(Session("Funccd")) = "1150" Then ' Amend OR
        '    ddlItsc.BackColor = Drawing.Color.LightGray
        '    ddlItsc.ForeColor = Drawing.Color.Black
        'End If

        txtSenName1.BackColor = Drawing.Color.LightGray
        txtSenName2.BackColor = Drawing.Color.LightGray
        txtSenAddr1.BackColor = Drawing.Color.LightGray
        txtSenAddr2.BackColor = Drawing.Color.LightGray
        txtCur.BackColor = Drawing.Color.LightGray
        txtRemCur.BackColor = Drawing.Color.LightGray
        '2008-12-04 Tom
        ddlComCd.BackColor = Drawing.Color.White
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim siteNode As System.Web.SiteMapNode

        '  ### Start : check Time Out ###
        If Session("strSysAuthorize") = "" Then
            Dim strUserInput As String
            Dim strWebStat As String
            strWebStat = ""
            strUserInput = Request.Cookies("UserInput").Value

            'Response.Cookies.Clear()
            'Response.Cookies("UserInput").Expires = DateTime.Now.AddDays(-1)
            Response.Cookies("UserInput").Expires = DateTime.Now 'clear cookies

            ' case :  not time out
            If Not PublicFunc.chkWebStat(strUserInput, strWebStat) Then GoTo exitHandle
            If strWebStat = "I" Then
                Response.Redirect("~/DisplayMsg.aspx?type= Please Log In.!!!&page=LOGIN")
            End If
            ' case :  not time out

            If Not PublicFunc.LogOut(strUserInput, strMsg) Then
                GoTo exitHandle
            End If
            Session.Abandon() '( ����ҧ������� session ������ ���������������ͧ client)
            Response.Redirect("~/DisplayMsg.aspx?type=Time Out !!! Please Log In again.&page=LOGIN")
        End If
        '  ### End : check Time Out ###

        '*****************************************************

        txtSenId.Attributes.Add("onChange", "enter();")
        txtSenId.Attributes.Add("onSelected", "enter();")
        btnSearch.Attributes.Add("onKeyUp", "enter();")
        txtSenName1.Attributes.Add("onClick", "enter();")

        ' 2008-09-30 Tom :
        txtValDate.Attributes.Add("onChange", "preadv();")
        txtValDate.Attributes.Add("onSelected", "preadv();")

        'txtValDate.Attributes.Add("onKeyUp", "preadv();")
        '2009-07-30 Tom :
        'hplValDate.Attributes.Add("onKeyUp", "preadv();")
        ''hplValDate.Attributes.Add("onClick", "focus();")

        ''2009-07-27 Tom :
        'txtRecAcc.Attributes.Add("onChange", "preadv();")
        'txtRecAcc.Attributes.Add("onSelected", "preadv();")

        ' 2009-09-08 Tom :
        'If PublicFunc.ValidateNum(txtRemAmt.Text) Then
        '    txtRemAmt.Attributes.Add("onChange", "amount();")
        'End If

        'cbReference = Page.ClientScript.GetCallbackEventReference(Me, "arg", "ReceiveServerData", "context")
        'callbackScript = "function CallTheServer(arg, context){" + cbReference + ";}"
        'Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "CallTheServer", callbackScript, True)

        '2012-11-05 R55040057 Tom : Support new organize
        'Session("Page") = "Entry"
        Session("Funccd") = Request.QueryString("MenuFunc")
        ' Set sitemap title
        siteNode = SiteMap.CurrentNode
        siteNode.ReadOnly = False
        '2012-11-02 R55040057 Tom Start : Support new organize
        Select Case Trim(Session("Funccd"))
            Case "1130"
                Page.Title = "Data Entry"
                siteNode.Title = "Data Entry"
                Session("Page") = "Entry"
            Case "1150"
                Page.Title = "Amend OR"
                siteNode.Title = "Amend OR"
                Session("Page") = "Amend"
                Session("SearchPage") = "Amend"
        End Select
        '2012-11-02 R55040057 Tom End: Support new organize

        Try
            If Not IsPostBack Then

                Session("dtPayment") = Nothing
                Session("dtSumRateInfo") = Nothing
                Session("dtAddInqRate") = Nothing
                Session("selectIndex") = Nothing
                Session("strFXCustId") = Nothing

                'Session("Funccd") = Request.QueryString("MenuFunc")
                '' Set sitemap title
                'siteNode = SiteMap.CurrentNode
                'siteNode.ReadOnly = False
                ''2012-11-02 R55040057 Tom Start : Support new organize
                'Select Case Trim(Session("Funccd"))
                '    Case "1130"
                '        Page.Title = "Data Entry"
                '        siteNode.Title = "Data Entry"
                '        Session("Page") = "Entry"
                '    Case "1150"
                '        Page.Title = "Amend OR"
                '        siteNode.Title = "Amend OR"
                '        Session("Page") = "Amend"
                'End Select
                ''2012-11-02 R55040057 Tom End: Support new organize

                ' Add data to dropdownlist
                Call AddCurrency()
                Call AddComCd()
                '2008-11-27 Tom :
                Call AddCountryCd()
                '2010-11-08 R53060089 Tom : Interface with Sierra (FX) 
                Call AddRate("ALL")

                ' Set panel
                Call SetPanel("LOAD")
                ' Set display Value
                Call SetDisValue()

                '2012-11-06 R55040057 Tom : Support new organize
                If Trim(Session("Funccd")) = "1150" Then
                    Call getInfoAmend()
                    Call getRateAmend()
                    Call getPayAmend()
                End If
                '2013-10-14 :: Kwang :: R56070118 Change Gl account booking TR of IMEX
                'txtTRdeal.Enabled = False
                'txtTRdeal.Text = ""
                'txtTRdeal.BackColor = Drawing.Color.LightGray
            End If

            Call SetDefaultGrid()

        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If

        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try
        '2009-07-30 Tom :
        'hplValDate.Attributes.Add("OnClick", "showCalendar('" & txtValDate.UniqueID & "', 'DD/MM/YYYY');")
        'hplValDate.NavigateUrl = "javascript:;"

exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If


    End Sub

    Protected Sub Page_PreInit(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreInit

        Me.Theme = "BlueFile"

    End Sub

    Private Sub AddCurrency()
        '*** CMHI:4c034eef-7430-4f6a-b889-2bb27c9c36f3

        Dim dtResultSet As DataSet
        Dim dtRow As DataRow

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        strSql = ""
        Try

            strSql = _
            "select '' as code " & _
            "from db2.host_currency " & _
            "where cur_cd not in ('US1','US2') " & _
            " and sell_tt > 0 union " & _
            "select cur_cd as code " & _
            "from db2.host_currency " & _
            "where cur_cd not in ('US1','US2') " & _
            " and sell_tt > 0 " & _
            " AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
            "order by code"


            'strSql = "select cur_cd from db2.host_currency"
            dtResultSet = connDB.RunQuerySql(strSql)
            If dtResultSet.Tables.Count > 0 Then

                For Each dtRow In dtResultSet.Tables(0).Rows
                    ' Rem Cur
                    ddlRemCur.DataSource = dtResultSet.Tables(0)
                    ddlRemCur.DataTextField = "code"
                    ddlRemCur.DataBind()
                    '2010-11-12 R53060089 Tom : Interface with Sierra (FX) 
                    '' A/C Cur 
                    'ddlAcCurPay.DataSource = dtResultSet.Tables(0)
                    'ddlAcCurPay.DataTextField = "code"
                    'ddlAcCurPay.DataBind()

                Next

            End If
        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Sub

    Private Sub AddCurRate(ByVal CurCode As DropDownList)
        '*** CMHI:480a66d2-414a-4d91-88cc-7e42557cf933
        Dim strSql As String
        Dim dtResultSet As DataSet
        Dim dtRateRow As DataRow
        Dim i As Integer
        Dim AddCurTHB As Boolean

        strSql = ""
        CurCode.DataSource = ""

        AddCurTHB = False

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency) '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System : defauat remcur in ddlInqPayCur

        Try
            '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System : defauat remcur in ddlInqPayCur
            'strSql = " select ' ' as code from db2.forlcuac union select distinct COALESCE(accurcd,'') as code from db2.forlcuac " & _
            '        " where forcustid = '" & Trim(txtSenId.Value) & "' "

            strSql = " select ' ' as code from db2.forlcuac union " & _
                            " select '" & concur.BaseCurrency & "' as code from db2.forlcuac union " & _
                         "select '" & Trim(ddlRemCur.Text) & "' as code from db2.forlcuac union " & _
                         "select distinct COALESCE(accurcd,'') as code from db2.forlcuac " & _
                         " where forcustid = '" & Trim(txtSenId.Value) & "' "

            dtResultSet = connDB.RunQuerySql(strSql)

            If dtResultSet.Tables.Count > 0 Then
                For Each dtRateRow In dtResultSet.Tables(0).Rows
                    CurCode.DataSource = dtResultSet.Tables(0)
                    CurCode.DataTextField = "code"
                    CurCode.DataBind()
                Next
            End If

            If dtResultSet.Tables(0).Rows.Count = 2 Then
                CurCode.SelectedIndex = 1
            End If

            For i = 0 To dtResultSet.Tables(0).Rows.Count - 1
                '***R56100048 Repalce "THB"
                'If Trim(dtResultSet.Tables(0).Rows(i).Item(0)) = "THB" Then
                If Trim(dtResultSet.Tables(0).Rows(i).Item(0)) = CType( _
                 Session("concurrencyInfo"), _
                 FORWEB_Concurrency).BaseCurrency Then
                    AddCurTHB = True
                    Exit For
                End If
            Next
        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try
    End Sub

    Private Sub AddComCd()

        Dim dtResultSet As DataSet
        Dim dtComCdRow As DataRow
        Dim dtRow As DataRow
        Dim strComCd As String, strDisPlay As String
        Dim i As Integer

        strSql = ""
        strComCd = ""
        Try
            '2008-10-21 Tom :
            'strSql = "select value  from db2.frcmtbcd where type = 'D019' and code = 'COMMO'"
            'Dim ResultSetComCd As DataSet = connDB.RunQuerySql(strSql)
            'If ResultSetComCd.Tables.Count > 0 Then
            '    For Each dtComCdRow In ResultSetComCd.Tables(0).Rows
            '        strComCd = Trim(dtComCdRow.Item(0).ToString)
            '    Next
            'End If

            '***56100048 Ron
            '2008-12-04 Tom :

            'strSql = "select '' as desc , '' code  from db2.frcmtbcd where type = 'C012' " & _
            '                " union select code||' : '||value as desc , code  from db2.frcmtbcd where type = 'C012' order by code"
            'strSql = "select '--Please Select Commodity Code--' as desc , '' code  from db2.frcmtbcd where type = 'C012' " & _
            '                " union select code||' : '||value as desc , code  from db2.frcmtbcd where type = 'C012' order by code"
            Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
            strSql = "select '' as desc , '' code  from db2.frcmtbcd where type = 'C012' " & _
                            " union select code||' : '||value as desc , code  " & _
                            "from db2.frcmtbcd " & _
                            "where type = 'C012' " & _
                            " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C012' ", concur.SWIFTCODE) & "' " & _
                            "order by code"


            dtResultSet = connDB.RunQuerySql(strSql)
            If dtResultSet.Tables.Count > 0 Then
                ddlComCd.DataSource = dtResultSet.Tables(0)
                ddlComCd.DataTextField = "desc"
                ddlComCd.DataValueField = "code"
                ddlComCd.DataBind()
                For Each dtRow In dtResultSet.Tables(i).Rows
                    strDisPlay = dtRow.Item(1)
                    If strDisPlay = Trim(strComCd) Then
                        ddlComCd.SelectedValue = strDisPlay
                        Exit Sub
                    End If
                Next

            End If

        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Sub
    '2008-11-27 Tom :
    Private Sub AddCountryCd()
        Dim strSql As String
        Dim dtResultSet As DataSet
        'Dim dtRow As DataRow
        'Dim i As Integer
        'Dim strDisPlay As String
        '***56100048 Ron
        'strSql = "select '--Please Select Country Code--' as desc , '' code  from db2.frcmtbcd where type = 'C003' " & _
        '        " union select code||' : '||value as desc ,  code from db2.frcmtbcd where type = 'C003' order by code"
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        strSql = "select '--Please Select Country Code--' as desc , '' code  from db2.frcmtbcd where type = 'C003' " & _
                " union select code||' : '||value as desc ,  code from db2.frcmtbcd " & _
                "where type = 'C003' " & _
                " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C003' ", concur.SWIFTCODE) & "' " & _
                "order by code"
        Try
            dtResultSet = connDB.RunQuerySql(strSql)
            If dtResultSet.Tables.Count > 0 Then
                ddlCtryCd.DataSource = dtResultSet.Tables(0)
                ddlCtryCd.DataTextField() = "desc"
                ddlCtryCd.DataValueField() = "code"
                ddlCtryCd.DataBind()

                'For i = 0 To dtResultSet.Tables(0).Rows.Count - 1
                '    For Each dtRow In dtResultSet.Tables(i).Rows
                '        strDisPlay = dtRow.Item(1)
                '        If strDisPlay = Trim(strCtryCd) Then
                '            ddlCtryCd.SelectedValue = strDisPlay
                '            Exit Sub
                '        End If
                '    Next
                'Next
            End If
        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Sub
    Protected Sub GridAddPay_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridAddPay.RowCreated

        '    If e.Row.RowType = DataControlRowType.DataRow Then
        '        If Not e.Row.RowState And DataControlRowState.Edit Then
        '            Dim imgDel As ImageButton = e.Row.Cells(0).Controls(1)
        '            imgDel.Attributes.Add("onclick", "return confirm('Confirm to delete this record?');")

        '        End If
        '    End If

        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(6).CssClass = "hiddencol"
            e.Row.Cells(7).CssClass = "hiddencol"
        ElseIf e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(6).CssClass = "hiddencol"
            e.Row.Cells(7).CssClass = "hiddencol"
        End If

    End Sub

    Protected Sub GridAddPay_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridAddPay.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            ' No.
            e.Row.Cells(2).Text = e.Row.RowIndex + 1
            ' A/C Cur.
            e.Row.Cells(3).Text = e.Row.Cells(3).Text.ToString()
            ' A/C No.
            e.Row.Cells(4).Text = e.Row.Cells(4).Text.ToString()
            ' Pay Amount
            e.Row.Cells(5).Text = Format(CDbl(e.Row.Cells(5).Text), "###,###,###,###,##0.00")
            e.Row.Cells(5).HorizontalAlign = HorizontalAlign.Right
            ' Rem Cur.
            e.Row.Cells(6).Text = e.Row.Cells(6).Text.ToString()
            ' Pay Amount
            e.Row.Cells(7).Text = Format(CDbl(e.Row.Cells(7).Text), "###,###,###,###,##0.00")
            e.Row.Cells(7).HorizontalAlign = HorizontalAlign.Right

            '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
            '' Rate Type
            'e.Row.Cells(7).Text = e.Row.Cells(7).Text.ToString()
            '' Exchange Rate
            'e.Row.Cells(8).Text = Format(CDbl(e.Row.Cells(8).Text), "##,##0.0000000")
            'e.Row.Cells(8).HorizontalAlign = HorizontalAlign.Right
            '' Deal No.
            'e.Row.Cells(9).Text = e.Row.Cells(9).Text.ToString()

            If e.Row.Cells(3).Text = "&nbsp;" Then
                e.Row.Cells(3).Text = ""
            ElseIf e.Row.Cells(4).Text = "&nbsp;" Then
                e.Row.Cells(4).Text = ""
            ElseIf e.Row.Cells(6).Text = "&nbsp;" Then
                e.Row.Cells(6).Text = ""
                '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
                'ElseIf e.Row.Cells(7).Text = "&nbsp;" Then
                '    e.Row.Cells(7).Text = ""
                'ElseIf e.Row.Cells(9).Text = "&nbsp;" Then
                '    e.Row.Cells(9).Text = ""
            End If

        End If

    End Sub

    Private Sub SetPanel(ByVal caseFor As String)
        Select Case Trim(UCase(caseFor))
            Case "LOAD"
                '2010-11-08 R53060089 Tom : Interface with Sierra (FX) 
                pnlInqAddRate.Visible = True
                pnlInqUpdRate.Visible = False
                pnlRate.Enabled = False
                btnInqRateAdd.Enabled = False

                pnlAddPay.Visible = True
                pnlUpdPay.Visible = False
                pnlPay.Enabled = False

                pnlSumRateInfo.Visible = False

            Case "ADD"
                pnlAddPay.Visible = False
                pnlUpdPay.Visible = True
            Case "UPD"
                pnlAddPay.Visible = True
                pnlUpdPay.Visible = False
        End Select

    End Sub
    Private Sub SetDisValue()
        Dim strtmpItscCd() As String, strItscCd As String

        '2012-11-05 R55040057 Tom Start: Support new organize
        'strSql = "select itscname from db2.frcmitsc  where itscno =  '" & Trim(Session("strRcUnit")) & "'"
        'Itsc Code
        txtItscCd.Text = Session("setItscVal")

        '***56100048 Ron SWIFTTCD on FRCMITSC-002
        'strSql = "select itscname from db2.frcmitsc  where itscno =  '" & Trim(txtItscCd.Text) & "'"
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        strSql = _
        "select itscname " & _
        "from db2.frcmitsc  " & _
        "where itscno =  '" & Trim(txtItscCd.Text) & "' " & _
        " AND SWIFTTCD = '" & concur.SWIFTCODE & "'"

        Dim ResultSetItsc As DataSet = connDB.RunQuerySql(strSql)
        If ResultSetItsc.Tables.Count > 0 Then
            Dim rowitsc As DataRow
            For Each rowitsc In ResultSetItsc.Tables(0).Rows
                txtItscName.Text = rowitsc.Item(0).ToString
            Next
        Else
            txtItscName.Text = ""
        End If
        '2012-11-05 R55040057 Tom End: Support new organize

        'Value Date
        If txtValDate.Value = "" Then
            txtValDate.Value = Format(Now, "dd/MM/yyyy")
        End If

        'A/C No 
        'ddlAcNoPay.Enabled = False
        '2010-11-12 R53060089 Tom : Interface with Sierra (FX) 
        'ddlAcCurPay.Enabled = False
        ddlAcNoPay.Enabled = False

        '2010-11-08 R53060089 Tom : Interface with Sierra (FX) 
        lblCur.Text = "XXX :"
        lblRemRate.Text = "0.00"

        lblCurPay.Text = "XXX :"
        lblRemPay.Text = "0.00"

        txtTRdeal.Enabled = False 'R56070118 Booking TR of IMEX

    End Sub

    Protected Sub btnSearchName_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchName.Click


        If Not getSenderInfo() Then
            pnlPay.Enabled = False

            strMsg = "Customer Id does not exist in FOR System." & "(" & Trim(txtSenId.Value) & ")"
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            txtSenId.Focus()
            Exit Sub
        End If

        If Trim(ddlRemCur.Text <> "") Then
            ''A/C No FCD 
            'pnlPay.Enabled = True
            '2010-11-08 R53060089 Tom : Interface with Sierra (FX)
            pnlRate.Enabled = True
            btnInqRateAdd.Enabled = True
        Else
            pnlPay.Enabled = False
            '2010-11-08 R53060089 Tom : Interface with Sierra (FX)
            pnlRate.Enabled = False
            btnInqRateAdd.Enabled = False
        End If

        Call AddCurRate(ddlInqPayCur) '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 

        '2010-11-12 R53060089 Tom : Interface with Sierra (FX) 
        'Call loadAccNo()

        'errMsg:

        '        If strMsg <> "" Then
        '            cstext1 = "alert('" & strMsg & "');"
        '            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        '        End If

    End Sub

    Private Function getSenderInfo() As Boolean
        Dim strCustStat As String, strTmpName As String
        '2009-09-10 Tom : 
        Dim strswname1 As String, strswname2 As String, straddr1 As String
        Dim straddr2 As String, straddr3 As String
        '2013-06-10 :: Bo :: R56030179 - CFE FMDS FOR to support Window 7
        Dim strSenId As String
        'PIK : 2015-07-15 : R58030116 CCB Request a performance tuning
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        'Dim cbsBankCd As String
        'cbsBankCd = concur.CbsBankCd

        Call ClearDataSender()
        Session("strOcCode") = ""
        getSenderInfo = True
        '2009-09-10 Tom : 
        strswname1 = ""
        strswname2 = ""
        straddr1 = ""
        straddr2 = ""
        straddr3 = ""


        Try
            If Trim(txtSenId.Value) <> "" Then
                '2013-06-10 :: Bo :: R56030179 - CFE FMDS FOR to support Window 7
                strSenId = Trim(txtSenId.Value)
                strSenId = Replace(strSenId, "'", "''")

                ' 2009-07-10 Tom : select addr3
                '' 2008-07-28 Tom : get objcd 
                ''strSql = "select swname1,swname2,addr1,addr2,custstatus,instruction,occode from db2.formcust " & _
                ''" where forcustid = '" & Trim(txtSenId.Value) & "'"
                'strSql = "select swname1,swname2,addr1,addr2,custstatus,instruction,occode,objcd from db2.formcust " & _
                '" where forcustid = '" & Trim(txtSenId.Value) & "'"

                'strSql = "select swname1,swname2,addr1,addr2,custstatus,instruction,occode,objcd,addr3 from db2.formcust " & _
                '         " where forcustid = '" & Trim(txtSenId.Value) & "'"
                ' 2010-10-28 Tom : fixed fault
                'strSql = "select swname1,swname2,addr1,addr2,custstatus,instruction,occode,objcd,addr3 from db2.formcust " & _
                '         " where forcustid = '" & Trim(txtSenId.Value) & "' and left(forcustid,3) <> 'TMP'"
                'strSql = "select swname1,swname2,addr1,addr2,custstatus,instruction,occode,objcd,addr3 from db2.formcust a, db2.forlcuid b " & _
                '         " where a.forcustid = '" & Trim(txtSenId.Value) & "' and a.forcustid = b.forcustid and left(a.forcustid,3) <> 'TMP' and a.custstatus not in ('D','W')"
                '2013-06-10 :: Bo :: R56030179 - CFE FMDS FOR to support Window 7
                'PIK : 2015-07-15 : R58030116 CCB Request a performance tuning
                'strSql = "select swname1,swname2,addr1,addr2,custstatus,instruction,occode,objcd,addr3 from db2.formcust a, db2.forlcuid b " & _
                '         " where a.forcustid = '" & strSenId & "' and a.forcustid = b.forcustid and left(a.forcustid,3) <> 'TMP' and a.custstatus not in ('D','W')"
                strSql = "select swname1,swname2,addr1,addr2,custstatus,instruction,occode,objcd,addr3 from db2.formcust a, db2.forlcuid b " & _
                         " where a.forcustid = '" & strSenId & "' and a.forcustid = b.forcustid and left(a.forcustid,3) <> 'TMP' and a.custstatus not in ('D','W')" & _
                         " and a.cbsbankcd = '" & concur.CbsBankCd & "'"

                Dim ResultSetCust As DataSet = connDB.RunQuerySql(strSql)

                'If ResultSetCust.Tables.Count > 0 Then
                If ResultSetCust.Tables(0).Rows.Count > 0 Then

                    Dim rowcust As DataRow
                    For Each rowcust In ResultSetCust.Tables(0).Rows

                        strCustStat = rowcust.Item(4).ToString

                        If (Trim(strCustStat) <> "A") And (Trim(strCustStat) <> "U") Then
                            getSenderInfo = False
                            Exit Function
                        End If
                        ' 2009-07-10 Tom :
                        'txtSenName1.Text = rowcust.Item(0).ToString
                        'txtSenName2.Text = rowcust.Item(1).ToString
                        'txtSenAddr1.Text = rowcust.Item(2).ToString
                        'txtSenAddr2.Text = rowcust.Item(3).ToString
                        ' 2009-09-07 Tom :
                        'strTmpName = Trim(rowcust.Item(1).ToString & rowcust.Item(2).ToString & rowcust.Item(3).ToString & rowcust.Item(8).ToString)

                        'txtSenName1.Text = rowcust.Item(0).ToString
                        'txtSenName2.Text = Mid(strTmpName, 1, 35)
                        'txtSenAddr1.Text = Mid(strTmpName, 36, 35)
                        'txtSenAddr2.Text = Mid(strTmpName, 71, 35)

                        '****** 2009-09-10 Tom : valdate Sender Info data ******

                        'strTmpName = Trim(rowcust.Item(1).ToString) & " " & Trim(rowcust.Item(2).ToString) & " " & Trim(rowcust.Item(3).ToString) & " " & Trim(rowcust.Item(8).ToString)

                        ''txtSenName1.Text = Trim(rowcust.Item(0).ToString)
                        'txtSenName2.Text = Left(Trim(strTmpName), 35)
                        'strTmpName = Mid(Trim(strTmpName), 36)
                        'txtSenAddr1.Text = Left(Trim(strTmpName), 35)
                        'strTmpName = Mid(Trim(strTmpName), 36)
                        'txtSenAddr2.Text = Left(Trim(strTmpName), 35)

                        strswname1 = Trim(rowcust.Item(0).ToString)
                        strswname2 = Trim(rowcust.Item(1).ToString)
                        straddr1 = Trim(rowcust.Item(2).ToString)
                        straddr2 = Trim(rowcust.Item(3).ToString)
                        straddr3 = Trim(rowcust.Item(8).ToString)

                        txtSenName1.Text = strswname1 'swname1

                        If strswname2 = "" Then 'swname2 
                            txtSenName2.Text = straddr1 'addr1
                            txtSenAddr1.Text = straddr2 'addr2
                            txtSenAddr2.Text = straddr3 'addr3
                        ElseIf (strswname2 <> "") And (straddr2 = "") And (straddr3 = "") Then
                            txtSenName2.Text = strswname2
                            txtSenAddr1.Text = straddr1
                        ElseIf (strswname2 <> "") And ((straddr2 = "") Or (straddr3 = "")) Then
                            txtSenName2.Text = strswname2
                            txtSenAddr1.Text = straddr1

                            If straddr2 <> "" Then txtSenAddr2.Text = straddr2
                            If straddr3 <> "" Then txtSenAddr2.Text = straddr3
                        Else
                            strTmpName = strswname2 & " " & straddr1 & " " & straddr2 & " " & straddr3
                            txtSenName2.Text = Left(Trim(strTmpName), 35)
                            strTmpName = Mid(Trim(strTmpName), 36)
                            txtSenAddr1.Text = Left(Trim(strTmpName), 35)
                            strTmpName = Mid(Trim(strTmpName), 36)
                            txtSenAddr2.Text = Left(Trim(strTmpName), 35)

                        End If

                        txtSpecInst.Value = rowcust.Item(5).ToString

                        Session("strOcCode") = rowcust.Item(6).ToString
                        Session("strObjCd") = rowcust.Item(7).ToString
                    Next
                Else
                    getSenderInfo = False
                End If
            End If
        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Function
    Private Function valSenId() As Boolean
        Dim strCustStat As String

        valSenId = True

        Try
            If Trim(txtSenId.Value) <> "" Then
                strSql = "select custstatus from db2.formcust " & _
                " where forcustid = '" & Trim(txtSenId.Value) & "'"
                Dim ResultSetCust As DataSet = connDB.RunQuerySql(strSql)
                If ResultSetCust.Tables(0).Rows.Count > 0 Then

                    Dim rowcust As DataRow
                    For Each rowcust In ResultSetCust.Tables(0).Rows

                        strCustStat = rowcust.Item(0).ToString
                        If (Trim(strCustStat) <> "A") And (Trim(strCustStat) <> "U") Then
                            valSenId = False
                            Exit Function
                        End If
                    Next
                Else
                    valSenId = False
                End If
            End If
        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Function
    Private Sub ClearDataSender()

        txtSenName1.Text = ""
        txtSenName2.Text = ""
        txtSenAddr1.Text = ""
        txtSenAddr2.Text = ""

        '2009-08-21 Tom :
        txtSpecInst.Value = ""

    End Sub
    Private Sub ClearGrid()
        'Rate Info
        dtAddInqRate.Clear()

        dtAddInqRate.Columns.Add(New DataColumn("No.", GetType(System.String)))
        dtAddInqRate.Columns.Add(New DataColumn("Rem Cur.", GetType(System.String)))
        dtAddInqRate.Columns.Add(New DataColumn("Rem Amount", GetType(System.Double)))
        dtAddInqRate.Columns.Add(New DataColumn("Rate Type", GetType(System.String)))
        dtAddInqRate.Columns.Add(New DataColumn("Ex. Rate", GetType(System.Double)))
        dtAddInqRate.Columns.Add(New DataColumn("Deal No.", GetType(System.String)))
        dtAddInqRate.Columns.Add(New DataColumn("Pay Cur.", GetType(System.String)))
        dtAddInqRate.Columns.Add(New DataColumn("Pay Amount", GetType(System.Double)))
        dtAddInqRate.Columns.Add(New DataColumn("Adj. Amt", GetType(System.Double)))
        dtAddInqRate.Columns.Add(New DataColumn("Tot Pay", GetType(System.Double)))
        dtAddInqRate.Columns.Add(New DataColumn(" ", GetType(System.String)))

        dr = dtAddInqRate.NewRow
        dr("No.") = dtAddInqRate.Rows.Count + 1
        dr("Rem Cur.") = ""
        dr("Rem Amount") = "0.00"
        dr("Rate Type") = ""
        dr("Ex. Rate") = "0.0000000"
        dr("Deal No.") = ""
        dr("Pay Cur.") = ""
        dr("Pay Amount") = "0.00"
        dr("Adj. Amt") = "0.00"
        dr("Tot Pay") = "0.00"
        dr(" ") = ""
        dtAddInqRate.Rows.Add(dr)
        GridAddInqRate.DataSource = dtAddInqRate
        GridAddInqRate.DataBind()
        GridAddInqRate.Rows(0).Enabled = False

        ' Inquiry Rate
        dtInqRate.Clear()

        dtInqRate.Columns.Add(New DataColumn("Rem Cur.", GetType(System.String)))
        dtInqRate.Columns.Add(New DataColumn("Rem Amount", GetType(System.Double)))
        dtInqRate.Columns.Add(New DataColumn("Rate Type", GetType(System.String)))
        dtInqRate.Columns.Add(New DataColumn("Ex.Rate", GetType(System.Double)))
        dtInqRate.Columns.Add(New DataColumn("Original No.", GetType(System.String)))
        dtInqRate.Columns.Add(New DataColumn("Deal No.", GetType(System.String)))
        dtInqRate.Columns.Add(New DataColumn("Pay Cur.", GetType(System.String)))
        dtInqRate.Columns.Add(New DataColumn("Pay Amount", GetType(System.String)))

        dr = dtInqRate.NewRow
        dr("Rem Cur.") = ""
        dr("Rem Amount") = 0.0
        dr("Rate Type") = ""
        dr("Ex.Rate") = 0.0
        dr("Original No.") = ""
        dr("Deal No.") = ""
        dr("Pay Cur.") = ""
        dr("Pay Amount") = 0.0

        dtInqRate.Rows.Add(dr)
        GridInqRate.DataSource = dtInqRate
        GridInqRate.DataBind()
        Session("dtInqRate") = dtInqRate
        pnlGridInq.Visible = False

        ' sum Rate Info
        dtSumRateInfo.Clear()
        dr = dtSumRateInfo.NewRow
        dr("No.") = dtSumRateInfo.Rows.Count + 1
        dr("Pay Cur.") = ""
        dr("Total Pay Amount") = 0.0
        dr("Acc Rate") = 0.0

        dtSumRateInfo.Rows.Add(dr)
        GridSumRate.DataSource = dtSumRateInfo
        GridSumRate.DataBind()
        Session("dtSumRateInfo") = dtSumRateInfo
        pnlSumRateInfo.Visible = False

        ' Payment Info
        dtPayment.Clear()
        dr = dtPayment.NewRow
        dr("No.") = dtPayment.Rows.Count + 1
        dr("A/C Cur.") = ""
        dr("A/C No.") = ""
        dr("Pay Amount") = 0.0
        dr("Rem Cur.") = ""
        dr("Rem Amount") = 0.0
        '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
        'dr("Rate Type") = ""
        'dr("Ex.Rate") = 0.0
        'dr("Deal No.") = ""
        dtPayment.Rows.Add(dr)
        GridAddPay.DataSource = dtPayment
        GridAddPay.DataBind()
        Session("dtPayment") = dtPayment
        GridAddPay.Enabled = False

        Session("dtPayment") = Nothing
        Session("dtAddInqRate") = Nothing '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 
        Session("dtSumRateInfo") = Nothing
    End Sub
    Private Sub ClearData()

        '2012-11-05 R55040057 Tom : Support new organize
        txtItscCd.Text = ""
        txtItscName.Text = ""

        txtSenId.Value = ""
        txtSenName1.Text = ""
        txtSenName2.Text = ""
        txtSenAddr1.Text = ""
        txtSenAddr2.Text = ""
        txtRemAmt.Text = "0.00"
        txtValDate.Value = ""
        txtRecAcc.Value = ""
        txtSpecInst.Value = ""
        txtCur.Text = ""
        Call ClearGrid() '2010-11-24 R53060089 Tom : 

        ' 2009-09-23 Tom :
        chkBkToTr.Checked = False
        chkPayFull.Checked = False

    End Sub
    Private Function getAccCur(ByVal inAcct As String) As String
        Dim dtCurAccResultSet As DataSet
        Dim rowCurAcc As DataRow
        Dim strAccCur As String
        strSql = ""
        getAccCur = ""

        Try
            '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
            'strSql = "select accurcd as code from db2.forlcuac where acno = '" & inAcct & "' " & _
            '         " and forcustid = '" & Trim(txtSenId.Value) & "' and accurcd <> 'THB' "

            strSql = "select accurcd as code from db2.forlcuac where acno = '" & inAcct & "' " & _
                     " and forcustid = '" & Trim(txtSenId.Value) & "'"
            dtCurAccResultSet = connDB.RunQuerySql(strSql)

            Dim CurAccResultSet As DataSet = connDB.RunQuerySql(strSql)

            If CurAccResultSet.Tables(0).Rows.Count > 0 Then

                For Each rowCurAcc In CurAccResultSet.Tables(0).Rows
                    strAccCur = Trim(rowCurAcc.Item(0).ToString)
                    ddlAcCurPay.SelectedValue = strAccCur
                Next
            End If
            '2010-11-09 R53060089 Tom Start : Interface with Sierra (FX) 
            ''case : Rem Cur = A/C Cur
            'If Trim(ddlAcCurPay.Text) = Trim(txtCurPay.Text) Then
            '    Call AddRateFCD("ALL", ddlRateTypFCD)
            '    'ddlRateTypFCD.Text = "NM"
            '    'txtExRateFCD.Text = "1.0000000"
            '    'ddlRateType.BackColor = Drawing.Color.LightGray
            '    'ddlRateType.Enabled = False
            '    'txtExRateFCD.BackColor = Drawing.Color.LightGray
            '    'txtExRateFCD.ReadOnly = True
            '    'txtDealNoFCD.BackColor = Drawing.Color.White
            '    ddlRateTypFCD.Enabled = True
            '    If ddlRateTypFCD.Text = "NM" Then
            '        ddlRateTypFCD.Enabled = False
            '    End If

            'Else    'case : 'Rem Cur <> A/C Cur
            '    Call AddRateFCD("NOTNM", ddlRateTypFCD)
            '    ''default  Ex. Rate
            '    'ddlRateTypFCD.Text = "CT"
            '    'txtDealNoFCD.BackColor = Drawing.Color.White
            '    'Call defaultRate()
            '    ddlRateTypFCD.Enabled = True
            'End If
            '2010-11-09 R53060089 Tom End : Interface with Sierra (FX) 

        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Function
    Private Sub loadAccNo()

        Dim dtAccFCDNoResultSet As DataSet
        Dim sumPayAmtGrid As Double
        Dim i As Integer

        strSql = ""
        sumPayAmtGrid = 0

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        Try
            'A/C 
            'strSql = " select '' as code from db2.forlcuac where forcustid = '" & Trim(txtSenId.Value) & "' and accurcd <> 'THB' union " & _
            '         " select acno as code from db2.forlcuac where forcustid = '" & Trim(txtSenId.Value) & "' and accurcd <> 'THB'  "

            '2010-11-12 R53060089 Tom : Interface with Sierra (FX) 
            'strSql = " select '' as code from db2.forlcuac where forcustid = '" & Trim(txtSenId.Value) & "' and accurcd <> 'THB' " & _
            '         " and accurcd in (select cur_cd from db2.host_currency where cur_cd not in ('US1','US2') and sell_tt > 0) " & _
            '         " union " & _
            '         " select acno as code from db2.forlcuac where forcustid = '" & Trim(txtSenId.Value) & "' and accurcd <> 'THB' " & _
            '         " and accurcd in (select cur_cd from db2.host_currency where cur_cd not in ('US1','US2') and sell_tt > 0) "

            strSql = _
            "select '' as code " & _
            "from db2.forlcuac " & _
            "where forcustid = '" & Trim(txtSenId.Value) & "' " & _
            " and accurcd = '" & Trim(ddlAcCurPay.Text) & "' " & _
            " and accurcd in " & _
            " (" & _
            "  select cur_cd " & _
            "  from db2.host_currency " & _
            "  where cur_cd not in ('US1','US2') " & _
            "   and sell_tt > 0 " & _
            "   AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
            "  ) " & _
            "union " & _
            "select acno as code " & _
            "from db2.forlcuac " & _
            "where forcustid = '" & Trim(txtSenId.Value) & "' " & _
            " and accurcd = '" & Trim(ddlAcCurPay.Text) & "' " & _
            " and accurcd in " & _
            " (" & _
            "  select cur_cd " & _
            "  from db2.host_currency " & _
            "  where cur_cd not in ('US1','US2') " & _
            "   and sell_tt > 0 " & _
            "   AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
            "  ) "

            dtAccFCDNoResultSet = connDB.RunQuerySql(strSql)
            If dtAccFCDNoResultSet.Tables(0).Rows.Count > 0 Then

                ddlAcNoPay.DataSource = dtAccFCDNoResultSet.Tables(0)
                ddlAcNoPay.DataTextField = "code"
                ddlAcNoPay.DataBind()
                'pnlRemAmtPay.Visible = True
                pnlPay.Visible = True
                GridAddPay.Visible = True
                pnlHeadPayInfo.Visible = True
                'lblErrFCD.Visible = False

                ddlAcNoPay.Enabled = True

                sumPayAmtGrid = 0
                If Session("dtPayment") Is Nothing Then
                    sumPayAmtGrid = CDbl(txtPayAmnt.Text)

                Else
                    For i = 0 To Session("dtPayment").Rows.Count - 1
                        If Trim(ddlAcCurPay.Text) = Trim(dtPayment.Rows(i).Item(1)) Then
                            sumPayAmtGrid = sumPayAmtGrid + CDbl(Trim(dtPayment.Rows(i).Item(3)))
                        End If
                    Next
                End If

                If ddlAcNoPay.Items.Count = 2 Then
                    ddlAcNoPay.SelectedIndex = 1
                    For i = 0 To Session("dtSumRateInfo").Rows.Count - 1

                        If Trim(ddlAcCurPay.Text) = Trim(dtSumRateInfo.Rows(i).Item(1)) Then
                            txtPayAmnt.Text = Format(CDbl(Trim(dtSumRateInfo.Rows(i).Item(2))) - sumPayAmtGrid, "#,##0.00")
                            txtRemAmnt.Text = Format(CDbl(txtPayAmnt.Text) / CDbl(Trim(dtSumRateInfo.Rows(i).Item(3))), "#,##0.00")
                            Exit For
                        End If

                    Next
                Else
                    txtPayAmnt.Text = "0.00"
                    txtRemAmnt.Text = "0.00"
                End If

            Else
                ' 2008-07-14 Tom :
                'pnlRemAmtFCD.Visible = False
                'pnlPay.Visible = False
                'GridAddratePay.Visible = False
                'lblErrFCD.Text = "*******  Foreign account not found !!!  *******"

                pnlHeadPayInfo.Visible = False
                'pnlRemAmtPay.Visible = False
                pnlPay.Visible = False
                GridAddPay.Visible = False
            End If

        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try
    End Sub

    Protected Sub ddlAcNoFCD_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAcNoPay.SelectedIndexChanged

        Dim i As Integer
        Dim sumPayAmtGrid As Double
        Dim calRemAmt As Double, calPayAmt As Double

        i = 0
        calRemAmt = 0
        calPayAmt = 0
        sumPayAmtGrid = 0

        '2010-11-12 R53060089 Tom Start: Interface with Sierra (FX) 
        ''validate Amount
        'If Not PublicFunc.ValidateNum(txtRemAmnt.Text) = True Then
        '    ddlAcNoPay.SelectedIndex = 0
        '    strMsg = "Amount is incorrect.!!! "
        '    Me.txtRemAmnt.Focus()
        '    GoTo errMsg
        'End If
        'If CDbl(Trim(txtRemAmnt.Text)) <= 0 Then
        '    ddlAcNoPay.SelectedIndex = 0
        '    strMsg = "Amount must more than 0.00 !!!"
        '    Me.txtRemAmnt.Focus()
        '    GoTo errMsg
        'End If
        'Call getAccCur(Trim(ddlAcNoPay.Text))

        If Session("dtPayment") Is Nothing Then
            sumPayAmtGrid = CDbl(txtPayAmnt.Text)

        Else
            For i = 0 To Session("dtPayment").Rows.Count - 1
                If Trim(ddlAcCurPay.Text) = Trim(dtPayment.Rows(i).Item(1)) Then
                    sumPayAmtGrid = sumPayAmtGrid + CDbl(Trim(dtPayment.Rows(i).Item(3)))
                End If
            Next
        End If

        For i = 0 To Session("dtSumRateInfo").Rows.Count - 1

            If Trim(ddlAcCurPay.Text) = Trim(dtSumRateInfo.Rows(i).Item(1)) Then

                calPayAmt = CDbl(Trim(dtSumRateInfo.Rows(i).Item(2))) - sumPayAmtGrid
                calRemAmt = calPayAmt / CDbl(Trim(dtSumRateInfo.Rows(i).Item(3)))

                Exit For
            End If

        Next

        txtPayAmnt.Text = Format(calPayAmt, "###,###,###,###,##0.00")
        txtRemAmnt.Text = Format(calRemAmt, "###,###,###,###,##0.00")

        '2010-11-12 R53060089 Tom End: Interface with Sierra (FX) 


errMsg:
        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub ddlRemCur_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRemCur.SelectedIndexChanged
        Call AddCurRate(ddlInqPayCur) '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System : defauat remcur in ddlInqPayCur
        '2010-11-24 R53060089 Tom Start: Clear data
        Call ClearGrid()
        ' Set panel
        Call SetPanel("LOAD")
        ' Set display Value
        Call SetDisValue()

        resetRate()
        resetPay()

        ddlRateType.Enabled = True
        ddlRateType.BackColor = Drawing.Color.LightCyan
        txtExRate.ReadOnly = False
        txtExRate.BackColor = Drawing.Color.LightCyan

        txtDeal.ReadOnly = False
        txtDeal.BackColor = Drawing.Color.White
        ddlInqPayCur.Enabled = True
        ddlInqPayCur.BackColor = Drawing.Color.LightCyan
        '2010-11-24 R53060089 Tom End: Clear data

        If (Trim(txtSenName1.Text) <> "") And (Trim(ddlRemCur.Text) <> "") Then
            ''A/C No FCD
            'pnlPay.Enabled = True
            '2010-11-08 R53060089 Tom : Interface with Sierra (FX) 
            pnlRate.Enabled = True
            btnInqRateAdd.Enabled = True

        Else
            pnlPay.Enabled = False
            '2010-11-08 R53060089 Tom : Interface with Sierra (FX) 
            pnlRate.Enabled = False
            btnInqRateAdd.Enabled = False
        End If

        '2010-11-08 R53060089 Tom : Interface with Sierra (FX) 
        lblCur.Text = Trim(ddlRemCur.Text)
        txtRemCur.Text = Trim(ddlRemCur.Text)

        lblCurPay.Text = Trim(ddlRemCur.Text)
        txtCur.Text = Trim(ddlRemCur.Text)

        txtRemAmt.Focus()
        '2010-11-09 R53060089 Tom Start : Interface with Sierra (FX) 
        ''2009-08-14 Tom :
        'If Trim(ddlRateTypFCD.Text) <> "" Then
        '    'case : Rem Cur = A/C Cur
        '    If Trim(ddlAcCurPay.Text) = Trim(txtCurPay.Text) Then
        '        Call AddRateFCD("ALL", ddlRateTypFCD)
        '        ddlRateTypFCD.Enabled = True
        '        If ddlRateTypFCD.Text = "NM" Then
        '            ddlRateTypFCD.Enabled = False
        '        End If

        '    Else    'case : 'Rem Cur <> A/C Cur
        '        Call AddRateFCD("NOTNM", ddlRateTypFCD)
        '        ddlRateTypFCD.Enabled = True
        '    End If
        'End If
        '2010-11-09 R53060089 Tom End : Interface with Sierra (FX) 

    End Sub

    Private Function ValDataEntry(ByVal inCase As String, ByRef strMsgError As String) As Boolean
        '*** CMHI:23d74005-35fb-4a20-8d09-cb9b74c7ec30
        Dim sellRate As Double, nomRate As Double, buyRate As Double
        Dim moreExRate As Double, nomAsset As String
        Dim lessExRate As Double, Equsd As Double
        Dim strValDate As String, strMsgRate As String
        Dim valDate As Date
        Dim dblSumrate As Double, dblDiffAmt As Double
        Dim strRateAmt As String, strDiffAmt As String
        Dim dblSumPay As Double, dblDiffPayAmt As Double
        Dim strPayAmt As String, strDiffPayAmt As String
        Dim strLimitCur As String
        Dim limitMargin As Double, paysellRate As Double
        Dim paynomRate As Double, paybuyRate As Double
        Dim sumPayRate As Double, sumPayAmt As Double
        Dim strsumPayRate As String, strsumPayAmt As String
        Dim strLimAdjAmt As String, strFlagUse As String
        Dim dblLimAdjAmt As Double

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        Dim i As Integer

        sumPayRate = 0
        sumPayAmt = 0
        dblLimAdjAmt = 0
        strLimAdjAmt = ""
        strFlagUse = ""

        ValDataEntry = True

        Select Case Trim(UCase(inCase))
            Case "SAVE"

                ' ITSC Code
                If Trim(txtItscCd.Text) = "" Then
                    strMsg = "ITSC Code should be filled. !!!"
                    ValDataEntry = False
                    GoTo exitHandle
                End If
                ' ITSC Name
                If Trim(txtItscName.Text) = "" Then
                    strMsg = "ITSC Name should be filled. !!!"
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                If Trim(txtSenId.Value) = "" Then
                    strMsg = "Sender Id should be filled.!!!"
                    ValDataEntry = False
                    Me.txtSenId.Focus()
                    GoTo exitHandle
                ElseIf Not valSenId() Then
                    strMsg = "Sender Id does not exist in FOR System." & "(" & Trim(txtSenId.Value) & ")"
                    ValDataEntry = False
                    Me.txtSenId.Focus()
                    GoTo exitHandle
                End If

                ' Sender Name
                If Trim(txtSenName1.Text) = "" Then
                    strMsg = "Sender name line 1 should be filled. !!!"
                    ValDataEntry = False
                    Me.txtSenName1.Focus()
                    GoTo exitHandle
                End If
                ' Remitting Cur.
                If Trim(ddlRemCur.Text) = "" Then
                    strMsg = "Remitting Currency should be filled.!!!"
                    ValDataEntry = False
                    Me.ddlRemCur.Focus()
                    GoTo exitHandle
                End If

                ' Remitting Amount.
                If Trim(txtRemAmt.Text) = "" Then
                    strMsg = "Remitting Amount should be filled.!!!"
                    ValDataEntry = False
                    Me.txtRemAmt.Focus()
                    GoTo exitHandle
                Else
                    If Not PublicFunc.ValidateNum(txtRemAmt.Text) Then
                        strMsg = "Remitting Amount is incorrect.!!!"
                        ValDataEntry = False
                        Me.txtRemAmt.Focus()
                        GoTo exitHandle
                    Else
                        If CDbl(Trim(txtRemAmt.Text)) <= 0 Then
                            strMsg = "Remitting Amount must more than 0.00 !!!"
                            ValDataEntry = False
                            Me.txtRemAmt.Focus()
                            GoTo exitHandle
                            '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System start
                            ' 2008-09-08 Tom : validate remcur 'JPY'
                            'ElseIf Trim(ddlRemCur.Text) = "JPY" Then
                            '    If CDbl(Right(txtRemAmt.Text, 2)) > 0 Then
                            '        strMsg = "Remitting Amount not allow decimal.!!!"
                            '        ValDataEntry = False
                            '        Me.txtRemAmt.Focus()
                            '        GoTo exitHandle
                            '    End If
                        ElseIf PublicFunc.validateNotAllowDecimal(Trim(ddlRemCur.Text), Trim(txtRemAmt.Text)) = False Then
                            strMsg = "Remitting Amount not allow decimal.!!!"
                            ValDataEntry = False
                            Me.txtRemAmt.Focus()
                            GoTo exitHandle
                            '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System end

                        End If

                    End If
                End If
                'Value Date
                If Not PublicFunc.ValidateDate(txtValDate.Value) Then
                    If Trim(txtValDate.Value) = "" Then
                        strMsg = "Value Date should be filled.!!!"
                    Else
                        strMsg = "Invalid Date Format!!!"
                    End If
                    ValDataEntry = False
                    Me.txtValDate.Focus()
                    GoTo exitHandle
                End If

                valDate = Trim(txtValDate.Value)
                If Trim(txtValDate.Value) <> Format(valDate, "dd/MM/yyyy") Then
                    strMsg = "Invalid Date Format!!!"
                    ValDataEntry = False
                    Me.txtValDate.Focus()
                    GoTo exitHandle

                Else
                    strValDate = Trim(txtValDate.Value)
                    If ((CDate(strValDate) - CDate(Today.Date.ToString)).Days > 7) Or _
                       ((CDate(Today.Date.ToString) - CDate(strValDate)).Days > 7) Then
                        strMsgError = "Invalid Value Date.!!!" & "\n" & "Value Date should be current date or more than not over 7 days"
                        ValDataEntry = False
                        Me.txtValDate.Focus()
                        Exit Function
                    End If
                End If

                ' Beneficiary Account
                If Trim(txtRecAcc.Value) = "" Then
                    strMsg = "Beneficiary Account should be filled.!!!"
                    ValDataEntry = False
                    Me.txtRecAcc.Focus()
                    GoTo exitHandle
                End If

                'START - xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENMAIL , FORWEB TH Validation
                If InStr(txtBenMail.Value, ",") > 0 Then
                    strMsg = "Please Enter Beneficiary email address and seperate each email by ';' . "
                    ValDataEntry = False
                    Me.txtBenMail.Focus()
                    GoTo exitHandle
                End If
                If Len(txtBenMail.Value) > 200 Then
                    strMsg = "Please Enter Beneficiary email address less than or equal to 200 characters"
                    ValDataEntry = False
                    Me.txtBenMail.Focus()
                    GoTo exitHandle
                End If
                txtBenMail.Value = Replace(txtBenMail.Value, Chr(9), "")
                txtBenMail.Value = Replace(txtBenMail.Value, Chr(10), "")
                txtBenMail.Value = Replace(txtBenMail.Value, vbCrLf, "")
                txtBenMail.Value = Replace(txtBenMail.Value, Chr(13), "")
                txtBenMail.Value = Replace(txtBenMail.Value, " ", "")
                If txtBenMail.Value <> "" Then

                    Dim arrBenMail() As String
                    Static strRegularExpression As Regex
                    strRegularExpression = New Regex("\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")
                    arrBenMail = Split(txtBenMail.Value, ";")
                    For i = 0 To UBound(arrBenMail)
                        If Not strRegularExpression.IsMatch(arrBenMail(i)) Then
                            strMsg = "Invalid input Email"
                            ValDataEntry = False
                            Me.txtBenMail.Focus()
                            GoTo exitHandle
                        End If
                    Next
                End If
                'END - SR3280


                If ddlCtryCd.SelectedIndex = 0 Then
                    strMsg = "Country Code should be filled.!!!"
                    ValDataEntry = False
                    Me.ddlCtryCd.Focus()
                    GoTo exitHandle
                End If


                If CDbl(lblRemRate.Text) > 0 Then
                    ' Rate Information
                    dblSumrate = CDbl(lblRemRate.Text)
                    If dblSumrate <> CDbl(txtRemAmt.Text) Then
                        If CDbl(txtRemAmt.Text) > dblSumrate Then
                            dblDiffAmt = CDbl(txtRemAmt.Text) - dblSumrate
                        Else
                            dblDiffAmt = dblSumrate - CDbl(txtRemAmt.Text)
                        End If
                        strDiffAmt = Format(dblDiffAmt, "#,##0.00")
                        strMsg = "Rate Information - Rem amount should be equal Remittance amount !!! \n" & "Available Amount = " & strDiffAmt & ""
                        ValDataEntry = False
                        txtRemRate.Focus()
                        GoTo exitHandle
                    End If

                    ' Payment Information
                    If CDbl(lblRemPay.Text) = 0 Then
                        '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System : comment this to allow user save the transaction which is pay cur is not cur in account list
                        'strMsg = "Payment Information is required !!!"
                        'ValDataEntry = False
                        'txtPayAmnt.Focus()
                        'GoTo exitHandle
                    Else
                        For i = 0 To Session("dtSumRateInfo").Rows.Count - 1
                            sumPayRate = sumPayRate + CDbl(Trim(dtSumRateInfo.Rows(i).Item(2)))
                        Next
                        strsumPayRate = Format(sumPayRate, "#,##0.00")

                        For i = 0 To Session("dtPayment").Rows.Count - 1
                            sumPayAmt = sumPayAmt + CDbl(Trim(dtPayment.Rows(i).Item(3)))
                        Next
                        strsumPayAmt = Format(sumPayAmt, "#,##0.00")

                        If CDbl(strsumPayRate) <> CDbl(strsumPayAmt) Then
                            strMsg = "Payment Information - Pay amount not match !!!"
                            ValDataEntry = False
                            txtPayAmnt.Focus()
                            GoTo exitHandle
                        End If

                    End If
                End If

                'TR Deal NO. '2013-11-05 :: Kwang :: R56070118
                If chkBkToTr.Checked = True Then
                    If Trim(txtTRdeal.Text) = "" Then
                        strMsg = "TR Deal No. should be filled. !!!"
                        ValDataEntry = False
                        Me.txtTRdeal.Focus()
                        GoTo exitHandle
                    End If
                End If


            Case "RATEINFO"

                'Remitting Amount is numeric
                If PublicFunc.ValidateNum(txtRemRate.Text) = False Then
                    strMsg = "Invalid Format !!! "
                    txtRemRate.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                If CDbl(txtRemRate.Text) = 0 Then
                    strMsg = "Please input amount !!! "
                    txtRemRate.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                'Rate type
                If Trim(ddlRateType.Text) = "" Then
                    strMsg = "Rate type should be selected  !!! "
                    ddlRateType.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                'Exch rate is numeric
                If PublicFunc.ValidateNum(txtExRate.Text) = False Then
                    strMsg = "Invalid Format !!! "
                    txtExRate.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                If CDbl(txtExRate.Text) = 0 Then
                    strMsg = "Please input exchange rate !!! "
                    txtExRate.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                'Pay Currency
                If Trim(ddlInqPayCur.Text) = "" Then
                    strMsg = "Currency should be selected  !!! "
                    ddlInqPayCur.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                'Pay Amount is numeric
                If PublicFunc.ValidateNum(txtPayAmt.Text) = False Then
                    strMsg = "Invalid Format !!! "
                    txtPayAmt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                If CDbl(txtPayAmt.Text) = 0 Then
                    strMsg = "Please input pay amount !!! "
                    txtPayAmt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System :  validate not allow decimal : start
                If PublicFunc.validateNotAllowDecimal(txtRemCur.Text, txtRemRate.Text) = False Then
                    strMsg = "Remitting Amount not allow decimal.!!!"
                    txtRemRate.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If
                'validate Adjust Pay Amount
                If PublicFunc.validateNotAllowDecimal(ddlInqPayCur.Text, txtAdjAmt.Text) = False Then
                    strMsg = "Adjust Pay Amount not allow decimal.!!!"
                    txtAdjAmt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If
                '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System :  validate not allow decimal : end


                'validate Deal No.
                strLimitCur = ""
                limitMargin = 0
                paysellRate = 0
                paynomRate = 0
                paybuyRate = 0

                Call getUsdMargin(strLimitCur, limitMargin)

                nomAsset = 0
                Equsd = 0

                If Not chkEqusd(strLimitCur, nomAsset) Then GoTo exitHandle
                If Not getRate(Trim(ddlInqPayCur.Text), paysellRate, paynomRate, paybuyRate) Then GoTo exitHandle

                If Trim(txtRemCur.Text) <> "USD" Then
                    Equsd = CDbl(txtPayAmt.Text) * paybuyRate / nomAsset
                Else
                    Equsd = CDbl(txtRemAmt.Text)
                End If

                If ((Left(Trim(ddlRateType.Text), 2) = "FW") Or (Left(Trim(ddlRateType.Text), 2) = "SP") Or (Left(Trim(ddlRateType.Text), 2) = "SO")) _
                    And (Trim(txtDeal.Text) = "") Then

                    strMsg = "Please input deal no. !!! "
                    txtDeal.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                ElseIf ((Left(Trim(ddlRateType.Text), 2) = "CT") Or (Left(Trim(ddlRateType.Text), 2) = "CP") Or (Left(Trim(ddlRateType.Text), 2) = "CM")) And (Equsd > limitMargin) And (Trim(txtDeal.Text) = "") Then
                    strMsg = "Please input deal no. !!! "
                    txtDeal.Focus()
                    txtDeal.BackColor = Drawing.Color.LightCyan
                    ValDataEntry = False
                    GoTo exitHandle

                End If

                If (Trim(txtRemCur.Text) = Trim(ddlInqPayCur.Text)) And (Left(Trim(ddlRateType.Text), 2) <> "NM") Then
                    strMsg = "Please change rate type !!! "
                    ddlRateType.Focus()
                    ddlRateType.BackColor = Drawing.Color.LightCyan
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                'Adjust amount is numeric
                If PublicFunc.ValidateNum(txtAdjAmt.Text) = False Then
                    strMsg = "Invalid Format !!! "
                    txtAdjAmt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                If (CDbl(txtAdjAmt.Text) <> 0) And (Session("AdjFlag") = False) Then
                    strMsg = "Please select type for adjust amount!!! "
                    btnAdjPlus.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                    '2010-12-02 R53060089 Tom :
                ElseIf (Session("AdjFlag") = True) And (CDbl(txtAdjAmt.Text) = 0) Then
                    strMsg = "Please input adjust amount!!! "
                    txtAdjAmt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                '2010-11-24 R53060089 Tom : Limit for Adjust Pay Amt
                '***56100048 Ron
                'Call PublicFunc.getLimitAdj(strLimAdjAmt, strFlagUse)
                Call PublicFunc.getLimitAdj(strLimAdjAmt, strFlagUse, concur.SWIFTCODE)

                If strFlagUse = "Y" Then
                    dblLimAdjAmt = CDbl(strLimAdjAmt)
                    If CDbl(txtAdjAmt.Text) > dblLimAdjAmt Then
                        strMsg = "Adjust amount is over limit!!! "
                        txtAdjAmt.Focus()
                        ValDataEntry = False
                        GoTo exitHandle
                    End If
                End If


            Case "RATEAMT"

                If Trim(txtRemCur.Text) <> Trim(ddlInqPayCur.Text) Then
                    '***R56100048 Repalce "THB"
                    'If ddlInqPayCur.Text <> "THB" Then
                    If ddlInqPayCur.Text <> CType(Session("concurrencyInfo"), _
                     FORWEB_Concurrency).BaseCurrency Then
                        moreExRate = Session("calRate") + CDbl(0.01 * Session("calRate"))
                        lessExRate = Session("calRate") - CDbl(0.01 * Session("calRate"))

                        If ((CDbl(txtExRate.Text) > moreExRate) Or (CDbl(txtExRate.Text) < lessExRate)) And (Trim(txtExRate.Text) <> "CM") Then
                            'ValidateData = False

                            strMsgRate = "This Ex.Rate is over or less than 1% of " & Session("calRate") & " " & " Rate"
                            cstext1 = "alert('" & strMsgRate & "');"
                            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                            GoTo exitHandle
                        End If

                    End If
                End If

            Case "PAYINF"


                'A/C No.
                If Trim(ddlAcNoPay.Text) = "" Then
                    strMsg = "A/C No. should be filled.!!! "
                    ddlAcNoPay.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                'A/C Cur.
                If Trim(ddlAcCurPay.Text) = "" Then
                    strMsg = "A/C Cur. should be filled.!!! "
                    ddlAcCurPay.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If
                'Pay Amount is numeric
                If Not PublicFunc.ValidateNum(txtPayAmnt.Text) = True Then
                    strMsg = "Pay Amount is incorrect.!!! "
                    txtPayAmnt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If
                If CDbl(txtPayAmnt.Text) = 0 Then
                    strMsg = "Pay Amount should be filled.!!! "
                    txtPayAmnt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

                If PublicFunc.validateNotAllowDecimal(Trim(ddlAcCurPay.Text), Trim(txtPayAmnt.Text)) = False Then
                    strMsg = "Pay Amount not allow decimal.!!!"
                    ValDataEntry = False
                    Me.txtPayAmnt.Focus()
                    GoTo exitHandle
                    '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System end

                End If

                'Rem Cur.
                If Trim(txtCur.Text) = "" Then
                    strMsg = "Currency should be filled.!!! "
                    ValDataEntry = False
                    GoTo exitHandle
                End If
                'Rem Amount is numeric
                If Not PublicFunc.ValidateNum(txtRemAmnt.Text) = True Then
                    strMsg = "Amount is incorrect.!!! "
                    txtRemAmnt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If
                If CDbl(txtRemAmnt.Text) = 0 Then
                    strMsg = "Amount should be filled.!!! "
                    txtRemAmnt.Focus()
                    ValDataEntry = False
                    GoTo exitHandle
                End If

        End Select

exitHandle:
        Session("ValidateData") = ValDataEntry

    End Function

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click

        btnSave.Enabled = False
        ' validate Data 
        If Not ValDataEntry("SAVE", strMsg) Then
            Page.MaintainScrollPositionOnPostBack = False
            GoTo errMsg
        End If

        If Not ValDataEntry("RATEAMT", strMsg) Then
            Page.MaintainScrollPositionOnPostBack = False
            GoTo errMsg
        End If

        If Not InsertTran() Then Exit Sub
        ' 2008-09-23 Tom :

        '2012-11-06 R55040057 Tom Start : Support new organize
        If Session("Page") = "Entry" Then
            Response.Redirect("~/printDet.aspx?MenuFunc=1130")
        ElseIf Session("Page") = "Amend" Then
            Response.Redirect("~/printDet.aspx?MenuFunc=1150")
        End If
        '2012-11-06 R55040057 Tom Start : Support new organize

        btnSave.Enabled = True
errMsg:
        If strMsg <> "" Then
            btnSave.Enabled = True
            'cstext1 = "alert('" & strMsg & "');"
            'cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Code Copied from FORWEB TH Version, to show the error msg from Data Entry Validation 
            txtErrMsg.Value = strMsg
            cs.RegisterStartupScript(cstype, csname1, "alertMsg();", True)

        End If
    End Sub

    'Protected Sub CustValDate_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustValDate.ServerValidate

    '    Try

    '        If Not ValDataEntry("VALDATE", strMsg) Then
    '            strMsg = "Invalid Value Date. !!!"
    '            args.IsValid = False
    '            Return
    '        End If

    '    Catch ex As Exception
    '        strMsg = ex.Message
    '        args.IsValid = False
    '        Return
    '    End Try
    'End Sub

    '    Protected Sub btnerrMsg_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnerrMsg.Click

    '        If Page.IsValid Then
    '        Else
    '            GoTo errMsg
    '        End If

    'errMsg:
    '        If strMsg <> "" Then
    '            cstext1 = "alert('" & strMsg & "');"
    '            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
    '        End If
    '    End Sub


    'Protected Sub txtRemAmt_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRemAmt.TextChanged
    '    Dim inRemAmt As String


    '    inRemAmt = Format(CDbl(txtRemAmt.Text), "###,###,###,###,##0.00")
    '    txtRemAmt.Text = Trim(inRemAmt)
    'End Sub

    Protected Sub btnFormAmt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFormAmt.Click
        Dim inRemAmt As String

        If PublicFunc.ValidateNum(txtRemAmt.Text) Then
            inRemAmt = Format(CDbl(txtRemAmt.Text), "###,###,###,###,##0.00")
            'txtRemAmt.MaxLength = 20
            txtRemAmt.Text = Trim(inRemAmt)
            'txtRemAmt.MaxLength = 14
        End If


    End Sub
    Private Sub SetDefaultGrid()


        Dim dr As DataRow
        '2010-11-08 R53060089 Tom : Interface with Sierra (FX)
        ' ## set default grid rate ##
        If (Session("dtAddInqRate") Is Nothing) And (GridAddInqRate.Rows.Count = 0) Then
            dtAddInqRate.Columns.Add(New DataColumn("No.", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Rem Cur.", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Rem Amount", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn("Rate Type", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Ex. Rate", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn("Deal No.", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Pay Cur.", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Pay Amount", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn("Adj. Amt", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn("Tot Pay", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn(" ", GetType(System.String)))

            dr = dtAddInqRate.NewRow
            dr("No.") = dtAddInqRate.Rows.Count + 1
            dr("Rem Cur.") = ""
            dr("Rem Amount") = "0.00"
            dr("Rate Type") = ""
            dr("Ex. Rate") = "0.0000000"
            dr("Deal No.") = ""
            dr("Pay Cur.") = ""
            dr("Pay Amount") = "0.00"
            dr("Adj. Amt") = "0.00"
            dr("Tot Pay") = "0.00"
            dr(" ") = ""

            dtAddInqRate.Rows.Add(dr)

            GridAddInqRate.DataSource = dtAddInqRate
            GridAddInqRate.DataBind()
            GridAddInqRate.Rows(0).Enabled = False

        End If

        ' ## set default grid payment ##
        If (Session("dtPayment") Is Nothing) Or (GridAddPay.Rows.Count < 0) Then
            '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
            'dtPayment.Columns.Add(New DataColumn("No.", GetType(System.String)))
            'dtPayment.Columns.Add(New DataColumn("Cur.", GetType(System.String)))
            'dtPayment.Columns.Add(New DataColumn("Amount", GetType(System.Double)))
            'dtPayment.Columns.Add(New DataColumn("A/C No.", GetType(System.String)))
            'dtPayment.Columns.Add(New DataColumn("A/C Cur.", GetType(System.String)))
            'dtPayment.Columns.Add(New DataColumn("Rate Type", GetType(System.String)))
            'dtPayment.Columns.Add(New DataColumn("Ex.Rate", GetType(System.String)))
            'dtPayment.Columns.Add(New DataColumn("Deal No.", GetType(System.String)))

            dtPayment.Columns.Add(New DataColumn("No.", GetType(System.String)))
            dtPayment.Columns.Add(New DataColumn("A/C Cur.", GetType(System.String)))
            dtPayment.Columns.Add(New DataColumn("A/C No.", GetType(System.String)))
            dtPayment.Columns.Add(New DataColumn("Pay Amount", GetType(System.Double)))
            dtPayment.Columns.Add(New DataColumn("Rem Cur.", GetType(System.String)))
            dtPayment.Columns.Add(New DataColumn("Rem Amount", GetType(System.Double)))


            dr = dtPayment.NewRow
            dr("No.") = dtPayment.Rows.Count + 1
            dr("A/C Cur.") = ""
            dr("A/C No.") = ""
            dr("Pay Amount") = 0.0
            dr("Rem Cur.") = ""
            dr("Rem Amount") = 0.0
            '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
            'dr("Rate Type") = ""
            'dr("Ex.Rate") = 0.0
            'dr("Deal No.") = ""
            dtPayment.Rows.Add(dr)
        Else
            dtPayment = Session("dtPayment")
        End If

        If (GridAddPay.Rows.Count = 0) Then
            GridAddPay.DataSource = dtPayment
            GridAddPay.DataBind()
            GridAddPay.Rows(0).Enabled = False
        End If
        ' ## set default grid ##

        ' ## set default grid Sum Rate Info ##
        If (Session("dtSumRateInfo") Is Nothing) Or (GridSumRate.Rows.Count < 0) Then
            dtSumRateInfo.Columns.Add(New DataColumn("No.", GetType(System.String)))
            dtSumRateInfo.Columns.Add(New DataColumn("Pay Cur.", GetType(System.String)))
            dtSumRateInfo.Columns.Add(New DataColumn("Total Pay Amount", GetType(System.Double)))
            dtSumRateInfo.Columns.Add(New DataColumn("Acc Rate", GetType(System.Double)))

            dr = dtSumRateInfo.NewRow
            dr("No.") = dtSumRateInfo.Rows.Count + 1
            dr("Pay Cur.") = ""
            dr("Total Pay Amount") = 0.0
            dr("Acc Rate") = 0.0

            dtSumRateInfo.Rows.Add(dr)
        Else
            dtSumRateInfo = Session("dtSumRateInfo")
        End If

        If (GridSumRate.Rows.Count = 0) Then
            GridSumRate.DataSource = dtSumRateInfo
            GridSumRate.DataBind()
            GridSumRate.Rows(0).Enabled = False
        End If
        ' ## set default grid ##


    End Sub

    Protected Sub btnAddPay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddPay.Click
        Dim i As Integer, j As Integer
        Dim dr As DataRow
        Dim sumRemAmt As Double, lessAmt As Double
        Dim sumPayAmt As Double, dblTotPayAmt As Double

        sumRemAmt = 0
        sumPayAmt = 0
        dblTotPayAmt = 0

        'validate Rate Info
        If Not ValDataEntry("PAYINF", strMsg) Then
            Page.MaintainScrollPositionOnPostBack = False
            GoTo errMsg

        End If
        GridAddPay.Enabled = True

        'check refresh
        If (Session("dtPayment") Is Nothing) Then
        Else
            For j = 0 To Session("dtPayment").Rows.Count - 1
                '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 
                'If ((Trim(dtPayment.Rows(j).Item(1)) = Trim(txtCurPay.Text)) And (CDbl(Trim(dtPayment.Rows(j).Item(2))) = CDbl(Trim(txtAmtPay.Text))) _
                '    And (Trim(dtPayment.Rows(j).Item(3)) = Trim(ddlAcNoPay.Text)) And (Trim(dtPayment.Rows(j).Item(4)) = Trim(ddlAcCurPay.Text)) _
                '    And (Trim(dtPayment.Rows(j).Item(5)) = Trim(ddlRateTypFCD.Text)) And (CDbl(Trim(dtPayment.Rows(j).Item(6))) = CDbl(Trim(txtExRateFCD.Text))) _
                '    And (Trim(dtPayment.Rows(j).Item(7)) = Trim(txtDealNoFCD.Text))) _
                '    Or ((Trim(dtPayment.Rows(j).Item(3)) = Trim(ddlAcNoPay.Text))) Then
                If ((Trim(dtPayment.Rows(j).Item(1)) = Trim(ddlAcCurPay.Text)) And (Trim(dtPayment.Rows(j).Item(2)) = Trim(ddlAcNoPay.Text)) _
                     And (CDbl(Trim(dtPayment.Rows(j).Item(3))) = CDbl(Trim(txtPayAmnt.Text))) And (Trim(dtPayment.Rows(j).Item(4)) = Trim(txtCur.Text))) _
                     And (CDbl(Trim(dtPayment.Rows(j).Item(5))) = CDbl(Trim(txtRemAmnt.Text))) Then
                    dtPayment = Session("dtPayment")
                    GridAddPay.DataSource = dtPayment
                    GridAddPay.DataBind()

                    resetPay()

                    Exit Sub
                End If
            Next
        End If

        '2010-11-09 R53060089 Tom Start : Interface with Sierra (FX) 
        ''count Rate in grid
        'cntRate = GridAddPay.Rows.Count + 1

        'If cntRate > 2 Then
        '    resetPay()
        '    strMsg = "Can not add rate more than 2. "
        '    GoTo errMsg
        'End If
        '2010-11-09 R53060089 Tom End : Interface with Sierra (FX) 

        GridAddPay.Rows(0).Enabled = True
        'display grid  default
        dr = dtPayment.NewRow
        If (GridAddPay.Rows.Count = 1) And (Trim(dtPayment.Rows(0).Item(4)) = "") Then
            dtPayment.Rows(0).Delete()
            GridAddPay.DataSource = dtPayment
            GridAddPay.DataBind()
        End If


        If strMsg = "" Then
            dr = dtPayment.NewRow
            dr("No.") = dtPayment.Rows.Count + 1
            dr("A/C Cur.") = Trim(ddlAcCurPay.Text)
            dr("A/C No.") = Trim(ddlAcNoPay.Text)
            dr("Pay Amount") = Trim(txtPayAmnt.Text)
            dr("Rem Cur.") = Trim(txtCur.Text)
            dr("Rem Amount") = Trim(txtRemAmnt.Text)
            '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 
            'dr("Rate Type") = Me.ddlRateTypFCD.Text.ToString
            'dr("Ex.Rate") = Me.txtExRateFCD.Text
            'dr("Deal No.") = Me.txtDealNoFCD.Text.ToString()
            'dtPayment.Rows.Add(dr)


            '2010-11-13 R53060089 Tom Start: Interface with Sierra (FX) 
            'sum Pay Amount in datagrid

            For i = 0 To Session("dtSumRateInfo").Rows.Count - 1
                If Trim(dtSumRateInfo.Rows(i).Item(1)) = Trim(ddlAcCurPay.Text) Then
                    dblTotPayAmt = CDbl(Trim(dtSumRateInfo.Rows(i).Item(2)))
                End If

            Next

            If Session("dtPayment") Is Nothing Then

                If dblTotPayAmt > CDbl(sumPayAmt) Then
                    lessAmt = Format(CDbl(dblTotPayAmt - CDbl(sumPayAmt)), "###,###,###,###,##0.00")
                Else
                    lessAmt = Format(CDbl(CDbl(sumPayAmt) - dblTotPayAmt), "###,###,###,###,##0.00")
                End If

                sumPayAmt = CDbl(txtPayAmnt.Text)
                sumRemAmt = CDbl(Trim(txtRemAmnt.Text))

            Else
                sumRemAmt = sumRemAmt + CDbl(txtRemAmnt.Text)
                For i = 0 To Session("dtPayment").Rows.Count - 1

                    sumRemAmt = sumRemAmt + CDbl(Trim(dtPayment.Rows(i).Item(5)))

                    If Trim(dtPayment.Rows(i).Item(1)) = Trim(ddlAcCurPay.Text) Then
                        sumPayAmt = sumPayAmt + CDbl(Trim(dtPayment.Rows(i).Item(3)))
                    End If

                Next

                If dblTotPayAmt > CDbl(sumPayAmt) Then
                    lessAmt = Format(CDbl(dblTotPayAmt - CDbl(sumPayAmt)), "###,###,###,###,##0.00")
                Else
                    lessAmt = Format(CDbl(CDbl(sumPayAmt) - dblTotPayAmt), "###,###,###,###,##0.00")
                End If

                sumPayAmt = Format(CDbl(sumPayAmt) + CDbl(txtPayAmnt.Text), "###,###,###,###,##0.00")

            End If


            If CDbl(sumPayAmt) > dblTotPayAmt Then

                strMsg = "Pay Amount is more than Total Pay Amount !!!" & "\n" & "Please input pay amount less than or equal : " & lessAmt
                cstext1 = "alert('" & strMsg & "');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                'txtPayAmnt.ReadOnly = False
                'txtPayAmnt.Focus()

                '2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
                If lessAmt = 0 Then
                    resetPay()
                End If

                GoTo errMsg
            End If

        End If

        '2010-11-13 R53060089 Tom End: Interface with Sierra (FX) 

        '  Sum Rem Amount
        'If Session("dtPayment") Is Nothing Then
        '    sumRemAmt = sumRemAmt + CDbl(Trim(txtRemAmnt.Text))

        'Else
        '    sumRemAmt = sumRemAmt + CDbl(Trim(dtPayment.Rows(0).Item(5)))
        '    For i = 0 To Session("dtPayment").Rows.Count - 1
        '        sumRemAmt = sumRemAmt + CDbl(Trim(txtRemAmnt.Text))
        '    Next
        'End If

        'lessAmt = 0
        'If CDbl(txtRemAmt.Text) < (CDbl(sumRemAmt)) Then
        '    'lessAmt = Format(CDbl(Trim(txtAmtPay.Text)) - ((CDbl(sumAmtPay)) - CDbl(txtRemAmt.Text)), "###,###,###,###,##0.00")
        ''    lessAmt = Format(((CDbl(sumRemAmt)) - CDbl(txtRemAmt.Text)), "###,###,###,###,##0.00")

        '    'strMsg = "Amount is more than Remitting Amount !!!" & "\n" & "Please input amount less than or equal : " & lessAmt
        '    strMsg = "Amount is more than Remitting Amount !!!"
        '    txtRemAmt.ReadOnly = False
        '    txtRemAmt.Focus()
        '    GoTo errMsg

        'Else
        '    '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 
        '    ''validate Amount
        '    'ValDataEntry("PAYAMT", strMsg)

        '    dtPayment.Rows.Add(dr)
        '    GridAddPay.DataSource = dtPayment
        '    GridAddPay.DataBind()
        '    Session("dtPayment") = dtPayment
        'End If

        dtPayment.Rows.Add(dr)
        GridAddPay.DataSource = dtPayment
        GridAddPay.DataBind()
        Session("dtPayment") = dtPayment

        lblRemPay.Text = Format(sumRemAmt, "###,###,###,###,##0.00")
        resetPay()

        If ddlAcCurPay.Items.Count = 2 Then
            ddlAcCurPay.SelectedIndex = 1
            ddlAcNoPay.Enabled = True
        End If
        'If ddlAcNoPay.Items.Count = 2 Then
        '    ddlAcNoPay.SelectedIndex = 1
        'End If

errMsg:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If


    End Sub
    Private Sub getUsdMargin(ByRef strLimitCur As String, ByRef limMargin As Double)

        Dim dtLimitMargin As DataRow
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        Try
            '***56100048 Ron
            'strSql = "select a.limtcur,a.margin  from db2.frcmpdlt a, db2.frcmtbcd b where a.prodcd = '" & Trim(strProdName) & "' and a.limitcd = 'FORLMTDEAL'" & _
            '                " and b.type = 'C008'  and  b.code = a.limitcd and b.flaguse = 'Y' "

            '***56100048 Ron SWIFTTCD on FRCMPDLT -003
            'strSql = _
            '"select a.limtcur,a.margin  from db2.frcmpdlt a, db2.frcmtbcd b " & _
            '"where a.prodcd = '" & Trim(strProdName) & "' " & _
            '" and a.limitcd = 'FORLMTDEAL'" & _
            '" and b.type = 'C008'  and  b.code = a.limitcd and b.flaguse = 'Y' " & _
            '" AND b.SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C008' and flaguse = 'Y' ", concur.SWIFTCODE) & "' "
            strSql = _
            "select a.limtcur,a.margin  from db2.frcmpdlt a, db2.frcmtbcd b " & _
            "where a.prodcd = '" & Trim(strProdName) & "' " & _
            " and a.limitcd = 'FORLMTDEAL'" & _
            " and b.type = 'C008'  and  b.code = a.limitcd and b.flaguse = 'Y' " & _
            " AND b.SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C008' and flaguse = 'Y' ", concur.SWIFTCODE) & "' " & _
            " AND a.SWIFTTCD = '" & concur.SWIFTCODE & "'"

            Dim ResultSetLimit As DataSet = connDB.RunQuerySql(strSql)
            If ResultSetLimit.Tables.Count > 0 Then
                For Each dtLimitMargin In ResultSetLimit.Tables(0).Rows
                    strLimitCur = Trim(dtLimitMargin.Item(0).ToString)
                    limMargin = dtLimitMargin.Item(1)
                Next
            End If
        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Sub
    Private Function chkEqusd(ByVal InCur As String, ByRef nomAsset As Double) As Boolean
        '*** CMHI:85eab60a-2b34-4fba-916b-e0f535a75372

        Dim dtRateRow As DataRow
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        chkEqusd = True

        strSql = _
        "select nom_asset " & _
        "from db2.host_currency " & _
        "where cur_cd = '" & Trim(InCur) & "' " & _
        " AND SWIFTTCD = '" & concur.SWIFTCODE & "' "

        Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
        If ResultSet.Tables.Count > 0 Then
            For Each dtRateRow In ResultSet.Tables(0).Rows
                nomAsset = CDbl(dtRateRow.Item(0))
            Next
        End If

    End Function
    '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 
    'Private Sub AddRateFCD(ByVal InCase As String, ByVal RateType As DropDownList)
    '    Dim strSql As String
    '    Dim dtRateResultSet As DataSet
    '    Dim dtRateRow As DataRow
    '    strSql = ""
    '    RateType.DataSource = ""

    '    Try
    '        Select Case UCase(InCase)
    '            Case "ALL"
    '                strSql = "select ' ' as code from db2.frcmtbcd where type = 'T008' and code <> 'CM' union select code from db2.frcmtbcd where type = 'T008' and code <> 'CM'  "
    '            Case "NOTNM"
    '                strSql = "select ' ' as code from db2.frcmtbcd where type = 'T008' and code not in ('NM','CM') union select code from db2.frcmtbcd where type = 'T008' and code not in ('NM','CM')  "
    '        End Select
    '        dtRateResultSet = connDB.RunQuerySql(strSql)
    '        If dtRateResultSet.Tables.Count > 0 Then
    '            For Each dtRateRow In dtRateResultSet.Tables(0).Rows
    '                RateType.DataSource = dtRateResultSet.Tables(0)
    '                RateType.DataTextField = "code"
    '                RateType.DataBind()
    '            Next
    '        End If
    '        If (Trim(UCase(InCase)) = "ALL") Then
    '            ddlRateTypFCD.Text = "NM"
    '            txtExRateFCD.Text = "1.0000000"
    '            ddlRateTypFCD.BackColor = Drawing.Color.LightGray
    '            ddlRateTypFCD.Enabled = False
    '            txtExRateFCD.BackColor = Drawing.Color.LightGray
    '            txtExRateFCD.ReadOnly = True
    '            txtDealNoFCD.BackColor = Drawing.Color.White
    '        Else
    '            'default  Ex. Rate
    '            ddlRateTypFCD.Text = "CT"
    '            txtDealNoFCD.BackColor = Drawing.Color.White
    '            Call defaultRate()
    '        End If


    '    Catch odbce As OdbcException

    '        Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Cancel")

    '    Catch ex As Exception

    '        Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Cancel")

    '    End Try
    'End Sub
    Private Sub AddRate(ByVal InCase As String)
        Dim strSql As String, strRateType As String
        Dim dblExRate As Double
        Dim dtRateResultSet As DataSet
        Dim dtRateRow As DataRow
        Dim i As Integer
        strSql = ""
        ddlRateType.DataSource = ""

        strRateType = Left(Trim(ddlRateType.Text), 2)
        dblExRate = CDbl(Trim(txtExRate.Text))

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        Try
            Select Case UCase(InCase)
                '***[Start]56100048 Ron
                'FCD
                Case "ALL"
                    'strSql = "select ' ' as data from db2.frcmtbcd where type = 'T008' union select code ||' : '||value as data from db2.frcmtbcd where type = 'T008'  "
                    strSql = _
                    "select ' ' as data from db2.frcmtbcd where type = 'T008' union " & _
                    "select code ||' : '||value as data from db2.frcmtbcd " & _
                    "where type = 'T008'  " & _
                    " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T008'", concur.SWIFTCODE) & "' "
                Case "NOTNM"
                    ''strSql = "select ' ' as data from db2.frcmtbcd where type = 'T008' and code not in ('NM','CM') union select code ||' : '||value as data from db2.frcmtbcd where type = 'T008' and code not in ('NM','CM')  "
                    'strSql = "select ' ' as data from db2.frcmtbcd where type = 'T008' and code <> 'NM' union select code ||' : '||value as data from db2.frcmtbcd where type = 'T008' and code <> 'NM'  "
                    strSql = _
                    "select ' ' as data from db2.frcmtbcd where type = 'T008' and code <> 'NM' union " & _
                    "select code ||' : '||value as data from db2.frcmtbcd " & _
                    "where type = 'T008' and code <> 'NM'  " & _
                    " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T008' and code <> 'NM'  ", concur.SWIFTCODE) & "' "
                    'THB
                Case "NOTCT"
                    'strSql = "select ' ' as data from db2.frcmtbcd where type = 'T008' and code <> 'CT' union select code ||' : '||value as data from db2.frcmtbcd where type = 'T008' and code <> 'CT' "
                    strSql = _
                    "select ' ' as data from db2.frcmtbcd where type = 'T008' and code <> 'CT' union " & _
                    "select code ||' : '||value as data from db2.frcmtbcd " & _
                    "where type = 'T008' and code <> 'CT' " & _
                    " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T008' and code <> 'CT' ", concur.SWIFTCODE) & "' "
                Case "NOTCM"
                    'strSql = "select ' ' as data from db2.frcmtbcd where type = 'T008' and code <> 'CM'  union select code ||' : '||value as data from db2.frcmtbcd where type = 'T008' and code <> 'CM' "
                    strSql = _
                    "select ' ' as data from db2.frcmtbcd where type = 'T008' and code <> 'CM'  union " & _
                    "select code ||' : '||value as data from db2.frcmtbcd " & _
                    "where type = 'T008' and code <> 'CM' " & _
                    " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T008' and code <> 'CM' ", concur.SWIFTCODE) & "' "
                    '***[End]56100048 Ron
            End Select
            dtRateResultSet = connDB.RunQuerySql(strSql)
            If dtRateResultSet.Tables.Count > 0 Then
                For Each dtRateRow In dtRateResultSet.Tables(0).Rows
                    ddlRateType.DataSource = dtRateResultSet.Tables(0)
                    ddlRateType.DataTextField = "data"
                    ddlRateType.DataBind()
                Next
            End If

            If Trim(txtRemCur.Text) <> Trim(ddlInqPayCur.Text) Then
                If strRateType <> "" Then
                    For i = 0 To ddlRateType.Items.Count - 1
                        If Left(ddlRateType.Items(i).Text, 2) = strRateType Then
                            ddlRateType.SelectedIndex = i
                        End If
                    Next
                End If
                If dblExRate <> 0 Then
                    txtExRate.Text = Format(dblExRate, "#,##0.0000000")
                End If
            End If

        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try
    End Sub
    Private Sub defaultRate()

        Dim i As Integer

        'case :  rem cur = pay cur
        If Trim(ddlRemCur.Text) = Trim(ddlInqPayCur.Text) Then
            For i = 0 To ddlRateType.Items.Count - 1
                If Left(ddlRateType.Items(i).Text, 2) = "NM" Then
                    ddlRateType.SelectedIndex = i
                End If
            Next
            txtExRate.Text = "1.0000000"
            ddlRateType.Enabled = False
            ddlRateType.BackColor = Drawing.Color.LightGray
            txtExRate.BackColor = Drawing.Color.LightGray
            txtExRate.ReadOnly = True

        Else    'case :  rem cur <> pay cur
            'default  Ex. Rate
            If (Left(ddlRateType.Text, 2) = "NM") Or Trim(ddlRateType.Text) = "" Then
                For i = 0 To ddlRateType.Items.Count - 1
                    If Left(ddlRateType.Items(i).Text, 2) = "CT" Then
                        ddlRateType.SelectedIndex = i
                    End If
                Next
                '2013-03-12 Tom : IM13-050945
                'txtExRate.Text = 0
                txtExRate.Text = "0.0000000"
            End If
            ddlRateType.Enabled = True
            ddlRateType.BackColor = Drawing.Color.LightCyan
            txtExRate.ReadOnly = False
            txtExRate.BackColor = Drawing.Color.LightCyan
        End If

    End Sub
    Private Function getRate(ByVal InRemCur As String, ByRef sellRate As Double, ByRef nomRate As Double, ByRef buyRate As Double) As Boolean
        '*** CMHI:3cc834c9-8a71-4bf0-88c6-886e37cd1362
        Dim dtRateRow As DataRow
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        getRate = True
        ' validate ex rate with sell_tt
        sellRate = 0
        strSql = _
        "select sell_tt , nom_asset, buy_tt  " & _
        "from db2.host_currency " & _
        "where cur_cd = '" & Trim(InRemCur) & "' " & _
        " AND SWIFTTCD = '" & concur.SWIFTCODE & "'"

        Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
        If ResultSet.Tables.Count > 0 Then
            For Each dtRateRow In ResultSet.Tables(0).Rows
                sellRate = CDbl(dtRateRow.Item(0))
                nomRate = CDbl(dtRateRow.Item(1))
                buyRate = CDbl(dtRateRow.Item(2))
            Next
        End If

    End Function

    Private Sub resetPay()

        If ddlAcCurPay.Items.Count <> 0 Then
            ddlAcCurPay.SelectedIndex = 0
        End If
        ddlAcCurPay.BackColor = Drawing.Color.LightCyan

        If ddlAcNoPay.Items.Count <> 0 Then
            ddlAcNoPay.SelectedIndex = 0
        End If

        ddlAcNoPay.Enabled = False

        txtPayAmnt.Text = "0.00"

        txtRemAmnt.Text = "0.00"


    End Sub

    Protected Sub btnResAddPay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnResAddPay.Click
        resetPay()
    End Sub
    'Private Function getSpecRate() As Boolean

    '    Dim strSql As String

    '    getSpecRate = False
    '    Try
    '        strSql = "select ratemrg from db2.forlcurt where forcustid = '" & Trim(txtSenId.Value) & "' and " & _
    '                 " prodcd = '" & Trim(strProdName) & "'  and  curcd = '" & Trim(txtRemCur.Text) & "'"

    '        Dim ResultSetSpec As DataSet = connDB.RunQuerySql(strSql)
    '        If ResultSetSpec.Tables.Count > 0 Then

    '            Dim rowdetSpec As DataRow
    '            For Each rowdetSpec In ResultSetSpec.Tables(0).Rows
    '                Session("rateMrgTHB") = CDbl(rowdetSpec.Item(0))
    '                getSpecRate = True
    '            Next
    '        End If

    '    Catch odbce As OdbcException
    '        Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
    '    Catch ex As Exception
    '        Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
    '    End Try

    'End Function

    Protected Sub GridAddPay_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridAddPay.RowDeleting
        Dim dr As DataRow
        Dim i As Integer
        Dim sumRemAmt As Double

        sumRemAmt = 0

        dtPayment = Session("dtPayment")
        If e.RowIndex - 1 < dtPayment.Rows.Count Then
            dtPayment.Rows(e.RowIndex).Delete()
            GridAddPay.DataSource = dtPayment
            GridAddPay.DataBind()
            Session("dtPayment") = dtPayment
        End If


        For i = 0 To Session("dtPayment").Rows.Count - 1
            sumRemAmt = sumRemAmt + CDbl(Trim(dtPayment.Rows(i).Item(5)))
        Next
        lblRemPay.Text = Format(sumRemAmt, "###,###,###,###,##0.00")


        ' reset control
        If GridAddPay.Rows.Count = 0 Then
            resetPay()
            pnlUpdPay.Visible = False
            pnlAddPay.Visible = True
        End If

        'default Grid Rate
        If (GridAddPay.Rows.Count = 0) Then
            dr = dtPayment.NewRow
            dr("No.") = dtPayment.Rows.Count + 1
            dr("A/C Cur.") = ""
            dr("A/C No.") = ""
            dr("Pay Amount") = 0.0
            dr("Rem Cur.") = ""
            dr("Rem Amount") = 0.0
            '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
            'dr("Rate Type") = ""
            'dr("Ex.Rate") = 0.0
            'dr("Deal No.") = ""
            dtPayment.Rows.Add(dr)

            GridAddPay.DataSource = dtPayment
            GridAddPay.DataBind()
            GridAddPay.Rows(0).Enabled = False
            Session("dtPayment") = Nothing

        End If
    End Sub

    Protected Sub btnResUpdFCD_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnResUpdFCD.Click
        resetPay()
    End Sub
    Private Function InsertTran() As Boolean
        '*** CMHI:f921268c-dba2-4093-af2a-211987bdb802
        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim myCommand As OdbcCommand = New OdbcCommand()
        Dim myTrans As OdbcTransaction

        Dim strItscCd As String, strSenId As String, strSenName1 As String
        Dim strSenName2 As String, strSenAddr1 As String, _
         strSenAddr2 As String, strRemCur As String
        Dim dblRemAmt As Double, strValDate As String, strRecAcc As String
        Dim strSpecInst As String, strComCd As String, strORRef As String, _
         strRemark As String
        Dim valDate As Date
        Dim i As Integer, IntserNoDrac As Integer, IntserNoRate As Integer
        Dim strSerDrac As String, strAcNo As String, strSerRate As String
        Dim strSenName As String, strObjDesc As String
        Dim strPreAdv As String, strBkToTr As String, strDetChar As String, _
         strCtryCd As String
        Dim strRemCurRate As String, strRateTyp As String, _
         strDealNo As String, strAcCur As String
        Dim dblRemAmtRate As Double, dblExRate As Double, dblAcAmt As Double
        Dim dbAdjAmt As Double, dblTotAcAmt As Double, dblPayAmt As Double, _
         dblRemAmtDrac As Double
        Dim strPayCur As String, strRemCurDrac As String, strAcType As String
        Dim strProcRemk As String, strOrgSenId As String, strSql As String
        Dim strTRdeal As String
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), _
         FORWEB_Concurrency)

        conn.Open()
        myCommand.Connection = conn
        myTrans = conn.BeginTransaction()
        myCommand.Transaction = myTrans

        InsertTran = True

        strORRef = ""
        IntserNoDrac = 0
        IntserNoRate = 0
        strObjDesc = ""
        strProcRemk = ""
        strOrgSenId = ""
        strTRdeal = ""
        If Session("Funccd") = "1150" Then ' Amend
            'Check status of transaction
            If Not valStatus(Session("ForRef"), strMsg) Then
                GoTo errMsg
            End If
        End If


        Try

            strItscCd = Trim(txtItscCd.Text)

            strSenId = Trim(txtSenId.Value)
            strSenName1 = PublicFunc.replaceFormSWIFT(Trim(txtSenName1.Text))
            strSenName2 = PublicFunc.replaceFormSWIFT(Trim(txtSenName2.Text))
            strSenAddr1 = PublicFunc.replaceFormSWIFT(Trim(txtSenAddr1.Text))
            strSenAddr2 = PublicFunc.replaceFormSWIFT(Trim(txtSenAddr2.Text))
            strRemCur = Trim(ddlRemCur.Text)

            dblRemAmt = CDbl(Trim(txtRemAmt.Text))

            valDate = Trim(txtValDate.Value)
            strValDate = Format(valDate, "yyyy-MM-dd")
            strRecAcc = PublicFunc.replaceFormSWIFT( _
             UCase(Trim(txtRecAcc.Value)))

            strPreAdv = "N"

            If rbPreAdv.SelectedValue = "F" Then
                strPreAdv = "F"
            End If

            strDetChar = "BEN"
            If chkPayFull.Checked = True Then
                strDetChar = "OUR"
            End If

            strBkToTr = "N"
            If chkBkToTr.Checked = True Then
                strBkToTr = "Y"
                strTRdeal = txtTRdeal.Text
            End If

            strSpecInst = PublicFunc.replaceFormSWIFT(UCase( _
             Trim(txtSpecInst.Value)))

            strComCd = Trim(ddlComCd.Text)

            strCtryCd = Trim(ddlCtryCd.Text)


            strRemark = PublicFunc.replaceString(Left(Trim( _
             txtRemark.Value), 200))

            Call getObjCd(strObjDesc)

            If Session("Funccd") = "1150" Then ' Amend
                strORRef = Session("ForRef")
            Else 'Entry - Gen reference
                If Not PublicFunc.genReference("ORREF", strItscCd, strORRef, _
                 strMsg, concur.SWIFTCODE) Then GoTo errMsg
            End If

            ' ----------------------------------------------------------------------------------------------------------------------------
            'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENEMAIL
            Dim strBenMail As String
            strBenMail = PublicFunc.replaceString(LCase(Left(Trim(txtBenMail.Value), 200)))




            If Session("Funccd") = "1150" Then ' Amend
                strSql = "select senid from db2.forwtran " & _
                         " where forref = '" & strORRef & "'"
                Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
                If ResultSet.Tables(0).Rows.Count > 0 Then
                    Dim rowCustid As DataRow
                    For Each rowCustid In ResultSet.Tables(0).Rows
                        strOrgSenId = Trim(rowCustid.Item(0).ToString)
                    Next
                End If

                If strSenId <> strOrgSenId Then 'senid is changed
                    If Session("strFXCustId") = Nothing Then

                        'myCommand.CommandText = _
                        '"update db2.forwtran " & _
                        '"set ITSCNO = '" & strItscCd & "'," & _
                        '" OCCODE = '" & Session("strOcCode") & "'," & _
                        '" SENID = '" & strSenId & "'," & _
                        '" SENNAME1 = '" & strSenName1 & "', " & _
                        '" SENNAME2 = '" & strSenName2 & "'," & _
                        '" SENADDR1 = '" & strSenAddr1 & "'," & _
                        '" SENADDR2 = '" & strSenAddr2 & "', " & _
                        '" RECAC = '" & strRecAcc & "'," & _
                        '" DETCHAR = '" & strDetChar & "'," & _
                        '" OBJCODE = '" & Session("strObjCd") & "', " & _
                        '" OBJDESC = '" & strObjDesc & "'," & _
                        '" CTRYCODE = '" & strCtryCd & "'," & _
                        '" COMCODE = '" & strComCd & "', " & _
                        '" VALDATE = '" & strValDate & "'," & _
                        '" REMCUR = '" & strRemCur & "'," & _
                        '" REMAMT = " & dblRemAmt & "," & _
                        '" BKTOTR = '" & strBkToTr & "', " & _
                        '" PROCSTEP = '" & strPreAdv & "'," & _
                        '" PROCSTAT = 'PD'," & _
                        '" TRNO = '" & strTRdeal & "'" & _
                        '"where  forref = '" & strORRef & "'"

                        'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENEMAIL
                        myCommand.CommandText = _
                        "update db2.forwtran " & _
                        "set ITSCNO = '" & strItscCd & "'," & _
                        " OCCODE = '" & Session("strOcCode") & "'," & _
                        " SENID = '" & strSenId & "'," & _
                        " SENNAME1 = '" & strSenName1 & "', " & _
                        " SENNAME2 = '" & strSenName2 & "'," & _
                        " SENADDR1 = '" & strSenAddr1 & "'," & _
                        " SENADDR2 = '" & strSenAddr2 & "', " & _
                        " RECAC = '" & strRecAcc & "'," & _
                        " DETCHAR = '" & strDetChar & "'," & _
                        " OBJCODE = '" & Session("strObjCd") & "', " & _
                        " OBJDESC = '" & strObjDesc & "'," & _
                        " CTRYCODE = '" & strCtryCd & "'," & _
                        " COMCODE = '" & strComCd & "', " & _
                        " VALDATE = '" & strValDate & "'," & _
                        " REMCUR = '" & strRemCur & "'," & _
                        " REMAMT = " & dblRemAmt & "," & _
                        " BKTOTR = '" & strBkToTr & "', " & _
                        " PROCSTEP = '" & strPreAdv & "'," & _
                        " PROCSTAT = 'PD'," & _
                        " TRNO = '" & strTRdeal & "'," & _
                        " BENEMAIL ='" & strBenMail & "'" & _
                        " where  forref = '" & strORRef & "'"

                    Else
                        'myCommand.CommandText = _
                        '"update db2.forwtran " & _
                        '"set ITSCNO = '" & strItscCd & "'," & _
                        '" OCCODE = '" & Session("strOcCode") & "'," & _
                        '" SENID = '" & strSenId & "'," & _
                        '" SENNAME1 = '" & strSenName1 & "', " & _
                        '" SENNAME2 = '" & strSenName2 & "'," & _
                        '" SENADDR1 = '" & strSenAddr1 & "'," & _
                        '" SENADDR2 = '" & strSenAddr2 & "', " & _
                        '" RECAC = '" & strRecAcc & "'," & _
                        '" DETCHAR = '" & strDetChar & "'," & _
                        '" OBJCODE = '" & Session("strObjCd") & "', " & _
                        '" OBJDESC = '" & strObjDesc & "'," & _
                        '" CTRYCODE = '" & strCtryCd & "'," & _
                        '" COMCODE = '" & strComCd & "', " & _
                        '" VALDATE = '" & strValDate & "'," & _
                        '" REMCUR = '" & strRemCur & "'," & _
                        '" REMAMT = " & dblRemAmt & ",BKTOTR = '" & strBkToTr & "', " & _
                        '" PROCSTEP = '" & strPreAdv & "', " & _
                        '" PROCSTAT = 'PD', " & _
                        '" FXCUSTID = '" & Session("strFXCustId") & "'," & _
                        '" TRNO = '" & strTRdeal & "'" & _
                        '"where  forref = '" & strORRef & "'"

                        'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENEMAIL
                        myCommand.CommandText = _
                        "update db2.forwtran " & _
                        "set ITSCNO = '" & strItscCd & "'," & _
                        " OCCODE = '" & Session("strOcCode") & "'," & _
                        " SENID = '" & strSenId & "'," & _
                        " SENNAME1 = '" & strSenName1 & "', " & _
                        " SENNAME2 = '" & strSenName2 & "'," & _
                        " SENADDR1 = '" & strSenAddr1 & "'," & _
                        " SENADDR2 = '" & strSenAddr2 & "', " & _
                        " RECAC = '" & strRecAcc & "'," & _
                        " DETCHAR = '" & strDetChar & "'," & _
                        " OBJCODE = '" & Session("strObjCd") & "', " & _
                        " OBJDESC = '" & strObjDesc & "'," & _
                        " CTRYCODE = '" & strCtryCd & "'," & _
                        " COMCODE = '" & strComCd & "', " & _
                        " VALDATE = '" & strValDate & "'," & _
                        " REMCUR = '" & strRemCur & "'," & _
                        " REMAMT = " & dblRemAmt & ",BKTOTR = '" & strBkToTr & "', " & _
                        " PROCSTEP = '" & strPreAdv & "', " & _
                        " PROCSTAT = 'PD', " & _
                        " FXCUSTID = '" & Session("strFXCustId") & "'," & _
                        " TRNO = '" & strTRdeal & "'," & _
                        " BENEMAIL ='" & strBenMail & "'" & _
                        " where  forref = '" & strORRef & "'"
                    End If
                    myCommand.ExecuteNonQuery()
                Else 'senid is not changed

                    If Session("strFXCustId") = Nothing Then
                        'myCommand.CommandText = _
                        '"update db2.forwtran " & _
                        '"set ITSCNO = '" & strItscCd & "'," & _
                        '" RECAC = '" & strRecAcc & "'," & _
                        '" DETCHAR = '" & strDetChar & "', " & _
                        '" OBJDESC = '" & strObjDesc & "'," & _
                        '" CTRYCODE = '" & strCtryCd & "'," & _
                        '" COMCODE = '" & strComCd & "', " & _
                        '" VALDATE = '" & strValDate & "'," & _
                        '" REMCUR = '" & strRemCur & "'," & _
                        '" REMAMT = " & dblRemAmt & "," & _
                        '" BKTOTR = '" & strBkToTr & "', " & _
                        '" PROCSTEP = '" & strPreAdv & "', " & _
                        '" PROCSTAT = 'PD'," & _
                        '" TRNO = '" & strTRdeal & "'" & _
                        '"where  forref = '" & strORRef & "'"

                        'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENEMAIL
                        myCommand.CommandText = _
                        "update db2.forwtran " & _
                        "set ITSCNO = '" & strItscCd & "'," & _
                        " RECAC = '" & strRecAcc & "'," & _
                        " DETCHAR = '" & strDetChar & "', " & _
                        " OBJDESC = '" & strObjDesc & "'," & _
                        " CTRYCODE = '" & strCtryCd & "'," & _
                        " COMCODE = '" & strComCd & "', " & _
                        " VALDATE = '" & strValDate & "'," & _
                        " REMCUR = '" & strRemCur & "'," & _
                        " REMAMT = " & dblRemAmt & "," & _
                        " BKTOTR = '" & strBkToTr & "', " & _
                        " PROCSTEP = '" & strPreAdv & "', " & _
                        " PROCSTAT = 'PD'," & _
                        " TRNO = '" & strTRdeal & "'," & _
                        " BENEMAIL ='" & strBenMail & "'" & _
                        " where  forref = '" & strORRef & "'"
                    Else

                        'myCommand.CommandText = _
                        '"update db2.forwtran " & _
                        '"set ITSCNO = '" & strItscCd & "'," & _
                        '" RECAC = '" & strRecAcc & "'," & _
                        '" DETCHAR = '" & strDetChar & "', " & _
                        '" OBJDESC = '" & strObjDesc & "'," & _
                        '" CTRYCODE = '" & strCtryCd & "'," & _
                        '" COMCODE = '" & strComCd & "', " & _
                        '" VALDATE = '" & strValDate & "'," & _
                        '" REMCUR = '" & strRemCur & "'," & _
                        '" REMAMT = " & dblRemAmt & "," & _
                        '" BKTOTR = '" & strBkToTr & "', " & _
                        '" PROCSTEP = '" & strPreAdv & "', " & _
                        '" PROCSTAT = 'PD', " & _
                        '" FXCUSTID = '" & Session("strFXCustId") & "'," & _
                        '" TRNO = '" & strTRdeal & "'" & _
                        '"where  forref = '" & strORRef & "'"

                        'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENEMAIL
                        myCommand.CommandText = _
                      "update db2.forwtran " & _
                      "set ITSCNO = '" & strItscCd & "'," & _
                      " RECAC = '" & strRecAcc & "'," & _
                      " DETCHAR = '" & strDetChar & "', " & _
                      " OBJDESC = '" & strObjDesc & "'," & _
                      " CTRYCODE = '" & strCtryCd & "'," & _
                      " COMCODE = '" & strComCd & "', " & _
                      " VALDATE = '" & strValDate & "'," & _
                      " REMCUR = '" & strRemCur & "'," & _
                      " REMAMT = " & dblRemAmt & "," & _
                      " BKTOTR = '" & strBkToTr & "', " & _
                      " PROCSTEP = '" & strPreAdv & "', " & _
                      " PROCSTAT = 'PD', " & _
                      " FXCUSTID = '" & Session("strFXCustId") & "'," & _
                      " TRNO = '" & strTRdeal & "'," & _
                      " BENEMAIL ='" & strBenMail & "'" & _
                      " where  forref = '" & strORRef & "'"

                    End If
                    myCommand.ExecuteNonQuery()
                End If

            Else ' Entry
                'myCommand.CommandText = _
                '"insert into db2.forwtran " & _
                '" (" & _
                '"  FORREF,CHANREF,OWDREF,ITSCNO,IDTYPE,IDNO, " & _
                '"  TAXID,OCCODE,SENID,SENNAME1,SENNAME2,SENADDR1," & _
                '"  SENADDR2,RECAC,RECNAME1,RECNAME2,RECADDR1,RECADDR2," & _
                '"  BENBANK,BENBANKDET1,BENBANKDET2,BENBANKDET3, " & _
                '"  BENBANKDET4,BENBANKDET5,DETCHAR,OBJCODE,OBJDESC," & _
                '"  DETPAY1,DETPAY2,DETPAY3, DETPAY4,APPCODE,CTRYCODE," & _
                '"  COMCODE,VALDATE,REMCUR,REMAMT,BKTOTR,PROCSTEP, " & _
                '"  PROCSTAT,REMARK1,REMARK2,REMARK3,REMARK4,REMARK5," & _
                '"  REMARK6,ATTFILE,FXCUSTID,TRNO,REMBANK" & _
                '"  ) " & _
                '"values" & _
                '" ('" & strORRef & "','','','" & strItscCd & "','','', " & _
                '"  '','" & Session("strOcCode") & "','" & strSenId & "'," & _
                '"  '" & strSenName1 & "','" & strSenName2 & "'," & _
                '"  '" & strSenAddr1 & "','" & strSenAddr2 & "'," & _
                '"  '" & strRecAcc & "','','','','','','','','', " & _
                '"  ' ','','" & strDetChar & "'," & _
                '"  '" & Session("strObjCd") & "','" & strObjDesc & "'," & _
                '"  '','','','','FORW','" & strCtryCd & "'," & _
                '"  '" & strComCd & "','" & strValDate & "'," & _
                '"  '" & strRemCur & "'," & dblRemAmt & "," & _
                '"  '" & strBkToTr & "','" & strPreAdv & "', " & _
                '"  'PD','','','','','','',''," & _
                '"  '" & Session("strFXCustId") & "','" & strTRdeal & "'," & _
                '"  '" & concur.SWIFTCODE & "' " & _
                '"  )"
                'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENEMAIL
                myCommand.CommandText = _
                "insert into db2.forwtran " & _
                " (" & _
                "  FORREF,CHANREF,OWDREF,ITSCNO,IDTYPE,IDNO, " & _
                "  TAXID,OCCODE,SENID,SENNAME1,SENNAME2,SENADDR1," & _
                "  SENADDR2,RECAC,RECNAME1,RECNAME2,RECADDR1,RECADDR2," & _
                "  BENBANK,BENBANKDET1,BENBANKDET2,BENBANKDET3, " & _
                "  BENBANKDET4,BENBANKDET5,DETCHAR,OBJCODE,OBJDESC," & _
                "  DETPAY1,DETPAY2,DETPAY3, DETPAY4,APPCODE,CTRYCODE," & _
                "  COMCODE,VALDATE,REMCUR,REMAMT,BKTOTR,PROCSTEP, " & _
                "  PROCSTAT,REMARK1,REMARK2,REMARK3,REMARK4,REMARK5," & _
                "  REMARK6,ATTFILE,FXCUSTID,TRNO,REMBANK,BENEMAIL"

                myCommand.CommandText = myCommand.CommandText & _
                "  ) " & _
                "values" & _
                " ('" & strORRef & "','','','" & strItscCd & "','','', " & _
                "  '','" & Session("strOcCode") & "','" & strSenId & "'," & _
                "  '" & strSenName1 & "','" & strSenName2 & "'," & _
                "  '" & strSenAddr1 & "','" & strSenAddr2 & "'," & _
                "  '" & strRecAcc & "','','','','','','','','', " & _
                "  ' ','','" & strDetChar & "'," & _
                "  '" & Session("strObjCd") & "','" & strObjDesc & "'," & _
                "  '','','','','FORW','" & strCtryCd & "'," & _
                "  '" & strComCd & "','" & strValDate & "'," & _
                "  '" & strRemCur & "'," & dblRemAmt & "," & _
                "  '" & strBkToTr & "','" & strPreAdv & "', " & _
                "  'PD','','','','','','',''," & _
                "  '" & Session("strFXCustId") & "','" & strTRdeal & "'," & _
                "  '" & concur.SWIFTCODE & "','" & strBenMail & "' " & _
                "  )"

                myCommand.ExecuteNonQuery()
            End If

            ' -------------------------------------------------------------
            '### FORWDRAC ###

            strPayCur = ""
            strRemCurDrac = ""
            strAcType = ""
            dblPayAmt = 0
            dblRemAmtDrac = 0

            If Session("Funccd") = "1150" Then ' Amend
                'Delete tran in forwdrac
                myCommand.CommandText = _
                "delete from db2.forwdrac " & _
                "where forref = '" & strORRef & "'"

                myCommand.ExecuteNonQuery()
            End If
            If Trim(GridAddPay.Rows(0).Cells(3).Text) <> "" Then
                For i = 0 To GridAddPay.Rows.Count - 1
                    Dim row As GridViewRow = GridAddPay.Rows(i)
                    IntserNoDrac = IntserNoDrac + 1
                    strSerDrac = CStr(IntserNoDrac)
                    strPayCur = Trim(row.Cells(3).Text)
                    strAcNo = Trim(row.Cells(4).Text)
                    dblPayAmt = CDbl(row.Cells(5).Text)
                    strRemCurDrac = Trim(row.Cells(6).Text)
                    dblRemAmtDrac = CDbl(row.Cells(7).Text)
                    '***R56100048 Repalce "THB"
                    'If strPayCur = "THB" Then
                    If strPayCur = CType(Session("concurrencyInfo"), _
                     FORWEB_Concurrency).BaseCurrency Then
                        'strAcType = "THB"
                        strAcType = CType(Session("concurrencyInfo"), _
                         FORWEB_Concurrency).BaseCurrency
                    Else
                        strAcType = "FCD"
                    End If

                    myCommand.CommandText = _
                        "insert into db2.forwdrac " & _
                        " (" & _
                        "  FORREF,SERIALNO,DRFOR,REMCUR,REMAMT," & _
                        "  SENAC,ACTYPE,ACCUR,ACAMT" & _
                        "  ) " & _
                        "values" & _
                        " ('" & strORRef & "','" & strSerDrac & "','REM'," & _
                        "  '" & strRemCurDrac & "', " & _
                        "   " & dblRemAmtDrac & ",'" & strAcNo & "'," & _
                        "  '" & strAcType & "','" & strPayCur & "'," & _
                        "   " & dblPayAmt & "" & _
                        "  )"

                    myCommand.ExecuteNonQuery()

                Next
            End If

            ' -------------------------------------------------------------
            'I### FORWRATE ###

            If Session("Funccd") = "1150" Then ' Amend
                'Delete transaction in forwrate
                myCommand.CommandText = "delete from db2.forwrate " & _
                                        " where forref = '" & strORRef & "'"

                myCommand.ExecuteNonQuery()
            End If
            If Trim(GridAddInqRate.Rows(0).Cells(3).Text) <> "" Then
                For i = 0 To GridAddInqRate.Rows.Count - 1
                    Dim row As GridViewRow = GridAddInqRate.Rows(i)

                    IntserNoRate = IntserNoRate + 1
                    strSerRate = CStr(IntserNoRate)
                    strRemCurRate = Trim(row.Cells(3).Text)
                    dblRemAmtRate = Format(CDbl(Trim(row.Cells(4).Text)) _
                     , "#,##0.00")
                    strRateTyp = Trim(row.Cells(5).Text)
                    dblExRate = Format(CDbl(Trim(row.Cells(6).Text)) _
                     , "#,##0.0000000")
                    strDealNo = Trim(row.Cells(7).Text)
                    strAcCur = Trim(row.Cells(8).Text)
                    dblAcAmt = Format(CDbl(Trim(row.Cells(9).Text)) _
                     , "##0.00")
                    dbAdjAmt = Format(CDbl(Trim(row.Cells(10).Text)) _
                     , "##0.00")
                    dblTotAcAmt = Format(CDbl(Trim(row.Cells(11).Text)) _
                     , "##0.00")

                    If CDbl(dblRemAmt) <> 0 Then
                        myCommand.CommandText = _
                        "insert into db2.forwrate " & _
                        " (" & _
                        "  FORREF,SERIALNO,RATETYPE,REMCUR,REMAMT," & _
                        "  REMRATE,DEALNO,USEFORFCD,DRACSER,DRCUR," & _
                        "  DRAMT,ADJPAYAMT" & _
                        "  ) " & _
                        "values" & _
                        " ('" & strORRef & "','" & strSerRate & "'," & _
                        "  '" & strRateTyp & "','" & strRemCurRate & "', " & _
                        "   " & dblRemAmtRate & "," & dblExRate & ", " & _
                        "  '" & strDealNo & "', '', '', " & _
                        "  '" & strAcCur & "'," & dblTotAcAmt & "," & _
                        "   " & dbAdjAmt & "" & _
                        "  )"

                        myCommand.ExecuteNonQuery()
                    End If

                Next
            End If

            ' -------------------------------------------------------------
            '### FORWTRTJ ###
            'Amend
            If Session("Funccd") = "1150" Then strProcRemk = "Amend OR"

            myCommand.CommandText = _
            "insert into db2.forwtrtj " & _
            " (FORREF,TRANDATE,TRANTIME,USERID," & _
            "  PROCSTAT,PROCREMK,FUNCCD" & _
            "  ) " & _
            "values" & _
            " ('" & strORRef & "',current date,current time," & _
            "  '" & Session("strUserID") & "', 'PD',  " & _
            "  '" & strProcRemk & "', '" & Session("Funccd") & "' " & _
            "  )"


            myCommand.ExecuteNonQuery()

            ' -------------------------------------------------------------
            'Update formcust

            myCommand.CommandText = _
            "update db2.formcust " & _
            "set instruction = '" & strSpecInst & "' " & _
            "where  forcustid = '" & strSenId & "'"

            myCommand.ExecuteNonQuery()

            ' -------------------------------------------------------------
            '### FORONOTE ###

            If strRemark <> "" Then

                myCommand.CommandText = _
                "insert into db2.foronote" & _
                " (" & _
                "  forref, entdate, enttime, entuser, remark" & _
                "  ) " & _
                "values" & _
                " ('" & strORRef & "',current date,current time," & _
                " '" & Session("strUserID") & "','" & strRemark & "'" & _
                "  )"

                myCommand.ExecuteNonQuery()

            End If

            myTrans.Commit()

        Catch odbce As OdbcException
            myTrans.Rollback()
            InsertTran = False

            If Session("Page") = "Entry" Then
                strMsg = "Entry Transaction failed.!!!OdbcException : " & _
                 odbce.Message.ToString().Replace("'", "\'") _
                 .Replace(Environment.NewLine, "")
            ElseIf Session("Page") = "Amend" Then
                strMsg = "Amend Transaction failed.!!!OdbcException : " & _
                 odbce.Message.ToString().Replace("'", "\'") _
                 .Replace(Environment.NewLine, "")
            End If

            'insert Error Log FORWLOG
            myCommand.CommandText = _
            "insert into db2.forwlog" & _
            " (" & _
            "  forref,trandate,trantime,userid,msgerr,funccd" & _
            "  )" & _
            "values" & _
            " ('" & strORRef & "',current date,current time, " & _
            "  '" & Session("strUserID") & "', " & _
            "  '" & Left(PublicFunc.replaceString(strMsg), 200) & "', " & _
            "  '" & Session("Funccd") & "'" & _
            "  )"
            myCommand.ExecuteNonQuery()

            GoTo errMsg
        Catch ex As Exception
            InsertTran = False

            If Session("Page") = "Entry" Then
                strMsg = "Entry transaction failed.!!!" & _
                 ex.Message.Replace("'", "\'").Replace(Environment.NewLine, "")
            ElseIf Session("Page") = "Amend" Then
                strMsg = "Amend transaction failed.!!!" & _
                 ex.Message.Replace("'", "\'").Replace(Environment.NewLine, "")
            End If

            ' check DB connection
            If conn.State = ConnectionState.Closed Then GoTo errMsg

            myTrans.Rollback()

            'insert Error Log FORWLOG
            myCommand.CommandText = _
            "insert into db2.forwlog" & _
            " (" & _
            "  forref,trandate,trantime,userid,msgerr,funccd" & _
            "  )" & _
            "values" & _
            " (" & _
            "  '" & strORRef & "',current date,current time, " & _
            "  '" & Session("strUserID") & "', " & _
            "  '" & Left(PublicFunc.replaceString(strMsg), 200) & "'," & _
            "  '" & Session("Funccd") & "'" & _
            "  )"
            myCommand.ExecuteNonQuery()

            GoTo errMsg
        Finally
            conn.Close()
        End Try

        strSenName = strSenName1 & strSenName2

        If InsertTran = True Then

            dtPayment.Rows.Clear()
            Session("ForRef") = strORRef
            Session("tempStat") = False

            If CDbl(lblRemRate.Text <> 0) Then
                Call EarMark()
            End If

        End If

errMsg:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If


    End Function

    Protected Sub GridAddPay_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridAddPay.SelectedIndexChanging

        Dim index As Integer = e.NewSelectedIndex.ToString
        Dim row As GridViewRow = GridAddPay.Rows(index)
        Dim strAcNo As String, strAcCur As String
        Dim i As Integer
        Session("selectPayIndex") = index

        GridAddPay.DataSource = dtPayment
        GridAddPay.DataBind()
        GridAddPay.Rows(index).ForeColor = Drawing.Color.Red
        GridAddPay.Rows(index).Font.Bold = False

        ' A/C Cur
        strAcCur = Trim(row.Cells(3).Text)
        For i = 0 To ddlAcCurPay.Items.Count - 1
            If Trim(ddlAcCurPay.Items(i).Value) = strAcCur Then
                ddlAcCurPay.Text = ddlAcCurPay.Items(i).Value
            End If
        Next

        '2012-12-26 R55040057 Tom : Support new organize
        Call loadAccNo()

        ' A/C No
        ddlAcNoPay.Enabled = True
        strAcNo = Trim(row.Cells(4).Text)
        For i = 0 To ddlAcNoPay.Items.Count - 1
            If Trim(ddlAcNoPay.Items(i).Value) = strAcNo Then
                ddlAcNoPay.Text = ddlAcNoPay.Items(i).Value
            End If
        Next

        '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 

        'ddlAccNo.SelectedValue = strAcNoTHB
        'ddlRateTypFCD.SelectedValue = strRateTypeFCD
        'txtExRateFCD.Text = strExRateFCD
        'txtDealNoFCD.Text = strDealNoFCD
        'Session("selectIndex") = index

        txtPayAmnt.Text = Format(CDbl(row.Cells(5).Text), "#,##0.00")
        txtCur.Text = Trim(row.Cells(6).Text)
        txtRemAmnt.Text = Format(CDbl(row.Cells(7).Text), "#,##0.00")


        ' 2009-10-19 Tom :
        'Select Case Trim(ddlRateType.Text)

        '2010-11-09 R53060089 Tom Start : Interface with Sierra (FX) 
        'Select Case Trim(strRateTypeFCD)
        '    Case "CT", "NM"
        '        txtExRateFCD.BackColor = Drawing.Color.LightGray
        '        txtExRateFCD.ReadOnly = True
        '        '2009-10-13 Tom : validate "SO"
        '        'Case "FW", "SP"
        '    Case "FW", "SP", "SO"
        '        txtDealNoFCD.BackColor = Drawing.Color.LightCyan
        '    Case Else
        '        txtExRateFCD.ReadOnly = False
        '        txtExRateFCD.BackColor = Drawing.Color.LightCyan
        '        txtDealNoFCD.BackColor = Drawing.Color.White
        'End Select

        'ddlRateTypFCD.Enabled = True
        'If Trim(ddlRateTypFCD.Text) = "NM" Then
        '    ddlRateTypFCD.Enabled = False
        'End If

        '2010-11-09 R53060089 Tom End : Interface with Sierra (FX)

        GridAddPay.Enabled = False
        pnlAddPay.Visible = False
        pnlUpdPay.Visible = True

    End Sub

    Protected Sub btnUpdPay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdPay.Click
        Dim j As Integer, i As Integer
        Dim dr As DataRow
        Dim sumRemAmt As Double, netAmt As Double
        Dim lessAmt As String
        Dim sumPayAmt As Double, dblTotPayAmt As Double

        sumRemAmt = 0
        sumPayAmt = 0
        dblTotPayAmt = 0
        netAmt = 0

        'check refresh
        If (Session("dtPayment") Is Nothing) Then
        Else
            For j = 0 To Session("dtPayment").Rows.Count - 1
                '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
                'If (Trim(dtPayment.Rows(j).Item(1)) = Trim(txtCurPay.Text)) And (CDbl(Trim(dtPayment.Rows(j).Item(2))) = CDbl(Trim(txtAmtPay.Text))) _
                '    And (Trim(dtPayment.Rows(j).Item(3)) = Trim(ddlAcNoPay.Text)) And (Trim(dtPayment.Rows(j).Item(4)) = Trim(ddlAcCurPay.Text)) _
                '    And (Trim(dtPayment.Rows(j).Item(5)) = Trim(ddlRateTypFCD.Text)) And (CDbl(Trim(dtPayment.Rows(j).Item(6))) = CDbl(Trim(txtExRateFCD.Text))) _
                '    And (Trim(dtPayment.Rows(j).Item(7)) = Trim(txtDealNoFCD.Text)) Then
                If (Trim(dtPayment.Rows(j).Item(1)) = Trim(ddlAcCurPay.Text)) And (Trim(dtPayment.Rows(j).Item(2)) = Trim(ddlAcNoPay.Text)) _
                     And (CDbl(Trim(dtPayment.Rows(j).Item(3))) = CDbl(Trim(txtPayAmnt.Text))) _
                     And (Trim(dtPayment.Rows(j).Item(4)) = Trim(txtCur.Text)) And (CDbl(Trim(dtPayment.Rows(j).Item(5))) = CDbl(Trim(txtRemAmnt.Text))) Then

                    dtPayment = Session("dtPayment")
                    GridAddPay.DataSource = dtPayment
                    GridAddPay.DataBind()

                    GridAddPay.SelectedRowStyle.Font.Bold = False
                    resetPay()
                    pnlUpdPay.Visible = False
                    pnlAddPay.Visible = True
                    GridAddPay.Enabled = True

                    Exit Sub
                End If
            Next
        End If


        'validate Rate Info
        If Not ValDataEntry("PAYINF", strMsg) Then GoTo errMsg

        'GridAddratePay.Enabled = True

        GridAddPay.Rows(0).Enabled = True
        'display grid  default
        dr = dtPayment.NewRow
        If (GridAddPay.Rows.Count = 1) And (Trim(dtPayment.Rows(0).Item(4)) = "") Then
            dtPayment.Rows(0).Delete()
            GridAddPay.DataSource = dtPayment
            GridAddPay.DataBind()
        End If

        ''count Rate in grid
        'cntRate = GridAddratePay.Rows.Count + 1

        'If cntRate > 2 Then
        '    strMsg = "Can not add rate more than 2. "
        '    GoTo errMsg
        'End If


        If strMsg = "" Then
            'dr = dtRateTHB.NewRow

            dr = dtPayment.Rows(Session("selectPayIndex"))
            dr("No.") = dtPayment.Rows.Count + 1
            dr("A/C Cur.") = Trim(ddlAcCurPay.Text)
            dr("A/C No.") = Trim(ddlAcNoPay.Text)
            dr("Pay Amount") = Trim(txtPayAmnt.Text)
            dr("Rem Cur.") = Trim(txtCur.Text)
            dr("Rem Amount") = Trim(txtRemAmnt.Text)
            '2010-11-09 R53060089 Tom : Interface with Sierra (FX)
            'dr("Rate Type") = Me.ddlRateTypFCD.Text.ToString
            'dr("Ex.Rate") = Me.txtExRateFCD.Text
            'dr("Deal No.") = Me.txtDealNoFCD.Text.ToString

            '2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
            'If CDbl(txtRemAmt.Text) < (CDbl(sumAmtPay)) Then
            '    lessAmt = Format(CDbl(Trim(txtRemAmnt.Text)) - ((CDbl(sumAmtPay)) - CDbl(txtRemAmt.Text)), "###,###,###,###,##0.00")

            '    strMsg = "Amount is more than Remitting Amount !!!" & "\n" & "Please input amount less than or equal : " & lessAmt
            '    txtRemAmnt.ReadOnly = False
            '    txtRemAmnt.Focus()
            '    GoTo errMsg

            '    'Else

            '    '    'validate Rate Amount
            '    '    ValDataEntry("RATEAMTFCD", strMsg)

            '    '    dtPayment.Rows.Add(dr)
            '    '    GridAddratePay.DataSource = dtPayment
            '    '    GridAddratePay.DataBind()
            '    '    Session("dtPayment") = dtPayment
            'End If

        End If

        '2010-11-13 R53060089 Tom Start: Interface with Sierra (FX) 
        'sum Pay Amount in datagrid
        If Session("dtPayment") Is Nothing Then
            'If CDbl(txtRemAmt.Text) > sumAmt Then
            '    lessAmt = Format(CDbl(CDbl(txtRemAmt.Text) - sumAmt), "###,###,###,###,##0.00")
            'Else
            '    lessAmt = Format(CDbl(sumAmt - CDbl(txtRemAmt.Text)), "###,###,###,###,##0.00")
            'End If
            sumPayAmt = CDbl(txtPayAmnt.Text)
            sumRemAmt = CDbl(Trim(txtRemAmnt.Text))
        Else

            For i = 0 To Session("dtPayment").Rows.Count - 1
                sumRemAmt = sumRemAmt + CDbl(Trim(dtPayment.Rows(i).Item(5)))

                'If Trim(dtPayment.Rows(i).Item(1)) = Trim(ddlAcCurPay.Text) Then
                'sumRemAmt = sumRemAmt + CDbl(Trim(dtPayment.Rows(i).Item(5)))

                If Trim(dtPayment.Rows(i).Item(1)) = Trim(ddlAcCurPay.Text) Then
                    sumPayAmt = sumPayAmt + CDbl(Trim(dtPayment.Rows(i).Item(3)))
                    'sumPayAmt = (sumPayAmt + CDbl(Trim(dtPayment.Rows(i).Item(3)))) - CDbl(Trim(dtPayment.Rows(Session("selectIndexPay")).Item(3)))

                End If
                'End If

            Next

            sumRemAmt = CDbl(sumRemAmt) - CDbl(Trim(dtPayment.Rows(Session("selectPayIndex")).Item(5)))
            sumPayAmt = CDbl(sumPayAmt) - CDbl(Trim(dtPayment.Rows(Session("selectPayIndex")).Item(3)))

            For i = 0 To Session("dtSumRateInfo").Rows.Count - 1
                If Trim(dtSumRateInfo.Rows(i).Item(1)) = Trim(ddlAcCurPay.Text) Then
                    dblTotPayAmt = CDbl(Trim(dtSumRateInfo.Rows(i).Item(2)))
                End If
            Next
            netAmt = CDbl(sumPayAmt) - CDbl(txtPayAmnt.Text)

            If dblTotPayAmt > CDbl(sumPayAmt) Then
                lessAmt = Format(CDbl(dblTotPayAmt - CDbl(sumPayAmt)), "###,###,###,###,##0.00")
            Else
                lessAmt = Format(CDbl(dblTotPayAmt - netAmt), "###,###,###,###,##0.00")
            End If

        End If

        If CDbl(sumPayAmt) > dblTotPayAmt Then

            strMsg = "Pay Amount is more than Total Pay Amount !!!" & "\n" & "Please input pay amount less than or equal : " & lessAmt
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)

            '2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
            If lessAmt = 0 Then
                resetPay()
            End If
            GoTo errMsg

        End If
        '2010-11-13 R53060089 Tom End: Interface with Sierra (FX) 

        GridAddPay.DataSource = dtPayment
        GridAddPay.DataBind()
        Session("dtPayment") = dtPayment

        sumRemAmt = sumRemAmt + CDbl(Trim(txtRemAmnt.Text))
        lblRemPay.Text = Format(sumRemAmt, "###,###,###,###,##0.00")

        resetPay()
        GridAddPay.SelectedRowStyle.Font.Bold = False
        pnlUpdPay.Visible = False
        pnlAddPay.Visible = True
        GridAddPay.Enabled = True

        If ddlAcCurPay.Items.Count = 2 Then
            ddlAcCurPay.SelectedIndex = 1
            ddlAcNoPay.Enabled = True
        End If
        'If ddlAcNoPay.Items.Count = 2 Then
        '    ddlAcNoPay.SelectedIndex = 1
        'End If

errMsg:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        Call ClearData()

        ' Add data to dropdownlist
        Call AddCurrency()
        Call AddComCd()
        '2008-11-27 Tom :
        Call AddCountryCd()
        '2010-11-08 R53060089 Tom : Interface with Sierra (FX) 
        Call AddRate("ALL")

        ' Set panel
        Call SetPanel("LOAD")
        ' Set display Value
        Call SetDisValue()
        resetRate()
        resetPay()
        '2012-11-28 R55040057 Tom Start : Support new organize
        If (Session("Page") = "Amend") Then
            ' update status 'PD' instead of 'WA'
            Call updateTempStatus("PD")
            Response.Redirect("~/SearchTrnFromChannel.aspx?MenuFunc=1150")
        End If
        '2012-11-28 R55040057 Tom End : Support new organize
    End Sub

    Protected Sub ButSearchCriteria_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButSearchCriteria.Click
        '*** CMHI:f1466bcf-5a99-4846-a2a6-b5654cb73452
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        Dim strsql As String = ""
        Dim strCondition As String = ""
        If Session("SEARCHSEDIDBY") = "BY_SendID" Then
            If Me.txtValueSearchSenderID.Text = "" Then
                cstext1 = "alert('Error !! Data should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                txtValueSearchSenderID.Focus()

                Exit Sub
            End If
            If (Trim(txtValueSearchSenderID.Text) <> "") And (Len(Trim(txtValueSearchSenderID.Text)) < 3) Then
                cstext1 = "alert('Error !! Please input value more than 2 characters !!');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                txtValueSearchSenderID.Focus()

                Exit Sub
            End If
        ElseIf Session("SEARCHSEDIDBY") = "BY_NAME" Then
            If Me.txtValueSendName.Text = "" Then
                cstext1 = "alert('Error !! Data should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                txtValueSendName.Focus()

                Exit Sub
            End If
            If (Trim(txtValueSendName.Text) <> "") And (Len(Trim(txtValueSendName.Text)) < 3) Then
                cstext1 = "alert('Error !! Please input value more than 2 characters !!');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                txtValueSendName.Focus()

                Exit Sub
            End If
        ElseIf Session("SEARCHSEDIDBY") = "BY_IDNO" Then
            If Me.DDLIDTYPE.SelectedValue = "" Or Trim(Me.DDLIDTYPE.SelectedValue) = "--Please Select ID Type--" Then
                cstext1 = "alert('Error !! Data should be selected.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                DDLIDTYPE.Focus()

                Exit Sub
            ElseIf Me.txtValueSendID.Text.ToString = "" Then
                cstext1 = "alert('Error !! Data should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                txtValueSendID.Focus()
                Exit Sub
            End If
        ElseIf Session("SEARCHSEDIDBY") = "BY_ACNo" Then
            If Me.txtValueACNo.Text = "" Then
                cstext1 = "alert('Error !! Data should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                txtValueACNo.Focus()
                Exit Sub
            End If
            If (Trim(txtValueACNo.Text) <> "") And (Len(Trim(txtValueACNo.Text)) < 3) Then
                cstext1 = "alert('Error !! Please input value more than 2 characters !!');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                txtValueACNo.Focus()

                Exit Sub
            End If
        End If

        If Session("SEARCHSEDIDBY") = "BY_SendID" Then
            strCondition = " a.forcustid like '%" & Trim(Me.txtValueSearchSenderID.Text) & "%'"
        ElseIf Session("SEARCHSEDIDBY") = "BY_NAME" Then
            strCondition = " coalesce(a.swname1,'') || coalesce(a.swname2,'') like '%" & Trim(Me.txtValueSendName.Text) & "%'"

        ElseIf Session("SEARCHSEDIDBY") = "BY_IDNO" Then
            strCondition = " b.idno = '" & Trim(Me.txtValueSendID.Text) & "' and b.idtype = '" & Trim(Me.DDLIDTYPE.SelectedValue.ToString()) & "'"
        ElseIf Session("SEARCHSEDIDBY") = "BY_ACNo" Then
            strCondition = " c.acno like '%" & Trim(Me.txtValueACNo.Text) & "%' and a.forcustid = c.forcustid "

        End If

        'PIK : 2015-07-15 : R58030116 CCB Request a performance tuning
        'strsql = "select distinct a.forcustid,swname1,swname2,addr1,addr2,phone1,a.faxno," & _
        '         " mobileno,email1,occode,a.itscno,custstatus " & _
        '         " from db2.formcust a, db2.forlcuid b, db2.forlcuac c, db2.frcmitsc d " & _
        '         " where  a.forcustid = b.forcustid and a.custstatus not in ('D','W') " & _
        '         " AND a.itscno = d.itscno " & _
        '         " AND d.SWIFTTCD = '" & concur.SWIFTCODE & "' and left(a.forcustid,3) <> 'TMP' and " & strCondition
        strsql = "select distinct a.forcustid,swname1,swname2,addr1,addr2,phone1,a.faxno," & _
                         " mobileno,email1,occode,a.itscno,custstatus " & _
                         " from db2.formcust a, db2.forlcuid b, db2.forlcuac c, db2.frcmitsc d " & _
                         " where  a.forcustid = b.forcustid and a.custstatus not in ('D','W') " & _
                         " AND a.itscno = d.itscno " & _
                         " AND d.SWIFTTCD = '" & concur.SWIFTCODE & "' and left(a.forcustid,3) <> 'TMP' and " & strCondition & _
                         " and a.cbsbankcd ='" & concur.CbsBankCd & "'"

        Dim dtResultSet2 As New DataSet
        Dim dtRow As DataRow
        Dim dtTableObj As New DataTable

        Session("DtResultDelete") = Nothing
        If strsql <> "" Then
            Dim conn As OdbcConnection = connDB.getDBConn()
            dtResultSet2 = connDB.RunQuerySql(strsql)
            If dtResultSet2.Tables.Count > 0 Then
                dtTableObj.Columns.Add("NO")
                dtTableObj.Columns.Add("SENDERID")
                dtTableObj.Columns.Add("SENDERNAME")
                dtTableObj.Columns.Add("ADDRESS1")
                dtTableObj.Columns.Add("ADDRESS2")
                dtTableObj.Columns.Add("TELNO")
                dtTableObj.Columns.Add("OCCODE")
                dtTableObj.Columns.Add("FAXNO")
                dtTableObj.Columns.Add("MOBILENO")
                dtTableObj.Columns.Add("EMAIL")
                dtTableObj.Columns.Add("ITSCNO")
                dtTableObj.Columns.Add("STATUS")
                Dim DR As DataRow
                For Each dtRow In dtResultSet2.Tables(0).Rows

                    DR = dtTableObj.NewRow
                    DR("NO") = CStr(CInt(dtTableObj.Rows.Count) + 1)
                    DR("SENDERID") = dtRow.Item(0).ToString()
                    DR("SENDERNAME") = dtRow.Item(1).ToString() & " " & dtRow.Item(2).ToString()
                    DR("ADDRESS1") = dtRow.Item(3).ToString()
                    DR("ADDRESS2") = dtRow.Item(4).ToString()
                    DR("TELNO") = dtRow.Item(5).ToString()
                    DR("OCCODE") = dtRow.Item(9).ToString()
                    DR("FAXNO") = dtRow.Item(6).ToString()
                    DR("MOBILENO") = dtRow.Item(7).ToString()
                    DR("EMAIL") = dtRow.Item(8).ToString()
                    DR("ITSCNO") = dtRow.Item(10).ToString()
                    DR("STATUS") = dtRow.Item(11).ToString()
                    dtTableObj.Rows.Add(DR)
                Next
            End If
        End If
        Session("dtTableObj") = dtTableObj
        MVSearchSenid.ActiveViewIndex = 1
        PDetailSendid.Visible = True
        Session("pageIndex") = ""
        GridResultSearch.SelectedIndex = -1
        Me.GridResultSearch.PageIndex = 0
        Me.GridResultSearch.DataSource = dtTableObj
        Me.GridResultSearch.DataBind()

    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Dim strsql As String
        txtValueSearchSenderID.BackColor = Drawing.Color.White
        txtValueSendName.BackColor = Drawing.Color.White
        DDLIDTYPE.BackColor = Drawing.Color.White
        txtValueSendID.BackColor = Drawing.Color.White
        txtValueACNo.BackColor = Drawing.Color.White

        '2010-09-08 Tom :
        txtValueSearchSenderID.Text = ""
        txtValueSendName.Text = ""
        txtValueSendID.Text = ""
        txtValueACNo.Text = ""

        MVSearchSenid.ActiveViewIndex = 1
        '***56100048 Ron
        'strsql = " select '' as code, '--Please Select ID Type--' as show from db2.frcmtbcd where type = 'T003' union " & _
        '         " select code , code || ' ' ||value as show from db2.frcmtbcd where type = 'T003'" & _
        '         " order by code "
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        strsql = " select '' as code, '--Please Select ID Type--' as show from db2.frcmtbcd where type = 'T003' union " & _
                 " select code , code || ' ' ||value as show from db2.frcmtbcd " & _
                 " where type = 'T003' " & _
                 " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T003' ", concur.SWIFTCODE) & "' " & _
                 " order by code "

        If Not PublicFunc.PopulateLoadDDL(Me.DDLIDTYPE, "code", "SHOW", strsql) Then
            cstext1 = "alert('Error!! List of ID Type Can not Load');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Exit Sub
        End If

        PDetailSendid.Visible = False
        Session("SEARCHSEDIDBY") = "BY_SendID"
        Me.RadioSearchBy.SelectedValue = "BY_SendID"

        txtValueSearchSenderID.Enabled = True
        txtValueSendName.Enabled = False
        DDLIDTYPE.Enabled = False
        txtValueSendID.Enabled = False
        txtValueACNo.Enabled = False
        Me.txtValueSearchSenderID.Text = ""
        txtValueSearchSenderID.Focus()

    End Sub

    Protected Sub GridResultSearch_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridResultSearch.PageIndexChanging
        ' 2008-09-30 Tom :

        Dim dtTableObj As DataTable
        If (Session("dtTableObj").Rows.Count > 0) And (Session("dtTableObj").Rows.Count <> Nothing) Then
            dtTableObj = Session("dtTableObj")
            Me.GridResultSearch.DataSource = Session("dtTableObj")
            Me.GridResultSearch.PageIndex = e.NewPageIndex
            Me.GridResultSearch.DataBind()
        End If

    End Sub

    Protected Sub GridResultSearch_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridResultSearch.RowDataBound
        ''GridResultSearch.Rows.Item(13).Visible = False
        'If GridResultSearch.Rows.Count > 0 Then
        '    GridResultSearch.Rows.Item(0).Cells(13).Visible = False
        '    GridResultSearch.Rows.Item(0).Cells(14).Visible = False
        '    GridResultSearch.Rows.Item(0).Cells(15).Visible = False

        'End If
        '2008-09-29 Tom  : 
        If e.Row.RowType = DataControlRowType.DataRow Then
            ' No.
            'e.Row.Cells(2).Text = (5 * CInt(pageHidden.Value)) + e.Row.RowIndex + 1
            e.Row.Cells(13).Visible = False
            e.Row.Cells(13).Width = 90
        End If
    End Sub
    Protected Sub GridResultSearch_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridResultSearch.RowEditing

        'Dim row As GridViewRow = GridResultSearch.Rows
        'Session("CustSearch") = Trim(row.Cells(2).Text)
        Dim strIDTYPE As String = ""
        '0,1,2,
        '3=dr("SENDERID") = dtRow.Item(0).ToString()
        '4=dr("SENDERNAME") = dtRow.Item(1).ToString() & " " & dtRow.Item(2).ToString()
        '5=dr("ADDRESS1") = dtRow.Item(3).ToString()
        '6=dr("ADDRESS2") = dtRow.Item(4).ToString()
        '7=dr("TELNO") = dtRow.Item(5).ToString()
        '8=dr("OCCODE") = dtRow.Item(6).ToString()
        '9=dr("FAXNO") = dtRow.Item(7).ToString()
        '10=dr("MOBILENO") = dtRow.Item(8).ToString()
        '11=dr("email") = dtRow.Item(8).ToString()
        '12=dr("ITSCNO") = dtRow.Item(9).ToString()
        '13=dr("STATUS") = dtRow.Item(10).ToString()
        '14=dr("SENDERNAME1") = dtRow.Item(1).ToString()
        '15=dr("SENDERNAME2") = dtRow.Item(2).ToString()
        MVSearchSenid.ActiveViewIndex = 2
        Me.LBSenderID.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(3).Text
        ' 2008-09-30 Tom :
        'Me.LBSenderName1.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(14).Text
        'Me.LBSenderName2.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(15).Text
        Me.LBSenderName1.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(4).Text

        Me.LBSenderAddress1.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(5).Text
        Me.LBSenderAddress2.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(6).Text
        getIDNO(GridResultSearch.Rows(e.NewEditIndex).Cells(3).Text, strIDTYPE)
        'LBIDNo.Text = "<strong>" + I.ItemAttributes.Title.ToUpper() + "</strong>" + "<br/>" + I.ItemAttributes.Address.Address1.ToString() + "<br/>" + I.ItemAttributes.Neighborhood + "<br/>" + "Tel:" + "&nbsp;" + I.ItemAttributes.PhoneNumber + "<br/>" + "Price Rating:" + "&nbsp;" + priceRating(I.ItemAttributes.PriceRating) + "<br/>" + "<br/>"
        Me.LBIDNo.Text = strIDTYPE
        Me.LBOCCode.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(8).Text
        Me.LBPhoneNo.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(7).Text
        Me.LBFaxNo.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(9).Text
        Me.LBMobileNo.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(10).Text
        Me.LBEmail.Text = GridResultSearch.Rows(e.NewEditIndex).Cells(11).Text
        Session("STATUS") = Trim(GridResultSearch.Rows(e.NewEditIndex).Cells(13).Text)
    End Sub

    Protected Sub GridResultSearch_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridResultSearch.SelectedIndexChanging

        Dim row As GridViewRow = GridResultSearch.Rows(e.NewSelectedIndex)


        'Session("STATUS") = Trim(row.Cells(13).Text)
        Session("STATUS") = GridResultSearch.Rows(e.NewSelectedIndex).Cells(13).Text
        If Trim(Session("STATUS")) <> "A" And Trim(Session("STATUS")) <> "U" Then
            'cstext1 = "alert('Customer is not active.');"
            strMsg = "Customer Id does not exist in FOR System." & "(" & Trim(GridResultSearch.Rows(e.NewSelectedIndex).Cells(3).Text) & ")"
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Exit Sub
        End If
        Me.MVSearchSenid.ActiveViewIndex = 0
        Me.txtSenId.Value = GridResultSearch.Rows(e.NewSelectedIndex).Cells(3).Text

        ' 2008-08-18 Tom : get Sender Information
        If Not getSenderInfo() Then
            pnlPay.Enabled = False

            'ddlRateTypFCD.Enabled = False
            'ddlRateType.Enabled = False

            strMsg = "Customer Id does not exist in FOR System." & "(" & Trim(txtSenId.Value) & ")"
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            txtSenId.Focus()
            Exit Sub
        End If

        If Trim(ddlRemCur.Text <> "") Then
            ''A/C No FCD
            'pnlPay.Enabled = True
        Else
            pnlPay.Enabled = False
        End If

        Call AddCurRate(ddlInqPayCur) '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 

        '2010-11-12 R53060089 Tom : Interface with Sierra (FX) 
        'Call loadAccNo()


    End Sub
    Protected Sub ButBackDetail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButBackDetail.Click
        Me.MVSearchSenid.ActiveViewIndex = 1
    End Sub

    Protected Sub ButSelectDetail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButSelectDetail.Click
        If Trim(Session("STATUS")) <> "A" And Trim(Session("STATUS")) <> "U" Then
            'cstext1 = "alert('Customer is not active.');"
            strMsg = "Customer Id does not exist in FOR System." & "(" & Trim(LBSenderID.Text) & ")"
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Exit Sub
        End If

        Me.MVSearchSenid.ActiveViewIndex = 0
        Me.txtSenId.Value = Me.LBSenderID.Text

        ' 2008-08-18 Tom : get Sender Information
        If Not getSenderInfo() Then
            pnlPay.Enabled = False

            'ddlRateTypFCD.Enabled = False
            'ddlRateType.Enabled = False
            strMsg = "Customer Id does not exist in FOR System." & "(" & Trim(txtSenId.Value) & ")"
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            txtSenId.Focus()
            Exit Sub
        End If

        If Trim(ddlRemCur.Text <> "") Then
            ''A/C No FCD
            'pnlPay.Enabled = True
        Else
            pnlPay.Enabled = False
        End If

        '2010-11-12 R53060089 Tom : Interface with Sierra (FX) 
        'Call loadAccNo()

    End Sub

    Protected Sub butBackCriteria_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butBackCriteria.Click
        Me.MVSearchSenid.ActiveViewIndex = 0

    End Sub

    Protected Sub RadioSearchBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioSearchBy.SelectedIndexChanged
        Session("SEARCHSEDIDBY") = RadioSearchBy.SelectedItem.Value

        If RadioSearchBy.Items(0).Selected Then
            txtValueSendName.Text = ""
            DDLIDTYPE.SelectedIndex = 0
            txtValueSendID.Text = ""
            txtValueACNo.Text = ""

            txtValueSearchSenderID.Enabled = True
            txtValueSendName.Enabled = False
            DDLIDTYPE.Enabled = False
            txtValueSendID.Enabled = False
            txtValueACNo.Enabled = False


        ElseIf RadioSearchBy.Items(1).Selected Then
            txtValueSearchSenderID.Text = ""
            DDLIDTYPE.SelectedIndex = 0
            txtValueSendID.Text = ""
            txtValueACNo.Text = ""

            txtValueSearchSenderID.Enabled = False
            txtValueSendName.Enabled = True
            DDLIDTYPE.Enabled = False
            txtValueSendID.Enabled = False
            txtValueACNo.Enabled = False
            txtValueSendName.Focus()
        ElseIf RadioSearchBy.Items(2).Selected Then
            txtValueSendName.Text = ""
            txtValueSearchSenderID.Text = ""
            txtValueACNo.Text = ""

            txtValueSearchSenderID.Enabled = False
            txtValueSendName.Enabled = False
            DDLIDTYPE.Enabled = True
            txtValueSendID.Enabled = True
            txtValueACNo.Enabled = False
            DDLIDTYPE.Focus()
        ElseIf RadioSearchBy.Items(3).Selected Then
            txtValueSearchSenderID.Text = ""
            txtValueSendName.Text = ""
            DDLIDTYPE.SelectedIndex = 0
            txtValueSendID.Text = ""

            txtValueSearchSenderID.Enabled = False
            txtValueSendName.Enabled = False
            DDLIDTYPE.Enabled = False
            txtValueSendID.Enabled = False
            txtValueACNo.Enabled = True
            txtValueACNo.Focus()
        End If
    End Sub
    Public Sub getIDNO(ByVal strForcustid As String, ByRef strIDTYPE As String)
        Dim strsql As String
        Dim dtresultset As DataSet
        Dim dtrow As DataRow
        Dim conn As OdbcConnection = connDB.getDBConn()

        '***56100048 Ron
        'strsql = "select a.idtype,a.idno,b.value from db2.forlcuid a" & _
        '         " left outer join(select value,code from db2.frcmtbcd where type = 'T003') as b on b.code = a.idtype" & _
        '         " where a.forcustid  = '" & strForcustid & "' "
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        strsql = "select a.idtype,a.idno,b.value from db2.forlcuid a" & _
                 " left outer join" & _
                 " (" & _
                 "  select value,code from db2.frcmtbcd where type = 'T003' " & _
                 "   AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T003' ", concur.SWIFTCODE) & "' " & _
                 "  ) as b on b.code = a.idtype" & _
                 " where a.forcustid  = '" & strForcustid & "' "
        dtresultset = connDB.RunQuerySql(strsql)

        If dtresultset.Tables.Count > 0 Then
            For Each dtrow In dtresultset.Tables(0).Rows
                strIDTYPE = strIDTYPE & dtrow.Item(2) & "&nbsp;::&nbsp;" & dtrow.Item(1) & "<br/>"
                'strIDTYPE = strIDTYPEtmp
            Next
            conn.Close()
        Else
            strIDTYPE = ""
        End If

    End Sub
    Public Sub getObjCd(ByRef strObjDesc As String)
        Dim strsql As String

        Try
            '***56100048 Ron
            'strsql = "select value from db2.frcmtbcd " & _
            '         " where type = 'C001' and code = '" & Session("strObjCd") & "'"
            Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
            strsql = "select value from db2.frcmtbcd " & _
                     " where type = 'C001' and code = '" & Session("strObjCd") & "' " & _
                     "  AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C001' and code = '" & Session("strObjCd") & "' ", concur.SWIFTCODE) & "' "
            Dim ResultSet As DataSet = connDB.RunQuerySql(strsql)

            If ResultSet.Tables(0).Rows.Count > 0 Then

                Dim rowObj As DataRow
                For Each rowObj In ResultSet.Tables(0).Rows
                    strObjDesc = Trim(rowObj.Item(0).ToString)
                Next
            End If
        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Sub

    Protected Sub btnValDate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnValDate.Click
        Dim chkstrValDate As String
        Dim chkvalDate As Date
        Dim strValDate() As String
        Dim i As Integer

        '2008-10-16 Tom :
        If Trim(txtValDate.Value) = "" Then
            strMsg = "Value Date should be filled.!!!"
            Me.txtValDate.Focus()
            GoTo errMsg

        ElseIf Not PublicFunc.ValidateDate(txtValDate.Value) Then

            If (Len(Trim(txtValDate.Value)) = 8) And (Mid(Trim(txtValDate.Value), 3, 1) <> "/") And (Mid(Trim(txtValDate.Value), 6, 1) <> "/") Then
                txtValDate.Value = Mid(Trim(txtValDate.Value), 1, 2) & "/" & Mid(Trim(txtValDate.Value), 3, 2) & "/" & Mid(Trim(txtValDate.Value), 5, 4)
            ElseIf Len(Trim(txtValDate.Value)) = 9 Then
                strValDate = Split(Trim(txtValDate.Value), "/")
                txtValDate.Value = ""
                For i = 0 To strValDate.Length - 1
                    txtValDate.Value = Trim(txtValDate.Value) & strValDate(i).ToString()
                Next
                txtValDate.Value = Mid(Trim(txtValDate.Value), 1, 2) & "/" & Mid(Trim(txtValDate.Value), 3, 2) & "/" & Mid(Trim(txtValDate.Value), 5, 4)
            Else
                strMsg = "Invalid Date Format!!!"
                Me.txtValDate.Focus()
                GoTo errMsg
            End If
        End If

        '2008-10-20 Tom :
        If Not PublicFunc.ValidateDate(txtValDate.Value) Then
            strMsg = "Invalid Date Format!!!"
            Me.txtValDate.Focus()
            GoTo errMsg
        End If
        chkvalDate = Trim(txtValDate.Value)
        If Trim(txtValDate.Value) <> Format(chkvalDate, "dd/MM/yyyy") Then
            strMsg = "Invalid Date Format!!!"
            Me.txtValDate.Focus()
            GoTo errMsg

        End If

        'chkvalDate = Trim(txtValDate.value)
        chkstrValDate = Format(chkvalDate, "yyyy-MM-dd")
        If chkstrValDate > Format(Now, "yyyy-MM-dd") Then
            rbPreAdv.Enabled = True
            rbPreAdv.SelectedValue = "F"
        Else
            rbPreAdv.Enabled = False
            rbPreAdv.SelectedValue = "N"
        End If
errMsg:
        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub txtRemAmt_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRemAmt.TextChanged
        Dim i As Integer
        If Not PublicFunc.ValidateNum(txtRemAmt.Text) Then
            strMsg = "Remitting Amount is incorrect.!!!"
            Me.txtRemAmt.Focus()
            GoTo errMsg
        End If

        txtRemRate.Text = Format(CDbl(txtRemAmt.Text), "###,###,###,###,##0.00")
        '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System start
        'If (Trim(ddlRemCur.Text) = "JPY") And (Right(txtRemAmt.Text, 2) <> "00") Then
        '    strMsg = "Remitting Amount is incorrect.!!!"
        '    Me.txtRemAmt.Focus()
        '    GoTo errMsg
        'End If
        txtRemAmt.Text = txtRemRate.Text
        If PublicFunc.validateNotAllowDecimal(Trim(ddlRemCur.Text), Trim(txtRemAmt.Text)) = False Then
            strMsg = "Remitting Amount not allow decimal.!!!"
            Me.txtRemAmt.Focus()
            GoTo errMsg
        End If

        Dim sumAmt As Double
        If Session("dtAddInqRate") Is Nothing Then Exit Sub
        For i = 0 To Session("dtAddInqRate").rows.count - 1
            sumAmt = CDbl(Session("dtAddInqRate").rows(i).item(2))
        Next

        txtRemRate.Text = Format(CDbl(txtRemAmt.Text) - sumAmt, "###,###,###,###,##0.00")
        '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System end
errMsg:
        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub chkBkToTr_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkBkToTr.CheckedChanged
        Dim strBkToTr As String
        strBkToTr = "N"
        If chkBkToTr.Checked = True Then
            strBkToTr = "Y"
            '2013-10-14 :: Kwang :: R56070118 Change Gl account booking TR of IMEX
            txtTRdeal.Enabled = True
            txtTRdeal.BackColor = Drawing.Color.LightCyan
        Else
            txtTRdeal.Enabled = False
            txtTRdeal.Text = ""
            txtTRdeal.BackColor = Drawing.Color.LightGray
        End If

    End Sub

    Protected Sub chkPayFull_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkPayFull.CheckedChanged
        Dim strDetChar As String
        strDetChar = "BEN"
        If chkPayFull.Checked = True Then
            strDetChar = "OUR"
        End If

    End Sub

    Protected Sub GridAddInqRate_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridAddInqRate.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            ' No.
            e.Row.Cells(2).Text = e.Row.RowIndex + 1
            ' Rem Cur.
            e.Row.Cells(3).Text = e.Row.Cells(3).Text
            ' Rem Amount
            e.Row.Cells(4).Text = Format(CDbl(e.Row.Cells(4).Text), "###,###,###,###,##0.00")
            e.Row.Cells(4).HorizontalAlign = HorizontalAlign.Right
            ' Rate Type
            e.Row.Cells(5).Text = e.Row.Cells(5).Text
            ' Ex.Rate
            e.Row.Cells(6).Text = Format(CDbl(e.Row.Cells(6).Text), "##,##0.0000000")
            e.Row.Cells(6).HorizontalAlign = HorizontalAlign.Right
            ' Deal No.
            e.Row.Cells(7).Text = e.Row.Cells(7).Text
            ' Pay Cur.
            e.Row.Cells(8).Text = e.Row.Cells(8).Text
            'Pay Amt
            e.Row.Cells(9).Text = Format(CDbl(e.Row.Cells(9).Text), "###,###,###,###,##0.00")
            e.Row.Cells(9).HorizontalAlign = HorizontalAlign.Right
            'Adj Amt
            e.Row.Cells(10).Text = Format(CDbl(e.Row.Cells(10).Text), "###,###,###,###,##0.00")
            e.Row.Cells(10).HorizontalAlign = HorizontalAlign.Right
            'Tot Pay
            e.Row.Cells(11).Text = Format(CDbl(e.Row.Cells(11).Text), "###,###,###,###,##0.00")
            e.Row.Cells(11).HorizontalAlign = HorizontalAlign.Right
            'Channel
            e.Row.Cells(12).Text = e.Row.Cells(12).Text
            e.Row.Cells(12).ControlStyle.Font.Size = 0
            e.Row.Cells(12).ControlStyle.ForeColor = Drawing.Color.White

            If e.Row.Cells(3).Text = "&nbsp;" Then
                e.Row.Cells(3).Text = ""
            ElseIf e.Row.Cells(5).Text = "&nbsp;" Then
                e.Row.Cells(5).Text = ""
            ElseIf e.Row.Cells(7).Text = "&nbsp;" Then
                e.Row.Cells(7).Text = ""
            ElseIf e.Row.Cells(8).Text = "&nbsp;" Then
                e.Row.Cells(8).Text = ""
            End If

        End If
    End Sub

    Protected Sub GridAddInqRate_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridAddInqRate.RowDeleting
        Dim dr As DataRow

        'set Available Amount
        Dim i As Integer
        Dim sumAmt As Double = 0
        '2012-11-06 R55040057 Tom : Support new organize
        Dim j As Integer, k As Integer
        Dim sumPayAmt As Double, sumRemAmt As Double
        Dim strPayCur As String, strPayCurSql As String
        Dim dblAccRate As Double


        dtAddInqRate = Session("dtAddInqRate")

        ' 2009-08-03 Tom : Don't delete rec from S1
        If Trim(GridAddInqRate.Rows(e.RowIndex).Cells(12).Text) = "Y" Then
            strMsg = "Can not delete this transaction."
            GoTo exitHandle
        End If

        If e.RowIndex - 1 < dtAddInqRate.Rows.Count Then
            dtAddInqRate.Rows(e.RowIndex).Delete()
            GridAddInqRate.DataSource = dtAddInqRate
            GridAddInqRate.DataBind()

            Session("dtAddInqRate") = dtAddInqRate
        End If

        ' reset control
        If GridAddInqRate.Rows.Count = 0 Then
            resetRate()
            pnlInqAddRate.Visible = True
            pnlInqUpdRate.Visible = False
        End If

        'default Grid Rate
        If (GridAddInqRate.Rows.Count = 0) Then
            dr = dtAddInqRate.NewRow
            dr("No.") = dtAddInqRate.Rows.Count + 1
            dr("Rem Cur.") = ""
            dr("Rem Amount") = "0.00"
            dr("Rate Type") = ""
            dr("Ex. Rate") = "0.0000000"
            dr("Deal No.") = ""
            dr("Pay Cur.") = ""
            dr("Pay Amount") = "0.00"
            dr("Adj. Amt") = "0.00"
            dr("Tot Pay") = "0.00"
            dr(" ") = ""

            dtAddInqRate.Rows.Add(dr)

            GridAddInqRate.DataSource = dtAddInqRate
            GridAddInqRate.DataBind()
            GridAddInqRate.Rows(0).Enabled = False

            Session("dtAddInqRate") = Nothing
        End If

        For i = 0 To dtAddInqRate.Rows.Count - 1
            sumAmt = sumAmt + CDbl(Trim(dtAddInqRate.Rows(i).Item(2)))
        Next

        lblRemRate.Text = Format(sumAmt, "###,###,###,###,##0.00")
        'lblTotRem.Text = Format(CDbl(lblRem.Text) - CDbl(lblRemAvl.Text), "###,###,###,###,##0.00")
        txtRemRate.Text = Format(CDbl(txtRemAmt.Text) - sumAmt, "###,###,###,###,##0.00")

        '2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
        If CDbl(lblRemRate.Text) = CDbl(txtRemAmt.Text) Then
            pnlSumRateInfo.Visible = True
            pnlPay.Enabled = True
            '2013-01-08 R55040057 Tom Start : Support new organize
            For i = 0 To Session("dtAddInqRate").Rows.Count - 1

                ' Clear Sum Rate Info - GridSumRate
                dtSumRateInfo.Clear()
                GridSumRate.DataSource = dtSumRateInfo
                GridSumRate.DataBind()
                Session("dtSumRateInfo") = dtSumRateInfo

                sumPayAmt = 0
                sumRemAmt = 0
                strPayCur = Trim(dtAddInqRate.Rows(i).Item(6))

                For j = 0 To Session("dtAddInqRate").Rows.Count - 1
                    If (strPayCur = Trim(dtAddInqRate.Rows(j).Item(6))) Then
                        sumPayAmt = sumPayAmt + CDbl(Trim(dtAddInqRate.Rows(j).Item(9)))
                        sumRemAmt = sumRemAmt + CDbl(Trim(dtAddInqRate.Rows(j).Item(2)))
                    End If
                Next
                dblAccRate = sumPayAmt / sumRemAmt
                For k = 0 To Session("dtSumRateInfo").Rows.Count - 1
                    If Trim(dtSumRateInfo.Rows(k).Item(1)) = strPayCur Then GoTo nexti
                Next
                dr = dtSumRateInfo.NewRow
                dr("No.") = dtSumRateInfo.Rows.Count + 1
                dr("Pay Cur.") = strPayCur
                dr("Total Pay Amount") = Format(sumPayAmt, "###,###,###,###,##0.00")
                dr("Acc Rate") = dblAccRate

                dtSumRateInfo.Rows.Add(dr)
                GridSumRate.DataSource = dtSumRateInfo
                GridSumRate.DataBind()
                Session("dtSumRateInfo") = dtSumRateInfo
nexti:
            Next
            ' Payment Info - GridAddPay
            dtPayment.Clear()
            dr = dtPayment.NewRow
            dr("No.") = dtPayment.Rows.Count + 1
            dr("A/C Cur.") = ""
            dr("A/C No.") = ""
            dr("Pay Amount") = 0.0
            dr("Rem Cur.") = ""
            dr("Rem Amount") = 0.0
            dtPayment.Rows.Add(dr)
            GridAddPay.DataSource = dtPayment
            GridAddPay.DataBind()
            Session("dtPayment") = dtPayment
            GridAddPay.Enabled = False
            lblRemPay.Text = "0.00"

            ' Set A/C Cur
            ddlAcCurPay.Items.Clear()
            ddlAcCurPay.DataBind()

            ddlAcCurPay.Items.Add("")
            For i = 0 To Session("dtSumRateInfo").Rows.Count - 1
                strPayCurSql = Trim(dtSumRateInfo.Rows(i).Item(1))
                ddlAcCurPay.Items.Add(strPayCurSql)
                ddlAcCurPay.DataBind()
            Next
            If ddlAcCurPay.Items.Count = 2 Then
                ddlAcCurPay.SelectedIndex = 1
                Call loadAccNo()
            End If
            '2013-01-08 R55040057 Tom End : Support new organize
        Else
            ' Sum Rate Info - GridSumRate
            dtSumRateInfo.Clear()
            dr = dtSumRateInfo.NewRow
            dr("No.") = dtSumRateInfo.Rows.Count + 1
            dr("Pay Cur.") = ""
            dr("Total Pay Amount") = 0.0
            dr("Acc Rate") = 0.0
            dtSumRateInfo.Rows.Add(dr)
            GridSumRate.DataSource = dtSumRateInfo
            GridSumRate.DataBind()
            Session("dtSumRateInfo") = dtSumRateInfo
            pnlSumRateInfo.Visible = False
            resetPay()
            pnlPay.Enabled = False

            '2012-11-06 R55040057 Tom : Support new organize
            ' Payment Info - GridAddPay
            dtPayment.Clear()
            dr = dtPayment.NewRow
            dr("No.") = dtPayment.Rows.Count + 1
            dr("A/C Cur.") = ""
            dr("A/C No.") = ""
            dr("Pay Amount") = 0.0
            dr("Rem Cur.") = ""
            dr("Rem Amount") = 0.0
            dtPayment.Rows.Add(dr)
            GridAddPay.DataSource = dtPayment
            GridAddPay.DataBind()
            Session("dtPayment") = dtPayment
            GridAddPay.Enabled = False
            lblRemPay.Text = "0.00"
        End If

        'If (Session("dtAddInqRate") Is Nothing) Then
        'ElseIf (Trim(Session("dtAddInqRate").Rows(0).Item(1)) = "") Then
        '    Session("dtAddInqRate") = Nothing
        'End If

exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
    End Sub

    Protected Sub GridAddInqRate_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridAddInqRate.SelectedIndexChanging
        Dim index As Integer = e.NewSelectedIndex.ToString
        Dim row As GridViewRow = GridAddInqRate.Rows(index)
        Dim strRateType As String
        Dim i As Integer
        Session("selectIndex") = index

        If (Trim(row.Cells(5).Text) = "CT") And (Trim(row.Cells(12).Text) = "Y") _
           Or (Trim(row.Cells(12).Text) = "N") Then

            GridAddInqRate.DataSource = Session("dtAddInqRate")
            GridAddInqRate.DataBind()
            GridAddInqRate.Rows(index).ForeColor = Drawing.Color.Red
            GridAddInqRate.Rows(index).Font.Bold = False

            If Trim(row.Cells(12).Text) = "Y" Then
                ddlRateType.Enabled = False
                txtExRate.ReadOnly = True
                txtDeal.ReadOnly = True
                ddlInqPayCur.Enabled = False
                txtAdjAmt.ReadOnly = True
            End If

            txtRemRate.Text = Format(CDbl(row.Cells(4).Text), "#,##0.00")

            strRateType = Trim(row.Cells(5).Text)

            For i = 0 To ddlRateType.Items.Count - 1
                If Left(ddlRateType.Items(i).Text, 2) = strRateType Then
                    ddlRateType.SelectedIndex = i
                    Exit For
                End If
            Next

            txtExRate.Text = Format(CDbl(row.Cells(6).Text), "#,##0.0000000")
            txtDeal.Text = Trim(row.Cells(7).Text)
            If Trim(txtDeal.Text) = "&nbsp;" Then
                txtDeal.Text = " "
            End If
            ' 2013-01-28 R55040057 Tom : Support new organize
            'ddlInqPayCur.Text = Trim(row.Cells(8).Text)
            For i = 0 To ddlInqPayCur.Items.Count - 1
                If ddlInqPayCur.Items(i).Text = Trim(row.Cells(8).Text) Then
                    ddlInqPayCur.SelectedIndex = i
                    Exit For
                End If
            Next
            txtPayAmt.Text = Format(CDbl(row.Cells(9).Text), "#,##0.00")

            If CDbl(txtPayAmt.Text) > CDbl(row.Cells(11).Text) Then
                txtAdjAmt.Text = Format(CDbl(txtPayAmt.Text) - CDbl(row.Cells(11).Text), "#,##0.00")
            Else
                txtAdjAmt.Text = Format(CDbl(row.Cells(11).Text) - CDbl(txtPayAmt.Text), "#,##0.00")
            End If
            Session("Channel") = Trim(row.Cells(12).Text)

            Select Case Left(Trim(ddlRateType.Text), 2)
                Case "CT"
                    txtExRate.BackColor = Drawing.Color.LightGray
                    txtExRate.ReadOnly = True
                Case "NM"
                    If txtRemCur.Text = ddlInqPayCur.Text Then
                        ddlRateType.Enabled = False
                        ddlRateType.BackColor = Drawing.Color.LightGray
                    End If
                    txtExRate.BackColor = Drawing.Color.LightGray
                    txtExRate.ReadOnly = True
                Case "FW", "SP"
                    txtDeal.BackColor = Drawing.Color.LightCyan
                Case Else
                    txtExRate.ReadOnly = False
                    txtExRate.BackColor = Drawing.Color.LightCyan
                    txtDeal.BackColor = Drawing.Color.White
            End Select
            Session("UpdFlag") = True
            GridAddInqRate.Enabled = False
            pnlInqAddRate.Visible = False
            pnlInqUpdRate.Visible = True


        Else
            strMsg = "Can not edit this transaction."
            GoTo exitHandle

        End If

        '2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
        ' sum Rate Info
        dtSumRateInfo.Clear()
        dr = dtSumRateInfo.NewRow
        dr("No.") = dtSumRateInfo.Rows.Count + 1
        dr("Pay Cur.") = ""
        dr("Total Pay Amount") = 0.0
        dr("Acc Rate") = 0.0
        dtSumRateInfo.Rows.Add(dr)
        GridSumRate.DataSource = dtSumRateInfo
        GridSumRate.DataBind()
        Session("dtSumRateInfo") = dtSumRateInfo
        pnlSumRateInfo.Visible = False
        resetPay()
        pnlPay.Enabled = False

        '2012-11-06 R55040057 Tom : Support new organize
        ' Payment Info - GridAddPay
        dtPayment.Clear()
        dr = dtPayment.NewRow
        dr("No.") = dtPayment.Rows.Count + 1
        dr("A/C Cur.") = ""
        dr("A/C No.") = ""
        dr("Pay Amount") = 0.0
        dr("Rem Cur.") = ""
        dr("Rem Amount") = 0.0
        dtPayment.Rows.Add(dr)
        GridAddPay.DataSource = dtPayment
        GridAddPay.DataBind()
        Session("dtPayment") = dtPayment
        GridAddPay.Enabled = False
        lblRemPay.Text = "0.00"
exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
    End Sub
    Private Sub resetRate()

        txtRemRate.Text = 0.0
        ddlRateType.SelectedIndex = 0
        txtRemRate.Text = "0.00"
        txtDeal.Text = ""
        txtExRate.Text = "0.0000000"
        'If ddlInqPayCur.Items.Count = 2 Then ddlInqPayCur.SelectedIndex = 1 Else ddlInqPayCur.SelectedIndex = 0
        If ddlInqPayCur.Items.Count > 0 Then
            If ddlInqPayCur.Items.Count = 2 Then ddlInqPayCur.SelectedIndex = 1 Else ddlInqPayCur.SelectedIndex = 0
        End If
        txtPayAmt.Text = "0.00"
        txtAdjAmt.Text = "0.00"

        '2009-09-17 Tom :
        btnAdjPlus.BackColor = Drawing.Color.LightGray
        btnAdjMinus.BackColor = Drawing.Color.LightGray

        Session("AdjFlag") = False '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System
    End Sub
    '2010-11-09 R53060089 Tom : Interface with Sierra (FX) 
    Protected Sub ddlRateType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRateType.SelectedIndexChanged
        Session("RateType") = Left(Trim(ddlRateType.Text), 2)
        Call calPayAmt()

    End Sub

    Private Sub calPayAmt()
        '*** CMHI:b5536de5-2720-4e7a-8303-b9071996318a
        Dim sellRate As Double, nomRate As Double, buyRate As Double
        Dim paysellRate As Double, paynomRate As Double, paybuyRate As Double
        Dim strRemCur As String
        Dim i As Integer

        strRemCur = ""

        If (Trim(ddlInqPayCur.Text) = "") Or (Trim(txtRemCur.Text) = "") Then GoTo exitHandle

        If Not getRate(Trim(txtRemCur.Text), sellRate, nomRate, buyRate) Then GoTo exitHandle
        If Not getRate(Trim(ddlInqPayCur.Text), paysellRate, paynomRate, paybuyRate) Then GoTo exitHandle
        '***R56100048 Repalce "THB"
        'If Trim(ddlInqPayCur.Text) = "THB" Then
        If Trim(ddlInqPayCur.Text) = CType(Session("concurrencyInfo"), _
         FORWEB_Concurrency).BaseCurrency Then
            Select Case Left(Trim(ddlRateType.Text), 2)
                Case "CT", "CP"
                    txtExRate.Text = Format(CDbl(sellRate), "##,##0.0000000")
                    txtExRate.ReadOnly = True
                    If Left(Trim(ddlRateType.Text), 2) = "CP" Then txtExRate.ReadOnly = False
                    txtExRate.BackColor = Drawing.Color.LightGray
                    txtPayAmt.Text = Format((CDbl(txtRemRate.Text) * CDbl(txtExRate.Text)), "###,###,###,###,##0.00")

                Case "NM"

                    txtExRate.Text = Format(CDbl(nomRate), "##,##0.0000000")
                    txtExRate.BackColor = Drawing.Color.LightGray
                    txtPayAmt.Text = Format((CDbl(txtRemRate.Text) * CDbl(txtExRate.Text)), "###,###,###,###,##0.00")

                    'check for special rate
                Case "CM"
                    txtExRate.Text = Format(CDbl(sellRate) + CDbl(Session("rateMrg")), "##,##0.0000000")
                    txtExRate.ReadOnly = True
                    txtExRate.BackColor = Drawing.Color.LightGray
                    txtPayAmt.Text = Format((CDbl(txtRemRate.Text) * CDbl(txtExRate.Text)), "###,###,###,###,##0.00")

                Case Else
                    txtExRate.ReadOnly = False
                    txtExRate.BackColor = Drawing.Color.LightCyan
                    txtPayAmt.Text = Format((CDbl(txtRemRate.Text) * CDbl(txtExRate.Text)), "###,###,###,###,##0.00")

            End Select

        Else  ' PayCur <> "THB"

            Select Case Left(Trim(ddlRateType.Text), 2)
                Case "NM"
                    For i = 0 To ddlInqPayCur.Items.Count - 1
                        If Trim(ddlInqPayCur.Items(i).Text) = Trim(ddlRemCur.Text) Then
                            ddlInqPayCur.SelectedIndex = i
                        End If
                    Next

                    If Trim(ddlInqPayCur.Text) <> Trim(txtRemCur.Text) Then
                        txtExRate.Text = Format(CDbl(nomRate), "##,##0.0000000")
                    Else
                        txtExRate.Text = "1.0000000"
                    End If

                    txtExRate.BackColor = Drawing.Color.LightGray
                    txtExRate.ReadOnly = True
                    txtPayAmt.Text = Format(CDbl(txtRemRate.Text), "###,###,###,###,##0.00")

                Case "CT", "CM"
                    If CDbl(paybuyRate) <> 0 Then
                        txtPayAmt.Text = Format((CDbl(txtRemRate.Text) * CDbl(sellRate)) / CDbl(paybuyRate), "###,###,###,###,##0.00")
                    End If
                    If CDbl(txtRemRate.Text) <> 0 Then
                        txtExRate.Text = Format(CDbl(txtPayAmt.Text) / CDbl(txtRemRate.Text), "##,##0.0000000")
                    End If
                    txtExRate.BackColor = Drawing.Color.LightGray
                    txtExRate.ReadOnly = True

                Case Else 'edit rate
                    txtExRate.ReadOnly = False
                    txtExRate.BackColor = Drawing.Color.LightCyan
                    If pnlInqAddRate.Visible = True And Session("btnCalPayAmt") = False Then
                        txtExRate.Text = "0.0000000"
                    End If
                    txtPayAmt.Text = Format((CDbl(txtRemRate.Text) * CDbl(txtExRate.Text)), "###,###,###,###,##0.00")

            End Select

        End If
        If (Left(Trim(ddlRateType.Text), 2) = "FW") Or (Left(Trim(ddlRateType.Text), 2) = "SP") _
            Or (Left(Trim(ddlRateType.Text), 2) = "SO") Then

            txtDeal.BackColor = Drawing.Color.LightCyan
        Else
            txtDeal.BackColor = Drawing.Color.White
        End If

        Session("calRate") = CDbl(txtExRate.Text)


        '2015-11-16 : PIK : R58100092 To Format Decimal in VND&JPY currencies in FOR and or FRC System :  validate not allow decimal
        If PublicFunc.validateNotAllowDecimal(ddlInqPayCur.SelectedValue, txtPayAmt.Text) = False Then
            txtPayAmt.Text = PublicFunc.convertFormatVar(Math.Round(CDbl(txtPayAmt.Text), MidpointRounding.ToEven), "AMT")
            'txtPayAmt.Text = PublicFunc.convertFormatVar(txtPayAmt.Text, "AMT")
        End If
exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
    End Sub

    Protected Sub ddlInqPayCur_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlInqPayCur.SelectedIndexChanged

        '*** CMHI:bfa81742-4303-4e11-ba48-3b69c1879b7e
        '***R56100048 Repalce "THB"
        'If Trim(ddlInqPayCur.Text) = "THB" Then
        If Trim(ddlInqPayCur.Text) = CType(Session("concurrencyInfo"), _
         FORWEB_Concurrency).BaseCurrency Then
            ' check for special rate
            If Not getSpecRate() Then
                Call AddRate("NOTCM")
            Else
                Call AddRate("NOTCT") 'special rate (add CM )
            End If
        Else
            If Trim(txtRemCur.Text) <> Trim(ddlInqPayCur.Text) Then
                Call AddRate("NOTNM")
            Else
                '2009-07-01 Tom :
                'Call AddRate("NOTCM")
                Call AddRate("ALL")
            End If
        End If
        Call defaultRate()
        Call calPayAmt()
errMsg:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub
    Private Function getSpecRate() As Boolean

        Dim strSql As String

        getSpecRate = False
        Try
            strSql = "select b.ratemrg from db2.forwtran a ,db2.forlcurt b where a.forref = '" & Session("ForRef") & "' and " & _
                           " a.senid = b.forcustid and b.prodcd = '" & Trim(strProdName) & "'  and  a.remcur = b.curcd"
            Dim ResultSetSpec As DataSet = connDB.RunQuerySql(strSql)
            If ResultSetSpec.Tables.Count > 0 Then

                Dim rowdetSpec As DataRow
                For Each rowdetSpec In ResultSetSpec.Tables(0).Rows
                    Session("rateMrg") = CDbl(rowdetSpec.Item(0))
                    getSpecRate = True
                Next
            End If

        Catch odbce As OdbcException
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        Catch ex As Exception
            If Session("Page") = "Entry" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Entry")
            ElseIf Session("Page") = "Amend" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Amend&frompage=Entry")
            End If
        End Try

    End Function

    Protected Sub btnInqAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInqAdd.Click
        Dim dr As DataRow
        Dim cntRate As Integer
        Dim i As Integer, j As Integer, k As Integer
        Dim sumAmt As Double, sumPayAmt As Double, sumRemAmt As Double
        Dim lessAmt As String
        Dim dblRemRate As String, dblPayAmt As String
        Dim dblAdjAmt As String, dblTotPay As String
        Dim strPayCur As String, strPayCurSql As String
        Dim dblAccRate As Double

        sumAmt = 0
        dblPayAmt = 0
        lessAmt = ""
        strMsg = ""

        dblTotPay = 0
        sumPayAmt = 0
        sumRemAmt = 0
        dblAccRate = 0

        strPayCur = ""
        pnlSumRateInfo.Visible = False
        pnlPay.Enabled = False
        strPayCurSql = ""

        'check refresh
        If (Session("dtAddInqRate") Is Nothing) Then
        Else
            dtAddInqRate = Session("dtAddInqRate")

            For j = 0 To Session("dtAddInqRate").Rows.Count - 1
                If (Trim(dtAddInqRate.Rows(j).Item(1)) = Trim(txtRemCur.Text)) And (CDbl(Trim(dtAddInqRate.Rows(j).Item(2))) = CDbl(txtRemAmt.Text)) _
                         And (Trim(dtAddInqRate.Rows(j).Item(3)) = Left(Trim(ddlRateType.Text), 2)) And (CDbl(Trim(dtAddInqRate.Rows(j).Item(4))) = CDbl(txtExRate.Text)) _
                        And (Trim(dtAddInqRate.Rows(j).Item(5)) = Trim(txtDeal.Text)) And (Trim(dtAddInqRate.Rows(j).Item(6)) = Trim(ddlInqPayCur.Text)) _
                        And (CDbl(Trim(dtAddInqRate.Rows(j).Item(7))) = CDbl(txtPayAmt.Text)) And (CDbl(Trim(dtAddInqRate.Rows(j).Item(8))) = CDbl(txtAdjAmt.Text)) Then
                    dtAddInqRate = Session("dtAddInqRate")
                    GridAddInqRate.DataSource = dtAddInqRate
                    GridAddInqRate.DataBind()
                    resetRate()
                    Exit Sub
                End If
            Next

        End If

        'count Rate in grid
        cntRate = GridAddInqRate.Rows.Count + 1

        If cntRate > 20 Then
            strMsg = "Can not add rate more than 20. "
            GoTo errMsg
        End If

        'validate Rate Info
        If Not ValDataEntry("RATEINFO", strMsg) Then GoTo errMsg

        GridAddInqRate.Rows(0).Enabled = True

        'display grid  default
        dr = dtAddInqRate.NewRow
        If (GridAddInqRate.Rows.Count = 1) And (Session("dtAddInqRate") Is Nothing) Then
            GridAddInqRate.DataSource = Nothing
            GridAddInqRate.DataBind()

        End If

        If Session("dtAddInqRate") Is Nothing Then
            dtAddInqRate.Columns.Add(New DataColumn("No.", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Rem Cur.", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Rem Amount", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn("Rate Type", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Ex. Rate", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn("Deal No.", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Pay Cur.", GetType(System.String)))
            dtAddInqRate.Columns.Add(New DataColumn("Pay Amount", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn("Adj. Amt", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn("Tot Pay", GetType(System.Double)))
            dtAddInqRate.Columns.Add(New DataColumn(" ", GetType(System.String)))

        Else
            dtAddInqRate = Session("dtAddInqRate")
        End If

        If Session("AdjFlag") = False Then
            dblTotPay = Format(CDbl(txtPayAmt.Text) - CDbl(txtAdjAmt.Text), "###,###,###,###,##0.00")
        ElseIf (CDbl(txtAdjAmt.Text) <> 0) Then
            If btnAdjPlus.BackColor = Drawing.Color.Gold Then
                dblTotPay = Format(CDbl(txtPayAmt.Text) + CDbl(txtAdjAmt.Text), "###,###,###,###,##0.00")

            Else
                dblTotPay = Format(CDbl(txtPayAmt.Text) - CDbl(txtAdjAmt.Text), "###,###,###,###,##0.00")

            End If
        End If

        dblRemRate = Format(CDbl(txtRemRate.Text), "###,###,###,###,##0.00")
        dblPayAmt = Format(CDbl(txtPayAmt.Text), "###,###,###,###,##0.00")
        dblAdjAmt = Format(dblTotPay - dblPayAmt, "###,###,###,###,##0.00")

        If strMsg = "" Then
            dr = dtAddInqRate.NewRow
            dr("No.") = dtAddInqRate.Rows.Count + 1
            dr("Rem Cur.") = Me.txtRemCur.Text.ToString
            dr("Rem Amount") = dblRemRate
            dr("Rate Type") = Left(Trim(ddlRateType.Text.ToString), 2)
            dr("Ex. Rate") = Me.txtExRate.Text
            dr("Deal No.") = Me.txtDeal.Text.ToString
            dr("Pay Cur.") = Me.ddlInqPayCur.Text.ToString
            dr("Pay Amount") = dblPayAmt
            dr("Adj. Amt") = dblAdjAmt
            dr("Tot Pay") = dblTotPay
            dr(" ") = "N"

            'sum Amount in datagrid
            If Session("dtAddInqRate") Is Nothing Then
                If CDbl(txtRemAmt.Text) > sumAmt Then
                    lessAmt = Format(CDbl(CDbl(txtRemAmt.Text) - sumAmt), "###,###,###,###,##0.00")
                Else
                    lessAmt = Format(CDbl(sumAmt - CDbl(txtRemAmt.Text)), "###,###,###,###,##0.00")
                End If
                sumAmt = CDbl(dblRemRate)
            Else

                For i = 0 To Session("dtAddInqRate").Rows.Count - 1
                    sumAmt = sumAmt + CDbl(Trim(dtAddInqRate.Rows(i).Item(2)))
                Next

                sumAmt = Format(sumAmt, "###,###,###,###,##0.00")

                If CDbl(txtRemAmt.Text) > CDbl(sumAmt) Then
                    lessAmt = Format(CDbl(CDbl(txtRemAmt.Text) - CDbl(sumAmt)), "###,###,###,###,##0.00")
                Else
                    lessAmt = Format(CDbl(CDbl(sumAmt) - CDbl(txtRemAmt.Text)), "###,###,###,###,##0.00")
                End If

                sumAmt = Format(CDbl(sumAmt) + CDbl(dblRemRate), "###,###,###,###,##0.00")

            End If

            If CDbl(sumAmt) > CDbl(txtRemAmt.Text) Then

                strMsg = "Amount is more than Remitting Amount !!!" & "\n" & "Please input remitting amount less than or equal : " & lessAmt
                cstext1 = "alert('" & strMsg & "');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)

                If (Session("dtAddInqRate") Is Nothing) Or (GridAddInqRate.Rows.Count < 0) Then

                    If pnlInqAddRate.Visible = True Then

                        dr = dtAddInqRate.NewRow
                        dr("No.") = dtAddInqRate.Rows.Count + 1
                        dr("Rem Cur.") = ""
                        dr("Rem Amount") = "0.00"
                        dr("Rate Type") = ""
                        dr("Ex. Rate") = "0.0000000"
                        dr("Deal No.") = ""
                        dr("Pay Cur.") = ""
                        dr("Pay Amount") = "0.00"
                        dr("Adj. Amt") = "0.00"
                        dr("Tot Pay") = "0.00"
                        dr(" ") = ""

                        dtAddInqRate.Rows.Add(dr)
                        GridAddInqRate.DataSource = dtAddInqRate
                        GridAddInqRate.DataBind()
                        GridAddInqRate.Rows(0).Enabled = False
                        txtRemAmt.Focus()
                        Exit Sub
                    End If
                End If


                GoTo errMsg
            Else
                'validate Rate Amount
                ValDataEntry("RATEAMT", strMsg)

                dtAddInqRate.Rows.Add(dr)
                GridAddInqRate.DataSource = dtAddInqRate
                GridAddInqRate.DataBind()
                Session("dtAddInqRate") = dtAddInqRate
            End If

            ''set Available Amount
            'lblRemAvl.Text = Format(CDbl(lblRemRate.Text) - sumAmt, "###,###,###,###,##0.00")
            'Session("RemAvl") = Format(CDbl(lblRemRate.Text) - sumAmt, "###,###,###,###,##0.00")
            lblRemRate.Text = Format(CDbl(sumAmt), "###,###,###,###,##0.00")

        End If
        Session("sumRemAmt") = sumAmt

        resetRate()

        ddlRateType.Enabled = True
        ddlRateType.BackColor = Drawing.Color.LightCyan
        txtExRate.ReadOnly = False
        txtExRate.BackColor = Drawing.Color.LightCyan

        txtDeal.ReadOnly = False
        txtDeal.BackColor = Drawing.Color.White
        ddlInqPayCur.Enabled = True
        ddlInqPayCur.BackColor = Drawing.Color.LightCyan

        Session("AdjFlag") = False

        ' 210-11-11 Tom : Detail Sum Pay Amount
        If CDbl(lblRemRate.Text) = CDbl(txtRemAmt.Text) Then

            pnlSumRateInfo.Visible = True
            pnlPay.Enabled = True

            If (GridSumRate.Rows.Count = 1) And (Trim(dtSumRateInfo.Rows(0).Item(1)) = "") Then
                dtSumRateInfo.Rows(0).Delete()
                GridSumRate.DataSource = dtSumRateInfo
                GridSumRate.DataBind()
            End If

            For i = 0 To Session("dtAddInqRate").Rows.Count - 1

                sumPayAmt = 0
                sumRemAmt = 0
                strPayCur = Trim(dtAddInqRate.Rows(i).Item(6))

                For j = 0 To Session("dtAddInqRate").Rows.Count - 1

                    If (strPayCur = Trim(dtAddInqRate.Rows(j).Item(6))) Then

                        sumPayAmt = sumPayAmt + CDbl(Trim(dtAddInqRate.Rows(j).Item(9)))
                        sumRemAmt = sumRemAmt + CDbl(Trim(dtAddInqRate.Rows(j).Item(2)))

                    End If

                Next

                'strAccRate = Format(sumPayAmt / sumRemAmt, "###,##0.0000000")
                dblAccRate = sumPayAmt / sumRemAmt

                If Session("dtSumRateInfo") Is Nothing Then
                    dr = dtSumRateInfo.NewRow
                    dr("No.") = dtSumRateInfo.Rows.Count + 1
                    dr("Pay Cur.") = strPayCur
                    dr("Total Pay Amount") = Format(sumPayAmt, "###,###,###,###,##0.00")
                    dr("Acc Rate") = dblAccRate

                    dtSumRateInfo.Rows.Add(dr)
                    GridSumRate.DataSource = dtSumRateInfo
                    GridSumRate.DataBind()
                    Session("dtSumRateInfo") = dtSumRateInfo
                Else

                    For k = 0 To Session("dtSumRateInfo").Rows.Count - 1
                        If Trim(dtSumRateInfo.Rows(k).Item(1)) = strPayCur Then GoTo nexti
                    Next
                    dr = dtSumRateInfo.NewRow
                    dr("No.") = dtSumRateInfo.Rows.Count + 1
                    dr("Pay Cur.") = strPayCur
                    dr("Total Pay Amount") = Format(sumPayAmt, "###,###,###,###,##0.00")
                    dr("Acc Rate") = dblAccRate

                    dtSumRateInfo.Rows.Add(dr)
                    GridSumRate.DataSource = dtSumRateInfo
                    GridSumRate.DataBind()
                    Session("dtSumRateInfo") = dtSumRateInfo

                End If


nexti:
            Next
            i = 0
            ddlAcCurPay.Items.Clear()
            ddlAcCurPay.DataBind()

            ddlAcCurPay.Items.Add("")
            For i = 0 To Session("dtSumRateInfo").Rows.Count - 1
                strPayCurSql = Trim(dtSumRateInfo.Rows(i).Item(1))
                ddlAcCurPay.Items.Add(strPayCurSql)
                ddlAcCurPay.DataBind()
            Next

            If ddlAcCurPay.Items.Count = 2 Then
                ddlAcCurPay.SelectedIndex = 1
                Call loadAccNo()
            End If

        End If

        txtRemRate.Text = Format(CDbl(txtRemAmt.Text) - CDbl(lblRemRate.Text), "###,###,###,###,##0.00")
        '2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
        If CDbl(lessAmt) = 0 Then
            resetRate()
            pnlSumRateInfo.Visible = True
            pnlPay.Enabled = True
        End If
errMsg:
        ''2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
        'If lessAmt = 0 Then
        '    resetRate()
        '    pnlSumRateInfo.Visible = True
        '    pnlPay.Enabled = True
        'End If

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If


    End Sub

    Protected Sub btnInqUpd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInqUpd.Click
        Dim dr As DataRow
        Dim i As Integer, j As Integer, k As Integer
        Dim sumAmt As Double, netAmt As Double
        Dim lessAmt As String
        Dim dblRemRate As String, dblPayAmt As String
        Dim dblAdjAmt As String, dblTotPay As String
        Dim strPayCur As String, strPayCurSql As String
        Dim sumPayAmt As Double, sumRemAmt As Double
        Dim dblAccRate As Double

        sumAmt = 0
        dblPayAmt = 0
        netAmt = 0
        lessAmt = ""
        strMsg = ""
        dblTotPay = 0

        dblTotPay = 0
        sumPayAmt = 0
        dblAccRate = 0
        strPayCur = ""
        pnlSumRateInfo.Visible = False
        pnlPay.Enabled = False

        strPayCurSql = ""
        'validate Rate Info
        If Not ValDataEntry("RATEINFO", strMsg) Then GoTo errMsg

        If Session("AdjFlag") = False Then
            dblTotPay = Format(CDbl(txtPayAmt.Text) - CDbl(txtAdjAmt.Text), "###,###,###,###,##0.00")
        ElseIf (CDbl(txtAdjAmt.Text) <> 0) Then
            If btnAdjPlus.BackColor = Drawing.Color.Gold Then
                dblTotPay = Format(CDbl(txtPayAmt.Text) + CDbl(txtAdjAmt.Text), "###,###,###,###,##0.00")
            Else
                dblTotPay = Format(CDbl(txtPayAmt.Text) - CDbl(txtAdjAmt.Text), "###,###,###,###,##0.00")

            End If
        End If

        dblRemRate = Format(CDbl(txtRemRate.Text), "###,###,###,###,##0.00")
        dblPayAmt = Format(CDbl(txtPayAmt.Text), "###,###,###,###,##0.00")
        dblAdjAmt = Format(dblTotPay - dblPayAmt, "###,###,###,###,##0.00")
        dtAddInqRate = Session("dtAddInqRate")

        dr = dtAddInqRate.Rows(Session("selectIndex"))
        dr("No.") = dtAddInqRate.Rows.Count + 1
        dr("Rem Cur.") = Me.txtRemCur.Text.ToString
        dr("Rem Amount") = dblRemRate
        dr("Rate Type") = Left(Trim(ddlRateType.Text.ToString), 2)
        dr("Ex. Rate") = Me.txtExRate.Text
        dr("Deal No.") = Me.txtDeal.Text.ToString
        dr("Pay Cur.") = Me.ddlInqPayCur.Text.ToString
        dr("Pay Amount") = dblPayAmt
        dr("Adj. Amt") = dblAdjAmt
        dr("Tot Pay") = dblTotPay
        dr(" ") = Session("Channel")

        'sum Amount in datagrid
        If Session("dtAddInqRate") Is Nothing Then
            If CDbl(txtRemAmt.Text) > sumAmt Then
                lessAmt = Format(CDbl(CDbl(txtRemAmt.Text) - sumAmt), "###,###,###,###,##0.00")
            Else
                lessAmt = Format(CDbl(sumAmt - CDbl(txtRemAmt.Text)), "###,###,###,###,##0.00")
            End If
            sumAmt = CDbl(dblRemRate)

        Else

            For i = 0 To Session("dtAddInqRate").Rows.Count - 1
                sumAmt = sumAmt + CDbl(Trim(dtAddInqRate.Rows(i).Item(2)))
            Next
            Session("sumRemAmt") = sumAmt
            sumAmt = Format(sumAmt, "###,###,###,###,##0.00")
            netAmt = CDbl(sumAmt) - CDbl(dblRemRate)

            If CDbl(txtRemAmt.Text) > CDbl(sumAmt) Then
                lessAmt = Format(CDbl(txtRemAmt.Text) - CDbl(sumAmt), "###,###,###,###,##0.00")
            Else
                lessAmt = Format(CDbl(txtRemAmt.Text) - CDbl(netAmt), "###,###,###,###,##0.00")
            End If

            '** Tom **
            ''set Available Amount
            'lblRemAvl.Text = Format(CDbl(lblRemRate.Text) - sumAmt, "###,###,###,###,##0.00")
            'Session("RemAvl") = Format(CDbl(lblRemRate.Text) - sumAmt, "###,###,###,###,##0.00")
            '** Tom **
            lblRemRate.Text = Format(CDbl(sumAmt), "###,###,###,###,##0.00")

        End If

        If CDbl(sumAmt) > CDbl(txtRemAmt.Text) Then
            strMsg = "Amount is more than Remitting Amount !!!" & "\n" & "Please input amount less than or equal : " & lessAmt
            GoTo errMsg
            txtRemRate.Focus()
        Else

            'validate Rate Amount
            ValDataEntry("RATEAMT", strMsg)

            GridAddInqRate.DataSource = dtAddInqRate
            GridAddInqRate.DataBind()

        End If
        Session("UpdFlag") = False
        resetRate()
        GridAddInqRate.Enabled = True
        GridAddInqRate.SelectedRowStyle.Font.Bold = False
        pnlInqAddRate.Visible = True
        pnlInqUpdRate.Visible = False

        '2009-07-10 Tom :
        ddlRateType.Enabled = True
        ddlRateType.BackColor = Drawing.Color.LightCyan
        txtExRate.ReadOnly = False
        txtExRate.BackColor = Drawing.Color.LightCyan

        txtDeal.ReadOnly = False
        txtDeal.BackColor = Drawing.Color.White
        ddlInqPayCur.Enabled = True
        ddlInqPayCur.BackColor = Drawing.Color.LightCyan

        Session("AdjFlag") = False

        ' 210-11-11 Tom : Detail Sum Pay Amount
        If CDbl(lblRemRate.Text) = CDbl(txtRemAmt.Text) Then
            pnlSumRateInfo.Visible = True
            pnlPay.Enabled = True

            If (GridSumRate.Rows.Count = 1) And (Trim(dtSumRateInfo.Rows(0).Item(1)) = "") Then
                dtSumRateInfo.Rows(0).Delete()
                GridSumRate.DataSource = dtSumRateInfo
                GridSumRate.DataBind()
            End If

            For i = 0 To Session("dtAddInqRate").Rows.Count - 1

                sumPayAmt = 0
                sumRemAmt = 0

                strPayCur = Trim(dtAddInqRate.Rows(i).Item(6))

                For j = 0 To Session("dtAddInqRate").Rows.Count - 1

                    If (strPayCur = Trim(dtAddInqRate.Rows(j).Item(6))) Then
                        sumPayAmt = sumPayAmt + CDbl(Trim(dtAddInqRate.Rows(j).Item(9)))
                        sumRemAmt = sumRemAmt + CDbl(Trim(dtAddInqRate.Rows(j).Item(2)))
                    End If

                Next

                'strAccRate = Format(sumPayAmt / sumRemAmt, "###,##0.0000000")
                dblAccRate = sumPayAmt / sumRemAmt

                If Session("dtSumRateInfo") Is Nothing Then
                    dr = dtSumRateInfo.NewRow
                    dr("No.") = dtSumRateInfo.Rows.Count + 1
                    dr("Pay Cur.") = strPayCur
                    dr("Total Pay Amount") = Format(sumPayAmt, "###,###,###,###,##0.00")
                    dr("Acc Rate") = dblAccRate

                    dtSumRateInfo.Rows.Add(dr)
                    GridSumRate.DataSource = dtSumRateInfo
                    GridSumRate.DataBind()
                    Session("dtSumRateInfo") = dtSumRateInfo
                Else

                    For k = 0 To Session("dtSumRateInfo").Rows.Count - 1
                        If Trim(dtSumRateInfo.Rows(k).Item(1)) = strPayCur Then GoTo nexti
                    Next
                    dr = dtSumRateInfo.NewRow
                    dr("No.") = dtSumRateInfo.Rows.Count + 1
                    dr("Pay Cur.") = strPayCur
                    dr("Total Pay Amount") = Format(sumPayAmt, "###,###,###,###,##0.00")
                    dr("Acc Rate") = dblAccRate

                    dtSumRateInfo.Rows.Add(dr)
                    GridSumRate.DataSource = dtSumRateInfo
                    GridSumRate.DataBind()
                    Session("dtSumRateInfo") = dtSumRateInfo

                End If

nexti:
            Next
            i = 0
            ddlAcCurPay.Items.Clear()
            ddlAcCurPay.DataBind()

            ddlAcCurPay.Items.Add("")
            For i = 0 To Session("dtSumRateInfo").Rows.Count - 1
                strPayCurSql = Trim(dtSumRateInfo.Rows(i).Item(1))
                ddlAcCurPay.Items.Add(strPayCurSql)
                ddlAcCurPay.DataBind()
            Next

            If ddlAcCurPay.Items.Count = 2 Then
                ddlAcCurPay.SelectedIndex = 1
                Call loadAccNo()
            End If

        End If

        txtRemRate.Text = Format(CDbl(txtRemAmt.Text) - CDbl(lblRemRate.Text), "###,###,###,###,##0.00")
        '2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
        If CDbl(lessAmt) = 0 Then
            resetRate()
            pnlSumRateInfo.Visible = True
            pnlPay.Enabled = True
        End If
errMsg:

        ''2010-11-13 R53060089 Tom : Interface with Sierra (FX) 
        'If CDbl(lessAmt) = 0 Then
        '    resetRate()
        '    pnlSumRateInfo.Visible = True
        '    pnlPay.Enabled = True
        'End If

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub btnInqResAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInqResAdd.Click
        resetRate()
        ddlRateType.Enabled = True
        ddlRateType.BackColor = Drawing.Color.LightCyan
        txtExRate.ReadOnly = False
        txtExRate.BackColor = Drawing.Color.LightCyan

        txtDeal.ReadOnly = False
        txtDeal.BackColor = Drawing.Color.White
        ddlInqPayCur.Enabled = True
        ddlInqPayCur.BackColor = Drawing.Color.LightCyan
    End Sub

    Protected Sub btnInqResUpd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInqResUpd.Click
        resetRate()
        ddlRateType.Enabled = True
        ddlRateType.BackColor = Drawing.Color.LightCyan
        txtExRate.ReadOnly = False
        txtExRate.BackColor = Drawing.Color.LightCyan

        txtDeal.ReadOnly = False
        txtDeal.BackColor = Drawing.Color.White
        ddlInqPayCur.Enabled = True
        ddlInqPayCur.BackColor = Drawing.Color.LightCyan
    End Sub

    Protected Sub btnInqRateAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInqRateAdd.Click
        Session("dtInqRate") = Nothing
        Call InqRate()
    End Sub
    Private Sub InqRate()

        Dim dr As DataRow
        Dim i As Integer
        Dim strData As String, strSql As String
        Dim strRateRep As String, strRateTyp As String, strBuySell As String
        Dim strComfStat As String, strTranStat As String, strDealNo As String, strRemCur As String
        Dim strValDate As String, strDateType As String, strFlagInq As String, strResP As String
        Dim strarrDataRep() As String, strarrData() As String
        Dim myCommand As OdbcCommand = New OdbcCommand()
        Dim mqConn As New MQService
        Dim outResCode As String
        Dim strFXCustId As String

        strRateRep = ""
        strValDate = ""
        strFXCustId = ""
        strRemCur = ""

        gRqUId = "INQ" & Trim(txtSenId.Value) & Format(Now, "yymmdd") & Format(DateTime.Now, "hhmmss")

        ' Get detail from FORMCUST
        'strSql = "select fxcustid,remcur from db2.forwtran where forref = '" & Session("ForRef") & "'"
        strSql = "select sierraid from db2.formcust where forcustid = '" & Trim(txtSenId.Value) & "'"

        Dim ResultSetTrn As DataSet = connDB.RunQuerySql(strSql)
        If ResultSetTrn.Tables.Count > 0 Then
            Dim rowdetTrn As DataRow
            For Each rowdetTrn In ResultSetTrn.Tables(0).Rows
                strFXCustId = Trim(rowdetTrn.Item(0).ToString())
            Next
        End If

        strRateTyp = "A"
        strBuySell = "S"
        strComfStat = "A"

        strTranStat = "O"
        strDealNo = ""
        strRemCur = Trim(txtRemCur.Text)

        Session("strFXCustId") = strFXCustId

        strRateRep = strFXCustId & ":" & strRateTyp & ":" & _
                     strBuySell & ":" & strComfStat & ":" & strTranStat & ":" & _
                     strDealNo & ":" & strRemCur

        strFlagInq = "2"
        strDateType = "Settle"
        strValDate = PublicFunc.FormDate(Trim(txtValDate.Value))

        If mqConn.GetSeesion(AppName, gUserid, gSession) Then
            strResP = ""
            outResCode = ""

            strData = gRqUId & Chr(9) & strFlagInq & Chr(9) & strRateRep & Chr(9) & strDateType & Chr(9) & strValDate & Chr(9) & Session("strUserID") & Chr(9) & gUserid & Chr(9) & gSession

            If Not mqConn.InqFXRAte("FOR", strData, strResP, strMsg, outResCode) Then
                'strMsg = ""
                If outResCode = "1002" Then

                    If mqConn.processSignOnMQ() Then
                        strMsg = ""
                        mqConn.GetSeesion(AppName, gUserid, gSession)
                        strData = gRqUId & Chr(9) & strFlagInq & Chr(9) & strRateRep & Chr(9) & strDateType & Chr(9) & strValDate & Chr(9) & Session("strUserID") & Chr(9) & gUserid & Chr(9) & gSession

                        If Not mqConn.InqFXRAte("FOR", strData, strResP, strMsg, outResCode) Then GoTo exitHandle


                    End If

                End If
            End If

            If Trim(strResP) = "" Then
                'strMsg = "Error!!! Inquiry Rate failed"
                GoTo exitHandle
            End If


            strarrDataRep = Split(strResP, Chr(9))

            'Repeat Rate
            For i = 0 To strarrDataRep.Length - 1
                strarrData = Split(strarrDataRep(i), ":")

                If Trim(strarrData(0)) <> "0001" Then

                    strMsg = "Refference : " & Session("ForRef") & "\n" & "Inquiry Rate failed.!!!" & strarrData(4)

                    GoTo exitHandle

                ElseIf Trim(strarrData(3)) <> "001" Then

                    strMsg = "Refference : " & Session("ForRef") & "\n" & "Inquiry Rate failed.!!!" & strarrData(4)

                    GoTo exitHandle
                Else
                    If gRqUId = Trim(strarrData(5)) Then
                        'If (GridInqRate.Rows.Count = 0) Then

                        ' 2009-08-06 Tom :
                        If (Session("dtInqRate") Is Nothing) Or (GridInqRate.Rows.Count < 0) Then
                            'create GridInqRate
                            dtInqRate.Columns.Add(New DataColumn("Rem Cur.", GetType(System.String)))
                            dtInqRate.Columns.Add(New DataColumn("Rem Amount", GetType(System.Double)))
                            dtInqRate.Columns.Add(New DataColumn("Rate Type", GetType(System.String)))
                            dtInqRate.Columns.Add(New DataColumn("Ex.Rate", GetType(System.Double)))
                            dtInqRate.Columns.Add(New DataColumn("Original No.", GetType(System.String)))
                            dtInqRate.Columns.Add(New DataColumn("Deal No.", GetType(System.String)))
                            dtInqRate.Columns.Add(New DataColumn("Pay Cur.", GetType(System.String)))
                            dtInqRate.Columns.Add(New DataColumn("Pay Amount", GetType(System.String)))
                        End If

                        dr = dtInqRate.NewRow
                        dr("Rem Cur.") = strarrData(9)
                        dr("Rem Amount") = strarrData(10)
                        dr("Rate Type") = strarrData(6)
                        dr("Ex.Rate") = strarrData(11)
                        dr("Original No.") = strarrData(7)
                        dr("Deal No.") = strarrData(8)
                        dr("Pay Cur.") = strarrData(12)
                        dr("Pay Amount") = strarrData(13)
                        dtInqRate.Rows.Add(dr)

                        GridInqRate.DataSource = dtInqRate
                        GridInqRate.DataBind()

                        Session("dtInqRate") = dtInqRate

                    End If
                End If

            Next i
            '2009-05-20 R51120036 Tom :
            pnlGridInq.Visible = True

        End If

exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub GridInqRate_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridInqRate.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then

            ' Rem Cur.
            e.Row.Cells(1).Text = e.Row.Cells(1).Text
            ' Rem Amount
            e.Row.Cells(2).Text = Format(CDbl(e.Row.Cells(2).Text), "###,###,###,###,##0.00")
            e.Row.Cells(2).HorizontalAlign = HorizontalAlign.Right
            ' Rate Type
            e.Row.Cells(3).Text = e.Row.Cells(3).Text
            ' Ex.Rate
            e.Row.Cells(4).Text = Format(CDbl(e.Row.Cells(4).Text), "##,##0.0000000")
            e.Row.Cells(4).HorizontalAlign = HorizontalAlign.Right
            ' Original No.
            e.Row.Cells(5).Text = e.Row.Cells(5).Text
            ' Deal No.
            e.Row.Cells(6).Text = e.Row.Cells(6).Text
            ' Pay Cur.
            e.Row.Cells(7).Text = e.Row.Cells(7).Text
            ' Pay Amount
            e.Row.Cells(8).Text = Format(CDbl(e.Row.Cells(8).Text), "###,###,###,###,##0.00")
            e.Row.Cells(8).HorizontalAlign = HorizontalAlign.Right

        End If
    End Sub
    Protected Sub GridInqRate_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridInqRate.SelectedIndexChanging
        Dim index As Integer = e.NewSelectedIndex.ToString
        Dim row As GridViewRow = GridInqRate.Rows(index)
        Dim strRateType As String, strPayCur As String
        Dim i As Integer
        Dim PayFlag As Boolean

        resetRate()

        GridInqRate.DataSource = Session("dtInqRate")
        GridInqRate.DataBind()

        If (CDbl(row.Cells(2).Text) = 0) Then
            strMsg = "Can not select this transaction."
            GoTo exitHandle
        End If

        ' Rem Cur.
        txtRemCur.Text = Trim(row.Cells(1).Text)

        ' Rem Amt
        Session("InqRemAmt") = CDbl(txtRemAmt.Text) - CDbl(lblRemRate.Text)
        If CDbl(Trim(row.Cells(2).Text)) < CDbl(Session("InqRemAmt")) Then
            txtRemRate.Text = Format(CDbl(Trim(row.Cells(2).Text)), "###,###,###,###,##0.00")
        Else
            txtRemRate.Text = Format(CDbl(Session("InqRemAmt")), "###,###,###,###,##0.00")
        End If


        If (Session("dtAddInqRate") Is Nothing) Then
        Else
            dtAddInqRate = Session("dtAddInqRate")
            For i = 0 To Session("dtAddInqRate").Rows.Count - 1

                If (Trim(dtAddInqRate.Rows(i).Item(1)) = Trim(row.Cells(1).Text)) And (Trim(dtAddInqRate.Rows(i).Item(3)) = Trim(row.Cells(3).Text)) _
                   And (Trim(dtAddInqRate.Rows(i).Item(5)) = Trim(row.Cells(6).Text)) Then

                    GoTo exitHandle

                End If
            Next

        End If

        ' Pay Cur
        PayFlag = False
        For i = 0 To ddlInqPayCur.Items.Count - 1
            If Trim(ddlInqPayCur.Items(i).Text) = Trim(row.Cells(7).Text) Then
                PayFlag = True
                ddlInqPayCur.SelectedIndex = i
                Exit For
            End If
        Next
        If PayFlag = False Then
            strMsg = "Pay Cur. mismatch !!!"
            GoTo exitHandle
        End If


        ' Rate Type
        strRateType = Trim(row.Cells(3).Text)

        For i = 0 To ddlRateType.Items.Count - 1
            If Left(ddlRateType.Items(i).Text, 2) = strRateType Then
                ddlRateType.SelectedIndex = i
                Exit For
            End If
        Next

        ' Ex.Rate
        txtExRate.Text = Format(CDbl(row.Cells(4).Text), "##,##0.0000000")
        Session("calRate") = CDbl(txtExRate.Text)
        ' Deal No.
        txtDeal.Text = Trim(row.Cells(6).Text)
        ' Pay Cur.
        strPayCur = Trim(row.Cells(7).Text)
        ' Pay Amount
        txtPayAmt.Text = Format((CDbl(txtRemRate.Text) * CDbl(txtExRate.Text)), "###,###,###,###,##0.00")

        'set enabled
        ddlRateType.Enabled = False
        txtExRate.ReadOnly = True
        txtDeal.ReadOnly = True
        ddlInqPayCur.Enabled = False

exitHandle:
        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub txtRemRate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRemRate.TextChanged
        If GridInqRate.Visible = True Then
            'validate Inquiry Rem Amt. 
            If ddlInqPayCur.Enabled = False Then
                If CDbl(txtRemRate.Text) > CDbl(Session("InqRemAmt")) Then
                    strMsg = "This Remitting Amount is over !!!"
                    txtRemRate.Focus()
                    GoTo errMsg
                End If
            End If
        End If

        'Validate Remitting Amount is numeric
        If PublicFunc.ValidateNum(txtRemRate.Text) = False Then
            strMsg = "Invalid Format !!! "
            txtRemRate.Focus()
            GoTo errMsg
        End If

        If CDbl(txtRemRate.Text) = 0 Then
            strMsg = "Please input amount !!! "
            txtRemRate.Focus()
            GoTo errMsg
        End If

        txtRemRate.Text = Format(CDbl(txtRemRate.Text), "###,###,###,###,##0.00")

        Session("calRate") = CDbl(txtExRate.Text)
        Session("btnCalPayAmt") = True

        ' validate Rate Amount
        If Not ValDataEntry("RATEAMT", strMsg) Then Exit Sub
        Call calPayAmt()

        'Session("TotAmt") = txtPayAmt.Text

        ''set enabled
        If ddlInqPayCur.Enabled = False Then
            ddlRateType.Enabled = False
            txtExRate.ReadOnly = True
            txtDeal.ReadOnly = True
            ddlInqPayCur.Enabled = False
        End If

errMsg:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub btnAdjPlus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdjPlus.Click
        'Session("AdjFlag") = True

        If btnAdjPlus.BackColor = Drawing.Color.Gold Then
            btnAdjPlus.BackColor = Drawing.Color.LightGray
            Session("AdjFlag") = False
        Else
            btnAdjPlus.BackColor = Drawing.Color.Gold
            Session("AdjFlag") = True
        End If
        btnAdjMinus.BackColor = Drawing.Color.LightGray

        txtAdjAmt.Focus()
    End Sub

    Protected Sub btnAdjMinus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdjMinus.Click

        'Session("AdjFlag") = True

        If btnAdjMinus.BackColor = Drawing.Color.Gold Then
            btnAdjMinus.BackColor = Drawing.Color.LightGray
            Session("AdjFlag") = False
        Else
            btnAdjMinus.BackColor = Drawing.Color.Gold
            Session("AdjFlag") = True
        End If
        btnAdjPlus.BackColor = Drawing.Color.LightGray

        txtAdjAmt.Focus()

    End Sub

    Protected Sub txtExRate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtExRate.TextChanged

        'Validate Exch rate is numeric
        If PublicFunc.ValidateNum(txtExRate.Text) = False Then
            strMsg = "Invalid Format !!! "
            txtExRate.Focus()
            GoTo errMsg
        End If

        If CDbl(txtExRate.Text) = 0 Then
            strMsg = "Please input exchange rate !!! "
            txtExRate.Focus()
            GoTo errMsg
        End If

        Session("calRate") = CDbl(txtExRate.Text)
        Session("btnCalPayAmt") = True
        ' validate Rate Amount
        If Not ValDataEntry("RATEAMT", strMsg) Then Exit Sub
        'If CDbl(txtPayAmt.Text) <> 0 Then

        Call calPayAmt()
        'End If
        'Session("TotAmt") = txtPayAmt.Text
errMsg:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub GridSumRate_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridSumRate.RowCreated
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(3).CssClass = "hiddencol"
        ElseIf e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(3).CssClass = "hiddencol"
        End If
    End Sub

    Protected Sub GridSumRate_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridSumRate.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            ' No.
            e.Row.Cells(0).Text = e.Row.RowIndex + 1
            ' Rem Cur.
            e.Row.Cells(1).Text = e.Row.Cells(1).Text
            ' Rem Amount
            e.Row.Cells(2).Text = Format(CDbl(e.Row.Cells(2).Text), "###,###,###,###,##0.00")
            e.Row.Cells(2).HorizontalAlign = HorizontalAlign.Right

        End If
    End Sub

    Protected Sub ddlAcCurPay_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAcCurPay.SelectedIndexChanged

        Call loadAccNo()

    End Sub

    Protected Sub txtPayAmnt_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPayAmnt.TextChanged

        Dim i As Integer
        Dim calRemAmt As Double

        calRemAmt = 0

        ' Validate data
        If Not PublicFunc.ValidateNum(txtPayAmnt.Text) Then
            strMsg = "Pay Amount is incorrect.!!!"
            txtPayAmnt.Focus()
            GoTo errMsg
        End If

        ' Get Rate
        For i = 0 To Session("dtSumRateInfo").Rows.Count - 1
            If Trim(ddlAcCurPay.Text) = Trim(dtSumRateInfo.Rows(i).Item(1)) Then
                calRemAmt = CDbl(txtPayAmnt.Text) / CDbl(Trim(dtSumRateInfo.Rows(i).Item(3)))
                Exit For
            End If
        Next

        txtPayAmnt.Text = Format(CDbl(txtPayAmnt.Text), "###,###,###,###,##0.00")
        txtRemAmnt.Text = Format(calRemAmt, "###,###,###,###,##0.00")

errMsg:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    '2010-11-19 R53060089 Tom : Interface with Sierra (FX) 
    Private Sub EarMark()

        Dim mqConn As New MQService
        Dim strData As String, strSql As String
        Dim strRateRep As String, strChanRef As String
        Dim strBenBank As String, strRateType As String
        Dim strValDate As String, strResP As String, strChanFg As String
        Dim strRemCur As String, strDealNo As String, strAcCur As String
        Dim strRemAmt As String, strAcAmt As String, strStatusFg As String
        Dim outResCode As String
        Dim myCommand As OdbcCommand = New OdbcCommand()
        Dim i As Integer, strSentDeal As Integer
        Dim j As Integer, cnt As Integer
        Dim sumamt As Double

        strRateRep = ""
        strValDate = ""
        strChanRef = ""
        strBenBank = ""
        strRemCur = ""
        strRemAmt = ""
        strSentDeal = 0
        cnt = 0
        sumamt = 0

        gRqUId = "INQ" & Session("ForRef") & Format(Now, "yymmdd") & Format(DateTime.Now, "hhmmss")

        ' Get detail from FORWTRAN
        strSql = "select chanref, benbank, valdate from db2.forwtran where forref = '" & Session("ForRef") & "'"
        Dim ResultSetTrn As DataSet = connDB.RunQuerySql(strSql)
        If ResultSetTrn.Tables.Count > 0 Then
            Dim rowdetTrn As DataRow
            For Each rowdetTrn In ResultSetTrn.Tables(0).Rows
                strChanRef = Trim(rowdetTrn.Item(0).ToString())
                strBenBank = Trim(rowdetTrn.Item(1).ToString())
                strValDate = PublicFunc.FormDate(rowdetTrn.Item(2).ToString())

            Next
        End If

        ' Get detail from GridAddInqRate
        cnt = Session("dtAddInqRate").Rows.Count

        Dim arrRemCur(cnt) As String, arrDealNo(cnt) As String, arrAcCur(cnt) As String
        Dim arrRemAmt(cnt) As Double, arrAcAmt(cnt) As Double

        Dim blnFound As Boolean, intRow As Integer
        intRow = 0

        For i = 0 To Session("dtAddInqRate").Rows.Count - 1


            strRemCur = Trim(Session("dtAddInqRate").Rows(i).Item(1)).ToUpper
            strRemAmt = Format(CDbl(Trim(Session("dtAddInqRate").Rows(i).Item(2))), "##0.0000000")
            strRateType = Trim(Session("dtAddInqRate").Rows(i).Item(3).ToString)
            strDealNo = Trim(Session("dtAddInqRate").Rows(i).Item(5).ToString)
            strAcCur = Trim(Session("dtAddInqRate").Rows(i).Item(6)).ToUpper
            '2010-12-01 R53060089 Tom : Change Tot Pay to Pay Amt  
            'strAcAmt = Format(CDbl(Trim(Session("dtAddInqRate").Rows(i).Item(9))), "##0.0000000")
            strAcAmt = Format(CDbl(Trim(Session("dtAddInqRate").Rows(i).Item(7))), "##0.0000000")
            strChanFg = Trim(Session("dtAddInqRate").Rows(i).Item(10).ToString)

            blnFound = False
            For j = 0 To Session("dtAddInqRate").Rows.Count - 1
                If (Trim(arrRemCur(j)) = strRemCur) And _
                   (Trim(arrDealNo(j)) = strDealNo) And _
                   (Trim(arrAcCur(j)) = strAcCur) Then

                    If ((strRateType = "FW") Or (strRateType = "SP") Or (strRateType = "SO")) And _
                       (strDealNo <> "") Then

                        blnFound = True
                        arrRemAmt(j) = CDbl(strRemAmt) + arrRemAmt(j)
                        arrAcAmt(j) = CDbl(strAcAmt) + arrAcAmt(j)
                        Exit For

                    End If


                End If

            Next

            If Not blnFound Then
                If ((strRateType = "FW") Or (strRateType = "SP") Or (strRateType = "SO")) And _
                    (strDealNo <> "") Then

                    arrRemCur(intRow) = strRemCur
                    arrDealNo(intRow) = strDealNo
                    arrAcCur(intRow) = strAcCur
                    arrRemAmt(intRow) = CDbl(strRemAmt)
                    arrAcAmt(intRow) = CDbl(strAcAmt)

                    intRow = intRow + 1
                End If
            End If

        Next

        For i = 0 To intRow - 1
            strSentDeal = strSentDeal + 1

            strAcAmt = Format(arrAcAmt(i), "##0.0000000")
            strRemAmt = Format(arrRemAmt(i), "##0.0000000")

            If strRateRep <> "" Then
                strRateRep = strRateRep & "|" & arrDealNo(i) & ":" & strBenBank & ":" & _
                             strValDate & ":" & arrAcCur(i) & ":" & strAcAmt & ":" & _
                             arrRemCur(i) & ":" & strRemAmt

            Else
                strRateRep = arrDealNo(i) & ":" & strBenBank & ":" & _
                             strValDate & ":" & arrAcCur(i) & ":" & strAcAmt & ":" & _
                             arrRemCur(i) & ":" & strRemAmt

            End If
        Next

        ' Group data for send to FX
        If strRateRep <> "" Then

            If mqConn.GetSeesion(AppName, gUserid, gSession) Then
                strStatusFg = "E"

                strData = Session("strUserID") & Chr(9) & gRqUId & Chr(9) & Session("ForRef") & Chr(9) & strStatusFg & Chr(9) & _
                          strSentDeal & Chr(9) & strRateRep & Chr(9) & gUserid & Chr(9) & gSession

                strResP = ""
                outResCode = ""

                If Not mqConn.EarMarkFX("FOR", strData, strResP, strMsg, outResCode) Then

                    If outResCode = "1002" Then

                        If mqConn.processSignOnMQ() Then
                            mqConn.GetSeesion(AppName, gUserid, gSession)
                            strData = Session("strUserID") & Chr(9) & gRqUId & Chr(9) & strChanRef & Chr(9) & strStatusFg & Chr(9) & _
                                      strSentDeal & Chr(9) & strRateRep & Chr(9) & gUserid & Chr(9) & gSession
                            mqConn.EarMarkFX("FOR", strData, strResP, strMsg, outResCode)
                        End If

                    End If

                    Exit Sub
                End If
            End If

        End If

exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    '2012-11-06 R55040057 Tom : Support new organize
    Private Sub getInfoAmend()
        Dim i As Integer
        Dim strSql As String
        Dim rowAmend As DataRow, rowNote As DataRow
        Dim strItscCd As String, strRemCur As String
        Dim strPreAdv As String, strComCd As String
        Dim strCtryCd As String, chkstrValDate As String
        Dim chkvalDate As Date, strValDate As DateTime


        Try
            '2013-10-14 :: Kwang :: R56070118 :: select new field(TRNO)
            'strSql = "SELECT A.ITSCNO, A.SENID, A.SENNAME1, A.SENNAME2, A.SENADDR1, A.SENADDR2, A.REMCUR, A.REMAMT, " & _
            '         " A.VALDATE, A.PROCSTEP, A.RECAC, A.BKTOTR, A.DETCHAR, B.INSTRUCTION, A.COMCODE, A.CTRYCODE " & _
            '         " FROM  DB2.FORWTRAN A , DB2.FORMCUST B  WHERE A.FORREF = '" & Session("ForRef") & "' " & _
            '         " AND A.SENID = B.FORCUSTID  "

            'strSql = "SELECT A.ITSCNO, A.SENID, A.SENNAME1, A.SENNAME2, A.SENADDR1, A.SENADDR2, A.REMCUR, A.REMAMT, " & _
            '         " A.VALDATE, A.PROCSTEP, A.RECAC, A.BKTOTR, A.DETCHAR, B.INSTRUCTION, A.COMCODE, A.CTRYCODE, A.TRNO " & _
            '         " FROM  DB2.FORWTRAN A , DB2.FORMCUST B  WHERE A.FORREF = '" & Session("ForRef") & "' " & _
            '         " AND A.SENID = B.FORCUSTID  "

            'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENEMAIL
            strSql = "SELECT A.ITSCNO, A.SENID, A.SENNAME1, A.SENNAME2, A.SENADDR1, A.SENADDR2, A.REMCUR, A.REMAMT, " & _
                     " A.VALDATE, A.PROCSTEP, A.RECAC, A.BKTOTR, A.DETCHAR, B.INSTRUCTION, A.COMCODE, A.CTRYCODE, A.TRNO, A.BENEMAIL " & _
                     " FROM  DB2.FORWTRAN A , DB2.FORMCUST B  WHERE A.FORREF = '" & Session("ForRef") & "' " & _
                     " AND A.SENID = B.FORCUSTID  "
            Dim ResultAmend As DataSet = connDB.RunQuerySql(strSql)
            If ResultAmend.Tables.Count > 0 Then

                For Each rowAmend In ResultAmend.Tables(0).Rows

                    strItscCd = Trim(rowAmend.Item(0).ToString())
                    txtSenId.Value = Trim(rowAmend.Item(1).ToString())
                    txtSenName1.Text = Trim(rowAmend.Item(2).ToString())
                    txtSenName2.Text = Trim(rowAmend.Item(3).ToString())
                    txtSenAddr1.Text = Trim(rowAmend.Item(4).ToString())
                    txtSenAddr2.Text = Trim(rowAmend.Item(5).ToString())

                    strRemCur = Trim(rowAmend.Item(6).ToString())
                    For i = 0 To ddlRemCur.Items.Count - 1
                        If Trim(ddlRemCur.Items(i).Text) = Trim(strRemCur) Then
                            ddlRemCur.SelectedIndex = i
                            Exit For
                        End If
                    Next

                    'txtRemAmt.Text = PublicFunc.convertFormatVar(Trim(rowAmend.Item(7)), "AMT")
                    txtRemAmt.Text = Format(CDbl(Trim(rowAmend.Item(7))), "#,##0.00")
                    strValDate = Trim(rowAmend.Item(8).ToString())
                    txtValDate.Value = strValDate.ToString("dd/MM/yyyy")

                    ' Pre-Advice
                    strPreAdv = Trim(rowAmend.Item(9).ToString())
                    If strPreAdv = "F" Then
                        rbPreAdv.Items(1).Selected = True
                    Else
                        rbPreAdv.Items(0).Selected = True
                    End If

                    rbPreAdv.Enabled = True
                    chkvalDate = Trim(txtValDate.Value)
                    chkstrValDate = Format(chkvalDate, "yyyy-MM-dd")
                    'If chkstrValDate < Format(Now, "yyyy-MM-dd") Then 'PIK
                    If chkstrValDate <= Format(Now, "yyyy-MM-dd") Then
                        rbPreAdv.Enabled = False
                    End If

                    txtRecAcc.Value = Trim(rowAmend.Item(10).ToString())

                    ' Book to TR
                    chkBkToTr.Checked = False
                    If Trim(rowAmend.Item(11).ToString()) = "Y" Then
                        chkBkToTr.Checked = True
                        txtTRdeal.Enabled = True
                        txtTRdeal.Text = Trim(rowAmend.Item(16).ToString()) '2013-10-14 :: Kwang :: R56070118 :: select new field(TRNO)
                    Else '2013-10-14 :: Kwang :: R56070118 :: select new field(TRNO)
                        txtTRdeal.Enabled = False
                        txtTRdeal.Text = ""
                    End If
                    'Pay in full
                    chkPayFull.Checked = False
                    If Trim(rowAmend.Item(12).ToString()) = "OUR" Then
                        chkPayFull.Checked = True
                    End If
                    txtSpecInst.Value = Trim(rowAmend.Item(13).ToString())
                    ' Commodity Code
                    strComCd = Trim(rowAmend.Item(14).ToString())
                    For i = 0 To ddlComCd.Items.Count - 1
                        If Left(Trim(ddlComCd.Items(i).Text), 2) = Trim(strComCd) Then
                            ddlComCd.SelectedIndex = i
                            Exit For
                        End If
                    Next
                    ' Country Code
                    strCtryCd = Trim(rowAmend.Item(15).ToString())
                    For i = 0 To ddlCtryCd.Items.Count - 1
                        If Left(Trim(ddlCtryCd.Items(i).Text), 2) = Trim(strCtryCd) Then
                            ddlCtryCd.SelectedIndex = i
                            Exit For
                        End If
                    Next
                Next

                txtBenMail.Value = Trim(rowAmend.Item(17).ToString()) 'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add BENEMAIL

                '### FORONOTE ###

                strSql = "SELECT REMARK, ENTDATE, ENTTIME FROM DB2.FORONOTE " & _
                         " WHERE FORREF = '" & Session("ForRef") & "'" & _
                         " ORDER BY ENTDATE, ENTTIME DESC "

                Dim ResultNote As DataSet = connDB.RunQuerySql(strSql)
                If ResultNote.Tables.Count > 0 Then
                    For Each rowNote In ResultNote.Tables(0).Rows
                        txtRemark.Value = Trim(rowNote.Item(0).ToString())
                        Exit For
                    Next
                End If

                Call AddCurRate(ddlInqPayCur)

                lblCur.Text = Trim(ddlRemCur.Text)
                txtRemCur.Text = Trim(ddlRemCur.Text)

                lblCurPay.Text = Trim(ddlRemCur.Text)
                txtCur.Text = Trim(ddlRemCur.Text)

            End If

            If (Trim(txtSenName1.Text) <> "") And (Trim(ddlRemCur.Text) <> "") Then
                pnlRate.Enabled = True
                btnInqRateAdd.Enabled = True
            Else
                pnlPay.Enabled = False
                pnlRate.Enabled = False
                btnInqRateAdd.Enabled = False
            End If

        Catch odbce As OdbcException
            If Session("Page") = "Receive" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Receive")
            End If
        Catch ex As Exception
            If Session("Page") = "Receive" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Receive")
            End If
        End Try

    End Sub
    '2012-11-28 R55040057 Tom : Support new organize
    Private Sub getRateAmend()
        Dim dr As DataRow
        Dim strSql As String
        Dim dtInqRateRow As DataRow
        Dim strRemCur As String
        Dim sumRemAmt As Double
        Dim dblTotPay As String, dblAdjAmt As String, dblPayAmt As String

        strRemCur = ""
        sumRemAmt = 0

        Try

            If Session("dtAddInqRate") Is Nothing Then
                strSql = "select  remcur,COALESCE(remamt,0), COALESCE(remrate,0), ratetype, dealno, drcur, COALESCE(dramt,0), COALESCE(adjpayamt,0) " & _
                         "from db2.forwrate where forref =  '" & Session("ForRef") & "' "
                Dim TrnRate As DataSet = connDB.RunQuerySql(strSql)
                If TrnRate.Tables(0).Rows.Count > 0 Then

                    dtAddInqRate.Columns.Add(New DataColumn("No.", GetType(System.String)))
                    dtAddInqRate.Columns.Add(New DataColumn("Rem Cur.", GetType(System.String)))
                    dtAddInqRate.Columns.Add(New DataColumn("Rem Amount", GetType(System.Double)))
                    dtAddInqRate.Columns.Add(New DataColumn("Rate Type", GetType(System.String)))
                    dtAddInqRate.Columns.Add(New DataColumn("Ex. Rate", GetType(System.Double)))
                    dtAddInqRate.Columns.Add(New DataColumn("Deal No.", GetType(System.String)))
                    dtAddInqRate.Columns.Add(New DataColumn("Pay Cur.", GetType(System.String)))
                    dtAddInqRate.Columns.Add(New DataColumn("Pay Amount", GetType(System.Double)))
                    dtAddInqRate.Columns.Add(New DataColumn("Adj. Amt", GetType(System.Double)))
                    dtAddInqRate.Columns.Add(New DataColumn("Tot Pay", GetType(System.Double)))
                    dtAddInqRate.Columns.Add(New DataColumn(" ", GetType(System.String)))

                    For Each dtInqRateRow In TrnRate.Tables(0).Rows

                        dr = dtAddInqRate.NewRow
                        dr("No.") = dtAddInqRate.Rows.Count + 1
                        dr("Rem Cur.") = dtInqRateRow.Item(0)
                        dr("Rem Amount") = dtInqRateRow.Item(1)
                        dr("Rate Type") = dtInqRateRow.Item(3)
                        dr("Ex. Rate") = dtInqRateRow.Item(2)
                        dr("Deal No.") = dtInqRateRow.Item(4)
                        dr("Pay Cur.") = dtInqRateRow.Item(5)
                        dblTotPay = Format(CDbl(dtInqRateRow.Item(6)), "###,###,###,###,##0.00")
                        dblAdjAmt = Format(CDbl(dtInqRateRow.Item(7)), "###,###,###,###,##0.00")
                        dblPayAmt = Format(CDbl(dblTotPay) - CDbl(dblAdjAmt), "###,###,###,###,##0.00")
                        dr("Pay Amount") = dblPayAmt
                        dr("Adj. Amt") = dblAdjAmt
                        dr("Tot Pay") = dblTotPay
                        dr(" ") = "N"

                        sumRemAmt = sumRemAmt + CDbl(dtInqRateRow.Item(1))
                        Session("sumRemAmt") = sumRemAmt

                        dtAddInqRate.Rows.Add(dr)
                        GridAddInqRate.DataSource = dtAddInqRate
                        GridAddInqRate.DataBind()
                    Next
                    Session("dtAddInqRate") = dtAddInqRate

                    pnlRate.Enabled = True
                    btnInqRateAdd.Enabled = True


                End If

            Else
                GridAddInqRate.DataSource = Session("dtAddInqRate")
                GridAddInqRate.DataBind()
            End If


            lblRemRate.Text = Format(sumRemAmt, "###,###,###,###,##0.00")

        Catch odbce As OdbcException
            If Session("Page") = "Receive" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Receive")
            ElseIf Session("Page") = "Cancel" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Cancel")

            End If
        Catch ex As Exception
            If Session("Page") = "Receive" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Receive")
            ElseIf Session("Page") = "Cancel" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Cancel")
            End If
        End Try

exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
    End Sub
    '2012-11-28 R55040057 Tom : Support new organize
    Private Sub getPayAmend()
        Dim i As Integer
        Dim dr As DataRow
        Dim strSql As String
        Dim dtInqPayRow As DataRow
        Dim strPayCurSql As String

        Try
            If (Session("dtPayment") Is Nothing) Then
                strSql = "select forref, serialno, drfor, remcur, COALESCE(remamt,0), senac, actype, actype, accur, COALESCE(acamt,0)" & _
                            "  from db2.forwdrac where forref = '" & Session("ForRef") & "' "
                Dim TrnPay As DataSet = connDB.RunQuerySql(strSql)
                If TrnPay.Tables(0).Rows.Count > 0 Then
                    dtPayment.Columns.Add(New DataColumn("No.", GetType(System.String)))
                    dtPayment.Columns.Add(New DataColumn("A/C Cur.", GetType(System.String)))
                    dtPayment.Columns.Add(New DataColumn("A/C No.", GetType(System.String)))
                    dtPayment.Columns.Add(New DataColumn("Pay Amount", GetType(System.Double)))
                    dtPayment.Columns.Add(New DataColumn("Rem Cur.", GetType(System.String)))
                    dtPayment.Columns.Add(New DataColumn("Rem Amount", GetType(System.Double)))

                    'Detail Sum Pay Amount
                    dtSumRateInfo.Columns.Add(New DataColumn("No.", GetType(System.String)))
                    dtSumRateInfo.Columns.Add(New DataColumn("Pay Cur.", GetType(System.String)))
                    dtSumRateInfo.Columns.Add(New DataColumn("Total Pay Amount", GetType(System.Double)))
                    dtSumRateInfo.Columns.Add(New DataColumn("Acc Rate", GetType(System.Double)))

                    For Each dtInqPayRow In TrnPay.Tables(0).Rows
                        'GridAddPay
                        dr = dtPayment.NewRow
                        dr("No.") = dtPayment.Rows.Count + 1
                        dr("A/C Cur.") = dtInqPayRow.Item(8)
                        dr("A/C No.") = dtInqPayRow.Item(5)
                        dr("Pay Amount") = dtInqPayRow.Item(9)
                        dr("Rem Cur.") = dtInqPayRow.Item(3)
                        dr("Rem Amount") = dtInqPayRow.Item(4)
                        dtPayment.Rows.Add(dr)

                        GridAddPay.DataSource = dtPayment
                        GridAddPay.DataBind()

                        'Detail Sum Pay Amount - GridSumRate
                        If Session("dtSumRateInfo") Is Nothing Then
                            dr = dtSumRateInfo.NewRow
                            dr("No.") = dtSumRateInfo.Rows.Count + 1
                            dr("Pay Cur.") = dtInqPayRow.Item(8)
                            dr("Total Pay Amount") = dtInqPayRow.Item(9)
                            dr("Acc Rate") = CDbl(dtInqPayRow.Item(9)) / CDbl(dtInqPayRow.Item(4))
                            dtSumRateInfo.Rows.Add(dr)

                            GridSumRate.DataSource = dtSumRateInfo
                            GridSumRate.DataBind()

                        Else
                            Session("dtSumRateInfo") = dtSumRateInfo
                        End If

                    Next
                    Session("dtPayment") = dtPayment
                    Session("dtSumRateInfo") = dtSumRateInfo

                    pnlSumRateInfo.Visible = True
                    pnlPay.Enabled = True

                    ddlAcCurPay.Items.Clear()
                    ddlAcCurPay.DataBind()
                    ddlAcCurPay.Items.Add("")
                    For i = 0 To Session("dtSumRateInfo").Rows.Count - 1
                        strPayCurSql = Trim(dtSumRateInfo.Rows(i).Item(1))
                        ddlAcCurPay.Items.Add(strPayCurSql)
                        ddlAcCurPay.DataBind()
                    Next

                    If ddlAcCurPay.Items.Count = 2 Then
                        ddlAcCurPay.SelectedIndex = 1
                        Call loadAccNo()
                    End If


                Else
                    ' Payment Info - GridAddPay
                    dtPayment.Clear()
                    dr = dtPayment.NewRow
                    dr("No.") = dtPayment.Rows.Count + 1
                    dr("A/C Cur.") = ""
                    dr("A/C No.") = ""
                    dr("Pay Amount") = 0.0
                    dr("Rem Cur.") = ""
                    dr("Rem Amount") = 0.0
                    dtPayment.Rows.Add(dr)
                    GridAddPay.DataSource = dtPayment
                    GridAddPay.DataBind()
                    Session("dtPayment") = dtPayment
                    GridAddPay.Enabled = False

                    'Detail Sum Pay Amount - GridSumRate
                    dtSumRateInfo.Clear()
                    dr = dtSumRateInfo.NewRow
                    dr("No.") = dtSumRateInfo.Rows.Count + 1
                    dr("Pay Cur.") = ""
                    dr("Total Pay Amount") = 0.0
                    dr("Acc Rate") = 0.0
                    dtSumRateInfo.Rows.Add(dr)
                    GridSumRate.DataSource = dtSumRateInfo
                    GridSumRate.DataBind()
                    Session("dtSumRateInfo") = dtSumRateInfo
                    pnlSumRateInfo.Visible = False

                End If

            Else
                GridAddPay.DataSource = Session("dtPayment")
                GridAddPay.DataBind()
            End If

            lblRemPay.Text = Format(Session("sumRemAmt"), "###,###,###,###,##0.00")

        Catch odbce As OdbcException
            If Session("Page") = "Receive" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Receive")
            ElseIf Session("Page") = "Cancel" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Cancel")

            End If
        Catch ex As Exception
            If Session("Page") = "Receive" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Receive")
            ElseIf Session("Page") = "Cancel" Then
                Response.Redirect("~/DisplayMsg.aspx?type=Load page failed.!!!&page=Cancel")
            End If
        End Try

exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
    End Sub
    '2012-12-22 R55040057 Tom : Support new organize
    Private Function valStatus(ByVal instrRef As String, ByRef strErrMsg As String) As Boolean
        Dim strSql As String
        Dim dtStatusRow As DataRow
        Dim strStatus As String

        strStatus = ""
        strErrMsg = ""
        valStatus = True

        ' Validate transaction receiving by back office
        strSql = "select procstat from db2.forwtran where forref = '" & instrRef & "'"
        Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
        If ResultSet.Tables.Count > 0 Then
            For Each dtStatusRow In ResultSet.Tables(0).Rows
                strStatus = Trim(dtStatusRow.Item(0).ToString)
            Next
            If (strStatus = "WR") Or (strStatus = "RC") Then
                valStatus = False
                Select Case strStatus
                    Case "WR"
                        strErrMsg = "Transaction is Receiving by Back office." & "\n" & "Refference  :  " & instrRef & ""
                    Case "RC"
                        strErrMsg = "Can not do this transaction.(Received by back office already)" & "\n" & "Refference  :  " & instrRef & ""
                End Select
            End If
        End If

        'errMsg:
        '        If strMsg <> "" Then
        '            cstext1 = "alert('" & strMsg & "');"
        '            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        '        End If

    End Function
    '2012-12-22 R55040057 Tom Start: Support new organize	
    Private Sub updateTempStatus(ByVal strtmpStat As String)
        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim myCommand As OdbcCommand = New OdbcCommand()
        Dim myTrans As OdbcTransaction

        conn.Open()
        myCommand.Connection = conn
        myTrans = conn.BeginTransaction()
        myCommand.Transaction = myTrans

        Try
            'Update temp status for transaction that amending by ITSC
            myCommand.CommandText = "update db2.forwtran set procstat = '" & strtmpStat & "' where forref = '" & Session("ForRef") & "'"
            myCommand.ExecuteNonQuery()
            myTrans.Commit()
            Session("tempStat") = False
        Catch odbce As OdbcException
            myTrans.Rollback()
            strMsg = "Update temp status failed.!!!OdbcException : " & odbce.Message.ToString().Replace("'", "\'").Replace(Environment.NewLine, "")

            'insert Error Log FORWLOG
            myCommand.CommandText = "insert into db2.forwlog(forref,trandate,trantime,userid,msgerr,funccd)" & _
                "values('" & Session("ForRef") & "',current date,current time, '" & Session("strUserID") & "', '" & Left(PublicFunc.replaceString(strMsg), 200) & "', '" & Session("Funccd") & "')"
            myCommand.ExecuteNonQuery()

            GoTo exitHandle

        Catch ex As Exception
            strMsg = "Update temp status failed.!!!" & ex.Message.Replace("'", "\'").Replace(Environment.NewLine, "")

            ' check DB connection
            If conn.State = ConnectionState.Closed Then GoTo exitHandle

            myTrans.Rollback()

            'insert Error Log FORWLOG
            myCommand.CommandText = "insert into db2.forwlog(forref,trandate,trantime,userid,msgerr,funccd)" & _
                                           "values('" & Session("ForRef") & "',current date,current time, '" & Session("strUserID") & "', '" & Left(PublicFunc.replaceString(strMsg), 200) & "', '" & Session("Funccd") & "')"
            myCommand.ExecuteNonQuery()

            GoTo exitHandle
        Finally
            conn.Close()
        End Try

exitHandle:
        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub txtTRdeal_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTRdeal.TextChanged

    End Sub
End Class
