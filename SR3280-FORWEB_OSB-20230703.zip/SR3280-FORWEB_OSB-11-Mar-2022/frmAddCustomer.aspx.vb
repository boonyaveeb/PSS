Imports System.Data.SqlClient
Imports System.Data
Imports System.Data.Odbc
Imports System.Configuration
Imports System.Data.Common
Imports System.Data.Odbc.OdbcDataAdapter
Imports System.Data.Odbc.OdbcException
Imports System.Data.DataSet
Imports System.Data.Odbc.OdbcConnection
Imports System.Data.DataTable
Imports System.Data.DataRow
Imports System.Web.Services.WebMethodAttribute
Imports System.Web.UI

Partial Class frmAddCustomer

    Inherits System.Web.UI.Page

    Dim strFORCUSTID As String
    Dim Mdt As New DataTable
    Dim ACCDT As New DataTable
    Dim DT_FEE As New DataTable
    Dim DT_RATE As New DataTable

    Dim intNumDate As Integer
    Private dtDateSelect As Date
    Dim cs As ClientScriptManager = Page.ClientScript
    Dim csname1 As String = "PopupScript"
    Dim cstext1 As String
    Dim cstype As Type = Me.GetType()
    Dim strMsgError As String
    Dim ProcessSuccess As Boolean = True
    Dim mintRowIden As Integer
    Public ddlPro As DropDownList
    Public ddlfee As DropDownList
    '**************************************************************************************************
    Dim OdbcMyTrans As OdbcTransaction
    Dim OdbcConn As OdbcConnection = connDB.getDBConn()
    Dim strMsgRunSql As String = ""
    '**************************************************************************************************
    Dim strStatus As String, strPswAutho As String
    Dim strAuthoName As String, strAuthoPsw As String
    Dim authoNoofChgDT As Integer
    Dim strAuthoRcUnit As String, strAuthoWebStat As String
    Dim strAuthoPswEncrypt As String, AuthoUserLevel As String
    Dim strReason1 As String, strReason2 As String
    Dim strUserMapping As String
    '**************************************************************************************************
    'kwang::2008-06-25
    'Dim mstrAuthUser As String
    'Dim mstrAutDate As String
    'Dim mstrAutTime As String
    'Kwang R52030022
    Dim dtFeeName As New DataTable



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strCustForSearch As String
        Dim ss As String = ""
        Dim strMsg As String
        strMsg = ""

        '  ### Start : check Time Out ###
        If Session("strSysAuthorize") = "" Then
            Dim strUserInput As String
            Dim strWebStat As String
            strWebStat = ""
            strUserInput = Request.Cookies("UserInput").Value

            Response.Cookies("UserInput").Expires = DateTime.Now 'clear cookies

            ' case :  not time out
            If Not PublicFunc.chkWebStat(strUserInput, strWebStat) Then GoTo exitHandle
            If strWebStat = "I" Then
                Response.Redirect("~/DisplayMsg.aspx?type= Please Log In.!!!&page=LOGIN")
            Else
                Session("CUSTWEBSTAT") = ""
            End If
            ' case :  not time out

            If Not PublicFunc.LogOut(strUserInput, strMsg) Then

                GoTo exitHandle

            End If
            'KWANG Session("SearchFor") R52030022
            If Session("SearchFor") = "INSERT" Then
                Session("SearchFor") = "WAITING"
                Session("CUSTWEBSTAT") = "LOG"
                Session("WAIT") = "TRUE"
                AddCustomer()
            End If

            Session.Abandon() '( ����ҧ������� session ������ ���������������ͧ client)
            Response.Redirect("~/DisplayMsg.aspx?type=Time Out !!! Please Log In again.&page=LOGIN")
        End If
        '  ### End : check Time Out ###

        If Session("strSysAuthorize") = "Yes" Then
            If Not (Page.IsPostBack) Then
                'First Load
                Session("SearchFor") = Request.QueryString("SEARCHFOR")
                strCustForSearch = Request.QueryString("strCustSearch")
                Session("Funccd") = Request.QueryString("MenuFunc")

                '**************************ź session************************************                
                'Mdt.Rows.Clear()
                'ACCDT.Rows.Clear()
                'DT_FEE.Rows.Clear()
                'DT_RATE.Rows.Clear()
                '*******************************************************************

                Menu_AddCustomer.Items(0).ImageUrl = "~/Image/selectedtab0.gif"
                '2010-09-01
                'Radio_typeCust.SelectedValue = "I"
                'Session("optcusttype") = "I"
                Session("optCustType") = "C"
                Radio_typeCust.SelectedValue = "C"
                Session("flagFeeChange") = False
                Session("flagRateChange") = False
                Radio_typeCust_SelectedIndexChanged(sender, e)
                Dim siteNode As System.Web.SiteMapNode
                siteNode = SiteMap.CurrentNode
                siteNode.ReadOnly = False
                Select Case Session("SearchFor")
                    Case "UPDATE"
                        Session("Mdt") = Nothing
                        Session("ACCDT") = Nothing
                        Session("DT_FEE") = Nothing
                        Session("DT_RATE") = Nothing

                        GetDataForUpdate(strCustForSearch)
                        Session("CheckCusProcess") = False
                        CheckCusProcess(strCustForSearch)
                        Session("strCustid") = strCustForSearch

                        If Session("WAIT") = "TRUE" Then
                            siteNode.Title = "Waiting Customer"
                            Session("SearchFor") = "WAITING"
                            Me.labShowCustId.Text = "Customer ID :: " & strCustForSearch
                            ButSave.Visible = True
                            ButUpdate.Visible = False
                        Else
                            ButSave.Visible = False
                            ButUpdate.Visible = True
                            Me.labShowCustId.Text = "Customer ID :: " & strCustForSearch
                            siteNode.Title = "Update Customer"
                        End If
                        'Kwang R52030022
                        If Session("WAIT") = "TRUE" Then
                            Me.ButSaveWait.Visible = True
                        Else
                            Me.ButSaveWait.Visible = False
                        End If
                    Case "INSERT"
                            Menu_AddCustomer.Items(0).ImageUrl = "~/Image/selectedtab0.gif"
                        '2010-09-01
                        'Radio_typeCust.SelectedValue = "I"
                        'Session("optcusttype") = "I"
                        Session("optCustType") = "C"
                        Radio_typeCust.SelectedValue = "C"
                            Radio_typeCust_SelectedIndexChanged(sender, e)
                            ButSave.Visible = True
                            ButUpdate.Visible = False
                            Session("Mdt") = Nothing
                            Session("ACCDT") = Nothing
                            Session("DT_FEE") = Nothing
                            Session("DT_RATE") = Nothing

                            Me.txtBirthDate.Text = Format(Now, "dd/MM/yyyy")
                            Me.labShowCustId.Text = ""

                            siteNode.Title = "Add Customer"

                            panel_SwiftAddr.Enabled = False
                            Me.txtAddressL1.Disabled = True
                            Me.txtAddressL2.Disabled = True
                            Me.txtAddressL3.Disabled = True
                            'Kwang R52030022
                            Me.ButSaveWait.Visible = True
                        ' Session("WAIT") = "FALSE"
                            Session("CustSearch") = ""
                    Case "DELETE"
                            Session("Mdt") = Nothing
                            Session("ACCDT") = Nothing
                            Session("DT_FEE") = Nothing
                            Session("DT_RATE") = Nothing

                            GetDataForUpdate(strCustForSearch)
                            EnableForm()
                            ButSave.Visible = False
                            ButUpdate.Visible = False
                            'Kwang R52030022
                            Me.ButSaveWait.Visible = False
                            Me.labShowCustId.Text = "Customer ID :: " & strCustForSearch
                            ' 2008-01-31 Tom :
                            siteNode.Title = "Delete Customer"
                            'For Each ctl As Control In Me.Controls
                    Case "INQUIRY"
                            Session("Mdt") = Nothing
                            Session("ACCDT") = Nothing
                            Session("DT_FEE") = Nothing
                            Session("DT_RATE") = Nothing
                            GetDataForUpdate(strCustForSearch)
                            EnableForm()
                            ButSave.Visible = False
                            ButUpdate.Visible = False
                            'Kwang R52030022
                            Me.ButSaveWait.Visible = False
                            Me.labShowCustId.Text = "Customer ID :: " & strCustForSearch
                            ' 2008-01-31 Tom :
                        siteNode.Title = "Inquiry Customer"
                        Call ProcessPIIlog(strMsg) 'P630017-07 PII : Robin : Feb-2021

                End Select
                'Robin


                hplBirthDate.Attributes.Add("OnClick", "showCalendar('" & txtBirthDate.UniqueID & "', 'DD/MM/YYYY');")
                hplBirthDate.NavigateUrl = "javascript:;"

                HplRegDate.Attributes.Add("OnClick", "showCalendar('" & TxtRegDate.UniqueID & "', 'DD/MM/YYYY');")
                HplRegDate.NavigateUrl = "javascript:;"

                Me.PanelReqAuthority.Visible = False


            Else
                'page postback
                Me.Title = Session("SearchFor") & "  CUSTOMER "
             
            End If

            If Me.ddlProvince.SelectedValue = "" Then
                Me.ddlDistrict.Enabled = False
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = False
                Me.txtPostCode.Value = ""
            End If


        Else
            '�ѧ����� login 
            Response.Redirect("~/LogIn.aspx", True)

        End If
        'Other

        If Session("AUTH2") = "AUTH_T" Then
            Me.PanelReqAuthority.Visible = False
            'Me.ButSave.Enabled = True
            Me.Panel3.Visible = True
        End If

        If Not IsNothing(ddlPro) Then ddlPro.AutoPostBack = True

        '******************Defind ALL Data Table *******************************
        'Identification
        If Session("Mdt") Is Nothing Then
            Mdt.Columns.Add(New DataColumn("NO", GetType(System.String)))
            Mdt.Columns.Add(New DataColumn("IDType", GetType(System.String)))

            Mdt.Columns.Add(New DataColumn("IDNUMBER", GetType(System.String)))
            Mdt.Columns.Add(New DataColumn("IDCode", GetType(System.String)))
        Else
            Mdt = Session("Mdt")

            'Check Color for Object 
            If Mdt.Rows.Count > 0 Then
                Me.ddlIdType.BackColor = Drawing.Color.White
                Me.txtIdNumber.Style.Value = "background-color: white; text-transform:uppercase;"
                Me.txtIdNumberThai.Style.Value = "background-color: white; text-transform:uppercase;"
            Else
                Me.ddlIdType.BackColor = Drawing.Color.LightCyan
                Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
                Me.txtIdNumberThai.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
            End If
        End If

        'Account
        If Session("ACCDT") Is Nothing Then
            ACCDT.Columns.Add(New DataColumn("NO", GetType(System.String)))
            ACCDT.Columns.Add(New DataColumn("ACC_NO", GetType(System.String)))
            ACCDT.Columns.Add(New DataColumn("ACC_TYPE", GetType(System.String)))
            ACCDT.Columns.Add(New DataColumn("ACC_CUR", GetType(System.String)))
            ACCDT.Columns.Add(New DataColumn("CHK_MAIN", GetType(System.String)))
            ACCDT.Columns.Add(New DataColumn("ACCCODE", GetType(System.String)))
            ACCDT.Columns.Add(New DataColumn("ACCCUR", GetType(System.String)))
        Else
            ACCDT = Session("ACCDT")
            'Check Color for Object 
            If ACCDT.Rows.Count > 0 Then
                Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: white"
                Me.ddlAcType.BackColor = Drawing.Color.White
                Me.ddlCurrency.BackColor = Drawing.Color.White
                Me.ChkMain.BackColor = Drawing.Color.White
            Else
                Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: lightcyan"
                Me.ddlAcType.BackColor = Drawing.Color.LightCyan
                Me.ddlCurrency.BackColor = Drawing.Color.LightCyan
                Me.ChkMain.BackColor = Drawing.Color.LightCyan
            End If
        End If

        'Fee
        If Session("DT_FEE") Is Nothing Then
            DT_FEE.Columns.Add(New DataColumn("NO", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("PRONAME", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("FEENAME", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("FEETYPE", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("FEEMAGIN", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("FEEMIN", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("FEEMAX", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("PROCODE", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("FEECODE", GetType(System.String)))
            DT_FEE.Columns.Add(New DataColumn("FEETYPECODE", GetType(System.String)))
            'Kwang R52030022
            DT_FEE.Columns.Add(New DataColumn("FEECUR", GetType(System.String)))
        Else
            DT_FEE = Session("DT_FEE")
        End If

        'Rate
        If Session("DT_RATE") Is Nothing Then
            DT_RATE.Columns.Add(New DataColumn("NO", GetType(System.String)))
            DT_RATE.Columns.Add(New DataColumn("PRONAME", GetType(System.String)))
            DT_RATE.Columns.Add(New DataColumn("RATECUR", GetType(System.String)))
            DT_RATE.Columns.Add(New DataColumn("RATEMAGIN", GetType(System.String)))
            DT_RATE.Columns.Add(New DataColumn("RATEMIN", GetType(System.String)))
            DT_RATE.Columns.Add(New DataColumn("RATEMAX", GetType(System.String)))

            DT_RATE.Columns.Add(New DataColumn("PROCODE", GetType(System.String)))
            DT_RATE.Columns.Add(New DataColumn("CURCODE", GetType(System.String)))
        Else
            DT_RATE = Session("DT_RATE")
        End If

        'Kwang R52030022
        If Session("dtFeename") Is Nothing Then
            dtFeeName.Columns.Add(New DataColumn("FEECODE", GetType(System.String)))
            dtFeeName.Columns.Add(New DataColumn("FEENAME", GetType(System.String)))
        Else
            dtFeeName = Session("dtFeename")
        End If


        Page.MaintainScrollPositionOnPostBack = True
        'Page.SmartNavigation = True

exitHandle:

        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If


    
    End Sub
    
    Public Function LoadMainInformation() As Boolean
        '*** CMHI:7447634b-5426-48a7-bef8-6c182ae20acf
        Dim strSql As String
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        LoadMainInformation = True
        strSql = _
        "select '' as code,'--Select Customer Type--' as SHOW  " & _
        "from db2.frcmtbcd  " & _
        "where type = 'T018'  " & _
        "union  " & _
        "select  substr(CODE,2,2) as code, " & _
        "  substr(CODE,2,2) ||' : '|| value ||' - '|| relatedcd as SHOW  " & _
        "from db2.frcmtbcd  A " & _
        "  INNER JOIN  " & _
        "    ( " & _
        "     SELECT SWIFTTCD FROM FRCMTBCD " & _
        "     WHERE TYPE = 'T018' " & _
        "       AND RELATEDCD IN " & _
        "         ( " & _
        "          select code from db2.frcmtbcd A " & _
        "            INNER JOIN  " & _
        "              ( " & _
        "               SELECT SWIFTTCD FROM FRCMTBCD " & _
        "               WHERE TYPE = 'T004'  " & _
        "                 AND SCBCODE IN ({@Replacement1}) " & _
        "                 ANd FLAGUSE = 'Y' " & _
        "                 AND SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
        "               ORDER BY SWIFTTCD DESC " & _
        "               FETCH FIRST 1 ROW ONLY " & _
        "               ) B " & _
        "            ON A.SWIFTTCD = B.SWIFTTCD " & _
        "          where type = 'T004'  " & _
        "            and scbcode in ({@Replacement1}) and flaguse = 'Y' " & _
        "          ) " & _
        "       AND SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
        "     ORDER BY SWIFTTCD DESC " & _
        "     FETCH FIRST 1 ROW ONLY        " & _
        "     ) B " & _
        "  ON A.SWIFTTCD = B.SWIFTTCD " & _
        "where type = 'T018'  " & _
        "  and relatedcd in  " & _
        "    ( " & _
        "     select code from db2.frcmtbcd A " & _
        "       INNER JOIN  " & _
        "         ( " & _
        "          SELECT SWIFTTCD FROM FRCMTBCD " & _
        "          WHERE TYPE = 'T004'  " & _
        "            AND SCBCODE IN ({@Replacement1}) " & _
        "            ANd FLAGUSE = 'Y' " & _
        "            AND SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
        "          ) B " & _
        "       ON A.SWIFTTCD = B.SWIFTTCD " & _
        "     where type = 'T004'  " & _
        "       and scbcode in ({@Replacement1}) and flaguse = 'Y' " & _
        "     ) " & _
        "order by code"


        If UCase(Session("optCustType")) = "I" Then
            strSql = strSql.Replace("{@Replacement1}", "'1','2'")
        Else
            strSql = strSql.Replace("{@Replacement1}", "'3','4'")
        End If

        If Not PublicFunc.PopulateLoadDDL(CustType, "CODE", "SHOW", strSql) Then GoTo exitHandle

        If UCase(Session("optCustType")) = "I" Then
            strSql = _
            "select '' as CODE,'','--Select Title Name--'  as SHOW " & _
            "from db2.frcmtbcd " & _
            "where type = 'C002' and flaguse = 'Y' " & _
            "union " & _
            "select CODE, value,value||' : '||relatedcd as SHOW " & _
            "from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "    (" & _
            "     SELECT DISTINCT L2A.SWIFTTCD " & _
            "     FROM DB2.FRCMTBCD L2A " & _
            "     WHERE L2A.TYPE = 'C002' " & _
            "       AND FLAGUSE = 'Y' " & _
            "       AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
            "     ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
            "     ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where type = 'C002' and flaguse = 'Y' " & _
            "order by code"
        Else
            strSql = _
            "select '' as CODE,'--Select Title Name--'  as SHOW " & _
            "from db2.frcmtbcd " & _
            "where type = 'C004' and flaguse = 'Y' " & _
            "union " & _
            "select CODE,value||' : '||relatedcd as SHOW " & _
            "from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "    (" & _
            "     SELECT DISTINCT L2A.SWIFTTCD " & _
            "     FROM DB2.FRCMTBCD L2A " & _
            "     WHERE L2A.TYPE = 'C004' " & _
            "       AND FLAGUSE = 'Y' " & _
            "       AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
            "     ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
            "     ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where type = 'C004' and flaguse = 'Y' " & _
            "order by code"

        End If

        If Not PublicFunc.PopulateLoadDDL(Me.DDLTitle, "CODE", "SHOW", strSql) Then GoTo exitHandle
        Dim strSubQueryResult2 = LoadMainInformation_SubQueryResult("2")
        Dim strSubQueryResult4 = LoadMainInformation_SubQueryResult("4")
        If Session("optcusttype") = "I" Then
            strSql = _
            "select '' as code,'--Please Select ID Type--' as SHOW  " & _
            "from SYSIBM.SYSDUMMY1  " & _
            "union  " & _
            "select code, code||' : '||value as SHOW  " & _
            "from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "    ( " & _
            "      SELECT SWIFTTCD FROM FRCMTBCD " & _
            "      WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "        AND TYPE = 'T003' " & _
            "        AND SCBCODE IS NOT NULL " & _
            "        AND CODE IN (" & strSubQueryResult2 & ") " & _
            "      ORDER BY SWIFTTCD DESC " & _
            "      FETCH FIRST 1 ROW ONLY " & _
            "    ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where Type = 'T003'  " & _
            "  and CODE IN  " & _
            "    ( " & _
            "      " & strSubQueryResult2 & " " & _
            "     )  " & _
            "and (scbcode is not null)  " & _
            "order by code"

        Else
            strSql = _
            "select '' as code,'--Please Select ID Type--' as SHOW  " & _
            "from SYSIBM.SYSDUMMY1 " & _
            "union  " & _
            "select A.code AS CC, A.code||' : '||A.value as SHOW  " & _
            "from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "    ( " & _
            "     SELECT SWIFTTCD,CODE FROM FRCMTBCD " & _
            "     WHERE Type = 'T003' " & _
            "       AND scbcode is not null " & _
            "       ANd CODE IN (" & _
                         strSubQueryResult4 & ") " & _
            "       AND SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "     ORDER BY SWIFTTCD DESC " & _
            "     FETCH FIRST 1 ROW ONLY " & _
            "    ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where Type = 'T003'  " & _
            "  and A.CODE IN  " & _
            "    (" & _
                    strSubQueryResult4 & ")  " & _
            "and (scbcode is not null)  " & _
            "order by code"
        End If

        Dim logger As New FORWEB_Logger(FORWEB_Logger.LogType.ActivityLog)
        logger.WriteLog(Chr(9) & "LoadMainInformation" & strSql & Chr(9) & "******")
        If Not PublicFunc.PopulateLoadDDL(Me.ddlIdType, "code", "SHOW", strSql) Then
            cstext1 = "alert('Error!! List of ID Type Can not Load');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            GoTo exitHandle
        End If

        If LoadMainInformation = True Then Exit Function


exitHandle:
        LoadMainInformation = False
    End Function
    Private Function LoadMainInformation_SubQueryResult(ByVal strOption As String) As String
        '*** CMHI:7447634b-5426-48a7-bef8-6c182ae20acf
        Dim strSQL As String = ""
        Dim strRslt As String = ""
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        If strOption = "1" Then
            '*** Bring it back [Select OTHINFORM...] => [Select code...]
            strSQL = _
            "Select code from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "    ( " & _
            "      SELECT SWIFTTCD FROM FRCMTBCD " & _
            "      WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "        AND TYPE = 'T004' " & _
            "        AND SCBCODE IN ('1','2') " & _
            "      ORDER BY SWIFTTCD DESC " & _
            "      FETCH FIRST 1 ROW ONLY " & _
            "    ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where Type = 'T004' and SCBCODE in ('1','2')  "

        ElseIf strOption = "2" Then
            Dim strSubQueryResult1 As String = LoadMainInformation_SubQueryResult("1")
            strSQL = _
            "SELECT VALUE FROM DB2.FRCMTBCD A " & _
            "  INNER JOIN " & _
            "    ( " & _
            "     SELECT SWIFTTCD FROM FRCMTBCD " & _
            "     WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "       AND TYPE = 'R001' " & _
            "       AND FLAGUSE = 'Y' " & _
            "       AND CODE IN (" & strSubQueryResult1 & ") " & _
            "     ORDER BY SWIFTTCD DESC " & _
            "     FETCH FIRST 1 ROW ONLY " & _
            "    ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "WHERE TYPE = 'R001' AND FLAGUSE = 'Y'  " & _
            "  AND CODE in " & _
            "    (" & strSubQueryResult1 & ") "
        ElseIf strOption = "3" Then
            '*** Bring it back [Select OTHINFORM...] => [Select code...]
            strSQL = _
            "Select code from db2.frcmtbcd  " & _
            "where Type = 'T004'  " & _
            "  and SCBCODE in ('3','4') " & _
            "  AND SWIFTTCD =  " & _
            "    ( " & _
            "      SELECT SWIFTTCD FROM FRCMTBCD " & _
            "      WHERE TYPE = 'T004' " & _
            "        AND SCBCODE IN ('3','4') " & _
            "        ANd SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "      ORDER BY SWIFTTCD DESC " & _
            "      FETCH FIRST 1 ROW ONLY " & _
            "    )"
        ElseIf strOption = "4" Then
            Dim strSubQueryResult3 As String = LoadMainInformation_SubQueryResult("3")
            strSQL = _
            "SELECT VALUE  " & _
            "     FROM DB2.FRCMTBCD A " & _
            "       INNER JOIN " & _
            "         ( " & _
            "          SELECT SWIFTTCD " & _
            "          FROM FRCMTBCD " & _
            "          WHERE TYPE = 'R001' " & _
            "            AND FLAGUSE = 'Y'  " & _
            "            AND CODE IN (" & strSubQueryResult3 & ") " & _
            "            AND SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "          ORDER BY SWIFTTCD DESC " & _
            "          FETCH FIRST 1 ROW ONLY " & _
            "         ) B " & _
            "       ON A.SWIFTTCD = B.SWIFTTCD " & _
            "     WHERE TYPE = 'R001' AND FLAGUSE = 'Y'  " & _
            "       AND A.CODE in " & _
            "         (" & strSubQueryResult3 & ") "
        End If
        Return PublicFunc.getQueryResultInCSV(strSQL)
    End Function
    Public Function LoadDDLIndividual() As Boolean
        '*** CMHI:f28e2931-4f10-44ef-9e40-992bfcaa01fd
        Dim strSql

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        LoadDDLIndividual = True
        'LoadDDLItsc
        strSql = " select '' as itscno,'','--Please Select ITSC NO.--' as SHOW " & _
                 " from db2.frcmitsc union " & _
                 " select itscno,itscname,itscno||' :  '|| itscname as SHOW" & _
                 " from db2.frcmitsc where status = 'A'" & _
                 " AND SWIFTTCD = '" & concur.SWIFTCODE & "'"
        If Not PublicFunc.PopulateLoadDDL(ddlItscNo, "itscno", "SHOW", strSql) Then GoTo exitHandle
        'Loadddl_Occode
        strSql = " select '' as  code,''," & _
                 "   '--Please Select OC Code--'  as SHOW " & _
                 " from db2.frcmtbcd " & _
                 " where type= 'C013' " & _
                 "   and flaguse = 'Y' " & _
                 " union  " & _
                 " select CODE,value,CODE||' : '||value as SHOW " & _
                 " from db2.frcmtbcd A " & _
                 "   INNER JOIN " & _
                 "     (" & _
                 "      SELECT DISTINCT L2A.SWIFTTCD " & _
                 "      FROM DB2.FRCMTBCD L2A " & _
                 "      WHERE L2A.TYPE = 'C013' AND FLAGUSE = 'Y' " & _
                 "        AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
                 "      ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
                 "      ) B " & _
                 "   ON A.SWIFTTCD = B.SWIFTTCD " & _
                 " where type= 'C013' " & _
                 "   and flaguse = 'Y'" & _
                 " order by code"
        If Not PublicFunc.PopulateLoadDDL(ddlOcCode_I, "CODE", "SHOW", strSql) Then GoTo exitHandle
        'Loadddl_nation()
        strSql = " select '' as code," & _
                 "   '--Please Select Nationality.--' as SHOW " & _
                 " from db2.frcmtbcd " & _
                 " where type = 'C003' and flaguse = 'Y' " & _
                 " union " & _
                 " select CODE,code||' : '|| value as SHOW " & _
                 " from db2.frcmtbcd A " & _
                 "   INNER JOIN " & _
                 "     (" & _
                 "      SELECT DISTINCT L2A.SWIFTTCD " & _
                 "      FROM DB2.FRCMTBCD L2A " & _
                 "      WHERE L2A.TYPE = 'C003' AND FLAGUSE = 'Y' " & _
                 "        AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
                 "      ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
                 "      ) B " & _
                 "   ON A.SWIFTTCD = B.SWIFTTCD " & _
                 " where type = 'C003' and flaguse = 'Y' " & _
                 " order by code "
        If Not PublicFunc.PopulateLoadDDL(Me.ddlNation_code, "CODE", "SHOW", strSql) Then GoTo exitHandle
        'Loadddl_career()
        strSql = " select '' as code," & _
                 "   '--Please Select Career.--'  as SHOW " & _
                 " from db2.frcmtbcd " & _
                 " where type = 'C007' " & _
                 "   and flaguse = 'Y' " & _
                 " union " & _
                 " select CODE, " & _
                 "   code||' : '|| value as SHOW " & _
                 " from db2.frcmtbcd A " & _
                 "   INNER JOIN " & _
                 "     (" & _
                 "      SELECT DISTINCT L2A.SWIFTTCD " & _
                 "      FROM DB2.FRCMTBCD L2A " & _
                 "      WHERE L2A.TYPE = 'C007' AND FLAGUSE = 'Y' " & _
                 "        AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
                 "      ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
                 "      ) B " & _
                 "   ON A.SWIFTTCD = B.SWIFTTCD " & _
                 " where type = 'C007' " & _
                 "   and flaguse = 'Y' order by code "
        If Not PublicFunc.PopulateLoadDDL(Me.ddlcareer, "CODE", "SHOW", strSql) Then GoTo exitHandle
        If LoadDDLIndividual = True Then Exit Function
exitHandle:
        LoadDDLIndividual = False
    End Function
    Public Function LoadDDLCoporate() As Boolean
        '*** CMHI:a199c784-36ae-4943-8c3e-a9dd398da6db
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        Dim strSql As String
        LoadDDLCoporate = True
        strSql = ""
        'CustType


        strSql = _
        "select '' as code,'--Select Customer Type--' as SHOW  " & _
        "from db2.frcmtbcd  " & _
        "where type = 'T018'  " & _
        "union " & _
        "select  substr(CODE,2,2) as code,  " & _
        "  substr(CODE,2,2) ||' : '|| value ||' - ' " & _
        "    || relatedcd as SHOW  " & _
        "from db2.frcmtbcd A  " & _
        "  INNER JOIN  " & _
        "    ( " & _
        "     SELECT DISTINCT SWIFTTCD  " & _
        "     FROM DB2.FRCMTBCD  " & _
        "     WHERE TYPE = 'T018' " & _
        "       AND SWIFTTCD IN('','" & concur.SWIFTCODE & "')  " & _
        "       AND RELATEDCD IN  " & _
        "         ( " & _
        "          select code from db2.frcmtbcd L2A " & _
        "            INNER JOIN  " & _
        "              ( " & _
        "               SELECT DISTINCT SWIFTTCD  " & _
        "               FROM DB2.FRCMTBCD  " & _
        "               WHERE TYPE = 'T004' AND SCBCODE IN ({@Replacement1})  " & _
        "                 AND FLAGUSE = 'Y'  " & _
        "                 AND SWIFTTCD IN('','" & concur.SWIFTCODE & "')  " & _
        "               ORDER BY SWIFTTCD DESC FETCH FIRST 1 ROW ONLY  " & _
        "               ) L2B  " & _
        "            ON L2A.SWIFTTCD = L2B.SWIFTTCD  " & _
        "          where L2A.type = 'T004'  " & _
        "            and L2A.scbcode in ({@Replacement1})  " & _
        "            and L2A.flaguse = 'Y' " & _
        "          ) " & _
        "     ORDER BY SWIFTTCD DESC FETCH FIRST 1 ROW ONLY  " & _
        "     ) B " & _
        "  ON A.SWIFTTCD = B.SWIFTTCD " & _
        "where A.type = 'T018'  " & _
        "  and A.relatedcd in  " & _
        "    ( " & _
        "     select code from db2.frcmtbcd L2A " & _
        "       INNER JOIN  " & _
        "         ( " & _
        "          SELECT DISTINCT SWIFTTCD  " & _
        "          FROM DB2.FRCMTBCD  " & _
        "          WHERE TYPE = 'T004' AND SCBCODE IN ({@Replacement1})  " & _
        "            AND FLAGUSE = 'Y'  " & _
        "            AND SWIFTTCD IN('','" & concur.SWIFTCODE & "')  " & _
        "          ORDER BY SWIFTTCD DESC FETCH FIRST 1 ROW ONLY  " & _
        "          ) L2B  " & _
        "       ON L2A.SWIFTTCD = L2B.SWIFTTCD  " & _
        "     where L2A.type = 'T004'  " & _
        "       and L2A.scbcode in ({@Replacement1})  " & _
        "       and L2A.flaguse = 'Y' " & _
        "     ) " & _
        "order by code"
        If UCase(Session("optCustType")) = "I" Then
            strSql = strSql.Replace("{@Replacement1}", "'1','2'")
        Else
            strSql = strSql.Replace("{@Replacement1}", "'3','4'")
        End If


        If Not PublicFunc.PopulateLoadDDL(CustType, "CODE", "SHOW", strSql) Then GoTo exitHandle

        'BusiType
        strSql = _
        "select '' as code,''," & _
        "  '--Please Select Business Type--' as SHOW from db2.frcmtbcd " & _
        "where type = 'T005' " & _
        "and flaguse = 'Y'  " & _
        "union " & _
        "select CODE, value ,(code||':'||value) as SHOW " & _
        "from db2.frcmtbcd A  " & _
        "   INNER JOIN " & _
        "     (" & _
        "      SELECT DISTINCT L2A.SWIFTTCD " & _
        "      FROM DB2.FRCMTBCD L2A " & _
        "      WHERE L2A.TYPE = 'T005' AND FLAGUSE = 'Y' " & _
        "        AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
        "      ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
        "      ) B " & _
        "   ON A.SWIFTTCD = B.SWIFTTCD " & _
        "where A.type = 'T005' and A.flaguse = 'Y' " & _
        "order by code"
        If Not PublicFunc.PopulateLoadDDL(DDL_BusinessType, "CODE", "SHOW", strSql) Then GoTo exitHandle

        If ddlItscNO_C.Items.Count = 0 Then
            strSql = " select '' as itscno,'--Please Select ITSC NO.--' as SHOW " & _
                     " from db2.frcmitsc union " & _
                     " select itscno,itscno||' :  '|| itscname as SHOW" & _
                     " from db2.frcmitsc where status = 'A'" & _
                     " AND swifttcd = '" & concur.SWIFTCODE & "'"
            If Not PublicFunc.PopulateLoadDDL(ddlItscNO_C, "itscno", "SHOW", strSql) Then GoTo exitHandle
        End If

        'Loadddl_Occode()
        strSql = " select '' as code,'','--Please Select OC Code--'  as SHOW " & _
                 " from db2.frcmtbcd " & _
                 " where type= 'C013' and flaguse = 'Y' union " & _
                 " select CODE,value,CODE||' : '||value as SHOW " & _
                 " from db2.frcmtbcd A " & _
                 "   INNER JOIN " & _
                 "     (" & _
                 "      SELECT DISTINCT L2A.SWIFTTCD " & _
                 "      FROM DB2.FRCMTBCD L2A " & _
                 "      WHERE L2A.TYPE = 'C013' AND FLAGUSE = 'Y' " & _
                 "        AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
                 "      ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
                 "      ) B " & _
                 "   ON A.SWIFTTCD = B.SWIFTTCD " & _
                 " where type= 'C013' and flaguse = 'Y'" & _
                 " order by code"
        If Not PublicFunc.PopulateLoadDDL(ddlOcCode_C, "CODE", "SHOW", strSql) Then GoTo exitHandle

        If LoadDDLCoporate = True Then Exit Function

exitHandle:
        LoadDDLCoporate = False

    End Function


    Protected Sub Radio_typeCust_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Radio_typeCust.SelectedIndexChanged
        Dim strsql As String

        Session("optCustType") = Radio_typeCust.SelectedValue.ToString()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
         Select Case UCase(Session("optCustType"))
            Case ""
                Panel1.Visible = False
                MViewTypeCust.ActiveViewIndex = 2
                MultiView_addCustomer.ActiveViewIndex = 6
                Session("CustTypeSelect") = ""
            Case "I"
                'Response.Redirect("~/frmAddCustomer.aspx?SEARCHFOR=INSERT")
                MViewTypeCust.ActiveViewIndex = 0
                Session("CustTypeSelect") = ""
                ddlItscNO_C.DataSource = ""
                ddlItscNO_C.DataBind()
                Me.txtIdNumber.Visible = True
                Me.txtIdNumberThai.Visible = False

                '*******Start : Customer Type �١ �Ѻ ID type **************
                '***56100048 Ron
                'strsql = " select '' as code,'--Please Select ID Type--' as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
                '         " code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y') union " & _
                '         " select code, code||' : '||value as SHOW from db2.frcmtbcd where Type = 'T003' " & _
                '         " and CODE IN (SELECT VALUE FROM DB2.FRCMTBCD WHERE TYPE = 'R001' AND FLAGUSE = 'Y' " & _
                '         "              AND CODE in	(Select code from db2.frcmtbcd where Type = 'T004' and SCBCODE in ('1','2'))) " & _
                '         " and (scbcode is not null) order by code"

                '*** Bring it back [Select OTHINFORM...] => [Select code...]
                strsql = " select '' as code,'--Please Select ID Type--' as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
                         " code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y') union " & _
                         " select code, code||' : '||value as SHOW from db2.frcmtbcd " & _
                         "where Type = 'T003' " & _
                         " and CODE IN " & _
                         " (" & _
                         "  SELECT VALUE FROM DB2.FRCMTBCD " & _
                         "  WHERE TYPE = 'R001' AND FLAGUSE = 'Y' " & _
                         "   AND CODE in	" & _
                         "   (" & _
                         "    Select code from db2.frcmtbcd " & _
                         "    where Type = 'T004' and SCBCODE in ('1','2') " & _
                         "     AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("Type = 'T004' and SCBCODE in ('1','2') ", concur.SWIFTCODE) & "' " & _
                         "    )" & _
                         "   AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'R001' and flaguse = 'Y' ", concur.SWIFTCODE) & "' " & _
                         "  ) " & _
                         " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T003'", concur.SWIFTCODE) & "' " & _
                         " and (scbcode is not null) order by code"

        Dim logger As New FORWEB_Logger(FORWEB_Logger.LogType.ActivityLog)
        logger.WriteLog(Chr(9) & "Radio_typeCust_SelectedIndexChanged" & strsql & Chr(9) & "******")
                If Not PublicFunc.PopulateLoadDDL(Me.ddlIdType, "code", "SHOW", strsql) Then
                    cstext1 = "alert('Error!! Information of  ID Type Can not Load');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If

                If Not Mdt Is Nothing Then
                    Session("Mdt") = Nothing
                    If Me.GridIdentification.Rows.Count > 0 Then
                        Me.GridIdentification.DataSourceID = ""
                        Me.GridIdentification.DataBind()
                    End If
                End If

                '*******End : Customer Type �١ �Ѻ ID type **************


                If Not LoadMainInformation() Then
                    'MsgBox("Can't Load DropdownLisf of Main")
                    cstext1 = "alert('Can not Load Information of Main Page');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Exit Sub
                End If

                If Not LoadDDLIndividual() Then
                    'MsgBox("Can't Load DropdownLisf of Individual")
                    cstext1 = "alert('Can not Load Information of Individual');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Exit Sub
                End If

                'LoadDDL_Province()

                'MultiView_addCustomer.ActiveViewIndex = 0
                Panel1.Visible = True
                Panel3.Visible = True
                Panel5.Visible = False
                Panel2.Visible = True
                ClearTextInput()
            Case "C"
                'Response.Redirect("~/frmAddCustomer.aspx?SEARCHFOR=INSERT")
                MViewTypeCust.ActiveViewIndex = 1
                Session("CustTypeSelect") = ""
                ddlItscNO_C.DataSource = ""
                ddlItscNO_C.DataBind()
                Me.txtIdNumber.Visible = True
                Me.txtIdNumberThai.Visible = False

                '*******Start : Customer Type �١ �Ѻ ID type **************
                '***56100048 Ron
                'strsql = " select '' as code,'--Please Select ID Type--' as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
                '         " code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y') union " & _
                '         " select code, code||' : '||value as SHOW from db2.frcmtbcd where Type = 'T003' " & _
                '         " and CODE IN (SELECT VALUE FROM DB2.FRCMTBCD WHERE TYPE = 'R001' AND FLAGUSE = 'Y' " & _
                '         "              AND CODE in	(Select code from db2.frcmtbcd where Type = 'T004' and SCBCODE in ('3','4'))) " & _
                '         " and (scbcode is not null) order by code"

                '*** Bring it back [Select OTHINFORM...] => [Select code...]
                strsql = " select '' as code,'--Please Select ID Type--' as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
                         " code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y') union " & _
                         " select code, code||' : '||value as SHOW " & _
                         " from db2.frcmtbcd " & _
                         " where Type = 'T003' " & _
                         "  and CODE IN " & _
                         "  (" & _
                         "   SELECT VALUE FROM DB2.FRCMTBCD " & _
                         "   WHERE TYPE = 'R001' AND FLAGUSE = 'Y' " & _
                         "    AND CODE in	" & _
                         "    (" & _
                         "     Select code from db2.frcmtbcd " & _
                         "     where Type = 'T004' and SCBCODE in ('3','4') " & _
                         "      AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("Type = 'T004' and SCBCODE in ('3','4') ", concur.SWIFTCODE) & "' " & _
                         "     )" & _
                         "    AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("TYPE = 'R001' AND FLAGUSE = 'Y' ", concur.SWIFTCODE) & "' " & _
                         "   ) " & _
                         "  AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("Type = 'T003' ", "") & "' " & _
                         " and (scbcode is not null) order by code"

        Dim logger As New FORWEB_Logger(FORWEB_Logger.LogType.ActivityLog)
        logger.WriteLog(strsql)
                If Not PublicFunc.PopulateLoadDDL(Me.ddlIdType, "code", "SHOW", strsql) Then
                    cstext1 = "alert('Error!! Information of ID Type Can not Load');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If

                If Not Mdt Is Nothing Then
                    Session("Mdt") = Nothing
                    If Me.GridIdentification.Rows.Count > 0 Then
                        Me.GridIdentification.DataSourceID = ""
                        Me.GridIdentification.DataBind()
                    End If
                End If

                '*******End : Customer Type �١ �Ѻ ID type **************

                If Not LoadMainInformation() Then
                    cstext1 = "alert('Can not Information of Main Page');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If

                If Not LoadDDLCoporate() Then
                    cstext1 = "alert('Can not Load Information of Coporate');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If

                Me.TxtRegDate.Text = Format(Now, "dd/MM/yyyy")


                'kwang::change date
                'PublicFunc.PopulateControlsDate(ddlRegDate, ddlRegMonth, ddlRegYear)

                Panel1.Visible = True
                Panel3.Visible = True
                Panel5.Visible = True
                Panel2.Visible = False
                ClearTextInput()
        End Select

    End Sub

    Protected Sub Menu_AddCustomer_MenuItemClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MenuEventArgs) Handles Menu_AddCustomer.MenuItemClick
        '*** CMHI:3cd41b40-d024-48b7-9b76-c7498721ce82
        Dim strsql As String
        Dim i As Integer

        Dim strMsgError As String = ""

        i = e.Item.Value
        SetMenuAddCustomer(i)
        Page.Validate()

        Select Case e.Item.Value
            Case 0
                'Information
                Page.Validate()
                MultiView_addCustomer.ActiveViewIndex = 0

            Case 1
                'Address
                Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
                If Me.ddlContryCode.Items.Count = 0 Then
                    strsql = _
                    "select '' as code,'','--Please Select Country Code--'  as SHOW  " & _
                    "from SYSIBM.SYSDUMMY1 " & _
                    "union  " & _
                    "select code, value,code|| ' : ' || value as SHOW  " & _
                    "from db2.frcmtbcd A " & _
                    "  INNER JOIN " & _
                    "    ( " & _
                    "      SELECT SWIFTTCD FROM FRCMTBCD " & _
                    "      WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
                    "        AND type = 'C003'  " & _
                    "        and flaguse = 'Y'  " & _
                    "      ORDER BY SWIFTTCD DESC " & _
                    "      FETCH FIRST 1 ROW ONLY " & _
                    "    ) B " & _
                    "  ON A.SWIFTTCD = B.SWIFTTCD " & _
                    "where type = 'C003' and flaguse = 'Y'  " & _
                    "order by code"

                    If Not PublicFunc.PopulateLoadDDL(Me.ddlContryCode, "CODE", "SHOW", strsql) Then
                        cstext1 = "alert('Error!! ID No. should be filled.');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    End If
                    Me.ddlContryCode.SelectedIndex = Me.ddlContryCode.Items.IndexOf(Me.ddlContryCode.Items.FindByValue(concur.ISO3166_1))
                End If

                If Trim(Me.ddlProvince.SelectedValue.ToString()) = "" Then
                    Me.ddlDistrict.Enabled = False
                Else
                    Me.ddlDistrict.Enabled = True
                End If

                If Me.ddlPostCode.Items.Count = 2 Then
                    Me.ddlPostCode.Enabled = False
                    Me.txtPostCode.Visible = False
                    Me.txtPostCode.Value = ""
                ElseIf Me.ddlPostCode.Items.Count = 1 Then
                    If Trim(Me.ddlDistrict.SelectedValue.ToString()) = "" Then
                        Me.ddlPostCode.Enabled = False
                        Me.txtPostCode.Visible = False
                        Me.txtPostCode.Value = ""
                    Else
                        Me.ddlPostCode.Enabled = False
                        Me.txtPostCode.Visible = True
                    End If
                Else
                    Me.ddlPostCode.Enabled = True
                    Me.txtPostCode.Visible = False
                    Me.txtPostCode.Value = ""
                End If

                MultiView_addCustomer.ActiveViewIndex = 1
                Me.Panel3.Visible = True

            Case 2
                'Identification
                If Not loadTabIdentifi() Then
                    cstext1 = "alert('Error!! Can not Load Tab Identification');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If

            Case 3
                'Account
                If Not loadTabAccount() Then
                    cstext1 = "alert('Error!! Account is not Load');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If

            Case 4
                'Special Fee
                If Not loadTabFee() Then
                    cstext1 = "alert('Error!! Can not Load Fee Tab.');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If
            Case 5
                'Special Rate

                If Not loadTabRate() Then
                    cstext1 = "alert('Error!! Can not Load Tab Rate.');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If
        End Select
    End Sub

    Protected Sub ButSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButSave.Click
        Session("WAIT") = "FALSE"
        Session("AUTH2") = "AUTH_F"
        If Not AddCustomer() Then

        End If
    End Sub
    Protected Sub SqlInsertFormcust_Inserted(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlInsertFormcust.Inserted
        Dim command As DbCommand
        Dim transaction As DbTransaction

        command = e.Command
        transaction = command.Transaction

        If ProcessSuccess = True Then
            transaction.Commit()
        Else
            transaction.Rollback()
        End If
    End Sub
    Protected Sub SqlInsertFormcust_Inserting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceCommandEventArgs) Handles SqlInsertFormcust.Inserting
        Dim command As DbCommand
        Dim connection As DbConnection
        Dim transaction As DbTransaction

        command = e.Command
        connection = command.Connection
        connection.Open()
        transaction = connection.BeginTransaction()

        command.Transaction = transaction
    End Sub

    Protected Sub SqlInsertFormcust_Selecting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceSelectingEventArgs) Handles SqlInsertFormcust.Selecting
        Dim command As DbCommand
        Dim connection As DbConnection
        Dim transaction As DbTransaction

        command = e.Command
        connection = command.Connection
        connection.Open()
        transaction = connection.BeginTransaction()

        command.Transaction = transaction
    End Sub

    Public Function genCustId(ByRef strFORCUSTID As String) As Boolean
        '*** CMHI:9c56026f-d283-4a54-9602-ea7c55997f1f
        Try
            Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
            If (Not Session("WAIT").ToString().Equals("TRUE")) Then
                strFORCUSTID = genCustId_GetLastRunningID(concur.SWIFTCODE, False)
                If (Long.Parse(strFORCUSTID) = 0) Then
                    strFORCUSTID = (Long.Parse(strFORCUSTID) + 1).ToString("000000")
                    strFORCUSTID = Date.Today.Year.ToString().Substring(2, 2) & strFORCUSTID
                Else
                    strFORCUSTID = (Long.Parse(strFORCUSTID) + 1).ToString("00000000")
                End If
                If (strFORCUSTID.Length = 8 And strFORCUSTID.Substring(0, 2) = "00") Then
                    strFORCUSTID = Date.Today.Year.ToString().Substring(2, 2) & strFORCUSTID.Substring(2, 6)
                End If
                strFORCUSTID = concur.SWIFTCODE.Substring(4, 2) & strFORCUSTID
            Else
                strFORCUSTID = genCustId_GetLastRunningID(concur.SWIFTCODE, True)
                strFORCUSTID = (Long.Parse(strFORCUSTID) + 1).ToString("0000000")
                strFORCUSTID = "TMP" & strFORCUSTID
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Public Function genCustId_GetLastRunningID(ByVal pSwiftCode As String, _
                 Optional ByVal pIsTempRunningID As Boolean = False) As String
        '*** CMHI:c3b84f23-2aea-4225-ad58-6b3a6241b948
        Dim strRslt As String = ""
        Dim strSql As String
        Dim strSwift56 = pSwiftCode.Substring(4, 2)

        If (pIsTempRunningID) Then
            strSql = "select Substr(RUNID,4,length(RUNID)-3) AS RUNID from " & _
                        "(select max(forcustid) AS RUNID " & _
                        "   from db2.formcust " & _
                        "   where Left(rtrim(forcustid),3) = 'TMP'" & _
                        "   fetch first 1 row only " & _
                        ") AS RUNID "
        Else
            strSql = "select Substr(RUNID,3,length(RUNID)-2) AS RUNID from " & _
                        "(select max(forcustid) AS RUNID " & _
                        "   from db2.formcust " & _
                        "   where Left(rtrim(forcustid),3) <> 'TMP'" & _
                        "    and substr(forcustid,1,4) = ? " & _
                        "   fetch first 1 row only " & _
                        ") AS RUNID " & _
                        "where Substr(RUNID,1,4) =?;"
        End If

        Dim strConn As String = ConfigurationManager.ConnectionStrings( _
         "ConnectionString").ToString()
        Dim conn As New OdbcConnection(strConn)
        Dim cmd As New Odbc.OdbcCommand(strSql, conn)
        conn.Open()
        cmd.Parameters.AddWithValue("Para1", strSwift56 & Date.Today.Year.ToString().Substring(2, 2))
        cmd.Parameters.AddWithValue("Para2", strSwift56 & Date.Today.Year.ToString().Substring(2, 2))
        Dim tb As DataTable = RGSDO.OdbcDBManager.getDataTable(cmd, "Table1")
        If (tb.Rows.Count > 0) Then
            If (tb.Rows(0)("RUNID").ToString().Equals("")) Then
                strRslt = "0"
            Else
                strRslt = tb.Rows(0)("RUNID").ToString()
            End If
        Else
            strRslt = "0"
        End If
        If (conn.State = ConnectionState.Open) Then conn.Close()
        Return strRslt
    End Function

    Protected Sub ButAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButAdd.Click
        Dim i As Integer

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        If Not Mdt Is Nothing Then
            If Mdt.Rows.Count > 9 Then
                cstext1 = "alert('Record less than 10');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If

            If Mdt.Rows.Count > 0 Then
                For i = 0 To Mdt.Rows.Count - 1
                    If Mdt.Rows(i).Item(3).ToString = Me.ddlIdType.SelectedValue.ToString Then
                        cstext1 = "alert('Please select New ID TYPE');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        ddlIdType.SelectedIndex = -1
                        Exit Sub
                    End If
                Next
            End If

            If Trim(Me.ddlIdType.SelectedValue.ToString()) = "" Then
                cstext1 = "alert('Please select ID TYPE');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                ddlIdType.SelectedIndex = -1
                Exit Sub
            End If

        End If
        If Me.ddlIdType.SelectedValue.ToString() = "324013" And Session("optCustType") = "C" Then
            If Trim(txtIdNumberThai.Value.ToString()) = "" Then
                cstext1 = "alert('Error!! Id No. should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Me.txtIdNumberThai.Focus()
                Exit Sub
            End If
        Else
            If Trim(txtIdNumber.Value.ToString()) = "" Then
                cstext1 = "alert('Error!! Id No. should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Me.txtIdNumber.Focus()
                Exit Sub
            End If

        End If
        '2009-10-21
        'If trim(txtIdNumber.Value.ToString()) = "" Then
        '    cstext1 = "alert('Error!! Id No. should be filled.');"
        '    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        '    Me.txtIdNumber.Focus()
        '    Exit Sub
        'End If

        Select Case ddlIdType.SelectedValue.ToString()
            'Case "324001"
            'Case "324004", "324001" '324004 : Juristic Id

            '*** [Start->]R56100048 Ron (Commented out the following lines of code as requested by UAT)
            Case "324001", "324004" ': Juristic Id
            '    If Len(Trim(txtIdNumber.Value)) <> 13 Then
            '        cstext1 = "alert('Error!! ID No. should be have 13 degits.');"
            '        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            '        Me.txtIdNumber.Focus()
            '        Exit Sub
            '    End If

            '    If Me.txtIdNumber.Value <> "" Then
            '        Dim sumdigit As Integer = 0
            '        Dim ChkSum As Integer = 0
            '        Dim Count As Integer = 1

            '        Dim ChkDigit = Val(Mid(txtIdNumber.Value, 13, 1))
            '        Do While Count < 13
            '            sumdigit = sumdigit + (Val(Mid(txtIdNumber.Value, Count, 1)) * (14 - Count))
            '            Count = Count + 1
            '        Loop
            '        ChkSum = 11 - sumdigit Mod 11
            '        ChkSum = ChkSum Mod 10
            '        If (ChkSum <> ChkDigit) Then
            '            cstext1 = "alert('Error!! Id No. incorrect.!!!');"
            '            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            '            Exit Sub
            '        End If

            '    End If

            '    If ddlIdType.SelectedValue.ToString() = "324004" Then
            '        If Mid(Me.txtIdNumber.Value.ToString(), 1, 1) <> "0" Then
            '            cstext1 = "alert('Error!! Juristic Id No. incorrect.!!!');"
            '            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            '            Exit Sub
            '        End If
            '    End If
                 If Not System.Text.RegularExpressions.Regex.IsMatch(txtIdNumber.Value, "^[a-z,A-Z,0-9,-]{0,}$") Then
                    cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Me.txtIdNumber.Focus()
                    Exit Sub
                 End If
            '*** [End->]R56100048 Ron (Commented out the following lines of code as requested by UAT)
            Case "324003" '324003 : Tax Id
                Dim var1 As Integer = 0

                '2012-10-03 :: kwang :: R55020103 
                'If Me.txtIdNumber.Value <> "" Then

                '    If Not IsNumeric(Me.txtIdNumber.Value) Then
                '        cstext1 = "alert('Error!! Id No. incorrect.');"
                '        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '        Exit Sub
                '    End If

                '    var1 = Len(Me.txtIdNumber.Value)
                '    If var1 <> 10 Then
                '        cstext1 = "alert('Tax Id must have 10 digits');"
                '        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '        Exit Sub
                '    End If

                '    If Me.txtIdNumber.Value <> "" Then
                '        Dim sumDigit As Integer = 0
                '        Dim lastDigit As Integer = 0
                '        Dim count As Integer = 1
                '        Do While (count < 10)
                '            If count Mod 2 = 1 Then
                '                sumDigit = sumDigit + (Val(Mid(Me.txtIdNumber.Value, count, 1)) * 3)
                '            Else
                '                sumDigit = sumDigit + (Val(Mid(Me.txtIdNumber.Value, count, 1)))
                '            End If
                '            count = count + 1
                '        Loop
                '        sumDigit = sumDigit Mod 10
                '        If sumDigit > 0 Then
                '            sumDigit = 10 - sumDigit
                '        Else
                '            sumDigit = 0
                '        End If
                '        lastDigit = Val(Mid(Me.txtIdNumber.Value, 10, 1))

                '        If sumDigit <> lastDigit Then
                '            cstext1 = "alert('Error!! Id No. incorrect.');"
                '            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '            Exit Sub
                '        End If

                '    End If
                'End If

                '*** [Start]-> R56100048 Ron (Requested by UAT)
                'If Len(Trim(txtIdNumber.Value)) <> 13 Then
                '    cstext1 = "alert('Error!! Tax ID No. should be have 13 degits.');"
                '    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '    Me.txtIdNumber.Focus()
                '    Exit Sub
                'End If
                 If Not System.Text.RegularExpressions.Regex.IsMatch(txtIdNumber.Value, "^[a-z,A-Z,0-9,-]{0,}$") Then
                    cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Me.txtIdNumber.Focus()
                    Exit Sub
                 End If
                '*** [End]-> R56100048 Ron (Requested by UAT)
            Case "324002"

                If IsNumeric(Mid(Me.txtIdNumber.Value.ToString(), 1, 2)) Then
                    cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Exit Sub
                End If
                Dim conn As OdbcConnection = connDB.getDBConn()
                Dim strsql As String
                Dim dtResultSet As DataSet


                '***56100048 Ron
                'strsql = " select code,value from db2.frcmtbcd where type= 'C003' and flaguse = 'Y'  " & _
                '         " and rtrim('" & UCase(Trim(Mid(Me.txtIdNumber.Value.ToString(), 1, 2))) & "') = code" & _
                '         " order by value "

                strsql = " select code,value from db2.frcmtbcd " & _
                " where type= 'C003' and flaguse = 'Y'  " & _
                "  and rtrim('" & UCase(Trim(Mid(Me.txtIdNumber.Value.ToString(), 1, 2))) & "') = code " & _
                "  AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD( _
                 "type= 'C003' and flaguse = 'Y' and rtrim('" & UCase(Trim(Mid(Me.txtIdNumber.Value.ToString(), 1, 2))) & "') = code ", concur.SWIFTCODE) & "' " & _
                " order by value "

                dtResultSet = connDB.RunQuerySql(strsql)
                If dtResultSet.Tables.Count > 0 Then
                    If dtResultSet.Tables(0).Rows.Count = 0 Then
                        cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        Exit Sub
                    End If
                Else
                    cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Exit Sub

                End If
                conn.Close()

        End Select

        If Not chkIdUnique(Trim(txtIdNumber.Value.ToString()), Trim(ddlIdType.SelectedValue.ToString())) Then
            cstext1 = "alert('Error !!! ID No. is Available Used, Please Insert Another Id No.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)

            Exit Sub
        End If

        Dim dr As DataRow
        dr = Mdt.NewRow
        'dr("IDType") = Me.ddlIdType.SelectedValue.ToString()
        dr("NO") = Mdt.Rows.Count + 1
        'dr("IDType") = ddlIdType.SelectedValue.ToString() & ":" & Mid(ddlIdType.SelectedItem.Text.ToString(), (Len(ddlIdType.SelectedItem.Text.ToString()) - 1 - InStr(ddlIdType.SelectedItem.Text.ToString(), ":") - 1), Len(ddlIdType.SelectedItem.Text.ToString()))
        dr("IDType") = ddlIdType.SelectedItem.Text.ToString()
        'trtempData = Trim(Mid(cboIDType.Text, 1, InStr(cboIDType.Text, ":") - 1)
        If Me.ddlIdType.SelectedValue.ToString() = "324013" And Session("optCustType") = "C" Then
            dr("IDNumber") = UCase(txtIdNumberThai.Value)
        Else
            dr("IDNumber") = UCase(txtIdNumber.Value)
        End If

        'dr("IDNumber") = UCase(txtIdNumber.Value)
        dr("IDCode") = ddlIdType.SelectedValue.ToString()
        'reset()
        Mdt.Rows.Add(dr)

        GridIdentification.DataSource = Mdt
        GridIdentification.DataBind()

        Session("Mdt") = Mdt
        If Mdt.Rows.Count > 0 Then
            Me.ddlIdType.BackColor = Drawing.Color.White
            Me.txtIdNumber.Style.Value = "background-color: white; text-transform:uppercase;"
            Me.txtIdNumberThai.Style.Value = "background-color: white; text-transform:uppercase;"
        Else
            Me.ddlIdType.BackColor = Drawing.Color.LightCyan
            Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
            Me.txtIdNumberThai.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
        End If
        'Session("flagRateChange") = True
        Me.ddlIdType.SelectedIndex = -1
        Me.txtIdNumber.Value = ""
        Me.txtIdNumberThai.Value = ""
        Me.ChkMain.Enabled = True
    End Sub
    Protected Sub ButIdenUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButIdenUpdate.Click
        Dim intRowIden As Integer
        Dim i As Integer

        'i = Session("mintRowIden")

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        If Not Mdt Is Nothing Then
            If Mdt.Rows.Count > 9 Then
                cstext1 = "alert('Record less than 10');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If

            If Mdt.Rows.Count > 0 Then
                For i = 0 To Mdt.Rows.Count - 1
                    If i = Session("mintRowIden") Then GoTo StepNext_i
                    If Trim(Me.ddlIdType.SelectedValue.ToString()) = "" Then
                        cstext1 = "alert('Please select New ID TYPE');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        'ddlIdType.SelectedIndex = -1
                        Exit Sub
                    End If
StepNext_i:
                Next
            End If

            If Trim(Me.ddlIdType.SelectedValue.ToString()) = "" Then
                cstext1 = "alert('Please select ID TYPE');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                ddlIdType.SelectedIndex = -1
                Exit Sub
            End If

        End If


        Select Case ddlIdType.SelectedValue.ToString()
            Case "324001", "324004" ' : Juristic Id
            '*** [Start]->R56100048 Ron (Commented out the following lines of code as requested by UAT)
                'If Len(Trim(txtIdNumber.Value)) <> 13 Then
                '    cstext1 = "alert('Error!! ID No. should be have 13 degits.');"
                '    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '    Me.txtIdNumber.Focus()
                '    Me.ddlIdType.BackColor = Drawing.Color.LightCyan
                '    Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
                '    Exit Sub
                'End If

                'If Me.txtIdNumber.Value <> "" Then
                '    Dim sumdigit As Integer = 0
                '    Dim ChkSum As Integer = 0
                '    Dim Count As Integer = 1

                '    Dim ChkDigit = Val(Mid(txtIdNumber.Value, 13, 1))
                '    Do While Count < 13
                '        sumdigit = sumdigit + (Val(Mid(txtIdNumber.Value, Count, 1)) * (14 - Count))
                '        Count = Count + 1
                '    Loop
                '    ChkSum = 11 - sumdigit Mod 11
                '    ChkSum = ChkSum Mod 10
                '    If (ChkSum <> ChkDigit) Then
                '        cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                '        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '        Me.ddlIdType.BackColor = Drawing.Color.LightCyan
                '        Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
                '        Exit Sub

                '    End If

                'End If
                'If ddlIdType.SelectedValue.ToString() = "324004" Then
                '    If Mid(Me.txtIdNumber.Value.ToString(), 1, 1) <> "0" Then
                '        cstext1 = "alert('Error!! Juristic Id No. incorrect.!!!');"
                '        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '        Exit Sub
                '    End If
                'End If
                 If Not System.Text.RegularExpressions.Regex.IsMatch(txtIdNumber.Value, "^[a-z,A-Z,0-9,-]{0,}$") Then
                    cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Me.txtIdNumber.Focus()
                    Exit Sub
                 End If
            '*** [End]->R56100048 Ron (Commented out the following lines of code as requested by UAT)


            Case "324003" '324003 : Tax Id
                Dim var1 As Integer = 0
                '2012-10-03 :: Kwang :: R55020103
                'If Me.txtIdNumber.Value <> "" Then

                '    If Not IsNumeric(Me.txtIdNumber.Value) Then
                '        cstext1 = "alert('Error!! Id No. incorrect.');"
                '        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '        Me.ddlIdType.BackColor = Drawing.Color.LightCyan
                '        Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"

                '        Exit Sub
                '    End If

                '    var1 = Len(Me.txtIdNumber.Value)
                '    If var1 <> 10 Then
                '        cstext1 = "alert('Tax Id must have 10 digits');"
                '        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '        Me.ddlIdType.BackColor = Drawing.Color.LightCyan
                '        Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"

                '        Exit Sub
                '    End If

                '    If Me.txtIdNumber.Value <> "" Then
                '        Dim sumDigit As Integer = 0
                '        Dim lastDigit As Integer = 0
                '        Dim count As Integer = 1
                '        Do While (count < 10)
                '            If count Mod 2 = 1 Then
                '                sumDigit = sumDigit + (Val(Mid(Me.txtIdNumber.Value, count, 1)) * 3)
                '            Else
                '                sumDigit = sumDigit + (Val(Mid(Me.txtIdNumber.Value, count, 1)))
                '            End If
                '            count = count + 1
                '        Loop
                '        sumDigit = sumDigit Mod 10
                '        If sumDigit > 0 Then
                '            sumDigit = 10 - sumDigit
                '        Else
                '            sumDigit = 0
                '        End If
                '        lastDigit = Val(Mid(Me.txtIdNumber.Value, 10, 1))

                '        If sumDigit <> lastDigit Then
                '            cstext1 = "alert('Error!! Id No. incorrect.');"
                '            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '            Me.ddlIdType.BackColor = Drawing.Color.LightCyan
                '            Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"

                '            Exit Sub
                '        End If

                '    End If
                'End If
                '*** [Start]-> R56100048 Ron (Requested by UAT)
                'If Len(Trim(txtIdNumber.Value)) <> 13 Then
                '    cstext1 = "alert('Error!! Tax ID No. should be have 13 degits.');"
                '    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                '    Me.txtIdNumber.Focus()
                '    Exit Sub
                'End If
                 If Not System.Text.RegularExpressions.Regex.IsMatch(txtIdNumber.Value, "^[a-z,A-Z,0-9,-]{0,}$") Then
                    cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Me.txtIdNumber.Focus()
                    Exit Sub
                 End If
                '*** [End]-> R56100048 Ron (Requested by UAT)


            Case "324002"

                If IsNumeric(Mid(Me.txtIdNumber.Value.ToString(), 1, 2)) Then
                    cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Exit Sub
                End If
                Dim conn As OdbcConnection = connDB.getDBConn()
                Dim strsql As String
                Dim dtResultSet As DataSet


                '***56100048 Ron
                'strsql = " select code,value from db2.frcmtbcd where type= 'C003' and flaguse = 'Y'  " & _
                '         " and rtrim('" & UCase(Trim(Mid(Me.txtIdNumber.Value.ToString(), 1, 2))) & "') = code" & _
                '         " order by value "
                strsql = " select code,value from db2.frcmtbcd where type= 'C003' and flaguse = 'Y'  " & _
                         " and rtrim('" & UCase(Trim(Mid(Me.txtIdNumber.Value.ToString(), 1, 2))) & "') = code " & _
                         " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD( _
                          "type= 'C003' and flaguse = 'Y' and rtrim('" & UCase(Trim(Mid(Me.txtIdNumber.Value.ToString(), 1, 2))) & "') = code ", concur.SWIFTCODE) & "' " & _
                         " order by value "

                dtResultSet = connDB.RunQuerySql(strsql)
                If dtResultSet.Tables.Count > 0 Then
                    If dtResultSet.Tables(0).Rows.Count = 0 Then
                        cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        Exit Sub
                    End If
                Else
                    cstext1 = "alert('Error!! Id No. incorrect.!!!');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Exit Sub

                End If
                conn.Close()
        End Select
        If Not chkIdUnique(Trim(txtIdNumber.Value.ToString()), Trim(ddlIdType.SelectedValue.ToString())) Then
            cstext1 = "alert('Error !!! ID No. is Available Used, Please Insert Another Id No.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)

            Exit Sub
        End If


        intRowIden = Session("mintRowIden")
        Mdt = Session("Mdt")
        Mdt.Rows(intRowIden).Item(1) = ddlIdType.SelectedItem.Text.ToString()
        'Mdt.Rows(intRowIden).Item(2) = Me.txtIdNumber.Value
        Mdt.Rows(intRowIden).Item(2) = UCase(txtIdNumber.Value)
        Mdt.Rows(intRowIden).Item(3) = Me.ddlIdType.SelectedValue.ToString()
        GridIdentification.DataSource = Mdt
        GridIdentification.DataBind()
        Session("Mdt") = Mdt

        'Session("flagRateChange") = True

        Me.ButIdenUpdate.Enabled = False
        Me.ButIdenCancel.Enabled = False

        Me.ButAdd.Enabled = True
        Me.ButClear.Enabled = True

        Me.ddlIdType.SelectedIndex = -1
        Me.txtIdNumber.Value = ""
        Me.txtIdNumberThai.Value = ""
        panel_gridIden.Enabled = True


        If Mdt.Rows.Count > 0 Then
            Me.ddlIdType.BackColor = Drawing.Color.White
            Me.txtIdNumber.Style.Value = "background-color: white; text-transform:uppercase;"
            Me.txtIdNumberThai.Style.Value = "background-color: white; text-transform:uppercase;"
        Else
            Me.ddlIdType.BackColor = Drawing.Color.LightCyan
            Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
            Me.txtIdNumberThai.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
        End If

    End Sub

    Protected Sub GridIdentification_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridIdentification.RowCancelingEdit
        GridIdentification.EditIndex = -1
        Session("Mdt") = Mdt
        GridIdentification.DataSource = Mdt
        GridIdentification.DataBind()
    End Sub
    Protected Sub GridIdentification_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridIdentification.RowEditing
    End Sub

    Protected Sub GridIdentification_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridIdentification.SelectedIndexChanging
        Dim row As GridViewRow = GridIdentification.Rows(e.NewSelectedIndex)
        Dim strIdnumber As String

        Session("mintRowIden") = e.NewSelectedIndex

        strIdnumber = Mdt.Rows(e.NewSelectedIndex).Item(2)
        Me.ddlIdType.SelectedIndex = -1
        Me.ddlIdType.Items.FindByValue(Mdt.Rows(e.NewSelectedIndex).Item(3)).Selected = True

        If Me.ddlIdType.SelectedValue.ToString() = "324013" And Session("optCustType") = "C" Then
            Me.txtIdNumberThai.Value = strIdnumber
            Me.txtIdNumberThai.Style.Value = "background-color: lightcyan; text-transform:uppercase;"

        Else
            Me.txtIdNumber.Value = strIdnumber
            Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"

        End If

        panel_gridIden.Enabled = False
        Me.ButIdenCancel.Enabled = True
        Me.ButIdenUpdate.Enabled = True

        Me.ButAdd.Enabled = False
        Me.ButClear.Enabled = False
        Me.ddlIdType.BackColor = Drawing.Color.LightCyan
        'Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"


    End Sub
    Protected Sub GridIdentification_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridIdentification.RowUpdating

        Dim gv As GridView = sender
        If gv.EditIndex > -1 Then
            Mdt = Session("Mdt")
            Mdt.Rows(e.RowIndex).Item(1) = Me.ddlIdType.SelectedValue.ToString()

            'Mdt.Rows(e.RowIndex).Item(2) = Me.txtIdNumber.Value
            If Me.ddlIdType.SelectedValue.ToString() = "324013" And Session("optCustType") = "C" Then
                Mdt.Rows(e.RowIndex).Item(2) = Me.txtIdNumberThai.Value
            Else
                Mdt.Rows(e.RowIndex).Item(2) = Me.txtIdNumber.Value
            End If
            e.Cancel = True
            GridIdentification.EditIndex = -1
            GridIdentification.DataSource = Mdt
            GridIdentification.DataBind()
        End If
        Me.panel_gridAccount.Enabled = True
    End Sub
    Protected Sub GridIdentification_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridIdentification.RowDeleting
        If e.RowIndex < Mdt.Rows.Count Then
            Mdt = Session("Mdt")
            Mdt.Rows(e.RowIndex).Delete()
            GridIdentification.DataSource = Mdt
            GridIdentification.DataBind()
            Session("Mdt") = Mdt

            If Mdt.Rows.Count > 0 Then
                Me.ddlIdType.BackColor = Drawing.Color.White
                Me.txtIdNumber.Style.Value = "background-color: white; text-transform:uppercase;"
                Me.txtIdNumberThai.Style.Value = "background-color: white; text-transform:uppercase;"
            Else
                Me.ddlIdType.BackColor = Drawing.Color.LightCyan
                Me.txtIdNumber.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
                Me.txtIdNumberThai.Style.Value = "background-color: lightcyan; text-transform:uppercase;"
            End If
        End If
    End Sub

    Protected Sub GridIdentification_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridIdentification.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(2).Text = e.Row.RowIndex + 1
        End If
    End Sub


    Protected Sub ButClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButClear.Click

        Me.ddlIdType.SelectedIndex = -1
        Me.txtIdNumber.Value = ""
        Me.txtIdNumberThai.Value = ""


    End Sub


    Private Sub LoadDDL_Province()
        '*** CMHI:2050f95b-bc50-4635-a064-4fe6c1890296
        Dim strSql As String
        Dim dtResultSet As New DataSet
        Dim dtRow As DataRow

        Dim dt As New DataTable
        Dim dr As DataRow

        Dim dtt As New DataTable
        dt.Columns.Add("code")
        dt.Columns.Add("value")
        dr = dt.NewRow

        dr.Item("code") = ""
        dr.Item("value") = ""
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        dt.Rows.Add(dr)
        Dim conn As OdbcConnection = connDB.getDBConn()
        strSql = _
        "select '' as code,'--Please Select Province--' as value " & _
        "from db2.frcmtbcd " & _
        "where type= 'C014' and flaguse = 'Y'  " & _
        "  and (relatedcd is null or relatedcd = '') " & _
        "union " & _
        "(select code,value " & _
        "from db2.frcmtbcd A " & _
        "  INNER JOIN " & _
        "   (" & _
        "    SELECT DISTINCT L2A.SWIFTTCD " & _
        "    FROM DB2.FRCMTBCD L2A " & _
        "    WHERE L2A.TYPE = 'C014' AND FLAGUSE = 'Y' " & _
        "      AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
        "      and (L2A.relatedcd is null or L2A.relatedcd = '')  " & _
        "    ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
        "    ) B " & _
        "   ON A.SWIFTTCD = B.SWIFTTCD " & _
        "where type= 'C014' and flaguse = 'Y' " & _
        "  and (relatedcd is null or relatedcd = '')  " & _
        "order by value )"

        dtResultSet = connDB.RunQuerySql(strSql)
        dtResultSet.Tables.Add(dt)

        If dtResultSet.Tables.Count > 0 Then

            For Each dtRow In dtResultSet.Tables(0).Rows
                ddlProvince.DataSource = dtResultSet.Tables(0)
                ddlProvince.DataValueField = "code"
                ddlProvince.DataTextField = "value"
                ddlProvince.DataBind()
            Next

            Me.ddlDistrict.Enabled = True

        End If
        conn.Close()

    End Sub

    Public Function LoadDDL_District() As DataSet
        '*** CMHI:f9c3eb11-a68a-4841-990d-94acff279c18
        Dim strSql As String
        Dim dtResultSet As DataSet
        Dim dtRow As DataRow

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        strSql = _
        "select '' as code ,'--Please Select District--' as value " & _
        "from db2.frcmtbcd " & _
        "where type= 'C014' and flaguse = 'Y' " & _
        "union " & _
        "(select code,value " & _
        "from db2.frcmtbcd A " & _
        "  INNER JOIN " & _
        "    (" & _
        "     SELECT DISTINCT L2A.SWIFTTCD " & _
        "     FROM DB2.FRCMTBCD L2A " & _
        "     WHERE L2A.TYPE = 'C014' AND FLAGUSE = 'Y' " & _
        "       AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
        "       and left(char(L2A.code),2) = " & _
        "         left(rtrim('" & Me.ddlProvince.SelectedValue.ToString() & "'),2) " & _
        "       and L2A.relatedcd <> '' " & _
        "     ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
        "     ) B " & _
        "   ON A.SWIFTTCD = B.SWIFTTCD " & _
        "where type= 'C014' and flaguse = 'Y' " & _
        "  and left(char(code),2) = " & _
        "    left(rtrim('" & Me.ddlProvince.SelectedValue.ToString() & "'),2) " & _
        "  and relatedcd <> '' " & _
        "order by value )"

        dtResultSet = connDB.RunQuerySql(strSql)

        If dtResultSet.Tables.Count > 0 Then
            For Each dtRow In dtResultSet.Tables(0).Rows
                ddlDistrict.DataSource = dtResultSet.Tables(0)
                ddlDistrict.DataValueField = "code"
                ddlDistrict.DataTextField = "value"
                ddlDistrict.DataBind()
            Next
        End If
        Me.ddlPostCode.DataSource = ""
        Me.ddlPostCode.Items.Add("--Please Select PostCode--")
        Me.ddlPostCode.DataBind()
        Me.ddlPostCode.Enabled = False
        Me.txtPostCode.Visible = False
        Me.txtPostCode.Value = ""
        conn.Close()

        Return dtResultSet
    End Function
    Public Sub LoadDDL_PostCode()
        '*** CMHI:bd905066-a542-4497-a37d-565fdaf58d34
        Dim strSql As String
        Dim dtResultSet As DataSet
        Dim dtPostcode As New DataTable
        Dim ds As New DataSet
        Dim strTmp() As String
        Dim i As Integer
        Dim drPostcode As DataRow

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        dtPostcode.Columns.Add("PostCode")
        strSql = _
        "select '--Please Select Postcode--' as code " & _
        "from db2.frcmtbcd where type = 'C014' " & _
        "  and flaguse = 'Y' union " & _
        "select COALESCE(relatedcd,'') as code " & _
        "from db2.frcmtbcd A " & _
        "  INNER JOIN " & _
        "    (" & _
        "     SELECT DISTINCT L2A.SWIFTTCD " & _
        "     FROM DB2.FRCMTBCD L2A " & _
        "     WHERE L2A.TYPE = 'C014' AND FLAGUSE = 'Y' " & _
        "       and rtrim(L2A.code) = " & _
        "         rtrim('" & Me.ddlDistrict.SelectedValue.ToString() & "') " & _
        "       AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
        "     ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
        "     ) B " & _
        "  ON A.SWIFTTCD = B.SWIFTTCD " & _
        "where type= 'C014' and flaguse = 'Y' " & _
        "  and rtrim(code) = " & _
        "    rtrim('" & Me.ddlDistrict.SelectedValue.ToString() & "') " & _
        "order by code "

        dtResultSet = connDB.RunQuerySql(strSql)
        If dtResultSet.Tables.Count > 0 Then
            Dim dtRow As DataRow
            For Each dtRow In dtResultSet.Tables(0).Rows
                If Trim(dtRow.Item(0)) <> "" Then
                    strTmp = Split(dtRow.Item(0).ToString(), ";", , CompareMethod.Text)
                    For i = 0 To strTmp.Length - 1
                        drPostcode = dtPostcode.NewRow()
                        drPostcode.Item("PostCode") = strTmp(i).ToString()
                        dtPostcode.Rows.Add(drPostcode)
                    Next
                End If
            Next
        Else
            ddlPostCode.Enabled = False
        End If

        ds.Tables.Add(dtPostcode)
        PublicFunc.PopulateDDL(Me.ddlPostCode, ds, "PostCode", "PostCode")

        If Me.ddlPostCode.Items.Count = 2 Then
            Me.ddlPostCode.SelectedIndex = 1
            Me.ddlPostCode.Enabled = False
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        ElseIf Me.ddlPostCode.Items.Count = 1 Then
            If Trim(Me.ddlDistrict.SelectedValue.ToString()) = "" Then
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = False
                Me.txtPostCode.Value = ""
            Else
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = True
            End If
        Else
            Me.ddlPostCode.Enabled = True
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        End If

        conn.Close()

    End Sub
    Protected Sub ddlProvince_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlProvince.SelectedIndexChanged
        If Trim(ddlProvince.SelectedValue.ToString()) <> "" Then
            Me.ddlDistrict.Enabled = True
            LoadDDL_District()
            Me.ddlPostCode.DataSource = ""
            Me.ddlPostCode.Items.Add("--Please Select PostCode--")
            Me.ddlPostCode.DataBind()
            Me.ddlPostCode.Enabled = False
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        Else

            Me.ddlDistrict.DataSource = ""
            Me.ddlDistrict.Items.Add("--Please Select District--")
            Me.ddlDistrict.DataBind()
            Me.ddlDistrict.Enabled = False

            Me.ddlPostCode.DataSource = ""
            Me.ddlPostCode.Items.Add("--Please Select PostCode--")
            Me.ddlPostCode.DataBind()
            Me.ddlPostCode.Enabled = False
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        End If
    End Sub
    Protected Sub ddlDistrict_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlDistrict.SelectedIndexChanged
        Me.ddlPostCode.Enabled = True
        LoadDDL_PostCode()
    End Sub

    Public Function ValidateTabInformation(ByRef strMsgError As String) As Boolean

        ValidateTabInformation = False
        Select Case Session("optCustType")
            Case ""
                Session("optCustType") = "I"
                Me.Radio_typeCust.SelectedValue = "I"
            Case "I"
                If Me.ddlItscNo.SelectedValue.ToString() = "" Then
                    strMsgError = "Error!! ITSC No. should be filled."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 0
                    SetMenuAddCustomer(0)
                    Me.ddlItscNo.Focus()
                    GoTo displayMsg
                End If

                If Me.ddlOcCode_I.SelectedValue.ToString() = "" Then
                    strMsgError = "Error!! OC code should be filled."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 0
                    SetMenuAddCustomer(0)
                    Me.ddlOcCode_I.Focus()
                    GoTo displayMsg
                End If

                If Not IsDate(Me.txtBirthDate.Text.ToString()) Then
                    strMsgError = "Invalid Birth Date."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 0
                    SetMenuAddCustomer(0)
                    Me.txtBirthDate.Focus()
                    GoTo displayMsg
                Else
                    Dim dateCompare As Date
                    dateCompare = Trim(Me.txtBirthDate.Text)
                    If dateCompare >= _
                       Format(Now, "yyyy-MM-dd") Then
                        strMsgError = "Invalid Birth Date."
                        MultiView_addCustomer.ActiveViewIndex = 0
                        MViewTypeCust.ActiveViewIndex = 0
                        SetMenuAddCustomer(0)
                        Me.txtBirthDate.Focus()
                        GoTo displayMsg
                    End If
                End If

                If Trim(Me.ddlNation_code.SelectedValue.ToString()) = "" Then
                    strMsgError = "Error!! Nationality should be filled."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 0
                    SetMenuAddCustomer(0)
                    Me.ddlNation_code.Focus()
                    GoTo displayMsg
                End If

                If Trim(Me.ddlsex.SelectedValue.ToString()) = "" Then
                    strMsgError = "Error!! Sex should be filled."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 0
                    SetMenuAddCustomer(0)
                    Me.ddlsex.Focus()
                    GoTo displayMsg
                End If

                If Trim(Me.ddlcareer.SelectedValue.ToString()) = "" Then
                    strMsgError = "Error!! Career should be filled."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 0
                    SetMenuAddCustomer(0)
                    Me.ddlcareer.Focus()
                    GoTo displayMsg
                End If

            Case "C"
                If Me.ddlItscNO_C.SelectedValue.ToString() = "" Then
                    strMsgError = "Error!! ITSC No. should be filled."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 1
                    SetMenuAddCustomer(0)
                    Me.ddlItscNO_C.Focus()
                    GoTo displayMsg
                End If

                If Me.ddlOcCode_C.SelectedValue.ToString() = "" Then
                    strMsgError = "Error!! OC code should be filled."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 1
                    SetMenuAddCustomer(0)
                    Me.ddlOcCode_C.Focus()
                    GoTo displayMsg
                End If

                If Me.DDL_BusinessType.SelectedValue.ToString() = "" Then
                    strMsgError = "Error!! Business Type should be filled."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 1
                    SetMenuAddCustomer(0)
                    Me.DDL_BusinessType.Focus()
                    GoTo displayMsg
                End If


                If Not IsDate(Me.txtRegDate.Text.ToString()) Then
                    strMsgError = "Invalid Juristic Date."
                    MultiView_addCustomer.ActiveViewIndex = 0
                    MViewTypeCust.ActiveViewIndex = 1
                    SetMenuAddCustomer(0)
                    Me.txtRegDate.Focus()
                    GoTo displayMsg
                Else
                    Dim dateCompare As Date
                    dateCompare = Trim(Me.txtRegDate.Text)
                    If dateCompare > _
                                          Format(Now, "yyyy-MM-dd") Then
                        strMsgError = "Invalid Juristic Date."
                        MultiView_addCustomer.ActiveViewIndex = 0
                        MViewTypeCust.ActiveViewIndex = 1
                        SetMenuAddCustomer(0)
                        Me.txtRegDate.Focus()
                        GoTo displayMsg
                    End If
                End If

        End Select

        '************************General Information********************

        If Trim(Me.CustType.SelectedValue.ToString()) = "" Then
            strMsgError = "Error!! Customer Type should be filled."
            MultiView_addCustomer.ActiveViewIndex = 0
            Select Case Session("optCustType")
                Case "I"
                    MViewTypeCust.ActiveViewIndex = 0
                Case "C"
                    MViewTypeCust.ActiveViewIndex = 1
            End Select
            SetMenuAddCustomer(0)
            Me.CustType.Focus()
            GoTo displayMsg
        End If

        If Trim(txtObjCode.Text.ToString()) = "" Then
            butObjCode.Focus()
            strMsgError = "Error!! Objective Code should be filled."
            MultiView_addCustomer.ActiveViewIndex = 0
            Select Case Session("optCustType")
                Case "I"
                    MViewTypeCust.ActiveViewIndex = 0
                Case "C"
                    MViewTypeCust.ActiveViewIndex = 1
            End Select
            SetMenuAddCustomer(0)
            GoTo displayMsg
        ElseIf Trim(txtSelectObj.Text.ToString()) = "318036" Or _
            Trim(txtSelectObj.Text.ToString()) = "318131" Or _
            Trim(txtSelectObj.Text.ToString()) = "318141" Then

            Me.txtObjDesc.Enabled = True

            If Trim(Me.txtObjDesc.Text) = "" Then
                strMsgError = "Error!! Objcode Description should be filled."
                MultiView_addCustomer.ActiveViewIndex = 0
                MViewTypeCust.ActiveViewIndex = 1
                SetMenuAddCustomer(0)
                Me.txtObjDesc.Focus()
                GoTo displayMsg
            End If
        End If

        '*************Start : Tab Information *****************************************
        If Me.DDLTitle.SelectedValue.ToString() = "" Then
            strMsgError = "Error!! Title name should be filled."
            MultiView_addCustomer.ActiveViewIndex = 0
            Select Case Session("optCustType")
                Case "I"
                    MViewTypeCust.ActiveViewIndex = 0
                Case "C"
                    MViewTypeCust.ActiveViewIndex = 1
            End Select
            SetMenuAddCustomer(0)
            Me.DDLTitle.Focus()
            GoTo displayMsg
        End If

        If Trim(Me.TextName1.Value.ToString()) = "" Then
            strMsgError = "Error!! Name should be filled."
            MultiView_addCustomer.ActiveViewIndex = 0
            Select Case Session("optCustType")
                Case "I"
                    MViewTypeCust.ActiveViewIndex = 0
                Case "C"
                    MViewTypeCust.ActiveViewIndex = 1
            End Select
            SetMenuAddCustomer(0)
            Me.TextName1.Focus()
            GoTo displayMsg
        End If

        If Trim(Me.txtNameRM.Value.ToString()) = "" Then
            strMsgError = "Error!! RM name should be filled."
            MultiView_addCustomer.ActiveViewIndex = 0
            Select Case Session("optCustType")
                Case "I"
                    MViewTypeCust.ActiveViewIndex = 0
                Case "C"
                    MViewTypeCust.ActiveViewIndex = 1
            End Select
            SetMenuAddCustomer(0)
            Me.txtNameRM.Focus()
            GoTo displayMsg
        End If
        '*******************End : Tab Information *********************************************

        '*******************Start Tab Address***************************************************
        If Trim(Me.txtAddressNo.Value.ToString()) = "" Then
            strMsgError = "Error!! Address No. should be filled."
            Me.txtAddressNo.Focus()
            GoTo checkTabAddress
        End If

        If Not IsNumeric(Trim(Me.txtMoo.Value.ToString())) And Trim(Me.txtMoo.Value.ToString()) <> "" Then
            strMsgError = "Error!! Moo is incorrect."
            Me.txtMoo.Focus()
            GoTo checkTabAddress
        End If

        If Trim(Me.txtSubDistrict.Value.ToString()) = "" Then
            strMsgError = "Error!! Sub District should be filled."
            Me.txtSubDistrict.Focus()
            GoTo checkTabAddress
        End If

        If Trim(Me.ddlProvince.SelectedValue.ToString()) = "" Then
            strMsgError = "Error!! Province should be filled."
            Me.ddlProvince.Focus()
            GoTo checkTabAddress
        End If

        If Trim(Me.ddlDistrict.SelectedValue.ToString()) = "" Then
            strMsgError = "Error!! District should be filled."
            Me.ddlDistrict.Focus()
            GoTo checkTabAddress
        End If

        If Me.ddlPostCode.Enabled = False And Me.ddlPostCode.Items.Count = 1 Then
            If Trim(Me.txtPostCode.Value.ToString()) = "" Then
                strMsgError = "Error!! PostCode should be filled."
                Me.txtPostCode.Focus()
                GoTo checkTabAddress
            End If
        ElseIf Me.ddlPostCode.Enabled = True And Me.ddlPostCode.Items.Count > 2 Then
            If Not IsNumeric(Trim(Me.ddlPostCode.SelectedItem.Text.ToString())) Then
                strMsgError = "Error!! PostCode should be filled."
                Me.ddlPostCode.Focus()
                GoTo checkTabAddress
            End If
        ElseIf Me.ddlPostCode.Enabled = False And Me.ddlPostCode.Items.Count = 2 Then
            If Trim(Me.ddlPostCode.SelectedItem.Text.ToString()) = "" Then
                strMsgError = "Error!! PostCode should be filled."
                Me.ddlPostCode.Focus()
                GoTo checkTabAddress
            End If
        ElseIf Me.txtPostCode.Visible = True Then
            If Trim(Me.txtPostCode.Value.ToString()) = "" Then
                strMsgError = "Error!! PostCode should be filled."
                Me.txtPostCode.Focus()
                GoTo checkTabAddress
            ElseIf Not IsNumeric(Trim(txtPostCode.Value.ToString())) And Trim(Me.txtPostCode.Value.ToString()) <> "" Then
                cstext1 = "alert('Please PostCode No incorrect.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Me.txtPostCode.Focus()
                Exit Function
            End If
        End If



        If Trim(Me.ddlContryCode.SelectedValue.ToString()) = "" Then
            strMsgError = "Error!! ContryCode should be filled."
            Me.ddlContryCode.Focus()
            GoTo checkTabAddress
        End If
        '*******************End Tab Address***************************************************


        '*******************Start Tab Identification***************************************************
        If (Mdt.Rows.Count = 0) Or (Mdt Is Nothing) Then
            strMsgError = "Please Insert Identifinication information."
            Me.ddlContryCode.Focus()
            MultiView_addCustomer.ActiveViewIndex = 2
            SetMenuAddCustomer(2)
            loadTabIdentifi()
            GoTo displayMsg
        End If
        '*******************End Tab Identification***************************************************

	
        '*******************Start Tab Account***************************************************
     '   If (ACCDT.Rows.Count = 0) Or (ACCDT Is Nothing) Then
     '       strMsgError = "Please Insert Account information."
     '       Me.ddlContryCode.Focus()
     '       MultiView_addCustomer.ActiveViewIndex = 3
     '       SetMenuAddCustomer(3)
     '       loadTabAccount()
     '       GoTo displayMsg
     '   End If
        '*******************End Tab Account***************************************************

        If Me.panel_SwiftAddr.Enabled = False Then
            'If Trim(Me.txtPostCode.Value.ToString()) = "" Then
            strMsgError = "Please Click Button (Generate Format Address For Swift)."
            Me.butRetiveAdd.Focus()
            GoTo checkTabAddress
            'End If
        Else
            If Session("SearchFor") = "UPDATE" Then
                If Trim(Me.txtAddressL1.Value) = "" And Trim(Me.txtAddressL2.Value) = "" _
                    And Trim(Me.txtAddressL3.Value) = "" Then
                    strMsgError = "Please Click Button (Generate Format Address For Swift)."
                    Me.butRetiveAdd.Focus()
                    GoTo checkTabAddress
                End If
            End If
        End If

        ValidateTabInformation = True
        Exit Function

checkTabAddress:
        MultiView_addCustomer.ActiveViewIndex = 1
        SetMenuAddCustomer(1)
        LoadTabAddress()
        GoTo displayMsg


displayMsg:
        cstext1 = "alert('" & strMsgError & "');"
        cs.RegisterStartupScript(cstype, csname1, cstext1, True)

    End Function
    Protected Sub butObjCode_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butObjCode.Click
        MultiView_addCustomer.ActiveViewIndex = 6
        Panel3.Visible = False
        txtSelectObj.Text = ""
        Me.LabelDisObj.Text = ""
        GridControls()
    End Sub

    Private Sub GridControls()
        '*** CMHI:dc0f51b5-1904-440b-8928-d540544f3352
        Dim strSql As String
        Dim dtResultSet2 As New DataSet
        Dim dtRow As DataRow
        Dim dtTableObj As New DataTable
        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        strSql = " select code, value, relatedcd, description, flaguse " & _
                 " from db2.frcmtbcd A " & _
                 "   INNER JOIN " & _
                 "     (" & _
                 "      SELECT DISTINCT L2A.SWIFTTCD " & _
                 "      FROM DB2.FRCMTBCD L2A " & _
                 "      WHERE L2A.TYPE = 'C001' " & _
                 "        AND SUBSTR(L2A.othinform,2,1) = '1' " & _
                 "        AND ( L2A.relatedcd is null " & _
                 "          or rtrim(L2A.relatedcd) = '') " & _
                 "        AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
                 "      ORDER BY L2A.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
                 "      ) B " & _
                 "   ON A.SWIFTTCD = B.SWIFTTCD " & _
                 " where type = 'C001' and substr(othinform,2,1)= '1' " & _
                 " and ( relatedcd is null or rtrim(relatedcd) = '') " & _
                 " order by code "

        dtResultSet2 = connDB.RunQuerySql(strSql)
        If dtResultSet2.Tables.Count > 0 Then
            dtTableObj.Columns.Add("code")
            dtTableObj.Columns.Add("value")
            dtTableObj.Columns.Add("relatedcd")
            dtTableObj.Columns.Add("description")
            dtTableObj.Columns.Add("flaguse")
            Dim DR As DataRow
            For Each dtRow In dtResultSet2.Tables(0).Rows
                DR = dtTableObj.NewRow
                DR("code") = dtRow.Item(0).ToString()
                DR("value") = dtRow.Item(1).ToString()
                DR("relatedcd") = dtRow.Item(2).ToString()
                DR("description") = dtRow.Item(3).ToString()
                DR("flaguse") = dtRow.Item(4).ToString()
                dtTableObj.Rows.Add(DR)
            Next

            GridObj1.DataSource = dtTableObj
            GridObj1.DataBind()
            GridObj1.SelectedIndex = -1
        End If

        conn.Close()

        GridOBJ2.Visible = False
        GridOBJ3.Visible = False
        GridOBJ4.Visible = False
        GridOBJ5.Visible = False
    End Sub
    Protected Sub GridOBJ1_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridObj1.SelectedIndexChanging
        '*** CMHI:528172ab-cc6e-49a8-b024-06ed28672ba5
        Dim strObjCode As String

        Dim row As GridViewRow = GridObj1.Rows(e.NewSelectedIndex)
        strObjCode = Trim(row.Cells(1).Text)

        Me.txtSelectObj.Text = strObjCode
        Me.LabelDisObj.Text = row.Cells(2).Text

        Dim strSql As String
        Dim dtResultSet2 As New DataSet
        Dim dtRow As DataRow
        Dim dtTableObj As New DataTable

        GridOBJ3.Visible = True
        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        strSql = "select code, value, relatedcd, " & _
                 "  description, flaguse " & _
                 "from db2.frcmtbcd A " & _
                 "  INNER JOIN " & _
                 "    (" & _
                 "     SELECT DISTINCT L2A.SWIFTTCD " & _
                 "     FROM DB2.FRCMTBCD L2A " & _
                 "     WHERE L2A.TYPE = 'C001' " & _
                 "       AND substr(L2A.othinform,2,1)= '1' " & _
                 "       AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
                 "       AND relatedcd = '" & strObjCode & "' " & _
                 "     ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
                 "     ) B " & _
                 "  ON A.SWIFTTCD = B.SWIFTTCD " & _
                 "where type = 'C001' and substr(othinform,2,1)= '1' " & _
                 "  and relatedcd = '" & strObjCode & "' " & _
                 "order by code "

        dtResultSet2 = connDB.RunQuerySql(strSql)
        If dtResultSet2.Tables.Count > 0 Then

            dtTableObj.Columns.Add("code")
            dtTableObj.Columns.Add("value")
            dtTableObj.Columns.Add("relatedcd")
            dtTableObj.Columns.Add("description")
            dtTableObj.Columns.Add("flaguse")
            Dim DR As DataRow
            For Each dtRow In dtResultSet2.Tables(0).Rows
                DR = dtTableObj.NewRow
                DR("code") = dtRow.Item(0).ToString()
                DR("value") = dtRow.Item(1).ToString()
                DR("relatedcd") = dtRow.Item(2).ToString()
                DR("description") = dtRow.Item(3).ToString()
                DR("flaguse") = dtRow.Item(4).ToString()
                dtTableObj.Rows.Add(DR)
            Next
            GridOBJ2.DataSource = dtTableObj
            GridOBJ2.DataBind()
            GridOBJ2.SelectedIndex = -1
        End If

        conn.Close()
        GridOBJ2.Visible = True
        GridOBJ3.Visible = False
        GridOBJ4.Visible = False
        GridOBJ5.Visible = False

    End Sub
    Protected Sub GridOBJ2_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridOBJ2.SelectedIndexChanging
        '*** CMHI:f8b791c4-2a23-4a4b-a30b-017858cbc374
        Dim strObjCode As String



        Dim row As GridViewRow = GridOBJ2.Rows(e.NewSelectedIndex)
        strObjCode = Trim(row.Cells(1).Text)
        Me.txtSelectObj.Text = strObjCode
        Me.LabelDisObj.Text = row.Cells(2).Text

        Dim strSql As String
        Dim dtResultSet2 As New DataSet
        Dim dtRow As DataRow
        Dim dtTableObj As New DataTable

        GridOBJ4.Visible = False
        GridOBJ5.Visible = False

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        strSql = _
        "select code, value, relatedcd, description, flaguse " & _
        "from db2.frcmtbcd A " & _
        "  INNER JOIN " & _
        "    (" & _
        "     SELECT DISTINCT L2A.SWIFTTCD " & _
        "     FROM DB2.FRCMTBCD L2A " & _
        "     WHERE L2A.TYPE = 'C001' " & _
        "       and substr(L2A.othinform,2,1)= '1' " & _
        "       and L2A.relatedcd = '" & strObjCode & "' " & _
        "       AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
        "     ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
        "     ) B " & _
        "  ON A.SWIFTTCD = B.SWIFTTCD " & _
        "where type = 'C001' and substr(othinform,2,1)= '1' " & _
        "  and relatedcd = '" & strObjCode & "' " & _
        "order by code "

        dtResultSet2 = connDB.RunQuerySql(strSql)
        If dtResultSet2.Tables.Count > 0 Then
            dtTableObj.Columns.Add("code")
            dtTableObj.Columns.Add("value")
            dtTableObj.Columns.Add("relatedcd")
            dtTableObj.Columns.Add("description")
            dtTableObj.Columns.Add("flaguse")
            Dim DR As DataRow
            For Each dtRow In dtResultSet2.Tables(0).Rows
                DR = dtTableObj.NewRow
                DR("code") = dtRow.Item(0).ToString()
                DR("value") = dtRow.Item(1).ToString()
                DR("relatedcd") = dtRow.Item(2).ToString()
                DR("description") = dtRow.Item(3).ToString()
                DR("flaguse") = dtRow.Item(4).ToString()
                dtTableObj.Rows.Add(DR)
            Next
            GridOBJ3.DataSource = dtTableObj
            GridOBJ3.DataBind()
            GridOBJ3.SelectedIndex = -1
        End If
        conn.Close()

        GridOBJ3.Visible = True
    End Sub
    Protected Sub GridOBJ3_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridOBJ3.SelectedIndexChanging
        '*** CMHI:e8515100-e35a-45be-a414-f8ed99b7e03f
        Dim strObjCode As String

        Dim row As GridViewRow = GridOBJ3.Rows(e.NewSelectedIndex)
        strObjCode = Trim(row.Cells(1).Text)
        Me.txtSelectObj.Text = strObjCode
        Me.LabelDisObj.Text = row.Cells(2).Text


        Dim strSql As String
        Dim dtResultSet2 As New DataSet
        Dim dtRow As DataRow
        Dim dtTableObj As New DataTable

        GridOBJ5.Visible = False

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        strSql = "select code, value, relatedcd, description, flaguse " & _
                 "from db2.frcmtbcd A " & _
                 "  INNER JOIN " & _
                 "    (" & _
                 "     SELECT DISTINCT L2A.SWIFTTCD " & _
                 "     FROM DB2.FRCMTBCD L2A " & _
                 "     WHERE L2A.TYPE = 'C001' " & _
                 "       and substr(L2A.othinform,2,1)= '1' " & _
                 "       and L2A.relatedcd = '" & strObjCode & "' " & _
                 "       AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
                 "     ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
                 "     ) B " & _
        "  ON A.SWIFTTCD = B.SWIFTTCD " & _
                 "where type = 'C001' and substr(othinform,2,1)= '1' " & _
                 "  and relatedcd = '" & strObjCode & "' " & _
                 "order by code "

        dtResultSet2 = connDB.RunQuerySql(strSql)
        If dtResultSet2.Tables.Count > 0 Then
            dtTableObj.Columns.Add("code")
            dtTableObj.Columns.Add("value")
            dtTableObj.Columns.Add("relatedcd")
            dtTableObj.Columns.Add("description")
            dtTableObj.Columns.Add("flaguse")
            Dim DR As DataRow
            For Each dtRow In dtResultSet2.Tables(0).Rows
                DR = dtTableObj.NewRow
                DR("code") = dtRow.Item(0).ToString()
                DR("value") = dtRow.Item(1).ToString()
                DR("relatedcd") = dtRow.Item(2).ToString()
                DR("description") = dtRow.Item(3).ToString()
                DR("flaguse") = dtRow.Item(4).ToString()
                dtTableObj.Rows.Add(DR)
            Next
            GridOBJ4.DataSource = dtTableObj
            GridOBJ4.DataBind()
            GridOBJ4.SelectedIndex = -1
        End If

        conn.Close()
        GridOBJ4.Visible = True

    End Sub
    Protected Sub GridOBJ4_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridOBJ4.SelectedIndexChanging
        '*** CMHI:a86725e0-76e1-45ab-a8f7-98205b360a44
        Dim strObjCode As String

        Dim row As GridViewRow = GridOBJ4.Rows(e.NewSelectedIndex)
        strObjCode = Trim(row.Cells(1).Text)
        Me.txtSelectObj.Text = strObjCode
        Me.LabelDisObj.Text = row.Cells(2).Text

        Dim strSql As String
        Dim dtResultSet2 As New DataSet
        Dim dtRow As DataRow
        Dim dtTableObj As New DataTable
        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        strSql = "select code, value, relatedcd, description, flaguse " & _
                 "from db2.frcmtbcd A " & _
                 "  INNER JOIN " & _
                 "    (" & _
                 "     SELECT DISTINCT L2A.SWIFTTCD " & _
                 "     FROM DB2.FRCMTBCD L2A " & _
                 "     WHERE L2A.TYPE = 'C001' " & _
                 "       and substr(L2A.othinform,2,1)= '1' " & _
                 "       and L2A.relatedcd = '" & strObjCode & "' " & _
                 "       AND L2A.SWIFTTCD IN('','" & concur.SWIFTCODE & "') " & _
                 "     ORDER BY L2a.SWIFTTCD DESC FETCH FIRST 1 ROW ONLY " & _
                 "     ) B " & _
        "  ON A.SWIFTTCD = B.SWIFTTCD " & _
                 "where type = 'C001' and substr(othinform,2,1)= '1' " & _
                 "  and relatedcd = '" & strObjCode & "' " & _
                 "order by code "

        dtResultSet2 = connDB.RunQuerySql(strSql)

        If dtResultSet2.Tables.Count > 0 Then
            dtTableObj.Columns.Add("code")
            dtTableObj.Columns.Add("value")
            dtTableObj.Columns.Add("relatedcd")
            dtTableObj.Columns.Add("description")
            dtTableObj.Columns.Add("flaguse")
            Dim DR As DataRow
            For Each dtRow In dtResultSet2.Tables(0).Rows
                DR = dtTableObj.NewRow
                DR("code") = dtRow.Item(0).ToString()
                DR("value") = dtRow.Item(1).ToString()
                DR("relatedcd") = dtRow.Item(2).ToString()
                DR("description") = dtRow.Item(3).ToString()
                DR("flaguse") = dtRow.Item(4).ToString()
                dtTableObj.Rows.Add(DR)
            Next
            GridOBJ5.DataSource = dtTableObj
            GridOBJ5.DataBind()
            GridOBJ5.SelectedIndex = -1
        End If
        conn.Close()
        GridOBJ5.Visible = True
    End Sub

    Protected Sub ButSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButSelect.Click
        Dim strSql As String
        Dim dtResultSet2 As DataSet
        Dim strMsgError As String
        Dim dtrow As DataRow

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        '***56100048 Ron
        'strSql = " select flaguse " & _
        '         " from db2.frcmtbcd " & _
        '         " where type = 'C001' and substr(othinform,2,1)= '1' and code = '" & Trim(Me.txtSelectObj.Text.ToString) & "' "
        strSql = " select flaguse " & _
                 " from db2.frcmtbcd " & _
                 " where type = 'C001' " & _
                 "  and substr(othinform,2,1)= '1' " & _
                 "  and code = '" & Trim(Me.txtSelectObj.Text.ToString) & "' " & _
                 "  AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C001' and substr(othinform,2,1)= '1' and code = '" & Trim(Me.txtSelectObj.Text.ToString) & "' ", concur.SWIFTCODE) & "' "


        dtResultSet2 = connDB.RunQuerySql(strSql)

        For Each dtrow In dtResultSet2.Tables(0).Rows
            If Trim(dtrow.Item(0).ToString()) = "N" Then
                strMsgError = "Error! Can not Select The Parent Code"
                cstext1 = "alert('" & strMsgError & "');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            Else
                Session("OBJCODE") = Me.txtSelectObj.Text
                Session("OBJCODEDIS") = Me.LabelDisObj.Text

                MultiView_addCustomer.ActiveViewIndex = 0
                Me.txtObjCode.Text = Session("OBJCODE")
                Me.txtObjDesc.Text = Session("OBJCODEDIS")


                If Trim(txtSelectObj.Text.ToString()) = "318036" Or _
                Trim(txtSelectObj.Text.ToString()) = "318131" Or _
                Trim(txtSelectObj.Text.ToString()) = "318141" Then
                    Select Case Session("SearchFor")
                        Case "INSERT"
                            Me.txtObjDesc.Enabled = True
                            Me.txtObjDesc.Text = ""
                            Me.txtObjDesc.BackColor = Drawing.Color.LightYellow
                            Me.txtObjDesc.Focus()
                        Case "UPDATE"
                            Me.txtObjDesc.Enabled = True
                            Me.txtObjDesc.BackColor = Drawing.Color.LightYellow
                            Me.txtObjDesc.Focus()
                    End Select
                Else
                    Me.txtObjDesc.Enabled = False
                End If



                Panel3.Visible = True
                Exit Sub

            End If
        Next

        conn.Close()
    End Sub


    Protected Sub ButAddAcc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButAddAcc.Click
        '*** CMHI:2188d99e-5e74-4323-935e-f970b24cc7ed
        Dim dr As DataRow
        Dim strChkMain As String = "N"
        Dim strRecAc, temp As String
        Dim i As Integer
        Dim strSql As String = ""

        If ChkMain.Checked Then
            strChkMain = "Y"
        End If

        If Not ACCDT Is Nothing Then

            If ACCDT.Rows.Count > 19 Then
                cstext1 = "alert('Maximum Record.Can not Insert Account');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If


            If ACCDT.Rows.Count > 0 Then
                For i = 0 To ACCDT.Rows.Count - 1
                    If ACCDT.Rows(i).Item(1).ToString = Me.txtAcNO.Value.ToString Then
                        cstext1 = "alert('Please Insert New Account');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        ButClearAcc_Click(sender, e)
                        Exit Sub
                    End If
                    '************************************
                    '2008-02-07 :: main account 
                    If ChkMain.Checked Then
                        If Not chkMainAcc(Trim(Me.txtAcNO.Value.ToString())) Then
                            MultiView_addCustomer.ActiveViewIndex = 3
                            SetMenuAddCustomer(3)
                            cstext1 = "alert('Can not add new account to main account. ');"
                            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                            Exit Sub
                        End If

                        If ACCDT.Rows(i).Item(4).ToString = "Y" Then
                            ACCDT.Rows(i).Item(4) = "N"
                        End If
                    End If

                    '************************************
                Next
            End If
        End If

        If Not validateAccount() Then
            Exit Sub
        End If

        strRecAc = ""
        For i = 1 To Len(Trim(txtAcNO.Value))
            temp = Asc(Mid(Trim(txtAcNO.Value.ToString()), i, 1))
            If (temp >= 48 And temp <= 57) Or (temp >= 65 And temp <= 90) Or (temp >= 97 And temp <= 122) Then
                strRecAc = strRecAc & Mid(Trim(txtAcNO.Value), i, 1)
            End If
        Next i

        '2010-03-09 : Tom
        'If CInt(txtAcNO.Value) = 0 Then
        '2010-03-08 :: FCD Account
        If CLng(txtAcNO.Value) = 0 Then
            cstext1 = "alert('Error!! Account incorrect.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Exit Sub
        End If

        If Not chkAddAcc(Trim(strRecAc)) Then
            cstext1 = "alert('Error !!! Account is Available Used, Please Insert Another Account.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)

            Exit Sub
        End If


        Dim strAcCode As String = Trim(ddlAcType.SelectedValue.ToString())

'[Start]->Ron@56100048
        If Len(strRecAc) <> 13 Then
            cstext1 = "alert('Error!! Account incorrect.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Exit Sub
        End If
        ''If Len(strRecAc) > 10 Then
        ''    If (strAcCode = "00" Or strAcCode = "01" Or strAcCode = "02" Or strAcCode = "03") Then
        ''        cstext1 = "alert('Error!! Account incorrect.');"
        ''        cs.RegisterStartupScript(cstype, csname1, cstext1, True)

        ''        Exit Sub
        ''    End If
        ''ElseIf Len(strRecAc) = 10 Then
        ''    If strAcCode <> "00" And strAcCode <> "01" And strAcCode <> "02" And strAcCode <> "03" Then
        ''        cstext1 = "alert('Error!! Account incorrect.');"
        ''        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        ''        Exit Sub
        ''    End If
        ''    '***R56100048 Repalce "THB"
        ''    'If UCase(Trim(Me.ddlCurrency.SelectedValue.ToString())) <> "THB" Then
        ''    If UCase(Trim(Me.ddlCurrency.SelectedValue.ToString())) <> _
        ''     CType(Session("concurrencyInfo"), _
        ''     FORWEB_Concurrency).BaseCurrency Then
        ''        cstext1 = "alert('Error!! Account incorrect.');"
        ''        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        ''        Exit Sub
        ''    End If
        ''End If
'[End]->Ron@56100048

        Select Case UCase(Trim(Me.ddlCurrency.SelectedValue.ToString()))
            'Case "THB"
            Case CType(Session("concurrencyInfo"), _
             FORWEB_Concurrency).BaseCurrency
                If Not chkDigitSAFEAc(Trim(strRecAc)) Then
                    cstext1 = "alert('Error!! Account incorrect.');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)

                    Exit Sub
                End If
            Case Else
                If Not chkDigitFCDAc(Trim(strRecAc)) Then
                    cstext1 = "alert('Error!! Account incorrect.');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Exit Sub
                End If
        End Select

        dr = ACCDT.NewRow
        dr("NO") = ACCDT.Rows.Count + 1
        dr("ACC_NO") = strRecAc
        dr("ACC_TYPE") = ddlAcType.SelectedItem.Text.ToString()
        dr("ACC_CUR") = ddlCurrency.SelectedItem.Text.ToString()
        dr("CHK_MAIN") = strChkMain
        dr("ACCCODE") = ddlAcType.SelectedValue.ToString()
        dr("ACCCUR") = ddlCurrency.SelectedValue.ToString()
        ACCDT.Rows.Add(dr)

        GridAccount.DataSource = ACCDT
        GridAccount.DataBind()
        Session("ACCDT") = ACCDT

        ButClearAcc_Click(sender, e)
        Me.ChkMain.Enabled = True
        If ACCDT.Rows.Count > 0 Then
            Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: white"
            Me.ddlAcType.BackColor = Drawing.Color.White
            Me.ddlCurrency.BackColor = Drawing.Color.White
            Me.ChkMain.BackColor = Drawing.Color.White
        Else
            Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: lightcyan"
            Me.ddlAcType.BackColor = Drawing.Color.LightCyan
            Me.ddlCurrency.BackColor = Drawing.Color.LightCyan
            Me.ChkMain.BackColor = Drawing.Color.LightCyan
        End If

    End Sub

    Protected Sub GridAccount_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridAccount.RowCancelingEdit
        GridIdentification.EditIndex = -1
        Session("Mdt") = Mdt
        GridIdentification.DataSource = Mdt
        GridIdentification.DataBind()
    End Sub
    Protected Sub GridAccount_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridAccount.RowEditing

    End Sub
    Protected Sub GridAccount_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridAccount.RowUpdating

        Dim intRowAcc As Integer
        Dim strChkMain As String = "N"

        If ChkMain.Checked Then
            strChkMain = "Y"
        End If


        intRowAcc = Session("mintRowAcc")
        ACCDT = Session("ACCDT")
        If Me.ddlIdType.SelectedValue.ToString() = "324013" And Session("optCustType") = "C" Then
            ACCDT.Rows(intRowAcc).Item(1) = Me.txtIdNumberThai.Value
        Else
            ACCDT.Rows(intRowAcc).Item(1) = Me.txtIdNumber.Value
        End If
        ACCDT.Rows(intRowAcc).Item(2) = Me.ddlAcType.SelectedItem.Text.ToString()
        ACCDT.Rows(intRowAcc).Item(3) = Me.ddlCurrency.SelectedItem.Text.ToString()
        ACCDT.Rows(intRowAcc).Item(4) = strChkMain
        ACCDT.Rows(intRowAcc).Item(5) = Me.ddlAcType.SelectedValue.ToString()
        ACCDT.Rows(intRowAcc).Item(6) = Me.ddlCurrency.SelectedValue.ToString()

        GridAccount.EditIndex = -1
        GridAccount.DataSource = ACCDT
        GridAccount.DataBind()
        Session("ACCDT") = ACCDT

    End Sub
    Protected Sub GridAccount_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridAccount.SelectedIndexChanging
        Dim strAccdt As String

        Session("mintRowAcc") = e.NewSelectedIndex
        Me.txtAcNO.Value = ACCDT.Rows(e.NewSelectedIndex).Item(1)
        strAccdt = ACCDT.Rows(e.NewSelectedIndex).Item(2)
        ' �ӡ�� focus ��ѧ value ���ç�Ѻ row ��� edit
        ddlAcType.SelectedIndex = -1
        ddlCurrency.SelectedIndex = -1

        ddlAcType.Items.FindByValue(ACCDT.Rows(e.NewSelectedIndex).Item(5)).Selected = True
        ddlCurrency.Items.FindByValue(ACCDT.Rows(e.NewSelectedIndex).Item(6)).Selected = True

        If ACCDT.Rows(e.NewSelectedIndex).Item(4) = "Y" Then
            Me.ChkMain.Checked = True
            Me.ChkMain.Enabled = False
        Else
            Me.ChkMain.Checked = False
            Me.ChkMain.Enabled = True
        End If
        '*************************************************
        Me.panel_gridAccount.Enabled = False

        Me.ButUpdateAcc.Enabled = True
        Me.ButCanAcc.Enabled = True

        Me.ButAddAcc.Enabled = False
        Me.ButClearAcc.Enabled = False

        Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: lightcyan"
        Me.ddlAcType.BackColor = Drawing.Color.LightCyan
        Me.ddlCurrency.BackColor = Drawing.Color.LightCyan
        Me.ChkMain.BackColor = Drawing.Color.LightCyan
    End Sub
    Protected Sub GridAccount_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridAccount.RowDeleting

        Dim blnUpdate As Boolean = True

        If e.RowIndex < ACCDT.Rows.Count Then
            ACCDT = Session("ACCDT")
            If Not ACCDT Is Nothing Then
                Dim strsql As String
                Dim tmpAccount As String = ACCDT.Rows(e.RowIndex).Item(1).ToString()
                '------------------------------------------------------------------------------------------------
                'Check account ����� account � table ����� � check ��� ���  account ��� �١��ҹ������������
                '�������ա���� delete �����
                strsql = " select acno,actype,accurcd from db2.forlcuac where " & _
                         " forcustid = '" & Trim(Session("strCustid")) & "' and " & _
                         " acno = '" & Trim(tmpAccount) & "'"

                Dim ResultSetAcc = connDB.RunQuerySql(strsql)
                If ResultSetAcc.Tables.Count > 0 Then
                    If ResultSetAcc.Tables(0).Rows.Count > 0 Then
                        GoTo StepChkAccProcess
                    Else
                        GoTo StepDeleteAccNormal
                    End If
                Else
                    GoTo StepDeleteAccNormal
                End If

                '------------------------------------------------------------------------------------------------

StepChkAccProcess:
                '2010-09-02
                '       strsql = " select a.senac from db2.forwdrac a  " & _
                '" left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                '" where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                '" and a.senac = '" & Trim(tmpAccount) & "' " & _
                '" union all " & _
                '" select a.dracno from db2.foropaid a " & _
                '" left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                '" where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC') " & _
                '" and a.dracno = '" & Trim(tmpAccount) & "' " & _
                '" union all " & _
                '" select a.dracno from db2.FOROFEDT a " & _
                '" left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                '" where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC')" & _
                '" and a.dracno = '" & Trim(tmpAccount) & "' "

                'strsql = " select a.senac from db2.forwdrac a  " & _
                '         " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                '         " and a.senac = '" & Trim(tmpAccount) & "' " & _
                '         " union all " & _
                '         " select a.dracno from db2.foropaid a " & _
                '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
                '         " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                '         " union all " & _
                '         " select a.dracno from db2.FOROFEDT a " & _
                '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')" & _
                '         " and a.dracno = '" & Trim(tmpAccount) & "' "

                'Kwang :: R53060089
                strsql = " select a.senac from db2.forwdrac a  " & _
                         " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                         " and b.senid not in (select senid from db2.forotran where procstat not in ('DL', 'RJ' , 'SC', 'CC','WS') )" & _
                         " and a.senac = '" & Trim(tmpAccount) & "' " & _
                         " union all " & _
                         " select a.dracno from db2.foropaid a " & _
                         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
                         " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                         " union all " & _
                         " select a.dracno from db2.FOROFEDT a " & _
                         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')" & _
                         " and a.dracno = '" & Trim(tmpAccount) & "' "

                Dim dtResultSetSenId As New DataSet
                Dim connSenId As OdbcConnection = connDB.getDBConn()
                Dim blnCanUpdate As Boolean

                dtResultSetSenId = connDB.RunQuerySql(strsql)

                If dtResultSetSenId.Tables.Count > 0 Then
                    If dtResultSetSenId.Tables(0).Rows.Count > 0 Then
                        blnCanUpdate = False
                    Else
                        blnCanUpdate = True
                    End If
                Else
                    blnCanUpdate = True
                End If

                connSenId.Close()

                If Not blnCanUpdate Then

                    MultiView_addCustomer.ActiveViewIndex = 3
                    SetMenuAddCustomer(3)

                    cstext1 = "alert('Can not update because account is processing. ');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Exit Sub
                End If
                '*********************************************************************************

StepDeleteAccNormal:
                If ACCDT.Rows(e.RowIndex).Item(4) = "Y" Then

                    'If ACCDT.Rows.Count = 2 Then
                    Dim i As Integer = e.RowIndex
                    Dim j As Integer

                    For j = 0 To ACCDT.Rows.Count - 1
                        If j = i Then GoTo stepNext_j
                        tmpAccount = ACCDT.Rows(j).Item(1).ToString()

                        '*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
                        '2010-09-02
                        'strsql = " select a.senac from db2.forwdrac a  " & _
                        '         " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                        '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                        '         " and a.senac = '" & Trim(tmpAccount) & "' " & _
                        '         " union all " & _
                        '         " select a.dracno from db2.foropaid a " & _
                        '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                        '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC') " & _
                        '         " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                        '         " union all " & _
                        '         " select a.dracno from db2.FOROFEDT a " & _
                        '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                        '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC')" & _
                        '         " and a.dracno = '" & Trim(tmpAccount) & "' "


                        'strsql = " select a.senac from db2.forwdrac a  " & _
                        '         " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                        '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                        '         " and a.senac = '" & Trim(tmpAccount) & "' " & _
                        '         " union all " & _
                        '         " select a.dracno from db2.foropaid a " & _
                        '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                        '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
                        '         " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                        '         " union all " & _
                        '         " select a.dracno from db2.FOROFEDT a " & _
                        '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                        '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')" & _
                        '         " and a.dracno = '" & Trim(tmpAccount) & "' "
                        'Kwang :: R53060089 
                        strsql = " select a.senac from db2.forwdrac a  " & _
                                 " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                                 " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                                 " and b.senid not in (select senid from db2.forotran where procstat not in ('DL', 'RJ' , 'SC', 'CC','WS') )" & _
                                 " and a.senac = '" & Trim(tmpAccount) & "' " & _
                                 " union all " & _
                                 " select a.dracno from db2.foropaid a " & _
                                 " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                                 " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
                                 " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                                 " union all " & _
                                 " select a.dracno from db2.FOROFEDT a " & _
                                 " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                                 " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')" & _
                                 " and a.dracno = '" & Trim(tmpAccount) & "' "

                        Dim dtResultSet As New DataSet
                        Dim conn As OdbcConnection = connDB.getDBConn()


                        dtResultSet = connDB.RunQuerySql(strsql)

                        If dtResultSet.Tables.Count > 0 Then
                            If dtResultSet.Tables(0).Rows.Count > 0 Then
                                blnUpdate = False
                            Else
                                blnUpdate = True
                            End If
                        Else
                            blnUpdate = True
                        End If

                        conn.Close()

                        If blnUpdate = True Then Exit For

                        'MultiView_addCustomer.ActiveViewIndex = 3
                        '    SetMenuAddCustomer(3)

                        '    cstext1 = "alert('Can not delete because main account . ');"
                        '    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        '    Exit Sub
                        'End If
                        '*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
stepNext_j:
                    Next

                    'End If

                    If blnUpdate Then
                        If ACCDT.Rows.Count > 0 Then
                            'ACCDT.Rows(j).Item(4) = "Y"
                            ACCDT.Rows(e.RowIndex).Item(4) = "Y"
                        End If

                        ACCDT.Rows(e.RowIndex).Delete()
                        GridAccount.DataSource = ACCDT
                        GridAccount.DataBind()


                    Else
                        MultiView_addCustomer.ActiveViewIndex = 3
                        SetMenuAddCustomer(3)

                        cstext1 = "alert('Can not delete this account. Because will be impact to account that processing.');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        Exit Sub
                    End If

                Else
                    ACCDT.Rows(e.RowIndex).Delete()
                End If
            End If
            '************************************
            GridAccount.DataSource = ACCDT
            GridAccount.DataBind()
            Session("ACCDT") = ACCDT
            ButClearAcc_Click(sender, e)

            If ACCDT.Rows.Count = 0 Then
                Me.ChkMain.Checked = True
                Me.ChkMain.Enabled = False
            Else

            End If

        End If

        If ACCDT.Rows.Count > 0 Then
            Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: white"
            Me.ddlAcType.BackColor = Drawing.Color.White
            Me.ddlCurrency.BackColor = Drawing.Color.White
            Me.ChkMain.BackColor = Drawing.Color.White
        Else
            Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: lightcyan"
            Me.ddlAcType.BackColor = Drawing.Color.LightCyan
            Me.ddlCurrency.BackColor = Drawing.Color.LightCyan
            Me.ChkMain.BackColor = Drawing.Color.LightCyan
        End If
    End Sub
    Protected Sub GridAccount_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridAccount.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(2).Text = e.Row.RowIndex + 1
        End If
    End Sub


    Protected Sub ButAddFEE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButAddFEE.Click
        Dim i As Integer
        If Not DT_FEE Is Nothing Then
            If DT_FEE.Rows.Count > 19 Then
                cstext1 = "alert('Maximum Record.Can not Insert Fee');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If
        End If


        If ddlProdName.SelectedValue.ToString() = "" Then
            cstext1 = "alert('Please Select Product Name');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            ddlProdName.Focus()
            Exit Sub
        End If

        If ddlFeeName.Items.Count > 0 Then
            If ddlFeeName.SelectedValue.ToString() = "" Then
                cstext1 = "alert('Please Select Fee Name');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                ddlFeeName.Focus()
                Exit Sub
            End If
        End If

        If ddlFeeType.SelectedValue.ToString() = "" Then
            cstext1 = "alert('Please Select Fee Type');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            ddlFeeType.Focus()
            Exit Sub
        End If

        If Trim(Me.txtFeeMagin.Text.ToString()) = "" Then Me.txtFeeMagin.Text = "0.0000000"
        If Trim(Me.txtMinFee.Text.ToString()) = "" Then Me.txtMinFee.Text = "0.00"
        If Trim(Me.txtMaxFee.Text.ToString()) = "" Then Me.txtMaxFee.Text = "0.00"

        If CDbl(Replace(Trim(Me.txtMinFee.Text.ToString()), ",", "")) > CDbl(Replace(Trim(Me.txtMaxFee.Text.ToString()), ",", "")) Then
            cstext1 = "alert('Error!! Maximum Fee should be more than Minimum Fee.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            txtMaxFee.Focus()
            Exit Sub
        End If
        If Not DT_FEE Is Nothing Then
            If DT_FEE.Rows.Count > 0 Then
                For i = 0 To DT_FEE.Rows.Count - 1
                    If DT_FEE.Rows(i).Item(7).ToString = Me.ddlProdName.SelectedValue.ToString() And _
                       DT_FEE.Rows(i).Item(8).ToString = Me.ddlFeeName.SelectedValue.ToString() And _
                       DT_FEE.Rows(i).Item(10).ToString = Me.ddlCurrencyBYfeecd.SelectedValue.ToString() Then
                        cstext1 = "alert('Please Insert New Value');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        ButClearFEE_Click(sender, e)
                        Exit Sub
                    End If
                Next
            End If
        End If

        Dim dr As DataRow
        dr = DT_FEE.NewRow

        dr("NO") = DT_FEE.Rows.Count + 1
        dr("PRONAME") = ddlProdName.SelectedItem.Text.ToString()
        If ddlFeeName.Items.Count > 0 Then
            dr("FEENAME") = ddlFeeName.SelectedItem.Text.ToString()
        Else
            dr("FEENAME") = ""
        End If

        dr("FEETYPE") = ddlFeeType.SelectedItem.Text.ToString()
        dr("FEEMAGIN") = Format(CDec(txtFeeMagin.Text.ToString()), "##,##0.0000000")
        dr("FEEMIN") = Format(CDec(txtMinFee.Text.ToString()), "##,##0.00")
        dr("FEEMAX") = Format(CDec(txtMaxFee.Text.ToString()), "##,##0.00")
        dr("PROCODE") = ddlProdName.SelectedValue.ToString()
        dr("FEECODE") = ddlFeeName.SelectedValue.ToString()
        dr("FEETYPECODE") = ddlFeeType.SelectedValue.ToString()
        'Kwang R52030022
        dr("FEECUR") = Me.ddlCurrencyBYfeecd.SelectedValue.ToString()

        DT_FEE.Rows.Add(dr)

        GridFee.DataSource = DT_FEE
        GridFee.DataBind()
        Session("DT_FEE") = DT_FEE

        Session("flagFeeChange") = True
        ButClearFEE_Click(sender, e)
        Me.GridFee.Enabled = True
    End Sub



    Protected Sub GridFee_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridFee.RowCancelingEdit
        GridFee.EditIndex = -1
        Session("Mdt") = Mdt
        GridIdentification.DataSource = Mdt
        GridIdentification.DataBind()
    End Sub


    Protected Sub GridFee_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridFee.RowDeleting
        If e.RowIndex < DT_FEE.Rows.Count Then
            DT_FEE = Session("DT_FEE")
            DT_FEE.Rows(e.RowIndex).Delete()
            GridFee.DataSource = DT_FEE
            GridFee.DataBind()
            Session("DT_FEE") = DT_FEE
            Session("flagFeeChange") = True
        End If
    End Sub

    Protected Sub GridFee_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridFee.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(2).Text = e.Row.RowIndex + 1
        End If

    End Sub

    Protected Sub ddlProdName_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlProdName.SelectedIndexChanged
        Dim strSQL As String
        Dim strFeeCode As String
        Dim dtResultSet, dtResultSet2 As DataSet
        Dim dtRow, dtRow2 As DataRow
        Dim strValue As String = ""
        Dim strText As String = ""
        'Dim dtFeename As New DataTable
        'R52030022
        'If Session("dtFeename") Is Nothing Then
        '    dtFeename.Columns.Add(New DataColumn("FEECODE", GetType(System.String)))
        '    dtFeename.Columns.Add(New DataColumn("FEENAME", GetType(System.String)))
        'Else
        '    ddlFeeName.DataSource = ""
        '    ddlFeeName.DataBind()
        'End If

        Me.ddlFeeName.DataSource = ""
        Me.ddlFeeName.DataBind()
        Me.ddlCurrencyBYfeecd.DataSource = ""
        Me.ddlCurrencyBYfeecd.DataBind()
        dtFeeName.Clear()
        'Me.ddlFeeName.Enabled = False

        'If dtFeeName.Rows.Count <= 0 Then

        '***56100048 Ron SWIFTTCD on FRCMSFEE -001
        'strSQL = "select feecd from db2.frcmsfee where prodcd = '" & Trim(Me.ddlProdName.SelectedValue.ToString()) & "'" & _
        '         " group by feecd"
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        strSQL = _
        "select feecd " & _
        "from db2.frcmsfee " & _
        "where prodcd = '" & Trim(Me.ddlProdName.SelectedValue.ToString()) & "' " & _
        " AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
        " group by feecd"
        dtResultSet = connDB.RunQuerySql(strSQL)
        If dtResultSet.Tables.Count > 0 Then
            For Each dtRow In dtResultSet.Tables(0).Rows
                strFeeCode = Trim(dtRow.Item(0).ToString())
                '***56100048 Ron SWIFTTCD on FRCMSFEE -002
                'strSQL = "select feename,feecd||':'||feename as SHOW from db2.frcmsfee where prodcd = '" & Trim(Me.ddlProdName.SelectedValue.ToString()) & "' " & _
                '         " and feecd = '" & strFeeCode & "'"
                strSQL = _
                "select feename,feecd||':'||feename as SHOW " & _
                "from db2.frcmsfee " & _
                "where prodcd = '" & Trim(Me.ddlProdName.SelectedValue.ToString()) & "' " & _
                " and feecd = '" & strFeeCode & "' " & _
                " AND SWIFTTCD = '" & concur.SWIFTCODE & "'"

                dtResultSet2 = connDB.RunQuerySql(strSQL)
                If dtResultSet2.Tables.Count > 0 Then
                    For Each dtRow2 In dtResultSet2.Tables(0).Rows
                        strText = Trim(dtRow2.Item(1).ToString())
                        Exit For
                    Next
                Else
                    strText = ""
                End If
                Dim dr As DataRow
                dr = dtFeeName.NewRow
                dr("FEECODE") = strFeeCode
                dr("FEENAME") = strText
                'dr("IDNumber") = Trim(dtRow.Item(1).ToString())
                'dr("IDCode") = Trim(dtRow.Item(0).ToString())
                dtFeeName.Rows.Add(dr)

            Next
            Session("dtFeename") = dtFeeName
            ddlFeeName.DataSource = dtFeeName
            ddlFeeName.DataValueField = dtFeeName.Columns(0).ToString
            ddlFeeName.DataTextField = dtFeeName.Columns(1).ToString
            ddlFeeName.DataBind()
            'Else

            '    Exit Sub
            'End If
        Else
            dtFeeName = Session("dtFeename")
            ddlFeeName.DataSource = dtFeeName
            ddlFeeName.DataValueField = dtFeeName.Columns(0).ToString
            ddlFeeName.DataTextField = dtFeeName.Columns(1).ToString
            ddlFeeName.DataBind()

        End If

        If ddlFeeName.Items.Count > 0 Then
            ddlFeeName.SelectedIndex = 0
        End If



        'strSQL = "select feecd as CODE, feename,feecd||':'||feename as SHOW from db2.frcmsfee where prodcd = '" & Trim(Me.ddlProdName.SelectedValue.ToString()) & "'"
        'Me.ddlFeeName.DataSource = ""
        'Me.ddlFeeName.DataBind()

        'If Not PublicFunc.PopulateLoadDDL(Me.ddlFeeName, "CODE", "SHOW", strSQL) Then
        '    cstext1 = "alert('Error!! Feename should be filled.');"
        '    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        'End If

        'R52030022
        If ddlFeeName.Items.Count > 0 Then
            Me.ddlFeeName.SelectedIndex = -1
            ddlFeeName.Enabled = True

        Else
            Me.ddlFeeName.DataSource = ""
            Me.ddlFeeName.DataBind()
            Me.ddlFeeName.Enabled = False
        End If

        'Kwang R52030022
        '***56100048 Ron SWIFTTCD on FRCMSFEE -003
        'strSQL = "select case remcur when '000' then '' else remcur end as CODE,case remcur when '000' then '' else remcur end as SHOW from db2.frcmsfee where prodcd = '" & Trim(Me.ddlProdName.SelectedValue.ToString()) & "'" & _
        ' " and feecd  = '" & Trim(Me.ddlFeeName.SelectedValue.ToString()) & "'  "
        strSQL = _
        "select " & _
        " case remcur " & _
        "  when '000' then '' " & _
        "  else remcur " & _
        " end as CODE," & _
        " case remcur " & _
        "  when '000' then '' " & _
        "  else remcur " & _
        " end as SHOW " & _
        "from db2.frcmsfee " & _
        "where prodcd = '" & Trim(Me.ddlProdName.SelectedValue.ToString()) & "' " & _
        " and feecd  = '" & Trim(Me.ddlFeeName.SelectedValue.ToString()) & "'  " & _
        " AND SWIFTTCD = '" & concur.SWIFTCODE & "'"


        Me.ddlCurrencyBYfeecd.DataSource = ""
        Me.ddlCurrencyBYfeecd.DataBind()

        If Not PublicFunc.PopulateLoadDDL(Me.ddlCurrencyBYfeecd, "CODE", "SHOW", strSQL) Then
            cstext1 = "alert('Error!! Feename should be filled.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
        If ddlCurrencyBYfeecd.Items.Count > 0 Then
            Me.ddlCurrencyBYfeecd.SelectedIndex = -1
            ddlCurrencyBYfeecd.Enabled = True

        Else
            Me.ddlCurrencyBYfeecd.DataSource = ""
            Me.ddlCurrencyBYfeecd.DataBind()
            Me.ddlCurrencyBYfeecd.Enabled = False
        End If


    End Sub


    Protected Sub GridRate_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridRate.RowCancelingEdit
        GridIdentification.EditIndex = -1
        Session("Mdt") = Mdt
        GridIdentification.DataSource = Mdt
        GridIdentification.DataBind()
    End Sub
    Protected Sub GridRate_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridRate.RowEditing
        '*** CMHI:84c472ab-3bf5-4127-b983-62ac89a277d7
        Dim strsql As String

        Me.ddlRateProname = Nothing

        Dim RNoHid As HiddenField = GridRate.Rows(e.NewEditIndex).FindControl("RNoHid")
        Dim PRONAMEHid As HiddenField = GridRate.Rows(e.NewEditIndex).FindControl("PRONAMEHid")
        Dim RATECURHid As HiddenField = GridRate.Rows(e.NewEditIndex).FindControl("RATECURHid")
        Dim RATEMAGINHid As HiddenField = GridRate.Rows(e.NewEditIndex).FindControl("RATEMAGINHid")
        Dim RATEMINHid As HiddenField = GridRate.Rows(e.NewEditIndex).FindControl("RATEMINHid")
        Dim RATEMAXHid As HiddenField = GridRate.Rows(e.NewEditIndex).FindControl("RATEMAXHid")

        If IsNothing(RNoHid) Or IsNothing(PRONAMEHid) Or IsNothing(RATECURHid) _
            Or IsNothing(RATEMINHid) Or IsNothing(RATEMAXHid) Then Exit Sub

        GridRate.EditIndex = e.NewEditIndex
        Session("DT_RATE") = DT_RATE
        GridRate.DataSource = DT_RATE
        GridRate.DataBind()

        Dim txtG_No As Label = CType(GridRate.Rows(e.NewEditIndex).FindControl("txtG_No"), Label)
        Dim ddlG_PRONAME As DropDownList = CType(GridRate.Rows(e.NewEditIndex).FindControl("ddlRateProname"), DropDownList)
        Dim ddlG_RATECUR As DropDownList = CType(GridRate.Rows(e.NewEditIndex).FindControl("ddlRateCurCode"), DropDownList)
        Dim txtG_RATEMagin As TextBox = CType(GridRate.Rows(e.NewEditIndex).FindControl("txtG_RATEMagin"), TextBox)
        Dim txtG_RATEMin As TextBox = CType(GridRate.Rows(e.NewEditIndex).FindControl("txtG_RATEMin"), TextBox)
        Dim txtG_RATEMax As TextBox = CType(GridRate.Rows(e.NewEditIndex).FindControl("txtG_RATEMax"), TextBox)

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        If Not IsNothing(ddlRateProname) Then
            strsql = "select prodcd as CODE, proddesc as SHOW from db2.frcmprod order by prodcd"
            If Not PublicFunc.PopulateLoadDDL(Me.ddlRateProname, "CODE", "SHOW", strsql) Then
                cstext1 = "alert('Error!! ID No. should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            End If
        End If

        If Not IsNothing(ddlG_RATECUR) Then
            strsql = _
            "select '' as CODE,'' as SHOW " & _
            "from db2.host_currency " & _
            "union " & _
            "select cur_cd as CODE, cur_cd ||':'|| cur_name as SHOW " & _
            "from db2.host_currency " & _
            "where cur_cd not in ('US1','US2') " & _
            " AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
            "order by CODE "

            If Not PublicFunc.PopulateLoadDDL(ddlG_RATECUR, "SHOW", "SHOW", strsql) Then

            End If
        End If

        txtG_No.Text = RNoHid.Value
        txtG_RATEMagin.Text = RATEMAGINHid.Value
        txtG_RATEMin.Text = RATEMINHid.Value
        txtG_RATEMax.Text = RATEMAXHid.Value


    End Sub
    Protected Sub GridRate_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridRate.RowUpdating
        Dim strChkMain As String = "N"
        Dim gv As GridView = sender


        If gv.EditIndex > -1 Then
            Dim txtG_ANo As Label = CType(GridRate.Rows(gv.EditIndex).FindControl("txtG_ANo"), Label)
            Dim txtG_ACCNO As TextBox = CType(GridRate.Rows(gv.EditIndex).FindControl("ddlG_ACCNO"), TextBox)
            Dim ddlG_ACCTYPE As DropDownList = CType(GridRate.Rows(gv.EditIndex).FindControl("ddlG_ACCType"), DropDownList)
            Dim ddlG_ACCCUR As DropDownList = CType(GridRate.Rows(gv.EditIndex).FindControl("ddlG_ACCCUR"), DropDownList)
            Dim chkG_MAIN As CheckBox = CType(GridRate.Rows(gv.EditIndex).FindControl("CHK_MAIN"), CheckBox)

            If chkG_MAIN.Checked Then
                strChkMain = "Y"
            End If

            DT_RATE = Session("DT_RATE")
            DT_RATE.Rows(e.RowIndex).Item(1) = txtAcNO.Value
            DT_RATE.Rows(e.RowIndex).Item(2) = ddlG_ACCTYPE.SelectedItem.Text.ToString()
            DT_RATE.Rows(e.RowIndex).Item(3) = ddlG_ACCCUR.SelectedItem.Text.ToString()
            DT_RATE.Rows(e.RowIndex).Item(4) = strChkMain

            DT_RATE.Rows(e.RowIndex).Item(5) = ddlG_ACCTYPE.SelectedValue.ToString()
            DT_RATE.Rows(e.RowIndex).Item(6) = ddlG_ACCCUR.SelectedValue.ToString()

            e.Cancel = True
            GridRate.EditIndex = -1
            GridRate.DataSource = DT_RATE
            GridRate.DataBind()
        End If

    End Sub
    Protected Sub GridRate_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridRate.RowDeleting
        If e.RowIndex < DT_RATE.Rows.Count Then
            DT_RATE = Session("DT_RATE")
            DT_RATE.Rows(e.RowIndex).Delete()
            GridRate.DataSource = DT_RATE
            GridRate.DataBind()
            Session("DT_RATE") = DT_RATE
            Session("flagRateChange") = True
        End If
    End Sub

    Protected Sub ButAddRate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButAddRate.Click
        Dim i As Integer

        If Not DT_RATE Is Nothing Then

            If DT_RATE.Rows.Count > 19 Then
                cstext1 = "alert('Maximum Record.Can not Insert Rate');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If

        End If

        If Me.ddlRateProname.SelectedValue = "" Then
            cstext1 = "alert('Please Select Product Name');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Me.ddlRateProname.Focus()
            Exit Sub
        End If
        If Me.ddlRateCurCode.SelectedValue = "" Then
            cstext1 = "alert('Please Select Currency of Rate');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            ddlRateCurCode.Focus()

            Exit Sub
        End If

        If Trim(Me.txtRateMargin.Text) = "" Then Me.txtRateMargin.Text = "0.0000000"
        If Trim(Me.txtRateMin.Text) = "" Then Me.txtRateMin.Text = "0.00"
        If Trim(Me.txtRateMax.Text) = "" Then Me.txtRateMax.Text = "0.00"

        If CDbl(Replace(Trim(Me.txtRateMin.Text.ToString()), ",", "")) > CDbl(Replace(Trim(Me.txtRateMax.Text.ToString()), ",", "")) Then
            cstext1 = "alert('Error!! Maximum Rate should be more than Minimum Rate.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            txtRateMax.Focus()
            Exit Sub
        End If

        If Not DT_RATE Is Nothing Then
            If DT_RATE.Rows.Count > 0 Then
                For i = 0 To DT_RATE.Rows.Count - 1
                    If DT_RATE.Rows(i).Item(6).ToString = ddlRateProname.SelectedValue.ToString() And _
                       DT_RATE.Rows(i).Item(7).ToString = ddlRateCurCode.SelectedValue.ToString() Then
                        cstext1 = "alert('Please Insert New Value');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        ButClearRate_Click(sender, e)
                        Exit Sub
                    End If
                Next
            End If
        End If


        Dim dr As DataRow
        dr = DT_RATE.NewRow

        dr("PRONAME") = ddlRateProname.SelectedItem.Text.ToString()
        dr("RATECUR") = ddlRateCurCode.SelectedItem.Text.ToString()
        If Me.RadioRateMargin.SelectedValue = "MINUS" Then
            If CDec(Me.txtRateMargin.Text.ToString()) = 0 Then
                dr("RATEMAGIN") = Format(CDec(Me.txtRateMargin.Text.ToString()), "##,##0.0000000")
            Else
                dr("RATEMAGIN") = Format(-(CDec(Me.txtRateMargin.Text.ToString())), "##,##0.0000000")
            End If
        Else
            dr("RATEMAGIN") = Format(CDec(Me.txtRateMargin.Text.ToString()), "##,##0.0000000")
        End If
        dr("RATEMIN") = Format(CDec(Me.txtRateMin.Text.ToString()), "##,##0.00")
        dr("RATEMAX") = Format(CDec(txtRateMax.Text.ToString()), "##,##0.00")

        dr("PROCODE") = ddlRateProname.SelectedValue.ToString()
        dr("CURCODE") = ddlRateCurCode.SelectedValue.ToString()

        DT_RATE.Rows.Add(dr)

        GridRate.DataSource = DT_RATE
        GridRate.DataBind()
        Session("DT_RATE") = DT_RATE
        Session("flagRateChange") = True
        ButClearRate_Click(sender, e)


    End Sub



    Protected Sub ButUpdateAcc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButUpdateAcc.Click
        '*** CMHI:a1def5f7-ff75-4e93-ab39-3d59b6ab47d8
        Dim strChkMain As String = "N"
        Dim i As Integer
        Dim strRecAc As String
        Dim temp As String

        If Not ACCDT Is Nothing Then

            If ACCDT.Rows.Count > 19 Then
                cstext1 = "alert('Record less than 10');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If
            '***********************************************************************************************
StepChkAccProcess:
            Dim strsql As String
            Dim tmpAccount As String = Me.txtAcNO.Value.ToString()

            '2010-09-02
            'strsql = " select a.senac from db2.forwdrac a  " & _
            '         " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
            '         " and a.senac = '" & Trim(tmpAccount) & "' " & _
            '         " union all " & _
            '         " select a.dracno from db2.foropaid a " & _
            '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC') " & _
            '         " and a.dracno = '" & Trim(tmpAccount) & "' " & _
            '         " union all " & _
            '         " select a.dracno from db2.FOROFEDT a " & _
            '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC')" & _
            '         " and a.dracno = '" & Trim(tmpAccount) & "' "

            strsql = " select a.senac from db2.forwdrac a  " & _
                        " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                        " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                        " and a.senac = '" & Trim(tmpAccount) & "' " & _
                        " union all " & _
                        " select a.dracno from db2.foropaid a " & _
                        " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                        " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
                        " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                        " union all " & _
                        " select a.dracno from db2.FOROFEDT a " & _
                        " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                        " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')" & _
                        " and a.dracno = '" & Trim(tmpAccount) & "' "

            Dim dtResultSetSenId As New DataSet
            Dim connSenId As OdbcConnection = connDB.getDBConn()
            Dim blnCanUpdate As Boolean

            dtResultSetSenId = connDB.RunQuerySql(strsql)

            If dtResultSetSenId.Tables.Count > 0 Then
                If dtResultSetSenId.Tables(0).Rows.Count > 0 Then
                    If ACCDT.Rows(i).Item(5) <> Me.ddlAcType.SelectedValue.ToString() Or _
                        ACCDT.Rows(i).Item(6) <> Me.ddlCurrency.SelectedValue.ToString() Then
                        blnCanUpdate = False
                    End If
                Else
                    blnCanUpdate = True
                End If
            Else
                blnCanUpdate = True
            End If

            connSenId.Close()

            If Not blnCanUpdate Then

                MultiView_addCustomer.ActiveViewIndex = 3
                SetMenuAddCustomer(3)

                cstext1 = "alert('Can not update because account is processing. ');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If

            '***********************************************************************************************
            'normal
            If ACCDT.Rows.Count > 0 Then
                For i = 0 To ACCDT.Rows.Count - 1
                    If i = Session("mintRowAcc") Then GoTo StepNext_i
                    If ACCDT.Rows(i).Item(1).ToString = Me.txtAcNO.Value.ToString Then
                        cstext1 = "alert('Please Insert New Account');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)

                        Exit Sub
                    End If

                    '************************************
                    '2008-02-07 :: main account 
                    If ChkMain.Checked Then
                        If Not chkMainAcc(Trim(Me.txtAcNO.Value.ToString())) Then
                            MultiView_addCustomer.ActiveViewIndex = 3
                            SetMenuAddCustomer(3)
                            cstext1 = "alert('Can not update this account to main account. ');"
                            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                            Exit Sub
                        End If

                        If ACCDT.Rows(i).Item(4).ToString = "Y" And i <> Session("mintRowAcc") Then
                            ACCDT.Rows(i).Item(4) = "N"
                        End If
                    End If
                    '************************************
StepNext_i:
                Next
            End If
        End If

        If Not validateAccount() Then
            Exit Sub
        End If

        strRecAc = ""
        For i = 1 To Len(txtAcNO.Value)
            temp = Asc(Mid(Trim(txtAcNO.Value), i, 1))
            If (temp >= 48 And temp <= 57) Or (temp >= 65 And temp <= 90) Or (temp >= 97 And temp <= 122) Then
                strRecAc = strRecAc & Mid(Trim(txtAcNO.Value), i, 1)
            End If
        Next i

        Select Case UCase(Trim(Me.ddlCurrency.SelectedValue.ToString()))
            '***R56100048 Repalce "THB"
            'Case "THB"
            Case CType(Session("concurrencyInfo"), _
             FORWEB_Concurrency).BaseCurrency
                If Not chkDigitSAFEAc(strRecAc) Then
                    cstext1 = "alert('Invalid account error(Digit)');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: lightcyan"
                    Me.ddlAcType.BackColor = Drawing.Color.LightCyan
                    Me.ddlCurrency.BackColor = Drawing.Color.LightCyan
                    Me.ChkMain.BackColor = Drawing.Color.LightCyan
                    Exit Sub
                End If
            Case Else
                If Not chkDigitFCDAc(strRecAc) Then
                    cstext1 = "alert('Invalid account error(Digit)');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: lightcyan"
                    Me.ddlAcType.BackColor = Drawing.Color.LightCyan
                    Me.ddlCurrency.BackColor = Drawing.Color.LightCyan
                    Me.ChkMain.BackColor = Drawing.Color.LightCyan
                    Exit Sub
                End If
        End Select

        If ChkMain.Checked Then
            strChkMain = "Y"
        End If

        i = Session("mintRowAcc")
        ACCDT = Session("ACCDT")
        '*******************************************************************************************
StepUpdateAccNormal:
        ACCDT.Rows(i).Item(1) = Me.txtAcNO.Value.ToString()
        ACCDT.Rows(i).Item(2) = Me.ddlAcType.SelectedItem.Text.ToString()
        ACCDT.Rows(i).Item(3) = Me.ddlCurrency.SelectedItem.Text.ToString()
        ACCDT.Rows(i).Item(4) = strChkMain
        ACCDT.Rows(i).Item(5) = Me.ddlAcType.SelectedValue.ToString()
        ACCDT.Rows(i).Item(6) = Me.ddlCurrency.SelectedValue.ToString()

        GridAccount.DataSource = ACCDT
        GridAccount.DataBind()
        Session("ACCDT") = ACCDT


        Me.ButUpdateAcc.Enabled = False
        Me.ButCanAcc.Enabled = False

        Me.ButAddAcc.Enabled = True
        Me.ButClearAcc.Enabled = True

        Me.panel_gridAccount.Enabled = True
        Me.ButClearAcc_Click(sender, e)

        If ACCDT.Rows.Count > 0 Then
            Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: white"
            Me.ddlAcType.BackColor = Drawing.Color.White
            Me.ddlCurrency.BackColor = Drawing.Color.White
            Me.ChkMain.BackColor = Drawing.Color.White
        Else
            Me.txtAcNO.Style.Value = "WIDTH: 191px; BACKGROUND-COLOR: lightcyan"
            Me.ddlAcType.BackColor = Drawing.Color.LightCyan
            Me.ddlCurrency.BackColor = Drawing.Color.LightCyan
            Me.ChkMain.BackColor = Drawing.Color.LightCyan
        End If
    End Sub

    Protected Sub ButCanAcc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButCanAcc.Click
        Me.panel_gridAccount.Enabled = True
        ButClearAcc_Click(sender, e)
        Me.ButUpdateAcc.Enabled = False
        Me.ButCanAcc.Enabled = False

        Me.ButAddAcc.Enabled = True
        Me.ButClearAcc.Enabled = True
        Me.ChkMain.Enabled = True
    End Sub


    Public Function chkDigitFCDAc(ByVal instraccNo As String) As Boolean
        'Dim i As Integer
        'Dim intResult As Integer, inttmpVal As Integer
        'Dim strFixChk As String, strComputeAcc As String

        'strFixChk = "65432"

        'intResult = 0
        'strComputeAcc = Mid(instraccNo, 4, 6)
        'For i = 1 To 5
        '    inttmpVal = Int(Mid(strFixChk, i, 1)) * Int(Mid(strComputeAcc, i, 1))
        '    intResult = intResult + inttmpVal
        'Next i
        'If Mid(strComputeAcc, 6, 1) <> Right(Trim(Str(10 - Right(Str(intResult), 1))), 1) Then
        '    chkDigitFCDAc = False
        'Else
        '    chkDigitFCDAc = True
        'End If
        chkDigitFCDAc = True
    End Function
    Public Function chkDigitSAFEAc(ByVal instraccNo As String) As Boolean
        '*** CMHI:4c4c093b-cbeb-42ab-a229-c23cd0d049d5
         ''Dim i As Integer, intResult As Integer, inttmpVal As Integer
         ''Dim strFixChk As String

         ''strFixChk = "432765432"

         ''If Len(instraccNo) = 10 Then
         ''    intResult = 0
         ''    For i = 1 To 9
         ''        inttmpVal = Int(Mid(strFixChk, i, 1)) * Int(Mid(instraccNo, i, 1))
         ''        inttmpVal = Int(Right(Str(inttmpVal), 1))
         ''        intResult = intResult + inttmpVal
         ''    Next i
         ''    If Mid(instraccNo, 10, 1) <> Right(Trim(Str(10 - Right(Str(intResult), 1))), 1) Then
         ''        chkDigitSAFEAc = False
         ''    Else
         ''        chkDigitSAFEAc = True
         ''    End If
         ''Else
         ''    chkDigitSAFEAc = False
         ''End If
        Return True
    End Function
    Public Function validateAccount() As Boolean
        validateAccount = False

        If Me.txtAcNO.Value = "" Then
            cstext1 = "alert('Please Insert Account No.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Me.txtAcNO.Focus()
            Exit Function
        ElseIf Not IsNumeric(Trim(Me.txtAcNO.Value)) And Trim(Me.txtAcNO.Value) <> "" Then
            cstext1 = "alert('Please Account No incorrect.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Me.txtAcNO.Focus()
            Exit Function
        End If

        If Me.ddlAcType.SelectedValue.ToString = "" Then
            cstext1 = "alert('Please Select Account Type');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Me.ddlAcType.Focus()
            Exit Function
        End If

        If Me.ddlCurrency.SelectedValue.ToString = "" Then
            cstext1 = "alert('Please Select Currency Code');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Me.ddlCurrency.Focus()
            Exit Function
        End If


        validateAccount = True

    End Function
    Protected Sub ButIgnore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButIgnore.Click
        MultiView_addCustomer.ActiveViewIndex = 0
        Panel3.Visible = True
    End Sub

    Protected Sub GridFee_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridFee.SelectedIndexChanging
        Session("mintRowEdit") = e.NewSelectedIndex
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        Me.txtFeeMagin.Text = Replace(DT_FEE.Rows(e.NewSelectedIndex).Item(4), ",", "")
        Me.txtMinFee.Text = Replace(DT_FEE.Rows(e.NewSelectedIndex).Item(5), ",", "")
        'If Replace(DT_FEE.Rows(e.NewSelectedIndex).Item(6), ",", "") = "999999999999999.99" Then
        '    Me.chkNoLimit.Checked = True
        '    Me.txtMaxFee.Enabled = False
        'Else
        '    Me.chkNoLimit.Checked = False
        '    Me.txtMaxFee.Enabled = True
        'End If

        Me.txtMaxFee.Text = Replace(DT_FEE.Rows(e.NewSelectedIndex).Item(6), ",", "")

        Dim strsql As String
        Me.ddlProdName.DataSource = ""
        Me.ddlProdName.DataBind()

        '***56100048 Ron SWIFTTCD on FRCMSFEE -004
        'strsql = " select '' as prodcd , '--Please Select Product Code--' as SHOW from db2.frcmprod a,db2.frcmsfee b union " & _
        '        " select a.prodcd , a.proddesc as SHOW from db2.frcmprod a,db2.frcmsfee b " & _
        '        " where a.prodcd = b.prodcd order by prodcd"
        strsql = _
        "select '' as prodcd , '--Please Select Product Code--' as SHOW " & _
        "from db2.frcmprod a,db2.frcmsfee b " & _
        "union " & _
        "select a.prodcd , a.proddesc as SHOW " & _
        "from db2.frcmprod a,db2.frcmsfee b " & _
        "where a.prodcd = b.prodcd " & _
        " AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
        "order by prodcd "

        If Not PublicFunc.PopulateLoadDDL(Me.ddlProdName, "prodcd", "SHOW", strsql) Then
            cstext1 = "alert('Error!! Can not Load Product Code.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Exit Sub
        End If
        Me.ddlProdName.SelectedIndex = -1
        ddlProdName.SelectedIndex = ddlProdName.Items.IndexOf(ddlProdName.Items.FindByValue(DT_FEE.Rows(e.NewSelectedIndex).Item(7)))
        ddlFeeType.SelectedIndex = ddlFeeType.Items.IndexOf(ddlFeeType.Items.FindByValue(DT_FEE.Rows(e.NewSelectedIndex).Item(9)))
        Me.ddlProdName.Items.FindByValue(DT_FEE.Rows(e.NewSelectedIndex).Item(7)).Selected = True
        Me.ddlFeeType.Items.FindByValue(DT_FEE.Rows(e.NewSelectedIndex).Item(9)).Selected = True

        If Trim(DT_FEE.Rows(e.NewSelectedIndex).Item(8)) <> "" Then

            Dim strProdName As String = DT_FEE.Rows(e.NewSelectedIndex).Item(7).ToString()
            Dim strNameFee As String = DT_FEE.Rows(e.NewSelectedIndex).Item(8).ToString()

            '***56100048 Ron SWIFTTCD on FRCMSFEE -005
            'strsql = "select feecd as CODE, feename,feecd||':'||feename as SHOW from db2.frcmsfee where prodcd = '" & Trim(strProdName) & "'"
            strsql = _
            "select feecd as CODE, feename,feecd||':'||feename as SHOW " & _
            "from db2.frcmsfee " & _
            "where prodcd = '" & Trim(strProdName) & "' " & _
            " AND SWIFTTCD = '" & concur.SWIFTCODE & "'"

            If Not PublicFunc.PopulateLoadDDL(Me.ddlFeeName, "CODE", "SHOW", strsql) Then
                cstext1 = "alert('Error!! Feename should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            End If
            ddlFeeName.Enabled = True
            ddlFeeName.SelectedIndex = ddlFeeName.Items.IndexOf(ddlFeeName.Items.FindByValue(DT_FEE.Rows(e.NewSelectedIndex).Item(8)))
        End If

        'Kwang Start R52030022
        If Trim(DT_FEE.Rows(e.NewSelectedIndex).Item(8)) <> "" Then

            Dim strProdName As String = DT_FEE.Rows(e.NewSelectedIndex).Item(7).ToString()
            Dim strNameFee As String = DT_FEE.Rows(e.NewSelectedIndex).Item(8).ToString()

            Dim strFeeCur As String = DT_FEE.Rows(e.NewSelectedIndex).Item(10).ToString()

            '***56100048 Ron SWIFTTCD on FRCMSFEE -006
            'strsql = "select case remcur when '000' then '' else remcur end as CODE, case remcur when '000' then '' else remcur end as SHOW " & _
            '         " from db2.frcmsfee where prodcd = '" & Trim(strProdName) & "'" & _
            '         " and feecd = '" & strNameFee & "'"
            strsql = _
            "select " & _
            " case remcur " & _
            "  when '000' then '' " & _
            "  else remcur " & _
            " end as CODE, " & _
            " case remcur " & _
            "  when '000' then '' " & _
            "  else remcur " & _
            " end as SHOW " & _
            "from db2.frcmsfee " & _
            "where prodcd = '" & Trim(strProdName) & "'" & _
            " and feecd = '" & strNameFee & "' " & _
            " AND SWIFTTCD = '" & concur.SWIFTCODE & "'"

            If Not PublicFunc.PopulateLoadDDL(Me.ddlCurrencyBYfeecd, "CODE", "SHOW", strsql) Then
                cstext1 = "alert('Error!! Feename should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            End If
            ddlCurrencyBYfeecd.Enabled = True
            ddlCurrencyBYfeecd.SelectedIndex = ddlCurrencyBYfeecd.Items.IndexOf(ddlCurrencyBYfeecd.Items.FindByValue(DT_FEE.Rows(e.NewSelectedIndex).Item(10)))
        End If
        'Kwang END R52030022

        If ddlFeeType.SelectedValue.ToString = "F" Then
            Me.txtMinFee.Enabled = False
            Me.txtMaxFee.Enabled = False
            Me.lbPercent.Visible = False
            Me.chkNoLimit.Enabled = False
        ElseIf ddlFeeType.SelectedValue.ToString = "P" Then
            Me.txtMinFee.Enabled = True
            Me.txtMaxFee.Enabled = True
            Me.lbPercent.Visible = True
            Me.chkNoLimit.Enabled = True
        End If

        If Replace(DT_FEE.Rows(e.NewSelectedIndex).Item(6), ",", "") = "999999999999999.99" Then
            Me.chkNoLimit.Checked = True
            Me.txtMaxFee.Enabled = False
        Else
            Me.chkNoLimit.Checked = False
            'Me.txtMaxFee.Enabled = True
        End If


        Me.ButAddFEE.Enabled = False
        Me.ButClearFEE.Enabled = False
        Me.ButCancelFee.Enabled = True
        Me.ButUpdateFee.Enabled = True

        Me.GridFee.Enabled = False
    End Sub

    Protected Sub ButUpdateFee_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButUpdateFee.Click
        Dim i As Integer
        If DT_FEE Is Nothing Then
            If DT_FEE.Rows.Count > 19 Then
                cstext1 = "alert('Maximum Record.Can not Insert Fee.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If
        End If

        If ddlProdName.SelectedValue.ToString() = "" Then
            cstext1 = "alert('Please Select Product Name');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            ddlProdName.Focus()
            Exit Sub
        End If

        If ddlFeeName.Items.Count > 0 Then
            If ddlFeeName.SelectedValue.ToString() = "" Then
                cstext1 = "alert('Please Select Fee Name');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                ddlFeeName.Focus()
                Exit Sub
            End If
        End If

        If ddlFeeType.SelectedValue.ToString() = "" Then
            cstext1 = "alert('Please Select Fee Type');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            ddlFeeType.Focus()
            Exit Sub
        End If

        If Trim(Me.txtFeeMagin.Text.ToString()) = "" Then Me.txtFeeMagin.Text = "0.0000000"
        If Trim(Me.txtMinFee.Text.ToString()) = "" Then Me.txtMinFee.Text = "0.00"
        If Trim(Me.txtMaxFee.Text.ToString()) = "" Then Me.txtMaxFee.Text = "0.00"


        If CDbl(Replace(Trim(Me.txtMinFee.Text.ToString()), ",", "")) > CDbl(Replace(Trim(Me.txtMaxFee.Text.ToString()), ",", "")) Then
            cstext1 = "alert('Error!! Maximum Fee should be more than Minimum Fee.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            txtMaxFee.Focus()
            Exit Sub
        End If

        If Not DT_FEE Is Nothing Then
            If DT_FEE.Rows.Count > 0 Then
                For i = 0 To DT_FEE.Rows.Count - 1
                    If i = Session("mintRowEdit") Then GoTo StepNext_i
                    If DT_FEE.Rows(i).Item(7).ToString = Me.ddlProdName.SelectedValue.ToString() And _
                       DT_FEE.Rows(i).Item(8).ToString = Me.ddlFeeName.SelectedValue.ToString() Then
                        cstext1 = "alert('Please Insert New Value');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                        Exit Sub
                    End If
StepNext_i:
                Next
            End If
        End If

        i = Session("mintRowEdit")

        DT_FEE = Session("DT_FEE")
        DT_FEE.Rows(i).Item(1) = Me.ddlProdName.SelectedItem.Text.ToString()
        DT_FEE.Rows(i).Item(3) = Me.ddlFeeType.SelectedItem.Text.ToString()

        DT_FEE.Rows(i).Item(4) = Format(CDbl(Me.txtFeeMagin.Text.ToString()), "##,##0.0000000")
        DT_FEE.Rows(i).Item(5) = Format(CDec(Me.txtMinFee.Text.ToString()), "##,##0.00")
        DT_FEE.Rows(i).Item(6) = Format(CDec(Me.txtMaxFee.Text.ToString()), "##,##0.00")

        DT_FEE.Rows(i).Item(7) = Me.ddlProdName.SelectedValue.ToString()
        If Me.ddlFeeName.Items.Count > 0 Then
            DT_FEE.Rows(i).Item(8) = Me.ddlFeeName.SelectedValue.ToString()
            DT_FEE.Rows(i).Item(2) = Me.ddlFeeName.SelectedItem.Text.ToString()
        End If
        DT_FEE.Rows(i).Item(9) = Me.ddlFeeType.SelectedValue.ToString()
        'Kwang R52030022
        DT_FEE.Rows(i).Item(10) = Me.ddlCurrencyBYfeecd.SelectedValue.ToString()

        GridFee.DataSource = DT_FEE
        GridFee.DataBind()
        Session("DT_FEE") = DT_FEE

        Me.ButAddFEE.Enabled = True
        Me.ButClearFEE.Enabled = True

        Me.ButUpdateFee.Enabled = False
        Me.ButCancelFee.Enabled = False

        Me.ddlProdName.SelectedIndex = -1
        Me.ddlFeeType.SelectedIndex = -1

        If Me.ddlFeeName.Items.Count > 0 Then
            Me.ddlFeeName.DataSource = ""
            Me.ddlFeeName.DataBind()
            Me.ddlFeeName.Enabled = False
        End If

        Session("flagFeeChange") = True
        ButClearFEE_Click(sender, e)

        Me.GridFee.Enabled = True

    End Sub

    Protected Sub GridRate_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridRate.SelectedIndexChanging

        Session("mintRowEdit") = e.NewSelectedIndex
        If Left(Trim(DT_RATE.Rows(e.NewSelectedIndex).Item(3).ToString()), 1) = "-" Then
            Me.RadioRateMargin.SelectedValue = "MINUS"
            Dim strMagin As String
            strMagin = Replace(Trim(DT_RATE.Rows(e.NewSelectedIndex).Item(3).ToString()), ",", "")
            Me.txtRateMargin.Text = Mid(strMagin, 2, Len(strMagin) - 1)
        Else
            Me.txtRateMargin.Text = Replace(DT_RATE.Rows(e.NewSelectedIndex).Item(3), ",", "")
        End If
        Me.txtRateMin.Text = Replace(DT_RATE.Rows(e.NewSelectedIndex).Item(4), ",", "")
        Me.txtRateMax.Text = Replace(DT_RATE.Rows(e.NewSelectedIndex).Item(5), ",", "")

        Me.ddlRateProname.SelectedIndex = -1
        Me.ddlRateCurCode.SelectedIndex = -1

        Me.ddlRateProname.Items.FindByValue(DT_RATE.Rows(e.NewSelectedIndex).Item(6)).Selected = True
        Me.ddlRateCurCode.Items.FindByValue(DT_RATE.Rows(e.NewSelectedIndex).Item(7)).Selected = True

        Me.ButAddRate.Enabled = False
        Me.ButClearRate.Enabled = False

        Me.ButUpdateRate.Enabled = True
        Me.ButCancelRate.Enabled = True
        Me.GridRate.Enabled = False
        Session("flagRateChange") = True

    End Sub

    Protected Sub ButUpdateRate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButUpdateRate.Click



        Dim i As Integer

        If Not DT_RATE Is Nothing Then

            If DT_RATE.Rows.Count > 19 Then
                cstext1 = "alert('Maximum Record.Can not Insert Rate.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Sub
            End If

        End If

        If Me.ddlRateProname.SelectedValue = "" Then
            cstext1 = "alert('Please Select Product Name');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Me.ddlRateProname.Focus()
            Exit Sub
        End If
        If Me.ddlRateCurCode.SelectedValue = "" Then
            cstext1 = "alert('Please Select Currency of Rate');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            ddlRateCurCode.Focus()

            Exit Sub
        End If


        If CDbl(Replace(Trim(Me.txtRateMin.Text.ToString()), ",", "")) > CDbl(Replace(Trim(Me.txtRateMax.Text.ToString()), ",", "")) Then
            cstext1 = "alert('Error!! Maximum Rate should be more than Minimum Rate.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Me.txtRateMax.Focus()
            Exit Sub
        End If

        If Trim(Me.txtRateMargin.Text) = "" Then Me.txtRateMargin.Text = "0.0000000"
        If Trim(Me.txtRateMin.Text) = "" Then Me.txtRateMin.Text = "0.00"
        If Trim(Me.txtRateMax.Text) = "" Then Me.txtRateMax.Text = "0.00"

        If Not DT_RATE Is Nothing Then
            If DT_RATE.Rows.Count > 0 Then
                For i = 0 To DT_RATE.Rows.Count - 1
                    If i = Session("MintRowEdit") Then GoTo StepNext_i
                    If DT_RATE.Rows(i).Item(6).ToString = ddlRateProname.SelectedValue.ToString() And _
                       DT_RATE.Rows(i).Item(7).ToString = ddlRateCurCode.SelectedValue.ToString() Then
                        cstext1 = "alert('Please Insert New Value');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)

                        Exit Sub
                    End If
StepNext_i:
                Next
            End If
        End If



        i = Session("mintRowEdit")

        DT_RATE = Session("DT_RATE")
        DT_RATE.Rows(i).Item(1) = Me.ddlRateProname.SelectedItem.Text.ToString()
        DT_RATE.Rows(i).Item(2) = Me.ddlRateCurCode.SelectedItem.Text.ToString()

        DT_RATE.Rows(i).Item(3) = Format(CDbl(Me.txtRateMargin.Text.ToString()), "##,##0.0000000")
        DT_RATE.Rows(i).Item(4) = Format(CDbl(Me.txtRateMin.Text.ToString()), "##,##0.00")
        DT_RATE.Rows(i).Item(5) = Format(CDbl(Me.txtRateMax.Text.ToString()), "##,##0.00")

        DT_RATE.Rows(i).Item(6) = Me.ddlRateProname.SelectedValue.ToString()
        DT_RATE.Rows(i).Item(7) = Me.ddlRateCurCode.SelectedValue.ToString()

        GridRate.DataSource = DT_RATE
        GridRate.DataBind()
        Session("DT_RATE") = DT_RATE

        Me.ButAddRate.Enabled = True
        Me.ButClearRate.Enabled = True

        Me.ButUpdateRate.Enabled = False
        Me.ButCancelRate.Enabled = False

        ButClearRate_Click(sender, e)
        Me.GridRate.Enabled = True

    End Sub

    Protected Sub ButClearFEE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButClearFEE.Click
        Me.ddlProdName.SelectedIndex = -1
        Me.ddlFeeType.SelectedIndex = -1

        If Me.ddlFeeName.Items.Count > 0 Then
            Me.ddlFeeName.DataSource = ""
            Me.ddlFeeName.DataBind()
            Me.ddlFeeName.Enabled = False

        End If
        If Me.ddlCurrencyBYfeecd.Items.Count > 0 Then
            Me.ddlCurrencyBYfeecd.DataSource = ""
            Me.ddlCurrencyBYfeecd.DataBind()
            Me.ddlCurrencyBYfeecd.Enabled = False

        End If
        Me.txtFeeMagin.Text = "0.0000000"
        Me.txtMinFee.Text = "0.00"
        Me.txtMaxFee.Text = "0.00"
        Me.txtMaxFee.Enabled = False
        Me.txtMinFee.Enabled = False
        Me.lbPercent.Visible = False
        Me.chkNoLimit.Enabled = False
        Me.chkNoLimit.Checked = False

        ddlProdName.SelectedIndex = ddlProdName.Items.IndexOf(ddlProdName.Items.FindByValue("FORO"))
        ddlProdName_SelectedIndexChanged(sender, e)
    End Sub

    Protected Sub ButCancelFee_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButCancelFee.Click
        GridFee.EditIndex = -1
        Session("Mdt") = Mdt
        GridIdentification.DataSource = Mdt
        GridIdentification.DataBind()

        Me.ddlProdName.SelectedIndex = -1
        Me.ddlFeeType.SelectedIndex = -1

        If Me.ddlFeeName.Items.Count > 0 Then
            Me.ddlFeeName.DataSource = ""
            Me.ddlFeeName.DataBind()
            Me.ddlFeeName.Enabled = False

        End If

        Me.txtFeeMagin.Text = ""
        Me.txtMinFee.Text = ""
        Me.txtMaxFee.Text = ""


        Me.ButAddFEE.Enabled = True
        Me.ButClearFEE.Enabled = True

        Me.ButCancelFee.Enabled = False
        Me.ButUpdateFee.Enabled = False

        Me.GridFee.Enabled = True
        ButClearFEE_Click(sender, e)
    End Sub



    Function GetDataForUpdate(ByRef strForCustID) As Boolean
        Dim strSql As String
        Dim dtResultSet2 As DataSet
        Dim strTitle As String
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        Dim conn As OdbcConnection = connDB.getDBConn()
        'Kwang R52030022
        'strSql = " SELECT FORCUSTID,ITSCNO, OCCODE, OBJCD, BOIFG, CUSTIND, CUSTTYPE,ENGTITLE, THTITLE,  SWNAME1, " & _
        '         " SWNAME2, RMNAME, RMNO, ADDR1, ADDR2, ADDR3, ADDRNO, MOO, SOI, ROAD, SUBDISTRICT, DISTRICT, PROVINCE, " & _
        '         " POSTCD, PHONE1, CNTYCD, EXT, FAXNO, MOBILENO, EMAIL1, EMAIL2, EMAIL3, CONTNAME, OPENDATE, CLOSEDATE, " & _
        '         " UPDUSER, UPDDATE, UPDTIME, COMMTHFG, SNDMETHOD,INSTRUCTION,CUSTSTATUS,AUTUSER,AUTDATE,AUTTIME,OBJDESC,PLACENAME,EXIMCUSTID FROM DB2.FORMCUST " & _
        '         " WHERE FORCUSTID = '" & strForCustID & "'"

        'strSql = " SELECT FORCUSTID,ITSCNO, OCCODE, OBJCD, BOIFG, CUSTIND, CUSTTYPE,ENGTITLE, THTITLE,  SWNAME1, " & _
        '         " SWNAME2, RMNAME, RMNO, ADDR1, ADDR2, ADDR3, ADDRNO, MOO, SOI, ROAD, SUBDISTRICT, DISTRICT, PROVINCE, " & _
        '         " POSTCD, PHONE1, CNTYCD, EXT, FAXNO, MOBILENO, EMAIL1, EMAIL2, EMAIL3, CONTNAME, OPENDATE, CLOSEDATE, " & _
        '         " UPDUSER, UPDDATE, UPDTIME, COMMTHFG, SNDMETHOD,INSTRUCTION,CUSTSTATUS,AUTUSER,AUTDATE,AUTTIME,OBJDESC,PLACENAME,EXIMCUSTID,SENDRCPT,CUSTVIP FROM DB2.FORMCUST " & _
        '         " WHERE FORCUSTID = '" & strForCustID & "'"

        'R53060089 Kwang
        'strSql = " SELECT FORCUSTID,ITSCNO, OCCODE, OBJCD, BOIFG, CUSTIND, CUSTTYPE,ENGTITLE, THTITLE,  SWNAME1, " & _
        '         " SWNAME2, RMNAME, RMNO, ADDR1, ADDR2, ADDR3, ADDRNO, MOO, SOI, ROAD, SUBDISTRICT, DISTRICT, PROVINCE, " & _
        '         " POSTCD, PHONE1, CNTYCD, EXT, FAXNO, MOBILENO, EMAIL1, EMAIL2, EMAIL3, CONTNAME, OPENDATE, CLOSEDATE, " & _
        '         " UPDUSER, UPDDATE, UPDTIME, COMMTHFG, SNDMETHOD,INSTRUCTION,CUSTSTATUS,AUTUSER,AUTDATE,AUTTIME,OBJDESC,PLACENAME,EXIMCUSTID,SENDRCPT,CUSTVIP,SIERRAID FROM DB2.FORMCUST " & _
        '         " WHERE FORCUSTID = '" & strForCustID & "'"


        'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add DoctoRecv ContactBy
        strSql = " SELECT FORCUSTID,ITSCNO, OCCODE, OBJCD, BOIFG, CUSTIND, CUSTTYPE,ENGTITLE, THTITLE,  SWNAME1, " & _
         " SWNAME2, RMNAME, RMNO, ADDR1, ADDR2, ADDR3, ADDRNO, MOO, SOI, ROAD, SUBDISTRICT, DISTRICT, PROVINCE, " & _
         " POSTCD, PHONE1, CNTYCD, EXT, FAXNO, MOBILENO, EMAIL1, EMAIL2, EMAIL3, CONTNAME, OPENDATE, CLOSEDATE, " & _
         " UPDUSER, UPDDATE, UPDTIME, COMMTHFG, SNDMETHOD,INSTRUCTION,CUSTSTATUS,AUTUSER,AUTDATE,AUTTIME,OBJDESC,PLACENAME,EXIMCUSTID,SENDRCPT,CUSTVIP,SIERRAID, " & _
         " COALESCE(DOCTORECV,''), COALESCE(CONTACTBY,'') FROM DB2.FORMCUST " & _
         " WHERE FORCUSTID = '" & strForCustID & "'"

        'FORCUSTID[0]   ITSCNO[1]   OCCODE[2]       OBJCD[3]        BOIFG[4]        CUSTIND[5]
        'CustType[6]    THTITLE[7]  ENGTITLE[8]     SWNAME2[9]      SWNAME1[10]     RMNAME[11] 
        'RMNO[12]       ADDR1[13]   ADDR3[14]       ADDR2[15]       ADDRNO[16]      MOO[17] 
        'SOI[18]        ROAD[19]    SUBDISTRICT[20] DISTRICT[21]    PROVINCE[22]    POSTCD[23]
        'PHONE1[24]     CNTYCD[25]  EXT[26]         FAXNO[27]       MOBILENO[28]    EMAIL1[29] 
        'EMAIL2[30]     EMAIL3[31]  CONTNAME[32]    OPENDATE[33]    CLOSEDATE[34]   UPDUSER[35] 
        'UPDDATE[36]    UPDTIME[37] COMMTHFG[38]    SNDMETHOD[39]   INSTRUCTION[40] CUSTSTATUS[41]
        'AUTUSER[42]    AUTDATE[43] AUTTIME[44]     OBJDESC[45]     PLACENAME[46]   EXIMCUSTID[47]
        'SENDRCTP[48]   CUSTVIP[49] SIERRAID[50]
        'DOCTORECV[51]  CONTACTBY[52]       'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add DoctoRecv


        dtResultSet2 = connDB.RunQuerySql(strSql)
        If dtResultSet2.Tables.Count > 0 Then
            Dim dtRow As DataRow
            For Each dtRow In dtResultSet2.Tables(0).Rows

                Session("optCustType") = UCase(Trim(dtRow.Item(5).ToString()))
                LoadMainInformation()
                Me.txtObjCode.Text = Trim(dtRow.Item(3).ToString())

                Dim strObjdes As String = ""
                If Trim(dtRow.Item(3).ToString()) = "318036" Or _
                Trim(dtRow.Item(3).ToString()) = "318131" Or _
                Trim(dtRow.Item(3).ToString()) = "318141" Then
                    strObjdes = Left(Trim(dtRow.Item(45).ToString()), 100)
                    Me.txtObjDesc.Enabled = True
                    Me.txtObjDesc.BackColor = Drawing.Color.LightYellow
                Else
                    If Not GetValueObj(Trim(dtRow.Item(3).ToString()), strObjdes) Then
                        cstext1 = "alert('Error!! Can not select Object Dexcription.');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    End If
                    Me.txtObjDesc.Enabled = False
                End If


                Me.txtObjDesc.Text = strObjdes
                Me.Radio_typeCust.Enabled = False
                '**********************Tab Address *************************************
                LoadDDL_Province()
                Me.ddlProvince.SelectedIndex = Me.ddlProvince.Items.IndexOf(Me.ddlProvince.Items.FindByValue(Trim(dtRow.Item(22).ToString())))
                LoadDDL_District()
                Me.ddlDistrict.SelectedIndex = Me.ddlDistrict.Items.IndexOf(Me.ddlDistrict.Items.FindByValue(Trim(dtRow.Item(21).ToString())))

                '***56100048 Ron
                'strSql = " select '' as code,'','--Please Select Country Code--'  as SHOW from db2.frcmtbcd where type = 'C003' and flaguse = 'Y' union " & _
                '         " select code, value,code|| ' : ' || value as SHOW from db2.frcmtbcd " & _
                '         " where type = 'C003' and flaguse = 'Y' " & _
                '         " order by code "
                strSql = " select '' as code,'','--Please Select Country Code--'  as SHOW from db2.frcmtbcd where type = 'C003' and flaguse = 'Y' union " & _
                         " select code, value,code|| ' : ' || value as SHOW from db2.frcmtbcd " & _
                         " where type = 'C003' and flaguse = 'Y' " & _
                         "  AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C003' and flaguse = 'Y' ", concur.SWIFTCODE) & "' " & _
                         " order by code "
                If Not PublicFunc.PopulateLoadDDL(Me.ddlContryCode, "CODE", "SHOW", strSql) Then
                    cstext1 = "alert('Error!! ID No. should be filled.');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                End If

                Me.ddlContryCode.SelectedIndex = Me.ddlContryCode.Items.IndexOf(Me.ddlContryCode.Items.FindByValue(Trim(dtRow.Item(25).ToString())))
                'Me.ddlContactBy.SelectedIndex = Me.ddlContactBy.Items.IndexOf(Me.ddlContactBy.Items.FindByValue(Trim(dtRow.Item(39).ToString())))
                'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Contact By
                Me.ddlContactBy.SelectedIndex = Me.ddlContactBy.Items.IndexOf(Me.ddlContactBy.Items.FindByValue(Trim(dtRow.Item(52).ToString())))
                '**********************Tab Address *************************************

                If Trim(dtRow.Item(5).ToString()) = "I" Then
                    Radio_typeCust.SelectedValue = "I"
                    MViewTypeCust.ActiveViewIndex = 0
                    LoadDDLIndividual()

                    Panel1.Visible = True
                    Panel3.Visible = True
                    Panel5.Visible = False
                    Panel2.Visible = True

                    Me.ddlItscNo.SelectedIndex = Me.ddlItscNo.Items.IndexOf(Me.ddlItscNo.Items.FindByValue(Trim(dtRow.Item(1).ToString())))
                    Me.ddlOcCode_I.SelectedIndex = Me.ddlOcCode_I.Items.IndexOf(Me.ddlOcCode_I.Items.FindByValue(Trim(dtRow.Item(2).ToString())))


                    Session("optCustType") = "I"
                    Me.ddlItscNo.Enabled = True
                    Me.ddlOcCode_I.Enabled = True

                    GetDataForInd(strForCustID)
                Else
                    Session("optCustType") = "C"
                    Radio_typeCust.SelectedValue = "C"
                    If Not LoadMainInformation() Then
                        cstext1 = "alert('Can not Load DropdownLisf of Main type C');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    End If

                    If Not LoadDDLCoporate() Then
                        cstext1 = "alert('Can not Load DropdownLisf of Menu Coporate');"
                        cs.RegisterStartupScript(cstype, csname1, cstext1, True)

                    End If
                    Me.ddlItscNO_C.SelectedIndex = Me.ddlItscNO_C.Items.IndexOf(Me.ddlItscNO_C.Items.FindByValue(Trim(dtRow.Item(1).ToString())))
                    Me.ddlOcCode_C.SelectedIndex = Me.ddlOcCode_C.Items.IndexOf(Me.ddlOcCode_C.Items.FindByValue(Trim(dtRow.Item(2).ToString())))

                    Me.ddlItscNO_C.Enabled = True
                    Me.ddlOcCode_C.Enabled = True


                    GetDataForCor(strForCustID)

                End If

                If Trim(dtRow.Item(4).ToString()) = "1" Then Me.checkBOI.Checked = True
                strTitle = Trim(dtRow.Item(8).ToString())
                Me.CustType.SelectedIndex = Me.CustType.Items.IndexOf(Me.CustType.Items.FindByValue(Trim(dtRow.Item(6).ToString())))
                Session("CustTypeSelect") = Trim(dtRow.Item(6).ToString())
                Me.DDLTitle.SelectedIndex = Me.DDLTitle.Items.IndexOf(Me.DDLTitle.Items.FindByValue(strTitle))
                'FORCUSTID[0]   ITSCNO[1]   OCCODE[2]       OBJCD[3]        BOIFG[4]        CUSTIND[5]
                'CustType[6]    THTITLE[7]  ENGTITLE[8]     SWNAME2[9]      SWNAME1[10]     RMNAME[11] 
                'RMNO[12]       ADDR1[13]   ADDR3[14]       ADDR2[15]       ADDRNO[16]      MOO[17] 
                'SOI[18]        ROAD[19]    SUBDISTRICT[20] DISTRICT[21]    PROVINCE[22]    POSTCD[23]
                'PHONE1[24]     CNTYCD[25]  EXT[26]         FAXNO[27]       MOBILENO[28]    EMAIL1[29] 
                'EMAIL2[30]     EMAIL3[31]  CONTNAME[32]    OPENDATE[33]    CLOSEDATE[34]   UPDUSER[35] 
                'UPDDATE[36]    UPDTIME[37] COMMTHFG[38]    SNDMETHOD[39]   INSTRUCTION[40] CUSTSTATUS[41]
                'AUTUSER[42]    AUTDATE[43] AUTTIME[44]     OBJDESC[45]     PLACENAME[46]   EXIMCUSTID[47]
                'SENDRCTP[48]   CUSTVIP[49] SIERRAID[50]
                'DOCTORECV[51]  CONTACTBY[52]       'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Add DoctoRecv
                Me.TextName1.Value = Trim(dtRow.Item(9).ToString())
                Me.TextName2.Value = Trim(dtRow.Item(10).ToString())

                Me.txtNameRM.Value = Trim(dtRow.Item(11).ToString())
                Me.txtNoRM.Value = Trim(dtRow.Item(12).ToString())
                Me.txtNoRM.EnableViewState = True

                Me.txtAddressL1.Value = Trim(dtRow.Item(13).ToString())
                Me.txtAddressL2.Value = Trim(dtRow.Item(14).ToString())
                Me.txtAddressL3.Value = Trim(dtRow.Item(15).ToString())

                Me.PlaceName.Value = dtRow.Item(46).ToString()
                Me.txtAddressNo.Value = Trim(dtRow.Item(16).ToString())
                Me.txtMoo.Value = Trim(dtRow.Item(17).ToString())
                Me.txtSoi.Value = Trim(dtRow.Item(18).ToString())
                Me.txtRoad.Value = Trim(dtRow.Item(19).ToString())

                Me.txtSubDistrict.Value = Trim(dtRow.Item(20).ToString())

                LoadDDL_Province()
                Me.ddlProvince.SelectedIndex = Me.ddlProvince.Items.IndexOf(Me.ddlProvince.Items.FindByValue(Trim(dtRow.Item(22).ToString())))
                LoadDDL_District()
                Me.ddlDistrict.SelectedIndex = Me.ddlDistrict.Items.IndexOf(Me.ddlDistrict.Items.FindByValue(Trim(dtRow.Item(21).ToString())))
                LoadDDL_PostCode()

                If Me.ddlPostCode.Items.IndexOf(Me.ddlPostCode.Items.FindByValue(Trim(dtRow.Item(23).ToString()))) = -1 Then
                    Me.txtPostCode.Value = Trim(dtRow.Item(23).ToString())
                Else
                    Me.ddlPostCode.SelectedIndex = Me.ddlPostCode.Items.IndexOf(Me.ddlPostCode.Items.FindByValue(Trim(dtRow.Item(23).ToString())))
                    Me.txtPostCode.Value = ""
                End If

                If Trim(dtRow.Item(24).ToString()) <> "" Then
                    Me.txtTelPhone.Text = Left(Trim(dtRow.Item(24).ToString()), 2) & "-" & Mid(Trim(dtRow.Item(24).ToString()), 3, 3) & "-" & Right(Trim(dtRow.Item(24).ToString()), 4)
                Else
                    Me.txtTelPhone.Text = ""
                End If

                Me.txtExt.Value = Trim(dtRow.Item(26).ToString())
                If Trim(dtRow.Item(27).ToString()) <> "" Then
                    Me.txtFaxNo.Text = Left(Trim(dtRow.Item(27).ToString()), 2) & "-" & Mid(Trim(dtRow.Item(27).ToString()), 3, 3) & "-" & Right(Trim(dtRow.Item(27).ToString()), 4)
                Else
                    Me.txtFaxNo.Text = ""
                End If

                If Trim(dtRow.Item(28).ToString()) <> "" Then
                    Me.txtMobileNo.Text = Left(Trim(dtRow.Item(28).ToString()), 2) & "-" & Mid(Trim(dtRow.Item(28).ToString()), 3, 4) & "-" & Right(Trim(dtRow.Item(28).ToString()), 4)
                Else
                    Me.txtMobileNo.Text = ""
                End If

                Me.txtEmail1.Text = Trim(dtRow.Item(29).ToString())
                Me.txtEmail2.Text = Trim(dtRow.Item(30).ToString())
                Me.txtEmail3.Text = Trim(dtRow.Item(31).ToString())


                'START xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Code Copied from FORWEB TH Version, Modified to fit current DOCTORECV requirement for this UR
                '#######################Set Document Information####################### 
                Dim arrDocToRcv() As String, strChanToRcvdb As String, m As Integer
                'Document To Receive 'DOCTORECV[51]

                If Trim(dtRow.Item(51).ToString()) <> "" Then
                    arrDocToRcv = Split(Trim(dtRow.Item(51).ToString()), "|")
                    For m = 0 To UBound(arrDocToRcv)
                        If arrDocToRcv(m) = "A" Then
                            chkRcvAdv.Checked = True
                        ElseIf arrDocToRcv(m) = "M" Then
                            chkRcvMT103.Checked = True
                            '2017-11-06 Ralph : UR#CB60040011 code here******************************
                        End If
                    Next m

                    strChanToRcvdb = Trim(dtRow.Item(39).ToString())
                    If strChanToRcvdb = "E" Then
                        chkRcvByEmail.Checked = True
                    End If
                End If
                'END xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Code Copied from FORWEB TH Version, Modified to fit current DOCTORECV requirement for this UR


                Dim dateOpen As Date
                dateOpen = Trim(dtRow.Item(33).ToString())
                If dateOpen = Nothing Then
                    Me.labShowOpenDate.Visible = False
                Else
                    If Session("SearchFor") = "DELETE" Or Session("SearchFor") = "INQUIRY" Or Session("SearchFor") = "UPDATE" Then
                        Me.labShowOpenDate.Visible = True
                        Me.labShowOpenDate.Text = "Open Date : " & Format(dateOpen, "dd/MM/yyyy")
                    Else
                        Me.labShowOpenDate.Visible = False
                    End If
                End If


                Me.txtContactName1.Value = Left(Trim(dtRow.Item(32).ToString()), 25)
                Me.txtContactName2.Value = Mid(Trim(dtRow.Item(32).ToString()), 26, Len(Me.txtContactName1.Value.ToString()))

                If Trim(dtRow.Item(38).ToString()) = "Y" Then Me.Check_comm.Checked = True

                Me.txtNote.Value = Trim(dtRow.Item(40).ToString())

                'Kwang::2008-06-25
                If Trim(dtRow.Item(43).ToString()) <> "" Then
                    Dim tmpDate As Date
                    tmpDate = Trim(dtRow.Item(43).ToString())
                    Session("CustAuthUser") = Trim(dtRow.Item(42).ToString())
                    Session("CustAutDate") = Format(tmpDate, "yyyy-MM-dd")
                    Session("CustAutTime") = Trim(dtRow.Item(44).ToString())
                Else
                    Session("CustAuthUser") = ""
                End If
                'kwang :: 2008-09-30
                Me.txtEximAlpha.Text = Trim(dtRow.Item(47).ToString())

                'Kwang R52030022
                If Trim(dtRow.Item(48).ToString()) = "Y" Then
                    Me.chkSendRCPT.Checked = True
                Else
                    Me.chkSendRCPT.Checked = False
                End If

                If Trim(dtRow.Item(49).ToString()) = "Y" Then
                    Me.chkCustVIP.Checked = True
                Else
                    Me.chkCustVIP.Checked = False

                End If

            Next

            'Kwang R53060089 
            Me.txtSierraID.Text = Trim(dtRow.Item(50).ToString())
            If GetAppcode(strForCustID) Then
                Me.labelShowBCMS.Visible = True
                Me.labelShowBCMS.Text = "BCMS"
            Else
                Me.labelShowBCMS.Visible = False
            End If

            GetDataForIden(strForCustID)
            GetDataForAccount(strForCustID)
            GetDataForFee(strForCustID)
            GetDataForRate(strForCustID)



        End If

        conn.Close()

    End Function
    Public Function GetDataForInd(ByVal strForCustID) As Boolean
        Dim strSql As String
        Dim dtResultSet2 As DataSet
        Dim conn As OdbcConnection = connDB.getDBConn()

        strSql = " SELECT FORCUSTID ,NATIONCD ,BIRTHDT, SEX , CARRER FROM DB2.FORLCUIN " & _
                 " WHERE FORCUSTID = '" & strForCustID & "'"

        'FORCUSTID [0] NATIONCD[1] BIRTHDT[2] SEX[3] CARRER[4]

        dtResultSet2 = connDB.RunQuerySql(strSql)
        If dtResultSet2.Tables.Count > 0 Then
            Dim dtRow2 As DataRow
            For Each dtRow2 In dtResultSet2.Tables(0).Rows
                Radio_typeCust.SelectedValue = "I"
                MViewTypeCust.ActiveViewIndex = 0

                Panel1.Visible = True
                Panel3.Visible = True
                Panel5.Visible = True
                Panel2.Visible = True

                Me.ddlNation_code.SelectedIndex = Me.ddlNation_code.Items.IndexOf(Me.ddlNation_code.Items.FindByValue(Trim(dtRow2.Item(1).ToString())))

                Dim dateBirth As Date
                dateBirth = Trim(dtRow2.Item(2).ToString())
                If dateBirth = Nothing Then dateBirth = Format(Now, "dd/MM/yyyy")
                Me.txtBirthDate.Text = Format(dateBirth, "dd/MM/yyyy")

                Me.ddlsex.SelectedIndex = Me.ddlsex.Items.IndexOf(Me.ddlsex.Items.FindByValue(Trim(dtRow2.Item(3).ToString())))
                Me.ddlcareer.SelectedIndex = Me.ddlcareer.Items.IndexOf(Me.ddlcareer.Items.FindByValue(Trim(dtRow2.Item(4).ToString())))

            Next
        End If

        conn.Close()
    End Function

    Public Function GetDataForCor(ByVal strForCustID) As Boolean
        Dim strSql As String
        Dim dtResultSet2 As DataSet
        Dim strRegDate As String
        Dim conn As OdbcConnection = connDB.getDBConn()

        strSql = " SELECT FORCUSTID ,REGDATE ,BUSITYPE FROM DB2.FORLCUCO " & _
                 " WHERE FORCUSTID = '" & strForCustID & "'"

        'FORCUSTID[0] ,REGDATE[1] ,BUSITYPe[2]

        dtResultSet2 = connDB.RunQuerySql(strSql)
        If dtResultSet2.Tables.Count > 0 Then
            Dim dtRow2 As DataRow
            For Each dtRow2 In dtResultSet2.Tables(0).Rows
                Radio_typeCust.SelectedValue = "C"
                MViewTypeCust.ActiveViewIndex = 1
                Panel1.Visible = True
                Panel3.Visible = True
                Panel5.Visible = True
                Panel2.Visible = False

                Dim dateReg As Date
                dateReg = Trim(dtRow2.Item(1).ToString())
                If dateReg = Nothing Then dateReg = Format(Now, "dd/MM/yyyy")

                strRegDate = Format(dateReg, "dd/MM/yyyy")

                Me.txtRegDate.Text = strRegDate

                Me.DDL_BusinessType.SelectedIndex = Me.DDL_BusinessType.Items.IndexOf(Me.DDL_BusinessType.Items.FindByValue(Trim(dtRow2.Item(2).ToString())))

            Next
        End If

        conn.Close()
    End Function
    Public Function GetDataForIden(ByVal strForCustID) As Boolean
        Dim strSql As String
        Dim dtresultset2 As DataSet

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        '***56100048 Ron
        'strSql = " SELECT a.IDTYPE ,a.IDNO,b.SHOW FROM DB2.FORLCUID a " & _
        '         " left outer join ( select code, code||' : '||value as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
        '         " code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y')) as b on b.code = a.idtype " & _
        '         " WHERE FORCUSTID = '" & strForCustID & "'"
        strSql = " SELECT a.IDTYPE ,a.IDNO,b.SHOW FROM DB2.FORLCUID a " & _
                 " left outer join " & _
                 "  ( " & _
                 "   select code, code||' : '||value as SHOW " & _
                 "   from db2.frcmtbcd " & _
                 "   where type = 'T003' and flaguse = 'Y' " & _
                 "    and code in " & _
                 "    (" & _
                 "     select value from db2.frcmtbcd " & _
                 "     where type = 'R001' and flaguse = 'Y' " & _
                 "      AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'R001' and flaguse = 'Y' ", concur.SWIFTCODE) & "' " & _
                 "     ) " & _
                 "   AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T003' and flaguse = 'Y' ", concur.SWIFTCODE) & "' " & _
                 "   ) as b on b.code = a.idtype " & _
                 " WHERE FORCUSTID = '" & strForCustID & "'"

        dtresultset2 = connDB.RunQuerySql(strSql)
        If dtresultset2.Tables.Count > 0 Then
            Dim dtRow As DataRow
            For Each dtRow In dtresultset2.Tables(0).Rows
                If Session("Mdt") Is Nothing Then
                    Mdt.Columns.Add(New DataColumn("NO", GetType(System.String)))
                    Mdt.Columns.Add(New DataColumn("IDType", GetType(System.String)))

                    Mdt.Columns.Add(New DataColumn("IDNUMBER", GetType(System.String)))
                    Mdt.Columns.Add(New DataColumn("IDCode", GetType(System.String)))
                Else

                End If

                Dim dr As DataRow
                dr = Mdt.NewRow
                dr("NO") = Mdt.Rows.Count + 1
                dr("IDType") = Trim(dtRow.Item(2).ToString())
                dr("IDNumber") = Trim(dtRow.Item(1).ToString())
                dr("IDCode") = Trim(dtRow.Item(0).ToString())
                Mdt.Rows.Add(dr)

                GridIdentification.DataSource = Mdt
                GridIdentification.DataBind()
                Session("Mdt") = Mdt

                Me.ddlIdType.SelectedIndex = -1
                Me.txtIdNumber.Value = ""
                Me.txtIdNumberThai.Value = ""
            Next
        End If

        conn.Close()
    End Function

    Public Function GetDataForAccount(ByVal strForCustID) As Boolean
        '*** CMHI:95918818-65fa-49a0-9c5e-0c1fe3a83e76
        Dim strSql As String
        Dim dtresultset2 As DataSet

        Dim concur As FORWEB_Concurrency = _
         CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        Dim conn As OdbcConnection = connDB.getDBConn()
        strSql = _
        "select a.acno,a.actype,a.accurcd,a.accmainfg,b.SHOW,c.SHOW  " & _
        "from db2.forlcuac a " & _
        " left outer join  " & _
        " ( " & _
        "  select code, code||':'||value as SHOW  " & _
        "  from db2.frcmtbcd sq1_L1_a " & _
        "   INNER JOIN  " & _
        "   ( " & _
        "    SELECT SWIFTTCD  " & _
        "    FROM db2.FRCMTBCD " & _
        "    WHERE TYPE = 'T001' AND FLAGUSE = 'Y' " & _
        "     AND OTHINFORM = 'W' " & _
        "     AND SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
        "    ORDER BY SWIFTTCD DESC " & _
        "    FETCH FIRST 1 ROW ONLY " & _
        "    ) sq1_L1_b " & _
        "   ON sq1_L1_a.SWIFTTCD = sq1_L1_b.SWIFTTCD " & _
        "  where type = 'T001' and flaguse = 'Y'  " & _
        "   and othinform = 'W' " & _
        "  ) as b  " & _
        "  on b.CODE = a.actype  " & _
        " left outer join  " & _
        " ( " & _
        "  select cur_cd as CODE, cur_cd ||':'|| cur_name as SHOW  " & _
        "  from db2.host_currency sq2_L1_a " & _
        "   INNER JOIN " & _
        "   ( " & _
        "    SELECT SWIFTTCD " & _
        "    FROM DB2.HOST_CURRENCY " & _
        "    WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
        "    ORDER BY SWIFTTCD DESC " & _
        "    FETCH FIRST 1 ROW ONLY " & _
        "    ) sq2_L1_b " & _
        "   ON sq2_L1_a.CUR_CD = sq2_L1_b.SWIFTTCD " & _
        "  )  as c on c.CODE = a.accurcd  " & _
        "where forcustid = '" & strForCustID & "'"


        'a.acno[0] a.actype[1] a.accurcd[2] a.accmainfg[3] b.show[4] c.show[5]

        dtresultset2 = connDB.RunQuerySql(strSql)
        If dtresultset2.Tables.Count > 0 Then
            Dim dtRow As DataRow
            For Each dtRow In dtresultset2.Tables(0).Rows
                If Session("ACCDT") Is Nothing Then
                    ACCDT.Columns.Add(New DataColumn("NO", GetType(System.String)))
                    ACCDT.Columns.Add(New DataColumn("ACC_NO", GetType(System.String)))
                    ACCDT.Columns.Add(New DataColumn("ACC_TYPE", GetType(System.String)))
                    ACCDT.Columns.Add(New DataColumn("ACC_CUR", GetType(System.String)))
                    ACCDT.Columns.Add(New DataColumn("CHK_MAIN", GetType(System.String)))
                    ACCDT.Columns.Add(New DataColumn("ACCCODE", GetType(System.String)))
                    ACCDT.Columns.Add(New DataColumn("ACCCUR", GetType(System.String)))
                Else
                    'ACCDT = Session("ACCDT")
                End If

                Dim dr As DataRow
                dr = ACCDT.NewRow

                dr("NO") = ACCDT.Rows.Count + 1
                dr("ACC_NO") = Trim(dtRow.Item(0).ToString())
                dr("ACC_TYPE") = Trim(dtRow.Item(4).ToString())
                dr("ACC_CUR") = Trim(dtRow.Item(5).ToString())
                dr("CHK_MAIN") = Trim(dtRow.Item(3).ToString())
                dr("ACCCODE") = Trim(dtRow.Item(1).ToString())
                dr("ACCCUR") = Trim(dtRow.Item(2).ToString())
                ACCDT.Rows.Add(dr)

                GridAccount.DataSource = ACCDT
                GridAccount.DataBind()
                Session("ACCDT") = ACCDT

                Me.txtAcNO.Value = ""
                ddlAcType.SelectedIndex = -1
                ddlCurrency.SelectedIndex = -1

            Next
        End If

        conn.Close()
    End Function
    Public Function GetDataForFee(ByVal strForCustID) As Boolean
        Dim strSql As String
        Dim dtresultset2 As DataSet

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim i As Integer
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        'Kwang R52030022
        'strSql = " select distinct a.prodcd,a.feecd,a.feetype,a.feemrg,a.minfee,a.maxfee,b.show,c.show,d.show from db2.forlcufe a " & _
        '         " left outer join (select prodcd as CODE, proddesc as SHOW from db2.frcmprod) as b on b.code = a.prodcd   " & _
        '         " left outer join (select code as CODE, value as SHOW from db2.frcmtbcd where type = 'T002' and flaguse = 'Y' ) as c on c.code = a.feetype " & _
        '         " left outer join (select feecd as CODE, feename,feecd||':'||feename as SHOW,prodcd from db2.frcmsfee ) as d on d.code  = a.feecd and d.prodcd = a.prodcd" & _
        '         " where a.forcustid = '" & strForCustID & "'"

        '***56100048 Ron
        'strSql = " select distinct a.prodcd,a.feecd,a.feetype,a.feemrg,a.minfee,a.maxfee,b.show,c.show,d.show,a.remcur from db2.forlcufe a " & _
        ' " left outer join (select prodcd as CODE, proddesc as SHOW from db2.frcmprod) as b on b.code = a.prodcd   " & _
        ' " left outer join (select code as CODE, value as SHOW from db2.frcmtbcd where type = 'T002' and flaguse = 'Y' ) as c on c.code = a.feetype " & _
        ' " left outer join (select feecd as CODE, feename,feecd||':'||feename as SHOW,prodcd from db2.frcmsfee ) as d on d.code  = a.feecd and d.prodcd = a.prodcd" & _
        ' " where a.forcustid = '" & strForCustID & "'"
        strSql = " select distinct a.prodcd,a.feecd,a.feetype,a.feemrg,a.minfee,a.maxfee,b.show,c.show,d.show,a.remcur from db2.forlcufe a " & _
         " left outer join (select prodcd as CODE, proddesc as SHOW from db2.frcmprod) as b on b.code = a.prodcd   " & _
         " left outer join " & _
         " (" & _
         "  select code as CODE, value as SHOW from db2.frcmtbcd " & _
         "  where type = 'T002' and flaguse = 'Y' " & _
         "   AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T002' and flaguse = 'Y' ", concur.SWIFTCODE) & "' " & _
         "  ) as c on c.code = a.feetype " & _
         " left outer join (select feecd as CODE, feename,feecd||':'||feename as SHOW,prodcd from db2.frcmsfee ) as d on d.code  = a.feecd and d.prodcd = a.prodcd" & _
         " where a.forcustid = '" & strForCustID & "'"


        dtresultset2 = connDB.RunQuerySql(strSql)
        If dtresultset2.Tables.Count > 0 Then
            Dim dtRow As DataRow
            For Each dtRow In dtresultset2.Tables(0).Rows
                If Session("DT_FEE") Is Nothing Then

                    DT_FEE.Columns.Add(New DataColumn("NO", GetType(System.String)))
                    DT_FEE.Columns.Add(New DataColumn("PRONAME", GetType(System.String)))
                    DT_FEE.Columns.Add(New DataColumn("FEENAME", GetType(System.String)))
                    DT_FEE.Columns.Add(New DataColumn("FEETYPE", GetType(System.String)))

                    DT_FEE.Columns.Add(New DataColumn("FEEMAGIN", GetType(System.String)))
                    DT_FEE.Columns.Add(New DataColumn("FEEMIN", GetType(System.String)))
                    DT_FEE.Columns.Add(New DataColumn("FEEMAX", GetType(System.String)))

                    DT_FEE.Columns.Add(New DataColumn("PROCODE", GetType(System.String)))
                    DT_FEE.Columns.Add(New DataColumn("FEECODE", GetType(System.String)))
                    DT_FEE.Columns.Add(New DataColumn("FEETYPECODE", GetType(System.String)))
                    'Kwang R52030022
                    DT_FEE.Columns.Add(New DataColumn("FEECUR", GetType(System.String)))
                Else
                    'DT_FEE = Session("DT_FEE")
                End If

                For i = 0 To DT_FEE.Rows.Count - 1
                    If DT_FEE.Rows(i).Item(1).ToString = Trim(dtRow.Item(6).ToString()) And _
                        Trim(Mid(DT_FEE.Rows(i).Item(2).ToString, 1, InStr(DT_FEE.Rows(i).Item(2).ToString, ":") - 1)) = Trim(Mid(Trim(dtRow.Item(8).ToString()), 1, InStr(Trim(dtRow.Item(8).ToString()), ":") - 1)) And _
                        DT_FEE.Rows(i).Item(10).ToString = Trim(dtRow.Item(9).ToString()) Then
                        GoTo stepNextRow
                    End If
                Next

                Dim dr As DataRow
                dr = DT_FEE.NewRow

                dr("NO") = DT_FEE.Rows.Count + 1
                dr("PRONAME") = Trim(dtRow.Item(6).ToString())
                dr("FEENAME") = Trim(dtRow.Item(8).ToString())
                dr("FEETYPE") = Trim(dtRow.Item(7).ToString())

                dr("FEEMAGIN") = Format(CDbl(Trim(dtRow.Item(3).ToString())), "##,##0.0000000")
                dr("FEEMIN") = Format(CDec(Trim(dtRow.Item(4).ToString())), "##,##0.00")
                dr("FEEMAX") = Format(CDec(Trim(dtRow.Item(5).ToString())), "##,##0.00")

                dr("PROCODE") = Trim(dtRow.Item(0).ToString())
                dr("FEECODE") = Trim(dtRow.Item(1).ToString())
                dr("FEETYPECODE") = Trim(dtRow.Item(2).ToString())
                'Kwang R52030022
                dr("FEECUR") = Trim(dtRow.Item(9).ToString())
                DT_FEE.Rows.Add(dr)

                GridFee.DataSource = DT_FEE
                GridFee.DataBind()
                Session("DT_FEE") = DT_FEE
stepNextRow:
            Next
        End If
        conn.Close()
    End Function

    Public Function GetDataForRate(ByVal strForCustID) As Boolean
        '*** CMHI:0fcc01db-5f34-48cf-b749-891b01e9d95e
        Dim strSql As String
        Dim dtresultset2 As DataSet

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        Dim conn As OdbcConnection = connDB.getDBConn()
        strSql = _
        "select a.prodcd,a.curcd,a.ratemrg,a.minamt,a.maxamt,b.show,c.show  " & _
        "from db2.forlcurt a  " & _
        " left outer join " & _
        " (" & _
        "  select prodcd as CODE, proddesc as SHOW " & _
        "  from db2.frcmprod" & _
        "  ) as b " & _
        " on b.code = a.prodcd " & _
        " left outer join " & _
        " (" & _
        "  select cur_cd as CODE, cur_cd ||':'|| cur_name as SHOW " & _
        "  from db2.host_currency" & _
        "  where swifttcd = '" & concur.SWIFTCODE & "' " & _
        "  ) as c on c.code = a.curcd " & _
        " where a.forcustid = '" & strForCustID & "' "

        'a.prodcd   [0] 
        'a.curcd    [1]
        'a.ratemrg  [2] 
        'a.minamt   [3] 
        'a.maxamt   [4] 
        'b.show     [5]
        'c.show     [6]

        dtresultset2 = connDB.RunQuerySql(strSql)
        If dtresultset2.Tables.Count > 0 Then
            Dim dtRow As DataRow
            For Each dtRow In dtresultset2.Tables(0).Rows
                If Session("DT_RATE") Is Nothing Then
                    DT_RATE.Columns.Add(New DataColumn("NO", GetType(System.String)))
                    DT_RATE.Columns.Add(New DataColumn("PRONAME", GetType(System.String)))
                    DT_RATE.Columns.Add(New DataColumn("RATECUR", GetType(System.String)))
                    DT_RATE.Columns.Add(New DataColumn("RATEMAGIN", GetType(System.String)))
                    DT_RATE.Columns.Add(New DataColumn("RATEMIN", GetType(System.String)))
                    DT_RATE.Columns.Add(New DataColumn("RATEMAX", GetType(System.String)))

                    DT_RATE.Columns.Add(New DataColumn("PROCODE", GetType(System.String)))
                    DT_RATE.Columns.Add(New DataColumn("CURCODE", GetType(System.String)))
                Else
                    'DT_RATE = Session("DT_RATE")
                End If

                Dim dr As DataRow
                dr = DT_RATE.NewRow

                dr("NO") = DT_RATE.Rows.Count + 1
                dr("PRONAME") = Trim(dtRow.Item(5).ToString())
                dr("RATECUR") = Trim(dtRow.Item(6).ToString())

                dr("RATEMAGIN") = Format(CDbl(Trim(dtRow.Item(2).ToString())), "##,##0.0000000")
                dr("RATEMIN") = Format(CDbl(Trim(dtRow.Item(3).ToString())), "##,##0.00")
                dr("RATEMAX") = Format(CDbl(Trim(dtRow.Item(4).ToString())), "##,##0.00")

                dr("PROCODE") = Trim(dtRow.Item(0).ToString())
                dr("CURCODE") = Trim(dtRow.Item(1).ToString())
                DT_RATE.Rows.Add(dr)

                GridRate.DataSource = DT_RATE
                GridRate.DataBind()
                Session("DT_RATE") = DT_RATE


            Next
        End If

        conn.Close()
    End Function


    Public Function DataCustIN(ByVal strForCustId As String, ByVal SearchFor As String, ByRef strMsgRunSql As String) As Boolean
        Dim strSql As String
        DataCustIN = True

        Mdt = Session("MDT")
        Dim i As Integer

        If Not Mdt Is Nothing Then
            If Mdt.Rows.Count > 0 Then

                Select Case UCase(SearchFor)
                    Case "INSERT"
                        For i = 0 To Mdt.Rows.Count - 1
                            strSql = " Insert into db2.forlcuid(FORCUSTID,IDTYPE,IDNO)  " & _
                                     " values('" & strForCustId & "','" & Mdt.Rows(i).Item(3) & "','" & Mdt.Rows(i).Item(2) & "')"

                            If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                                DataCustIN = False
                                Exit Function
                            End If
                        Next
                    Case "UPDATE"
                        For i = 0 To Mdt.Rows.Count - 1
                            strSql = "Delete from db2.forlcuid where forcustid ='" & strForCustId & "' "
                            If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                                DataCustIN = False
                                Exit Function
                            End If

                            If Not DataCustIN(strForCustId, "INSERT", strMsgRunSql) Then
                                DataCustIN = False
                                Exit Function
                            End If
                        Next
                    Case "DELETE"

                        '-_-'

                    Case "WAITING"
                        For i = 0 To Mdt.Rows.Count - 1
                            strSql = "Delete from db2.forlcuid where forcustid ='" & strForCustId & "' "
                            If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                                DataCustIN = False
                                Exit Function
                            End If

                            If Not DataCustIN(strForCustId, "INSERT", strMsgRunSql) Then
                                DataCustIN = False
                                Exit Function
                            End If
                        Next
                End Select
            Else
                If UCase(SearchFor) = "UPDATE" Or UCase(SearchFor) = "WAITING" Then
                    strSql = "Delete from db2.forlcuid where forcustid ='" & strForCustId & "' "
                    If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                        DataCustIN = False
                        Exit Function
                    End If

                End If


            End If
        End If

    End Function
    Public Function DataCustAC(ByVal strForCustId As String, ByVal SearchFor As String, ByRef strMsgRunSql As String) As Boolean
        Dim strSql As String
        Dim i As Integer
        DataCustAC = True

        ACCDT = Session("ACCDT")
        If Not ACCDT Is Nothing Then
            If ACCDT.Rows.Count > 0 Then
                Select Case UCase(SearchFor)
                    Case "INSERT"
                        For i = 0 To ACCDT.Rows.Count - 1
                            strSql = " Insert into db2.FORLCUAC(FORCUSTID,ACNO,ACTYPE,ACCURCD,ACCMAINFG)  " & _
                                        " values('" & strForCustId & "','" & Trim(ACCDT.Rows(i).Item(1)) & "','" & Trim(ACCDT.Rows(i).Item(5)) & "','" & Trim(ACCDT.Rows(i).Item(6)) & "','" & Trim(ACCDT.Rows(i).Item(4)) & "')"
                            If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                                DataCustAC = False
                                Exit Function
                            End If
                        Next
                    Case "UPDATE"
                        strSql = "DELETE from db2.forlcuac where FORCUSTID = '" & strForCustId & "'"

                        'Step :: 1 -> Delete 
                        If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                            DataCustAC = False
                            Exit Function
                        End If
                        'Step :: 2 -> Insert
                        If Not DataCustAC(strForCustId, "INSERT", strMsgRunSql) Then
                            DataCustAC = False
                            Exit Function
                        End If


                    Case "DELETE"
                        '-(-'
                    Case "WAITING"
                        strSql = "DELETE from db2.forlcuac where FORCUSTID = '" & strForCustId & "'"

                        'Step :: 1 -> Delete 
                        If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                            DataCustAC = False
                            Exit Function
                        End If
                        'Step :: 2 -> Insert
                        If Not DataCustAC(strForCustId, "INSERT", strMsgRunSql) Then
                            DataCustAC = False
                            Exit Function
                        End If


                End Select

            Else
                If UCase(SearchFor) = "UPDATE" Or UCase(SearchFor) = "WAITING" Then
                    strSql = "DELETE from db2.forlcuac where FORCUSTID = '" & strForCustId & "'"

                    If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                        DataCustAC = False
                        Exit Function
                    End If
                End If

            End If

        End If
    End Function
    Public Function DataCustFEE(ByVal strForCustId As String, ByVal SearchFor As String, ByRef strMsgRunSql As String) As Boolean
        Dim strSql As String
        Dim i As Integer
        DataCustFEE = True
        DT_FEE = Session("DT_FEE")
        If Not DT_FEE Is Nothing Then
            If DT_FEE.Rows.Count > 0 Then
                Select Case UCase(SearchFor)
                    Case "INSERT"
                        For i = 0 To DT_FEE.Rows.Count - 1

                            'strSql = " Insert into db2.FORLCUFE(FORCUSTID,PRODCD,FEECD,FEETYPE,FEEMRG,MINFEE,MAXFEE)  " & _
                            '         " values('" & strForCustId & "','" & Trim(DT_FEE.Rows(i).Item(7)) & "','" & Trim(DT_FEE.Rows(i).Item(8)) & "','" & Trim(DT_FEE.Rows(i).Item(9)) & "'," & Replace(Trim(DT_FEE.Rows(i).Item(4)), ",", "") & "," & Replace(Trim(DT_FEE.Rows(i).Item(5)), ",", "") & "," & Replace(Trim(DT_FEE.Rows(i).Item(6)), ",", "") & ")"

                            'Kwang R52030022 :: 
                            strSql = " Insert into db2.FORLCUFE(FORCUSTID,PRODCD,FEECD,FEETYPE,FEEMRG,MINFEE,MAXFEE,REMCUR)  " & _
                                     " values('" & strForCustId & "','" & Trim(DT_FEE.Rows(i).Item(7)) & "','" & Trim(DT_FEE.Rows(i).Item(8)) & "','" & Trim(DT_FEE.Rows(i).Item(9)) & "'," & Replace(Trim(DT_FEE.Rows(i).Item(4)), ",", "") & "," & Replace(Trim(DT_FEE.Rows(i).Item(5)), ",", "") & "," & Replace(Trim(DT_FEE.Rows(i).Item(6)), ",", "") & ",'" & Trim(DT_FEE.Rows(i).Item(10)) & "')"

                            If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                                DataCustFEE = False
                                Exit Function
                            End If
                        Next
                    Case "UPDATE"
                        strSql = "Delete from db2.forlcufe where forcustid = '" & strForCustId & "'"
                        If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                            DataCustFEE = False
                            Exit Function
                        End If

                        If Not DataCustFEE(strForCustId, "INSERT", strMsgRunSql) Then
                            DataCustFEE = False
                            Exit Function
                        End If


                    Case "DELETE"
                        '-_-'
                    Case "WAITING"
                        strSql = "Delete from db2.forlcufe where forcustid = '" & strForCustId & "'"
                        If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                            DataCustFEE = False
                            Exit Function
                        End If

                        If Not DataCustFEE(strForCustId, "INSERT", strMsgRunSql) Then
                            DataCustFEE = False
                            Exit Function
                        End If
                End Select
            Else
                If UCase(SearchFor) = "UPDATE" Or UCase(SearchFor) = "WAITING" Then
                    strSql = "Delete from db2.forlcufe where forcustid = '" & strForCustId & "'"
                    If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunSql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                        DataCustFEE = False
                        Exit Function
                    End If
                End If

            End If
        End If


    End Function
    Public Function DataCustRate(ByVal strForCustId As String, ByVal SearchFor As String, ByRef strMsgRunsql As String) As Boolean
        Dim strSql As String
        Dim i As Integer
        DataCustRate = True
        DT_RATE = Session("DT_RATE")
        If Not DT_RATE Is Nothing Then
            If DT_RATE.Rows.Count > 0 Then
                Select Case UCase(SearchFor)
                    Case "INSERT"
                        For i = 0 To DT_RATE.Rows.Count - 1
                            strSql = " Insert into db2.FORLCURT(FORCUSTID,PRODCD,CURCD,RATEMRG,MINAMT,MAXAMT)  " & _
                                      " values('" & strForCustId & "','" & Trim(DT_RATE.Rows(i).Item(6)) & "','" & Trim(DT_RATE.Rows(i).Item(7)) & "'," & Replace(Trim(DT_RATE.Rows(i).Item(3)), ",", "") & "," & Replace(Trim(DT_RATE.Rows(i).Item(4)), ",", "") & "," & Replace(Trim(DT_RATE.Rows(i).Item(5)), ",", "") & ")"

                            If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunsql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                                DataCustRate = False
                                Exit Function
                            End If

                        Next
                    Case "UPDATE"

                        strSql = "DELETE FROM DB2.FORLCURT WHERE FORCUSTID = '" & strForCustId & "'"
                        If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunsql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                            DataCustRate = False
                            Exit Function
                        End If

                        If Not DataCustRate(strForCustId, "INSERT", strMsgRunsql) Then
                            DataCustRate = False
                            Exit Function
                        End If


                    Case "DELETE"
                    Case "WAITING"
                        strSql = "DELETE FROM DB2.FORLCURT WHERE FORCUSTID = '" & strForCustId & "'"
                        If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunsql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                            DataCustRate = False
                            Exit Function
                        End If

                        If Not DataCustRate(strForCustId, "INSERT", strMsgRunsql) Then
                            DataCustRate = False
                            Exit Function
                        End If
                End Select
            Else
                If UCase(SearchFor) = "UPDATE" Or UCase(SearchFor) = "WAITING" Then
                    strSql = "DELETE FROM DB2.FORLCURT WHERE FORCUSTID = '" & strForCustId & "'"
                    If Not RunSqlFor(OdbcConn, OdbcMyTrans, strSql, strMsgRunsql, strForCustId, Session("strUserID"), Session("Funccd")) Then
                        DataCustRate = False
                        Exit Function
                    End If
                End If
            End If
        End If


    End Function


    Protected Sub BtnNextInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnNextInfo.Click
        Dim strsql As String
        Page.Validate()
        If Me.ddlContryCode.Items.Count = 0 Then
            '***56100048 Ron
            'strsql = " select '' as code,'','--Please Select Country Code--'  as SHOW from db2.frcmtbcd where type = 'C003' and flaguse = 'Y' union " & _
            '         " select code, value,code|| ' : ' || value as SHOW from db2.frcmtbcd where type = 'C003' and flaguse = 'Y' order by code"
            Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
            strsql = _
            " select '' as code,'','--Please Select Country Code--'  as SHOW from db2.frcmtbcd where type = 'C003' and flaguse = 'Y' union " & _
            " select code, value,code|| ' : ' || value as SHOW from db2.frcmtbcd " & _
            "where type = 'C003' and flaguse = 'Y' " & _
            " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C003' and flaguse = 'Y' ", concur.SWIFTCODE) & "' " & _
            "order by code"
            If Not PublicFunc.PopulateLoadDDL(Me.ddlContryCode, "CODE", "SHOW", strsql) Then
                cstext1 = "alert('Error!! ID No. should be filled.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)

            End If
            Me.ddlContryCode.SelectedIndex = Me.ddlContryCode.Items.IndexOf(Me.ddlContryCode.Items.FindByValue("TH"))
        End If

        If Trim(Me.ddlProvince.SelectedValue.ToString()) = "" Then
            Me.ddlDistrict.Enabled = False
        Else
            Me.ddlDistrict.Enabled = True
        End If


        If Me.ddlPostCode.Items.Count = 2 Then
            Me.ddlPostCode.Enabled = False
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        ElseIf Me.ddlPostCode.Items.Count = 1 Then
            If Trim(Me.ddlDistrict.SelectedValue.ToString()) = "" Then
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = False
                Me.txtPostCode.Value = ""
            Else
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = True
            End If
        Else
            Me.ddlPostCode.Enabled = True
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        End If


        MultiView_addCustomer.ActiveViewIndex = 1
        SetMenuAddCustomer(1)

    End Sub
    Public Function SetMenuAddCustomer(ByVal Item As Integer) As Boolean
        Dim i As Integer
        Dim strNameImage As String

        For i = 0 To Menu_AddCustomer.Items.Count - 1
            If i = Item Then
                strNameImage = "~/Image/selectedtab" & CStr(i) & ".gif"
                Menu_AddCustomer.Items(i).ImageUrl = Trim(strNameImage)
            Else
                strNameImage = "~/Image/unselectedtab" & CStr(i) & ".gif"
                Menu_AddCustomer.Items(i).ImageUrl = Trim(strNameImage)
            End If
        Next

    End Function

    Protected Sub ButClearAcc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButClearAcc.Click
        Me.txtAcNO.Value = ""
        Me.ddlAcType.SelectedIndex = -1
        Me.ddlCurrency.SelectedIndex = -1
        Me.ChkMain.Checked = False
    End Sub

    Protected Sub ButClearRate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButClearRate.Click
        Me.ddlRateProname.SelectedIndex = -1
        Me.ddlRateCurCode.SelectedIndex = -1
        Me.txtRateMargin.Text = "0.0000000"
        Me.txtRateMax.Text = "0.00"
        Me.txtRateMin.Text = "0.00"
        Me.RadioRateMargin.SelectedValue = "PLUS"
    End Sub

    Protected Sub ButBackIden_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButBackIden.Click
        MultiView_addCustomer.ActiveViewIndex = 1
        SetMenuAddCustomer(1)
        If Trim(Me.ddlProvince.SelectedValue.ToString()) = "" Then
            Me.ddlDistrict.Enabled = False
        Else
            Me.ddlDistrict.Enabled = True
        End If

        If Me.ddlPostCode.Items.Count = 2 Then
            Me.ddlPostCode.Enabled = False
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        ElseIf Me.ddlPostCode.Items.Count = 1 Then
            If Trim(Me.ddlDistrict.SelectedValue.ToString()) = "" Then
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = False
                Me.txtPostCode.Value = ""
            Else
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = True
            End If
        Else
            Me.ddlPostCode.Enabled = True
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        End If

        Page.Validate()
    End Sub

    Protected Sub ButNextIden_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButNextIden.Click

        SetMenuAddCustomer(3)
        Page.Validate()
        If Not loadTabAccount() Then
            cstext1 = "alert('Error!! Can not Load Tab Account');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub ButBackAcc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButBackAcc.Click
        Dim strSql As String
        MultiView_addCustomer.ActiveViewIndex = 2
        Me.ButIdenUpdate.Enabled = False
        Me.ButIdenCancel.Enabled = False
        Page.Validate()

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        If Session("optcusttype") = "I" Then
            '***56100048 Ron
            'strSql = _
            '" select '' as code,'--Please Select ID Type--' as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
            '" code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y') union " & _
            '" select code, code||' : '||value as SHOW from db2.frcmtbcd " & _
            '" where Type = 'T003' " & _
            '"  and CODE IN " & _
            '"  (" & _
            '"   SELECT VALUE FROM DB2.FRCMTBCD " & _
            '"   WHERE TYPE = 'R001' AND FLAGUSE = 'Y' " & _
            '"    AND CODE in " & _
            '"    (" & _
            '"     Select code from db2.frcmtbcd " & _
            '"     where Type = 'T004' and SCBCODE in ('1','2')" & _
            '"     )" & _
            '"   ) " & _
            '" and (scbcode is not null) " & _
            '"order by code"

            '*** Bring it back [Select OTHINFORM...] => [Select code...]
            strSql = _
            " select '' as code,'--Please Select ID Type--' as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
            " code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y') union " & _
            " select code, code||' : '||value as SHOW from db2.frcmtbcd " & _
            " where Type = 'T003' " & _
            "  and CODE IN " & _
            "  (" & _
            "   SELECT VALUE FROM DB2.FRCMTBCD " & _
            "   WHERE TYPE = 'R001' AND FLAGUSE = 'Y' " & _
            "    AND CODE in " & _
            "    (" & _
            "     Select code from db2.frcmtbcd " & _
            "     where Type = 'T004' and SCBCODE in ('1','2') " & _
            "      AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("Type = 'T004' and SCBCODE in ('1','2') ", concur.SWIFTCODE) & "' " & _
            "     )" & _
            "   ) " & _
            "  AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T003'", concur.SWIFTCODE) & "' " & _
            " and (scbcode is not null) " & _
            "order by code"

        Else
            'strSql = " select '' as code,'--Please Select ID Type--' as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
            '         " code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y') union " & _
            '         " select code, code||' : '||value as SHOW from db2.frcmtbcd where Type = 'T003' " & _
            '         " and CODE IN (SELECT VALUE FROM DB2.FRCMTBCD WHERE TYPE = 'R001' AND FLAGUSE = 'Y' " & _
            '         "              AND CODE in	(Select code from db2.frcmtbcd where Type = 'T004' and SCBCODE in ('3','4'))) " & _
            '         " and (scbcode is not null) order by code"

            '*** Bring it back [Select OTHINFORM...] => [Select code...]
            strSql = _
            " select '' as code,'--Please Select ID Type--' as SHOW from db2.frcmtbcd where type = 'T003' and flaguse = 'Y' and " & _
            " code in (select value from db2.frcmtbcd where type = 'R001' and flaguse = 'Y') union " & _
            " select code, code||' : '||value as SHOW " & _
            " from db2.frcmtbcd " & _
            " where Type = 'T003' " & _
            "  and CODE IN " & _
            "  (" & _
            "   SELECT VALUE FROM DB2.FRCMTBCD " & _
            "   WHERE TYPE = 'R001' AND FLAGUSE = 'Y' " & _
            "    AND CODE in	" & _
            "    (" & _
            "     Select code from db2.frcmtbcd " & _
            "     where Type = 'T004' and SCBCODE in ('3','4') " & _
            "      AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("Type = 'T004' and SCBCODE in ('3','4') ", concur.SWIFTCODE) & "' " & _
            "     ) " & _
            "   ) " & _
            "  AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T003' ", concur.SWIFTCODE) & "' " & _
            " and (scbcode is not null) order by code"

        End If

        Dim logger As New FORWEB_Logger(FORWEB_Logger.LogType.ActivityLog)
        logger.WriteLog(Chr(9) & "ButBackAcc" & strSql & Chr(9) & "******")
        If Not PublicFunc.PopulateLoadDDL(Me.ddlIdType, "code", "SHOW", strSql) Then
            cstext1 = "alert('Error!! List of ID Type Can not Load');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)

        End If
        SetMenuAddCustomer(2)
    End Sub

    Protected Sub ButNextAcc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButNextAcc.Click
        SetMenuAddCustomer(4)
        Page.Validate()
        If Not loadTabFee() Then
            cstext1 = "alert('Error!! Can not Load Tab Fee');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
    End Sub

    Protected Sub ButBackFee_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButBackFee.Click

        SetMenuAddCustomer(3)
        Page.Validate()

        If Not loadTabAccount() Then
            cstext1 = "alert('Error!! Can not Load Tab Account');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub ButNextFee_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButNextFee.Click


        SetMenuAddCustomer(5)
        Page.Validate()

        If Not loadTabRate() Then
            cstext1 = "alert('Error!! Can not Load Tab rate');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
    End Sub

    Protected Sub ButBackRate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButBackRate.Click

        SetMenuAddCustomer(4)
        Page.Validate()
        If Not loadTabFee() Then
            cstext1 = "alert('Error!! Can not Load Tab Fee');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub

    Protected Sub btnBackInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBackInfo.Click
        MultiView_addCustomer.ActiveViewIndex = 0

        Page.Validate()

        SetMenuAddCustomer(0)
    End Sub

    Protected Sub BtnNextIden_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnNextIden.Click

        SetMenuAddCustomer(2)
        Page.Validate()

        If Not loadTabIdentifi() Then
            cstext1 = "alert('Error!! Can not Load Tab Identification');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Sub


    Protected Sub ButCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButCancel.Click
        Session("FromCancel") = True 'P630017-07 PII Log : March 2021 : Robin : Because from Cancel it still continues to record PII Log
        Select Case UCase(Session("SearchFor"))
            Case "INSERT"
                If Session("WAIT") = "TRUE" Then
                    If Trim(Session("Funccd")) = "2110" Then
                        Response.Redirect("~/frmAddCustomer.aspx?SEARCHFOR=INSERT")
                    Else
                        Response.Redirect("~/frmSearchCustomer.aspx?SEARCHFOR=" & Session("SearchFor") & "&LOAD=""")
                    End If
                Else
                    Response.Redirect("~/frmAddCustomer.aspx?SEARCHFOR=INSERT")
                End If
            Case "WAITING"
                Response.Redirect("~/frmSearchCustomer.aspx?SEARCHFOR=WAITING&LOAD=""")
            Case Else
                Response.Redirect("~/frmSearchCustomer.aspx?SEARCHFOR=" & Session("SearchFor") & "&LOAD=""")
        End Select

    End Sub
    Public Sub EnableForm()
        Me.Radio_typeCust.Enabled = False
        Me.txtAcNO.Disabled = True
        Me.txtAddressL1.Disabled = True
        Me.txtAddressL2.Disabled = True
        Me.txtAddressL3.Disabled = True
        Me.txtAddressNo.Disabled = True
        Me.txtContactName1.Disabled = True
        Me.txtContactName2.Disabled = True
        Me.txtExt.Disabled = True
        Me.txtIdNumber.Disabled = True

        Me.txtFaxNo.Enabled = True
        Me.txtIdNumberThai.Disabled = True
        Me.txtNote.Disabled = True
        Me.txtMoo.Disabled = True
        Me.txtRoad.Disabled = True
        Me.txtSoi.Disabled = True
        Me.PlaceName.Disabled = True
        Me.txtSubDistrict.Disabled = True
        Me.TextName1.Disabled = True
        Me.TextName2.Disabled = True
        Me.Panel_address.Enabled = False
        Me.Panel_Account.Enabled = False
        Me.panel_Addaccount.Enabled = False
        Me.panel_AddIden.Enabled = False
        Me.Panel_generalInfo.Enabled = False
        Me.panel_gridAccount.Enabled = False
        Me.Panel_gridRate.Enabled = False
        Me.Panel_Identification.Enabled = False
        Me.Panel_SpecialFee.Enabled = False
        Me.Panel_SpecialRate.Enabled = False
        Me.Panel1.Enabled = False
        Me.Panel2.Enabled = False
        Me.Panel4.Enabled = False
        Me.Panel5.Enabled = False

    End Sub
    Public Sub ClearTextInput()
        Me.TextName1.Value = ""
        Me.TextName2.Value = ""
        Me.txtNameRM.Value = ""
        Me.txtNote.Value = ""

        Me.txtAddressL1.Value = ""
        Me.txtAddressL2.Value = ""
        Me.txtAddressL3.Value = ""

        Me.txtContactName1.Value = ""
        Me.txtContactName2.Value = ""

        Me.txtExt.Value = ""
        Me.txtFaxNo.Text = ""
        Me.txtTelPhone.Text = ""
        Me.txtMobileNo.Text = ""

        Me.txtMoo.Value = ""
        Me.txtRoad.Value = ""

        Me.txtSelectObj.Text = ""
        Me.txtObjCode.Text = ""
        Me.txtObjDesc.Text = ""

        Me.txtSoi.Value = ""
        Me.PlaceName.Value = ""
        Me.txtSubDistrict.Value = ""

        LoadDDL_Province()
        Me.ddlProvince.SelectedIndex = -1
        LoadDDL_District()
        Me.ddlPostCode.Enabled = True
        LoadDDL_PostCode()

        Me.txtIdNumber.Value = ""
        Me.txtIdNumberThai.Value = ""
        Me.txtAddressNo.Value = ""
        Me.txtMoo.Value = ""

        Me.txtFeeMagin.Text = ""
        Me.txtMinFee.Text = ""
        Me.txtMaxFee.Text = ""

        Me.txtRateMargin.Text = ""
        Me.txtRateMin.Text = ""
        Me.txtRateMax.Text = ""

        Me.txtContactName1.Value = ""
        Me.txtContactName2.Value = ""
        Me.txtEmail1.Text = ""
        Me.txtEmail2.Text = ""
        Me.txtEmail3.Text = ""
        Me.ddlContactBy.SelectedIndex = -1
    End Sub

    Public Function AddCustomer() As Boolean
        '*** CMHI:97b150e9-0fb0-4973-929f-641cb71bcdd3
        AddCustomer = True
        Dim strsql As String
        Dim strItscNo As String
        Dim strOcCode As String
        Dim strObjCD As String = ""
        Dim strBOIfg As String = "0"
        Dim strCustInd As String
        Dim strCustType As String
        Dim strThTitle As String
        Dim strEngTitle As String = ""
        Dim strSwname2 As String
        Dim strSwname1 As String
        Dim strRmname As String
        Dim strRmno As String
        Dim strAddr1 As String
        Dim strAddr3 As String
        Dim strAddr2 As String
        Dim strAddrNO As String
        Dim strMOO As String
        Dim strSOI, strRoad, strSubDistrict, strDistrict As String
        Dim strProvince, strPostcd, strPhone1 As String
        Dim strEXT, strFaxNO, strMobileNO, strEmail1, strEmail2, strEmail3 As String
        Dim strContname, strUpdUser As String
        Dim strBirthDate As String

        Dim strCommthFG As String = "N"
        'Dim strSnDMethod As String ''xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - replaced by strContactBy
        Dim strTitleArr() As String
        Dim strCntycd As String
        Dim strMsgError As String = ""
        Dim strNote As String

        Dim strAutUserid As String
        Dim StrAutTime As String
        Dim StrAutDate As String

        Dim strPlaceName As String
        Dim strEximAlpha As String


        Dim i, j As Integer
        Dim strStatus As String = "A"
        'KWANG :: R52030022
        Dim strSendrcpt As String = "N"
        Dim strCustVIP As String = "N"
        Dim strTmpCustid As String = ""
        'Kwang :: R53060089
        Dim strSeirraID As String
        'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - DoctoRecv, Contact By
        Dim strDocToRcv As String, strChanToRcv As String, strContactBy As String


        Dim concur As FORWEB_Concurrency = _
         CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        'START xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - DoctoRecv and Chan to Receive
        strDocToRcv = ""
        strChanToRcv = ""

        'M : Recieve Document OR Debit Advice
        If chkRcvAdv.Checked = True Then
            strDocToRcv = "A"
        End If

        'M : Recieve Document MT103 (.pdf format)
        If chkRcvMT103.Checked = True Then
            If strDocToRcv = "" Then
                strDocToRcv = "M"
            Else
                strDocToRcv = strDocToRcv & "|M"
            End If
        End If

        'E : Recieve Document by E-Mail 
        If chkRcvByEmail.Checked = True Then
            strChanToRcv = "E"
        End If

        'Validate choose doc to receive but not choose channel to receive
        If strDocToRcv <> "" And strChanToRcv = "" Then
            strMsgRunSql = "Document Information.\nPlease select Channel To Receive !!"
            cstext1 = "alert('" & strMsgRunSql & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            Call Menu_AddCustomer_MenuItemClick(Me, New MenuEventArgs(Menu_AddCustomer.Items(1)))
            Exit Function
        End If


        'Validate email when choose channel to receive doc by email
        If InStr(strChanToRcv, "E") > 0 Or ddlContactBy.SelectedValue = "E" Then
            strEmail1 = txtEmail1.Text
            strEmail2 = txtEmail2.Text
            strEmail3 = txtEmail3.Text
            If strEmail1 = "" And strEmail2 = "" And strEmail3 = "" Then

                strMsgRunSql = "Contact Information.\nPlease input E-Mail Address !!"
                cstext1 = "alert('" & strMsgRunSql & "');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Call Menu_AddCustomer_MenuItemClick(Me, New MenuEventArgs(Menu_AddCustomer.Items(1)))
                Exit Function
            End If
        End If
        'END - SR3280 - Robin

        'Kwang R52030022
        If Session("WAIT") = "TRUE" Then
            strStatus = "W"
            If Session("optCustType") Is Nothing Then
                strCustInd = Radio_typeCust.SelectedValue
            Else
                strCustInd = Session("optCustType")
            End If

            GoTo StepNotCheck
        ElseIf Session("WAIT") = "FALSE" Then
            If Not DT_RATE Is Nothing Then
                If DT_RATE.Rows.Count > 0 Then Session("flagRateChange") = True
            End If
            If Not DT_FEE Is Nothing Then
                If DT_FEE.Rows.Count > 0 Then Session("flagFeeChange") = True
            End If

            strStatus = "A"
        End If
        strTmpCustid = Session("CustSearch")



        For j = 0 To Me.MultiView_addCustomer.Controls.Count - 2
            Me.MultiView_addCustomer.ActiveViewIndex = j
            Me.MultiView_addCustomer.Page.Validate()
            For i = 0 To Me.MultiView_addCustomer.Page.Validators.Count - 1
                If Not MultiView_addCustomer.Page.Validators(i).IsValid Then
                    strMsgError = Page.Validators(i).ErrorMessage
                    cstext1 = "alert('" & strMsgError & "');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    SetMenuAddCustomer(j)
                    Exit Function
                End If
            Next
        Next


        If Not ValidateTabInformation(strMsgError) Then Exit Function


        '******authorize 2 **********************************
        DT_RATE = Session("DT_RATE")
        DT_FEE = Session("DT_FEE")

        If Session("flagFeeChange") = True Or Session("flagRateChange") = True Then
            GoTo StepCheckUser2
        Else
            Session("AUTH2") = "AUTH_T"
            GoTo StepAddCustomer
        End If


StepCheckUser2:
        '****************************************************************************************
        If Not DT_RATE Is Nothing And Session("AUTH2") <> "AUTH_T" Then
            If DT_RATE.Rows.Count > 0 Then GoTo StepCallUser2

        ElseIf Not DT_FEE Is Nothing And Session("AUTH2") <> "AUTH_T" Then
            If DT_FEE.Rows.Count > 0 Then GoTo StepCallUser2
        Else
            Session("AUTH2") = "AUTH_T"
            Me.Panel3.Visible = True
            Me.PanelReqAuthority.Visible = False
            GoTo StepAddCustomer
        End If
        '****************************************************************************************
StepCallUser2:
        Me.MultiView_addCustomer.ActiveViewIndex = 0
        SetMenuAddCustomer(0)
        Me.PanelReqAuthority.Visible = True
        Me.Panel3.Visible = False
        Select Case Session("SearchFor")
            Case "INSERT", "UPDATE"
                lblReason1.Text = "Special Fee or Special Rate has been changed."
            Case "DELETE"
                lblReason1.Text = "Delete transaction is requested."
        End Select
        lblReason2.Text = "An authorization is required to complete the transaction."
        Session("AUTH2") = "AUTH_F"
        Session("USERAUTH2") = ""
        Exit Function
        '****************************************************************************************
StepAddCustomer:
        If Session("AUTH2") = "AUTH_T" Then
StepNotCheck:
            If Session("optcusttype") = "I" Then
                strItscNo = Me.ddlItscNo.SelectedValue.ToString()
                strOcCode = Me.ddlOcCode_I.SelectedValue.ToString()
            Else
                strItscNo = Me.ddlItscNO_C.SelectedValue.ToString()
                strOcCode = Me.ddlOcCode_C.SelectedValue.ToString()
            End If

            If Me.checkBOI.Checked = True Then strBOIfg = "1"
            strCustInd = Session("optCustType")
            strCustType = Me.CustType.SelectedValue.ToString()
            strThTitle = Me.DDLTitle.SelectedValue.ToString()

            If Trim(DDLTitle.SelectedValue.ToString()) <> "" Then
                If Trim(Session("optCustType")) = "I" Then
                    strTitleArr = Split(DDLTitle.SelectedItem.Text.ToString(), " : ", , CompareMethod.Text)
                    If Trim(strTitleArr(0)) <> "" And Trim(strTitleArr(1)) <> "" Then
                        strThTitle = DDLTitle.SelectedValue.ToString()
                        strEngTitle = strTitleArr(1).ToString()
                    End If
                Else
                    strTitleArr = Split(DDLTitle.SelectedItem.Text.ToString(), " : ", , CompareMethod.Text)
                    If Trim(strTitleArr(0)) <> "" And Trim(strTitleArr(1)) <> "" Then
                        strThTitle = DDLTitle.SelectedValue.ToString()
                        strEngTitle = strTitleArr(1).ToString()
                    End If

                End If

            End If
            '*******objcode
            Dim strObjDesc As String
            If Trim(Me.txtObjCode.Text.ToString()) = "318036" Or _
            Trim(txtObjCode.Text.ToString()) = "318131" Or _
            Trim(txtObjCode.Text.ToString()) = "318141" Then
                strObjDesc = PublicFunc.replaceString(Left(Me.txtObjDesc.Text.ToString(), 100))
            Else
                strObjDesc = ""
            End If

            strSwname1 = PublicFunc.replaceString(Me.TextName1.Value.ToUpper)
            strSwname2 = PublicFunc.replaceString(Me.TextName2.Value.ToUpper)
            strRmname = PublicFunc.replaceString(Me.txtNameRM.Value.ToUpper)
            strRmno = PublicFunc.replaceString(Me.txtNoRM.Value)
            strAddr1 = Left(PublicFunc.replaceString(Me.txtAddressL1.Value.ToString.ToUpper), 35)
            strAddr2 = Left(PublicFunc.replaceString(Me.txtAddressL2.Value.ToString.ToUpper), 35)
            strAddr3 = Left(PublicFunc.replaceString(Me.txtAddressL3.Value.ToString.ToUpper), 35)
            strAddrNO = PublicFunc.replaceString(Me.txtAddressNo.Value.ToString.ToUpper)
            strMOO = PublicFunc.replaceString(Me.txtMoo.Value.ToString.ToUpper)
            strSOI = PublicFunc.replaceString(Me.txtSoi.Value.ToString.ToUpper)
            strRoad = PublicFunc.replaceString(Me.txtRoad.Value.ToString.ToUpper)
            strSubDistrict = PublicFunc.replaceString(Me.txtSubDistrict.Value.ToString.ToUpper)
            strDistrict = Me.ddlDistrict.SelectedValue.ToString()
            strProvince = Me.ddlProvince.SelectedValue.ToString()
            strPlaceName = PublicFunc.replaceString(Me.PlaceName.Value.ToString())

            If Not Me.ddlPostCode.Enabled And Trim(Me.txtPostCode.Value.ToString()) = "" Then
                If Trim(Me.ddlPostCode.SelectedValue.ToString()) = "" Or Trim(Me.ddlPostCode.SelectedValue.ToString()) = "--Please Select Postcode--" Then
                    strPostcd = ""
                Else
                    strPostcd = Trim(Me.ddlPostCode.SelectedValue.ToString())
                End If
            ElseIf Trim(Me.txtPostCode.Value.ToString()) = "" Then
                If Trim(Me.ddlPostCode.SelectedValue.ToString()) = "" Or Trim(Me.ddlPostCode.SelectedValue.ToString()) = "--Please Select Postcode--" Then
                    strPostcd = ""
                Else
                    strPostcd = Trim(Me.ddlPostCode.SelectedValue.ToString())
                End If
            Else
                strPostcd = PublicFunc.replaceString(Trim(Me.txtPostCode.Value.ToString()).ToString())
            End If

            'StepNotCheck:

            strPhone1 = Trim(Replace(Trim(Me.txtTelPhone.Text.ToString()), "-", ""))
            strCntycd = Me.ddlContryCode.SelectedValue.ToString()

            strEXT = Me.txtExt.Value
            strFaxNO = Trim(Replace(Trim(Me.txtFaxNo.Text.ToString()), "-", ""))
            strMobileNO = Trim(Replace(Trim(Me.txtMobileNo.Text.ToString()), "-", ""))

            strEmail1 = PublicFunc.replaceString(Me.txtEmail1.Text)
            strEmail2 = PublicFunc.replaceString(Me.txtEmail2.Text)
            strEmail3 = PublicFunc.replaceString(Me.txtEmail3.Text)

            strContname = UCase(Left(PublicFunc.replaceString(Me.txtContactName1.Value & Me.txtContactName2.Value), 50))
            If Session("strUserID") Is Nothing Then strUpdUser = "WEBFOR"
            strUpdUser = Session("strUserID")

            strNote = Left(Replace(Me.txtNote.Value, "'", " "), 200)

            If Me.Check_comm.Checked = True Then strCommthFG = "Y"
            'strSnDMethod = Me.ddlContactBy.SelectedValue.ToString() 'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - replaced by strContactBy
            strContactBy = Me.ddlContactBy.SelectedValue.ToString()
            Dim strCustAutUser As String = ""
            If Not Session("CustAuthUser") Is Nothing Then strCustAutUser = Session("CustAuthUser")
            If Session("USERAUTH2") = "" Then
                If strCustAutUser <> "" Then
                    strAutUserid = strCustAutUser
                    StrAutDate = Trim("'" & Session("CustAutDate") & "'")
                    StrAutTime = Trim("'" & Session("CustAutTime") & "'")
                Else
                    strAutUserid = ""
                    StrAutDate = "NULL"
                    StrAutTime = "NULL"
                End If
            Else
                strAutUserid = Trim(Session("USERAUTH2"))
                'StrAutDate = Format(Now, "yyyy-MM-dd")
                'StrAutTime = Right(Now, 8)
                'kwang :: 2008-06-25
                'Dim AutDate As Date
                'AutDate = Trim(Format(Now.Date.Day, "00") & "/" & Format(Now.Month, "00") & "/" & Format(Now.Year, "0000"))
                'StrAutDate = Format(AutDate, "yyyy-MM-dd")
                'StrAutTime = Format(Now.TimeOfDay.Hours, "00") & ":" & Format(Now.TimeOfDay.Minutes, "00") & ":" & Format(Now.TimeOfDay.Seconds, "00")
                StrAutDate = "current date"
                StrAutTime = "current time"
            End If

            'strEximAlpha = Left(Trim(Me.txtEximAlpha.Value), 11)
            strEximAlpha = Left(Trim(Me.txtEximAlpha.Text), 11)

            'Kwang R52030022
            If Me.chkSendRCPT.Checked = True Then
                strSendrcpt = "Y"
            Else
                strSendrcpt = "N"
            End If

            If Me.chkCustVIP.Checked = True Then
                strCustVIP = "Y"
            Else
                strCustVIP = "N"
            End If

            'Kwang :: R53060089 
            strSeirraID = Left(Trim(txtSierraID.Text.ToString), 4)
            'cstext1 = "alert('" & StrAutDate & "');"
            'cs.RegisterStartupScript(cstype, csname1, cstext1, True)

            If Session("SearchFor") <> "UPDATE" And (Session("SearchFor") = "INSERT" Or Session("SearchFor") = "WAITING") Then

                If Session("SearchFor") = "WAITING" And (Session("CustSearch") <> "" And Not Session("CustSearch") Is Nothing) Then
                    If Session("WAIT") = "TRUE" Then
                        strFORCUSTID = Session("CustSearch")
                        If Left(strFORCUSTID, 3) = "TMP" Then
                            strStatus = "W"
                            GoTo UpdateCustTmp
                        End If
                    End If
                ElseIf Session("WAIT") = "FALSE" Then
                    strStatus = "A"
                End If

                If Not genCustId(strFORCUSTID) Then
                    ProcessSuccess = False
                    strMsgError = "Can not Generate New Customer ID\n"
                    cstext1 = "alert('" & strMsgError & "');"
                    cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                    AddCustomer = False
                    Exit Function
                End If

                'Kwang R52030022
                If Session("SearchFor") = "WAITING" And Session("WAIT") = "TRUE" Then strStatus = "W"

                'strsql = "INSERT INTO DB2.FORMCUST(FORCUSTID,ITSCNO, OCCODE, OBJCD, BOIFG, CUSTIND, CUSTTYPE, THTITLE, ENGTITLE, SWNAME1, SWNAME2, RMNAME, RMNO, ADDR1, ADDR2, ADDR3, ADDRNO, MOO, SOI, ROAD, SUBDISTRICT, DISTRICT, PROVINCE, POSTCD, PHONE1, CNTYCD, EXT, FAXNO, MOBILENO, EMAIL1, EMAIL2, EMAIL3, CONTNAME, OPENDATE, UPDUSER, UPDDATE, UPDTIME, COMMTHFG, SNDMETHOD,INSTRUCTION,CUSTSTATUS,AUTUSER,AUTDATE,AUTTIME,OBJDESC,PLACENAME,EXIMCUSTID) " & _
                '         " values( " & _
                '         " '" & strFORCUSTID & "' ,'" & strItscNo & "', '" & strOcCode & "', " & _
                '         " '" & Trim(Me.txtObjCode.Text) & "', '" & strBOIfg & "', '" & strCustInd & "', '" & strCustType & "', " & _
                '         " '" & strThTitle & "', '" & strEngTitle & "', '" & strSwname1 & "', '" & strSwname2 & "'," & _
                '         " '" & strRmname & "', '" & strRmno & "', '" & strAddr1 & "', '" & strAddr2 & "'," & _
                '         " '" & strAddr3 & "', '" & strAddrNO & "', '" & strMOO & "', '" & strSOI & "', " & _
                '         " '" & strRoad & "', '" & strSubDistrict & "', '" & strDistrict & "', '" & strProvince & "'," & _
                '         " '" & strPostcd & "', '" & strPhone1 & "', '" & strCntycd & "', '" & strEXT & "'," & _
                '         " '" & strFaxNO & "', '" & strMobileNO & "', '" & strEmail1 & "', '" & strEmail2 & "'," & _
                '         " '" & strEmail3 & "', '" & strContname & "',current date,'" & strUpdUser & "'," & _
                '         " current date,current time, '" & strCommthFG & "', '" & strSnDMethod & "','" & strNote & "','" & strStatus & "',' " & strAutUserid & "', " & _
                '         " " & StrAutDate & "," & StrAutTime & ",'" & strObjDesc & "','" & strPlaceName & "','" & strEximAlpha & "')"

                'strsql = "INSERT INTO DB2.FORMCUST(FORCUSTID,ITSCNO, OCCODE, OBJCD, BOIFG, CUSTIND, CUSTTYPE, THTITLE, ENGTITLE, SWNAME1, SWNAME2, RMNAME, RMNO, ADDR1, ADDR2, ADDR3, ADDRNO, MOO, SOI, ROAD, SUBDISTRICT, DISTRICT, PROVINCE, POSTCD, PHONE1, CNTYCD, EXT, FAXNO, MOBILENO, EMAIL1, EMAIL2, EMAIL3, CONTNAME, OPENDATE, UPDUSER, UPDDATE, UPDTIME, COMMTHFG, SNDMETHOD,INSTRUCTION,CUSTSTATUS,AUTUSER,AUTDATE,AUTTIME,OBJDESC,PLACENAME,EXIMCUSTID,SENDRCPT,CUSTVIP) " & _
                '         " values( " & _
                '         " '" & strFORCUSTID & "' ,'" & strItscNo & "', '" & strOcCode & "', " & _
                '         " '" & Trim(Me.txtObjCode.Text) & "', '" & strBOIfg & "', '" & strCustInd & "', '" & strCustType & "', " & _
                '         " '" & strThTitle & "', '" & strEngTitle & "', '" & strSwname1 & "', '" & strSwname2 & "'," & _
                '         " '" & strRmname & "', '" & strRmno & "', '" & strAddr1 & "', '" & strAddr2 & "'," & _
                '         " '" & strAddr3 & "', '" & strAddrNO & "', '" & strMOO & "', '" & strSOI & "', " & _
                '         " '" & strRoad & "', '" & strSubDistrict & "', '" & strDistrict & "', '" & strProvince & "'," & _
                '         " '" & strPostcd & "', '" & strPhone1 & "', '" & strCntycd & "', '" & strEXT & "'," & _
                '         " '" & strFaxNO & "', '" & strMobileNO & "', '" & strEmail1 & "', '" & strEmail2 & "'," & _
                '         " '" & strEmail3 & "', '" & strContname & "',current date,'" & strUpdUser & "'," & _
                '         " current date,current time, '" & strCommthFG & "', '" & strSnDMethod & "','" & strNote & "','" & strStatus & "',' " & strAutUserid & "', " & _
                '         " " & StrAutDate & "," & StrAutTime & ",'" & strObjDesc & "','" & strPlaceName & "','" & strEximAlpha & "','" & strSendrcpt & "','" & strCustVIP & "')"
                'R53060089
                'strsql = _
                '"INSERT INTO DB2.FORMCUST" & _
                '"(" & _
                '" FORCUSTID,ITSCNO, OCCODE, OBJCD, BOIFG, CUSTIND, " & _
                '" CUSTTYPE, THTITLE, ENGTITLE, SWNAME1, SWNAME2, RMNAME, " & _
                '" RMNO, ADDR1, ADDR2, ADDR3, ADDRNO, MOO, SOI, ROAD, " & _
                '" SUBDISTRICT, DISTRICT, PROVINCE, POSTCD, PHONE1, " & _
                '" CNTYCD, EXT, FAXNO, MOBILENO, EMAIL1, EMAIL2, EMAIL3, " & _
                '" CONTNAME, OPENDATE, UPDUSER, UPDDATE, UPDTIME, COMMTHFG, " & _
                '" SNDMETHOD,INSTRUCTION,CUSTSTATUS,AUTUSER,AUTDATE,AUTTIME," & _
                '" OBJDESC,PLACENAME,EXIMCUSTID,SENDRCPT,CUSTVIP,SIERRAID," & _
                '" CBSBANKCD) "
                'strsql &= _
                '"values" & _
                '" ( " & _
                '"  '" & strFORCUSTID & "' ,'" & strItscNo & "', " & _
                '"  '" & strOcCode & "', '" & Trim(Me.txtObjCode.Text) & "'," & _
                '"  '" & strBOIfg & "', '" & strCustInd & "', '" & strCustType & "', " & _
                '"  '" & strThTitle & "', '" & strEngTitle & "', " & _
                '"  '" & strSwname1 & "', '" & strSwname2 & "'," & _
                '"  '" & strRmname & "', '" & strRmno & "', " & _
                '"  '" & strAddr1 & "', '" & strAddr2 & "'," & _
                '"  '" & strAddr3 & "', '" & strAddrNO & "', " & _
                '"  '" & strMOO & "', '" & strSOI & "', " & _
                '"  '" & strRoad & "', '" & strSubDistrict & "', " & _
                '"  '" & strDistrict & "', '" & strProvince & "'," & _
                '"  '" & strPostcd & "', '" & strPhone1 & "', " & _
                '"  '" & strCntycd & "', '" & strEXT & "'," & _
                '"  '" & strFaxNO & "', '" & strMobileNO & "', " & _
                '"  '" & strEmail1 & "', '" & strEmail2 & "'," & _
                '"  '" & strEmail3 & "', '" & strContname & "'," & _
                '"  current date,'" & strUpdUser & "'," & _
                '"  current date,current time, '" & strCommthFG & "', " & _
                '"  '" & strSnDMethod & "','" & strNote & "'," & _
                '"  '" & strStatus & "',' " & strAutUserid & "', " & _
                '"  " & StrAutDate & "," & StrAutTime & "," & _
                '"  '" & strObjDesc & "','" & strPlaceName & "'," & _
                '"  '" & strEximAlpha & "','" & strSendrcpt & "'," & _
                '"  '" & strCustVIP & "','" & strSeirraID & "'," & _
                '"  '" & concur.CbsBankCd & "'" & _
                '"  )"

                'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - New column - DOCTORECV - CONTACT BY
                strsql = _
                "INSERT INTO DB2.FORMCUST" & _
                "(" & _
                " FORCUSTID,ITSCNO, OCCODE, OBJCD, BOIFG, CUSTIND, " & _
                " CUSTTYPE, THTITLE, ENGTITLE, SWNAME1, SWNAME2, RMNAME, " & _
                " RMNO, ADDR1, ADDR2, ADDR3, ADDRNO, MOO, SOI, ROAD, " & _
                " SUBDISTRICT, DISTRICT, PROVINCE, POSTCD, PHONE1, " & _
                " CNTYCD, EXT, FAXNO, MOBILENO, EMAIL1, EMAIL2, EMAIL3, " & _
                " CONTNAME, OPENDATE, UPDUSER, UPDDATE, UPDTIME, COMMTHFG, " & _
                " SNDMETHOD,INSTRUCTION,CUSTSTATUS,AUTUSER,AUTDATE,AUTTIME," & _
                " OBJDESC,PLACENAME,EXIMCUSTID,SENDRCPT,CUSTVIP,SIERRAID," & _
                " CBSBANKCD, DOCTORECV, CONTACTBY) "

                strsql &= _
                "values" & _
                " ( " & _
                "  '" & strFORCUSTID & "' ,'" & strItscNo & "', " & _
                "  '" & strOcCode & "', '" & Trim(Me.txtObjCode.Text) & "'," & _
                "  '" & strBOIfg & "', '" & strCustInd & "', '" & strCustType & "', " & _
                "  '" & strThTitle & "', '" & strEngTitle & "', " & _
                "  '" & strSwname1 & "', '" & strSwname2 & "'," & _
                "  '" & strRmname & "', '" & strRmno & "', " & _
                "  '" & strAddr1 & "', '" & strAddr2 & "'," & _
                "  '" & strAddr3 & "', '" & strAddrNO & "', " & _
                "  '" & strMOO & "', '" & strSOI & "', " & _
                "  '" & strRoad & "', '" & strSubDistrict & "', " & _
                "  '" & strDistrict & "', '" & strProvince & "'," & _
                "  '" & strPostcd & "', '" & strPhone1 & "', " & _
                "  '" & strCntycd & "', '" & strEXT & "'," & _
                "  '" & strFaxNO & "', '" & strMobileNO & "', " & _
                "  '" & strEmail1 & "', '" & strEmail2 & "'," & _
                "  '" & strEmail3 & "', '" & strContname & "'," & _
                "  current date,'" & strUpdUser & "'," & _
                "  current date,current time, '" & strCommthFG & "', " & _
                "  '" & strChanToRcv & "','" & strNote & "'," & _
                "  '" & strStatus & "',' " & strAutUserid & "', " & _
                "  " & StrAutDate & "," & StrAutTime & "," & _
                "  '" & strObjDesc & "','" & strPlaceName & "'," & _
                "  '" & strEximAlpha & "','" & strSendrcpt & "'," & _
                "  '" & strCustVIP & "','" & strSeirraID & "'," & _
                "  '" & concur.CbsBankCd & "','" & strDocToRcv & "','" & strContactBy & "'" & _
                "  )"


                OdbcConn.Open()
                OdbcMyTrans = OdbcConn.BeginTransaction()

                If Not RunSqlFor(OdbcConn, OdbcMyTrans, strsql, strMsgRunSql, strFORCUSTID, Session("strUserID"), Session("Funccd")) Then
                    GoTo ChkProcessRollback
                Else
                    'R520300022
                    If strTmpCustid <> "" Then
                        If Session("SearchFor") = "WAITING" And strStatus = "A" Then
                            strsql = " UPDATE db2.FORMCUST SET CUSTSTATUS = 'A' " & _
                                     " where FORCUSTID = '" & Trim(strTmpCustid) & "' "
                            If Not RunSqlFor(OdbcConn, OdbcMyTrans, strsql, strMsgRunSql, strFORCUSTID, Session("strUserID"), Session("Funccd")) Then
                                GoTo ChkProcessRollback
                            End If

                        End If
                    End If

                    Dim strsqlInv As String = ""
                    Dim strNationCode As String
                    Dim strSex As String
                    Dim strCareer As String

                    Select Case (strCustInd)
                        Case "I"
                            Dim Dbirth As Date = Me.txtBirthDate.Text
                            strNationCode = Me.ddlNation_code.SelectedValue.ToString()
                            strSex = Me.ddlsex.SelectedValue.ToString()
                            strCareer = Me.ddlcareer.SelectedValue.ToString()
                            strBirthDate = Format(Dbirth, "yyyy-MM-dd")
                            strsql = "Insert into db2.FORLCUIN (FORCUSTID,NATIONCD,BIRTHDT,SEX,CARRER) values('" & strFORCUSTID & "', '" & strNationCode & "','" & strBirthDate & "' ,'" & strSex & "','" & strCareer & "')"
                        Case "C"
                            Dim DregDt As Date = Me.txtRegDate.Text
                            Dim strregdt As String
                            strregdt = Format(DregDt, "yyyy-MM-dd")
                            strsql = "Insert into db2.FORLCUCO (FORCUSTID,REGDATE,BUSITYPE) values('" & strFORCUSTID & "','" & strregdt & "' ,'" & Me.DDL_BusinessType.SelectedValue.ToString() & "')"
                    End Select


                    'If Not connDB.RunSql(OdbcConn, OdbcMyTrans, strsql, strMsgRunSql) Then
                    If Not RunSqlFor(OdbcConn, OdbcMyTrans, strsql, strMsgRunSql, strFORCUSTID, Session("strUserID"), Session("Funccd")) Then
                        GoTo ChkProcessRollback
                    End If

                    'FORLCUID
                    If Not DataCustIN(strFORCUSTID, Session("SearchFor"), strMsgRunSql) Then
                        GoTo ChkProcessRollback
                    End If
                    'FORLCUAC 
                    If Not DataCustAC(strFORCUSTID, Session("SearchFor"), strMsgRunSql) Then
                        GoTo ChkProcessRollback
                    End If

                    'FORLCUFE
                    If Not DataCustFEE(strFORCUSTID, Session("SearchFor"), strMsgRunSql) Then
                        GoTo ChkProcessRollback
                    End If

                    'FORLCURT
                    If Not DataCustRate(strFORCUSTID, Session("SearchFor"), strMsgRunSql) Then
                        GoTo ChkProcessRollback
                    End If
                End If
                '2008-05-30 :: Kwang :: R50080011 >> Add Label for Show detail Customer Name.
                Session("CUSTDETAIL") = strFORCUSTID & " " & strSwname1 & " " & strSwname2
                GoTo ChkProcessCommit
            Else
                'Update 
                strFORCUSTID = Session("CustSearch")


                'Session("CheckCusProcess") = False  �դ���
                If Not ChkAccBeforeUpdate(strFORCUSTID) Then
                    If Session("CheckCusProcess") = False Then
                        strMsgRunSql = "Can not update because Customer is processing."
                        ProcessSuccess = False
                        MultiView_addCustomer.ActiveViewIndex = 3
                        SetMenuAddCustomer(3)
                        GoTo ChkProcess
                    End If
                Else
                    If Session("CheckCusProcess") = False Then
                        strsql = "UPDATE DB2.FORMCUST SET " & _
                                     "UPDUSER = '" & strUpdUser & "'," & _
                                     "UPDDATE = current date,UPDTIME = current time , " & _
                                     "CUSTSTATUS = 'U' " & _
                                     "WHERE FORCUSTID = '" & strFORCUSTID & "' and custstatus <> 'D'"
                        OdbcConn.Open()
                        OdbcMyTrans = OdbcConn.BeginTransaction()
                        If Not RunSqlFor(OdbcConn, OdbcMyTrans, strsql, strMsgRunSql, strFORCUSTID, Session("strUserID"), Session("Funccd")) Then
                            GoTo ChkProcessRollback
                        End If
                        strsql = ""
                        '2010-09-03
                        'GoTo StepUpdateAccount
                        GoTo StepUpdateFE_RT
                    End If
                End If
                strStatus = "U"
UpdateCustTmp:
                OdbcConn.Open()
                OdbcMyTrans = OdbcConn.BeginTransaction()

                'strsql = "UPDATE DB2.FORMCUST SET " & _
                '         "ITSCNO = '" & strItscNo & "', " & _
                '         "OCCODE = '" & strOcCode & "', OBJCD = '" & Trim(Me.txtObjCode.Text) & "', " & _
                '         "BOIFG = '" & strBOIfg & "' , CUSTIND = '" & strCustInd & "'," & _
                '         "CUSTTYPE = '" & strCustType & "', THTITLE = '" & strThTitle & "', " & _
                '         "ENGTITLE = '" & strEngTitle & "', SWNAME2 = '" & strSwname2 & "'," & _
                '         "SWNAME1 = '" & strSwname1 & "', RMNAME = '" & strRmname & "'," & _
                '         "RMNO = '" & strRmno & "', ADDR1 = '" & strAddr1 & "'," & _
                '         "ADDR2 = '" & strAddr2 & "',ADDR3 = '" & strAddr3 & "'," & _
                '         "ADDRNO = '" & strAddrNO & "', MOO = '" & strMOO & "'," & _
                '         "SOI = '" & strSOI & "',ROAD = '" & strRoad & "'," & _
                '         "SUBDISTRICT = '" & strSubDistrict & "', DISTRICT = '" & strDistrict & "'," & _
                '         "PROVINCE = '" & strProvince & "',POSTCD = '" & strPostcd & "'," & _
                '         "PHONE1 =  '" & strPhone1 & "', CNTYCD = '" & strCntycd & "'," & _
                '         "EXT = '" & strEXT & "',FAXNO = '" & strFaxNO & "'," & _
                '         "MOBILENO = '" & strMobileNO & "',EMAIL1 = '" & strEmail1 & "'," & _
                '         "EMAIL2 = '" & strEmail2 & "',EMAIL3 = '" & strEmail3 & "'," & _
                '         "CONTNAME = '" & strContname & "' ," & _
                '         "UPDUSER = '" & strUpdUser & "'," & _
                '         "UPDDATE = current date,UPDTIME = current time , " & _
                '         "COMMTHFG = '" & strCommthFG & "',SNDMETHOD = '" & strSnDMethod & "'," & _
                '         "INSTRUCTION = '" & strNote & "'," & _
                '         "CUSTSTATUS = '" & strStatus & "', " & _
                '         "AUTUSER = '" & strAutUserid & "'," & _
                '         "AUTDATE = " & StrAutDate & "," & _
                '         "AUTTIME = " & StrAutTime & "," & _
                '         "OBJDESC = '" & strObjDesc & "'," & _
                '         "PLACENAME = '" & strPlaceName & "'," & _
                '         "EXIMCUSTID= '" & strEximAlpha & "'," & _
                '         "SENDRCPT = '" & strSendrcpt & "'," & _
                '         "CUSTVIP = '" & strCustVIP & "'," & _
                '         "SIERRAID = '" & strSeirraID & "'" & _
                '         "where FORCUSTID = '" & strFORCUSTID & "' and custstatus <> 'D'"


                'xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - New column - DOCTORECV
                strsql = "UPDATE DB2.FORMCUST SET " & _
                         "ITSCNO = '" & strItscNo & "', " & _
                         "OCCODE = '" & strOcCode & "', OBJCD = '" & Trim(Me.txtObjCode.Text) & "', " & _
                         "BOIFG = '" & strBOIfg & "' , CUSTIND = '" & strCustInd & "'," & _
                         "CUSTTYPE = '" & strCustType & "', THTITLE = '" & strThTitle & "', " & _
                         "ENGTITLE = '" & strEngTitle & "', SWNAME2 = '" & strSwname2 & "'," & _
                         "SWNAME1 = '" & strSwname1 & "', RMNAME = '" & strRmname & "'," & _
                         "RMNO = '" & strRmno & "', ADDR1 = '" & strAddr1 & "'," & _
                         "ADDR2 = '" & strAddr2 & "',ADDR3 = '" & strAddr3 & "'," & _
                         "ADDRNO = '" & strAddrNO & "', MOO = '" & strMOO & "'," & _
                         "SOI = '" & strSOI & "',ROAD = '" & strRoad & "'," & _
                         "SUBDISTRICT = '" & strSubDistrict & "', DISTRICT = '" & strDistrict & "'," & _
                         "PROVINCE = '" & strProvince & "',POSTCD = '" & strPostcd & "'," & _
                         "PHONE1 =  '" & strPhone1 & "', CNTYCD = '" & strCntycd & "'," & _
                         "EXT = '" & strEXT & "',FAXNO = '" & strFaxNO & "'," & _
                         "MOBILENO = '" & strMobileNO & "',EMAIL1 = '" & strEmail1 & "'," & _
                         "EMAIL2 = '" & strEmail2 & "',EMAIL3 = '" & strEmail3 & "'," & _
                         "CONTNAME = '" & strContname & "' ," & _
                         "UPDUSER = '" & strUpdUser & "'," & _
                         "UPDDATE = current date,UPDTIME = current time , " & _
                         "COMMTHFG = '" & strCommthFG & "',SNDMETHOD = '" & strChanToRcv & "'," & _
                         "INSTRUCTION = '" & strNote & "'," & _
                         "CUSTSTATUS = '" & strStatus & "', " & _
                         "AUTUSER = '" & strAutUserid & "'," & _
                         "AUTDATE = " & StrAutDate & "," & _
                         "AUTTIME = " & StrAutTime & "," & _
                         "OBJDESC = '" & strObjDesc & "'," & _
                         "PLACENAME = '" & strPlaceName & "'," & _
                         "EXIMCUSTID= '" & strEximAlpha & "'," & _
                         "SENDRCPT = '" & strSendrcpt & "'," & _
                         "CUSTVIP = '" & strCustVIP & "'," & _
                         "SIERRAID = '" & strSeirraID & "'," & _
                         "DOCTORECV = '" & strDocToRcv & "'," & _
                         "CONTACTBY = '" & strContactBy & "' " & _
                         "where FORCUSTID = '" & strFORCUSTID & "' and custstatus <> 'D'"

                If Not RunSqlFor(OdbcConn, OdbcMyTrans, strsql, strMsgRunSql, strFORCUSTID, Session("strUserID"), Session("Funccd")) Then
                    GoTo ChkProcessRollback
                Else

                    Dim strsqlInv As String = ""
                    Dim strNationCode As String
                    Dim strSex As String
                    Dim strCareer As String
                    Select Case (strCustInd)
                        Case "I"
                            Dim Dbirth As Date = Me.txtBirthDate.Text
                            strNationCode = Me.ddlNation_code.SelectedValue.ToString()
                            strSex = Me.ddlsex.SelectedValue.ToString()
                            strCareer = Me.ddlcareer.SelectedValue.ToString()
                            strBirthDate = Format(Dbirth, "yyyy-MM-dd")
                            strsql = " UPDATE db2.FORLCUIN SET " & _
                                     " NATIONCD = '" & strNationCode & "'," & _
                                     " BIRTHDT = '" & strBirthDate & "' ," & _
                                     " SEX = '" & strSex & "'," & _
                                     " CARRER = '" & strCareer & "' " & _
                                     " where FORCUSTID = '" & strFORCUSTID & "' "
                        Case "C"
                            Dim DregDt As Date = Me.txtRegDate.Text
                            Dim strregdt As String
                            strregdt = Format(DregDt, "yyyy-MM-dd")

                            strsql = " UPDATE db2.FORLCUCO SET " & _
                                     " REGDATE = '" & strregdt & "' ," & _
                                     " BUSITYPE = '" & Me.DDL_BusinessType.SelectedValue.ToString() & "'" & _
                                     " where FORCUSTID = '" & strFORCUSTID & "' "

                    End Select



                    'If Not connDB.RunSql(OdbcConn, OdbcMyTrans, strsqlInv, strMsgRunSql) Then
                    If Not RunSqlFor(OdbcConn, OdbcMyTrans, strsql, strMsgRunSql, strFORCUSTID, Session("strUserID"), Session("Funccd")) Then
                        GoTo ChkProcessRollback
                    End If

                    'FORLCUID
                    If Not DataCustIN(strFORCUSTID, Session("SearchFor"), strMsgRunSql) Then
                        GoTo ChkProcessRollback
                    End If

StepUpdateFE_RT:
                    'FORLCUFE
                    If Not DataCustFEE(strFORCUSTID, Session("SearchFor"), strMsgRunSql) Then
                        GoTo ChkProcessRollback
                    End If
                    'FORLCURT
                    If Not DataCustRate(strFORCUSTID, Session("SearchFor"), strMsgRunSql) Then
                        GoTo ChkProcessRollback
                    End If
StepUpdateAccount:
                    'FORLCUAC 
                    If Not DataCustAC(strFORCUSTID, Session("SearchFor"), strMsgRunSql) Then
                        GoTo ChkProcessRollback
                    End If
                End If
                '2008-05-30 :: Kwang :: R50080011 >> Add Label for Show detail Customer Name.
                Session("CUSTDETAIL") = strFORCUSTID & " :: " & strSwname1 & " " & strSwname2
                GoTo ChkProcessCommit
            End If 'Case Update or Insert

        Else '�ѧ����ա�� Authorize ����� 2


        End If

ChkProcessCommit:
        OdbcMyTrans.Commit()
        ProcessSuccess = True
        GoTo ChkProcess

ChkProcessRollback:
        If OdbcConn Is Nothing Then OdbcMyTrans.Rollback()
        ProcessSuccess = False

ChkProcess:
        OdbcConn.Close()

        If ProcessSuccess Then
            Session("AUTH2") = "AUTH_F"
            Session("USERAUTH2") = ""
            Session("flagFeeChange") = False
            Select Case Session("SearchFor")
                Case "UPDATE"
                    Response.Redirect("~/DisplayMsg.aspx?type=Update Customer completed .&page=UPDATE_CUST")
                Case "INSERT"
                    Response.Redirect("~/DisplayMsg.aspx?type=Insert New Customer completed.&page=CUSTOMER")
                Case "WAITING"
                    If Session("CUSTWEBSTAT") <> "LOG" Then
                        If Session("WAIT") <> "FALSE" Then
                            Response.Redirect("~/DisplayMsg.aspx?type=Insert Temporary Customer completed.&page=CUSTOMER")
                        Else
                            Response.Redirect("~/DisplayMsg.aspx?type=Insert New Customer completed.&page=CUSTOMER")
                        End If
                    End If
            End Select

        Else
            cstext1 = "alert('" & strMsgRunSql & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If

    End Function

    Protected Sub ButUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButUpdate.Click
        AddCustomer()
    End Sub



    Protected Sub CustType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CustType.SelectedIndexChanged
        Session("CustTypeSelect") = Me.CustType.SelectedValue.ToString()

    End Sub
    Public Function RunSqlFor(ByVal conn As OdbcConnection, ByVal Mytrans As OdbcTransaction, ByVal strRunSql As String, ByRef strMsg As String, ByVal strForRef As String, ByVal strUserid As String, ByVal strFuccd As String) As Boolean
        Dim myCommand As OdbcCommand = New OdbcCommand()
        myCommand.Connection = conn
        myCommand.Transaction = Mytrans

        Try
            myCommand.CommandText = strRunSql
            myCommand.ExecuteNonQuery()
            'Mytrans.Commit()
            RunSqlFor = True
        Catch odbce As OdbcException

            RunSqlFor = False
            strMsg = "OdbcException : " & odbce.Message.ToString().Replace("'", "\'").Replace(Environment.NewLine, "")
            strMsg = Left(Replace(strMsg, "'", " "), 200)
            Select Case UCase(Session("SearchFor"))
                Case "INSERT"

                Case "UPDATE", "DELETE"
                    Dim connError As OdbcConnection = connDB.getDBConn()
                    Dim MytransError As OdbcTransaction
                    Dim myCommandError As OdbcCommand = New OdbcCommand()

                    connError.Open()
                    myCommandError.Connection = connError
                    MytransError = connError.BeginTransaction()
                    myCommandError.Transaction = MytransError

                    myCommandError.CommandText = "insert into db2.forwlog(forref,trandate,trantime,userid,msgerr,funccd)" & _
                                             "values('" & strForRef & "',current date,current time, '" & strUserid & "','" & strMsg & "','" & strFuccd & "')"
                    myCommandError.ExecuteNonQuery()
                    MytransError.Commit()
                    connError.Close()

            End Select
            Exit Function
        Catch ex As Exception
            RunSqlFor = False

            strMsg = Left(Replace(strMsg, "'", " "), 200)
            If conn Is Nothing Then
                myCommand.CommandText = "insert into db2.forwlog(forref,trandate,trantime,userid,msgerr,funccd)" & _
                            "values('" & strForRef & "',current date,current time, '" & strUserid & "','" & strMsg & "','" & strFuccd & "')"
                myCommand.ExecuteNonQuery()
                Exit Function
            Else
                strMsg = "Connection Database ERROR!!"
            End If

        Finally
        End Try

    End Function
    Public Function GetValueObj(ByVal strObjcode As String, ByRef strObjdes As String) As Boolean
        Dim strsql As String
        Dim dtResultSet As New DataSet
        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim dtrow As DataRow


        '***56100048 Ron
        'strsql = "select value from db2.frcmtbcd where type = 'C001' and code = '" & strObjcode & "' "
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        strsql = _
        " select value from db2.frcmtbcd " & _
        " where type = 'C001' and code = '" & strObjcode & "' " & _
        "  AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'C001' and code = '" & strObjcode & "' ", concur.SWIFTCODE) & "' "

        dtResultSet = connDB.RunQuerySql(strsql)

        If dtResultSet.Tables.Count > 0 Then
            For Each dtrow In dtResultSet.Tables(0).Rows
                strObjdes = dtrow.Item(0)
                Return True
                conn.Close()
                Exit Function
            Next
        Else
            strObjdes = "Can not select description"
            Return True
        End If

        conn.Close()

    End Function

    Protected Sub GridIdentification_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridIdentification.PageIndexChanging
        GridIdentification.DataSource = Mdt
        Me.GridIdentification.DataBind()
        Me.GridIdentification.PageIndex = e.NewPageIndex
        Me.GridIdentification.DataBind()
    End Sub

    Protected Sub GridAccount_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridAccount.PageIndexChanging
        GridAccount.DataSource = ACCDT
        Me.GridAccount.DataBind()
        Me.GridAccount.PageIndex = e.NewPageIndex
        Me.GridAccount.DataBind()
    End Sub

    Protected Sub GridFee_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridFee.PageIndexChanging
        GridFee.DataSource = DT_FEE
        Me.GridFee.DataBind()
        Me.GridFee.PageIndex = e.NewPageIndex
        Me.GridFee.DataBind()
    End Sub

    Protected Sub GridRate_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridRate.PageIndexChanging
        GridRate.DataSource = DT_RATE
        Me.GridRate.DataBind()
        Me.GridRate.PageIndex = e.NewPageIndex
        Me.GridRate.DataBind()
    End Sub
    Protected Sub GridRate_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridRate.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            ' No.
            e.Row.Cells(2).Text = e.Row.RowIndex + 1
            'proname()
            e.Row.Cells(3).Text = e.Row.Cells(3).Text.ToString()
            ' ratecur
            e.Row.Cells(4).Text = e.Row.Cells(4).Text.ToString()
            ' ratemagin
            e.Row.Cells(5).Text = e.Row.Cells(5).Text.ToString()
            ' ratemin
            e.Row.Cells(6).Text = e.Row.Cells(6).Text.ToString()
            ' ratemax
            e.Row.Cells(7).Text = e.Row.Cells(7).Text.ToString()
            '' procode
            'e.Row.Cells(8).Text = e.Row.Cells(8).Text.ToString()
            ' curcode
            'e.Row.Cells(9).Text = e.Row.Cells(9).Text.ToString()

        End If
    End Sub

    Protected Sub ddlAcType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAcType.SelectedIndexChanged
        '*** CMHI:2a2567bb-eeeb-46bc-be1a-45f71a806b68
        Dim strAcCode As String = Trim(ddlAcType.SelectedValue.ToString())

        If strAcCode = "00" Or strAcCode = "01" Or strAcCode = "02" Or strAcCode = "03" Then
            Me.ddlCurrency.SelectedIndex = -1

            '***R56100048 Repalce "THB"
            'Me.ddlCurrency.Items.FindByValue("THB").Selected = True
            Me.ddlCurrency.Items.FindByValue( _
             CType(Session("concurrencyInfo"), FORWEB_Concurrency).BaseCurrency _
             ).Selected = True
            ddlCurrency.DataBind()

        Else
            ddlCurrency.SelectedIndex = -1
        End If

    End Sub

    '********************************AUTHORIZE 2 *******************************************
    Public Function ReqAuthorize() As Boolean

        DT_RATE = Session("DT_RATE")
        DT_FEE = Session("DT_FEE")

        If (Not DT_RATE Is Nothing And DT_RATE.Rows.Count > 0) Or (Not DT_FEE Is Nothing And DT_FEE.Rows.Count > 0) Then
            Me.PanelReqAuthority.Visible = True
            Me.ButSave.Enabled = False
            Select Case Session("SearchFor")
                Case "ADD'"
                    strReason1 = "Special Fee or Special Rate has been changed."
                Case "UPDATE'"
                    strReason1 = "Special Fee or Special Rate has been changed."
                Case "DELETE'"
                    strReason1 = "Delete transaction is requested."
            End Select

            strReason2 = "An authorization is required to complete the transaction."

            lblReason1.Text = Trim(strReason1)
            lblReason2.Text = Trim(strReason2)
            ReqAuthorize = True
        End If

    End Function

    Protected Sub btnOKAutho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOKAutho.Click
        Dim strUserLevel As String
        Dim strMsg As String

        strUserLevel = ""
        strMsg = ""
        Session("AUTH2") = "AUTH_F"
        Session("USERAUTH2") = ""
        If Not validatedata("INPUT", strMsg) Then GoTo errMsg

        strAuthoName = Trim(txtUserAutho.Text)
        strAuthoPsw = Trim(txtPassAutho.Text)

        ' encrypt password
        encriptPswd(strAuthoPsw, strAuthoPswEncrypt)

        'step 1=> Check user in system
        If Not getUserDataFile(strAuthoName, strAuthoPsw, strAuthoPswEncrypt, strMsg) Then GoTo errMsg

        ' step 2 => validate password
        If Not validatedata("PSWDCORR", strMsg) Then GoTo errMsg

        ' step 3 => validate user status 
        If Not validatedata("STATUS", strMsg) Then GoTo errMsg


        'step 4 => validate password expired
        'If Not validatedata("PSWDEXP", strMsg) Then GoTo errMsg

        ' step 5=>  Get user Level
        If Not GetUserLevel(strAuthoName, AuthoUserLevel) Then
            strMsg = "Authorization failed !!!"
            GoTo errMsg
        End If

        ' step 6 =>  Check user security
        If Not ChkSecurity(Session("strUserProd"), strAuthoName, AuthoUserLevel, strMsg) Then
            If strMsg = "" Then
                strMsg = "Authorization failed !!!"
                GoTo errMsg
            End If
        End If

        Session("AUTH2") = "AUTH_T"
        Session("USERAUTH2") = UCase(Trim(Me.txtUserAutho.Text.ToString()))

        Me.PanelReqAuthority.Visible = False
        Me.Panel3.Visible = True

        AddCustomer()

        Exit Sub
        'callPageBack()

errMsg:
        If strMsg <> "" Then
            cstext1 = "alert('" & strMsg & "');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
            txtUserAutho.Text = ""
            txtPassAutho.Text = ""
        End If

    End Sub

    Public Function validatedata(ByVal validFor As String, ByRef strMsg As String) As Boolean

        Dim instrStatus As String

        strMsg = ""
        '   All data is valid
        validatedata = True

        Select Case Trim(UCase(validFor))
            Case "INPUT"            ' Input value should be filled
                If Trim(txtUserAutho.Text) = "" Then
                    validatedata = False
                    strMsg = "Error !! User Id should be filled."
                    Exit Function
                End If
                If Trim(txtUserAutho.Text) = Session("strUserInput") Then
                    validatedata = False
                    strMsg = "Can not  authorized with the same user id."
                    Exit Function
                End If
                If Trim(txtPassAutho.Text) = "" Then
                    validatedata = False
                    strMsg = "Error !!! Password should be filled."
                    Exit Function
                End If

            Case "STATUS"             ' Status of user
                instrStatus = Trim(Mid(strStatus, 1, 1))

                If strStatus = "AV" Then       ' ID is revoked
                    validatedata = False
                    strMsg = "Can not Authorization !!! This User ID is revoked. Please contact Admin."
                    txtUserAutho.Focus()
                    Exit Function
                End If

                If instrStatus = "I" Then
                    validatedata = False
                    strMsg = "Can not Authorization !!!  This User ID is waiting for authorize."
                    txtUserAutho.Focus()
                    Exit Function
                End If

                If strAuthoWebStat = "A" Then
                    validatedata = False
                    strMsg = "Can not Authorization !!!  User ID is Available Used."
                    txtUserAutho.Focus()
                    Exit Function
                End If

            Case "PSWDCORR"             ' Password is correct or not

                '2020-02-03 : OT62110004, support FRC AD Authen
				Try
					Dim mynamespace, X As Object
					Dim strUserID, strPWD As String
					Dim ldapUrl As String = getLDAPURL()
					Dim domain As String = getDomain()

					Const ADS_SECURE_AUTHENTICATION = &H1

					'If hasUserMapping(Session("strUserID"), strUserMapping) Then
					'    strUserID = CStr(Trim(strUserMapping)) & "@scbcorp.co.th"
					'Else
					strUserID = CStr(Trim(strAuthoName)) & "@" & domain
					'End If

					strPWD = CStr(Trim(strAuthoPsw))

					mynamespace = GetObject("LDAP:")
					X = mynamespace.OpenDSObject(ldapUrl, strUserID, strPWD, ADS_SECURE_AUTHENTICATION)
					If Err.Number = 0 Then
						'Update pwd in DB
						updateUserPwd()
					Else
						validatedata = False
						strMsg = "Can not Authorization !!!  Password is incorrect."
						txtPassAutho.Focus()
						Exit Function

					End If
				Catch ex As Exception
					validatedata = False
					strMsg = "Can not Authorization !!!  Password is incorrect."
					txtPassAutho.Focus()
					Exit Function
				End Try

                'If strPswAutho <> strAuthoPswEncrypt Then
                'validatedata = False
                'strMsg = "Can not Authorization !!!  Password is incorrect."
                'txtPassAutho.Focus()
                'Exit Function
                'End If

            Case "PSWDEXP"           ' Expire or should be changed password
                If authoNoofChgDT >= 30 Then
                    strMsg = "Can not Authorization !!! Password expired, Please change password."
                    txtPassAutho.Focus()
                    Exit Function
                End If

        End Select
    End Function

    Public Function getUserDataFile(ByVal strAuthoName As String, ByVal strAuthoPsw As String, ByVal strAuthoPswEncrypt As String, ByRef strMsg As String) As Boolean

        Dim strSql As String

        'strPwdEncrypt = ""
        'strWebStat = ""

        

        

        Try
            strSql = "select pswd, status, (days(current date) - days(chgpswdt) - 1) as noofday, COALESCE(pswd1, ''), " & _
                            " COALESCE(pswd2, ''), COALESCE(pswd3, ''), rcunit, webstatus " & _
                            " from db2.frcmuser where userid = '" & strAuthoName & "' and status NOT in ('ID','AD')"
            Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
            If ResultSet.Tables.Count > 0 Then
                Dim rowuser As DataRow
                For Each rowuser In ResultSet.Tables(0).Rows
                    strPswAutho = Trim(rowuser.Item(0))
                    strStatus = Trim(rowuser.Item(1))
                    authoNoofChgDT = CInt(Trim(rowuser.Item(2)))
                    strAuthoRcUnit = Trim(rowuser.Item(6))
                    strAuthoWebStat = rowuser.Item(7).ToString
					getUserDataFile = True
                Next
            Else
				getUserDataFile = False
                strMsg = "Error !!! User id doesn't exist."
            End If
        Catch odbce As OdbcException
            getUserDataFile = False
            strMsg = "Authorization failed !!!"
        Catch ex As Exception

            getUserDataFile = False
            strMsg = "Authorization failed !!!"
        End Try

        txtUserAutho.Focus()
    End Function

    Protected Sub encriptPswd(ByVal pswd As String, ByRef strPwdEncrypt As String)
        Dim length As Integer
        Dim i As Integer
        Dim intTmp As String

        intTmp = 0
        length = Len(Trim(pswd))
        For i = 1 To length
            intTmp = intTmp + (Asc(Mid(pswd, i, 1)) * i)
        Next i
        strPwdEncrypt = CStr(intTmp)
    End Sub

    Public Sub updateUserPwd(ByVal user As String, ByVal encryptPwd As String)

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim myCommand As OdbcCommand = New OdbcCommand()
        Dim myTrans As OdbcTransaction
        conn.Open()
        myCommand.Connection = conn
        myTrans = conn.BeginTransaction()
        myCommand.Transaction = myTrans

        Try

            myCommand.CommandText = "update db2.frcmuser " & _
                                                                         " set pswd = '" & encryptPwd & "' " & _
                                                                         " where userid = '" & user & "'"

            myCommand.ExecuteNonQuery()
            myTrans.Commit()
        Catch odbce As OdbcException

            myTrans.Rollback()
            'strMsg = "Log In failed !!!"
            GoTo errMsg
        Catch ex As Exception

            myTrans.Rollback()
            'strMsg = "Log In failed !!!"
            GoTo errMsg
        Finally
            conn.Close()
        End Try

errMsg:

        'If strMsg <> "" Then
        'cstext1 = "alert('" & strMsg & "');"
        ' cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        ' End If

    End Sub

    Public Sub updateUserPwd()

        Dim conn As OdbcConnection = connDB.getDBConn()
        Dim myCommand As OdbcCommand = New OdbcCommand()
        Dim myTrans As OdbcTransaction
        conn.Open()
        myCommand.Connection = conn
        myTrans = conn.BeginTransaction()
        myCommand.Transaction = myTrans

        Try

            myCommand.CommandText = "update db2.frcmuser " & _
                                                                         " set pswd = '" & strAuthoPswEncrypt & "' " & _
                                                                         " where userid = '" & strAuthoName & "'"

            myCommand.ExecuteNonQuery()
            myTrans.Commit()
        Catch odbce As OdbcException
            ProcessSuccess = False
            myTrans.Rollback()
            GoTo errMsg
        Catch ex As Exception
            ProcessSuccess = False
            myTrans.Rollback()
            GoTo errMsg
        Finally
            conn.Close()
        End Try

errMsg:


    End Sub

    Public Function hasUserMapping(ByVal LogOnUser As String, ByRef UserMapping As String) As Boolean
        Dim strSql As String
        Dim dtRow As DataRow
        Dim conn As OdbcConnection = connDB.getDBConn()

        hasUserMapping = False

        Try
            strSql = "SELECT VALUE, SWIFTTCD FROM DB2.FRCMTBCD WHERE TYPE = 'U001' and CODE = '" & LogOnUser & "' "
            Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
            If ResultSet.Tables.Count > 0 Then
                For Each dtRow In ResultSet.Tables(0).Rows
                    UserMapping = Trim(dtRow.Item(0))
                    hasUserMapping = True
                Next
            End If
        Catch odbce As OdbcException
            hasUserMapping = False

        Catch ex As Exception
            hasUserMapping = False
        Finally
            conn.Close()
        End Try


        Return hasUserMapping

    End Function

    Public Function GetUserLevel(ByVal LogOnUser As String, ByRef AuthoUserLevel As String) As Boolean
        Dim strSql As String
        Dim dtRow As DataRow

        GetUserLevel = True

        Try
            strSql = "select a.prodcd, a.levlcd from db2.frcluspl a  where a.userid = '" & LogOnUser & "'"
            Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
            If ResultSet.Tables.Count > 0 Then
                For Each dtRow In ResultSet.Tables(0).Rows
                    AuthoUserLevel = Trim(dtRow.Item(1))
                Next
            End If
        Catch odbce As OdbcException
            GetUserLevel = False
        Catch ex As Exception
            GetUserLevel = False
        End Try

        Return GetUserLevel

    End Function

    Public Function ChkSecurity(ByVal LogOnProd As String, ByVal LogOnUser As String, ByVal LogOnLevl As String, ByRef strMsg As String) As Boolean
        Dim strSql As String
        Dim dtRow As DataRow
        Dim strAuthoFunccd As String, strAuthoSumFunccd As String
        Dim AuthoFunccd As Boolean

        strMsg = ""

        ChkSecurity = True
        strAuthoFunccd = ""
        strAuthoSumFunccd = ""
        AuthoFunccd = False

        Dim conn As OdbcConnection = connDB.getDBConn()

        Try
            strSql = "select a.funccd, current date from db2.frclplfn a  where a.prodcd = '" & LogOnProd & "' " & _
                            " and  a.levlcd = '" & LogOnLevl & "' "
            Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
            If ResultSet.Tables.Count > 0 Then
                For Each dtRow In ResultSet.Tables(0).Rows

                    If Session("Funccd") = strAuthoFunccd Then
                        AuthoFunccd = True
                        Exit For
                    End If
                Next
            End If

            If AuthoFunccd = False Then
                ChkSecurity = False
                strMsg = "Authorization failed !!! This user id can not do this function"
            End If

        Catch odbce As OdbcException
            ChkSecurity = False
        Catch ex As Exception
            ChkSecurity = False
        End Try

        Return ChkSecurity
    End Function


    Protected Sub btnCanAutho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCanAutho.Click
        Session("AUTH2") = "AUTH_F"
        Session("USERAUTH2") = ""

        txtUserAutho.Text = ""
        txtPassAutho.Text = ""

        Me.PanelReqAuthority.Visible = False
        Me.Panel3.Visible = True
    End Sub
    Protected Sub callPageBack()
        Response.Redirect("~/frmSearchCustomer.aspx?page=CUSDEL&SEARCHFOR=" & Session("SearchFor") & "&AUTH2=T ")
    End Sub

    Protected Sub ddlFeeType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFeeType.SelectedIndexChanged
        If ddlFeeType.SelectedValue.ToString = "F" Then
            Me.txtFeeMagin.Focus()
            Me.txtMinFee.Text = "0.00"
            Me.txtMaxFee.Text = "0.00"
            Me.txtMinFee.Enabled = False
            Me.txtMaxFee.Enabled = False
            Me.lbPercent.Visible = False
            Me.chkNoLimit.Enabled = False
        ElseIf ddlFeeType.SelectedValue.ToString = "P" Then
            Me.txtMinFee.Enabled = True
            Me.txtMaxFee.Enabled = True
            Me.lbPercent.Visible = True
            Me.chkNoLimit.Enabled = True
        End If
    End Sub



    Protected Sub ButIdenCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButIdenCancel.Click
        panel_gridIden.Enabled = True
        Me.ButIdenUpdate.Enabled = False
        Me.ButIdenCancel.Enabled = False

        Me.ButAdd.Enabled = True
        Me.ButClear.Enabled = True

        Me.ddlIdType.SelectedIndex = -1
        Me.txtIdNumber.Value = ""
        Me.txtIdNumberThai.Value = ""
    End Sub

    Protected Sub GridIdentification_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridIdentification.SelectedIndexChanged

    End Sub

    Protected Sub ddlIdType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlIdType.SelectedIndexChanged
        If Me.ddlIdType.SelectedValue.ToString() = "324013" And Session("optCustType") = "C" Then
            Me.txtIdNumber.Visible = False
            Me.txtIdNumberThai.Visible = True
        Else
            Me.txtIdNumber.Visible = True
            Me.txtIdNumberThai.Visible = False
        End If
    End Sub


    Public Function CheckControlToValidate(ByVal controlValidate As Integer) As Boolean
        CheckControlToValidate = True
        Page.Validate()
        Dim i As Integer
        Me.MultiView_addCustomer.ActiveViewIndex = controlValidate
        Me.MultiView_addCustomer.Page.Validate()
        For i = 0 To Me.MultiView_addCustomer.Page.Validators.Count - 1
            If Not MultiView_addCustomer.Page.Validators(i).IsValid Then
                strMsgError = Page.Validators(i).ErrorMessage
                cstext1 = "alert('" & strMsgError & "');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                SetMenuAddCustomer(controlValidate)
                CheckControlToValidate = False
                Exit Function
            End If
        Next

    End Function



    Protected Sub ButCancelRate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButCancelRate.Click
        ButClearRate_Click(sender, e)
        Me.GridRate.Enabled = True

        Me.ButAddRate.Enabled = True
        Me.ButClearRate.Enabled = True

        Me.ButUpdateRate.Enabled = False
        Me.ButCancelRate.Enabled = False
    End Sub

    Public Function loadTabIdentifi() As Boolean
        '*** CMHI:95c52540-563c-4e9e-b806-4c896a4d8ace
        Dim strSql As String
        loadTabIdentifi = False
        Me.ButIdenUpdate.Enabled = False
        Me.ButIdenCancel.Enabled = False
        Me.ButAdd.Enabled = True
        Me.ButClear.Enabled = True

        Me.panel_gridIden.Enabled = True
        Me.GridIdentification.Enabled = True

        Me.ddlIdType.SelectedIndex = -1
        Me.txtIdNumber.Value = ""
        '2009-10-21
        Me.txtIdNumberThai.Value = ""

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        If Me.ddlIdType.Items.Count = 0 Then
            Dim strSubQueryResult2 As String = loadTabIdentifi_SubQueryResult("2")
            If Session("optcusttype") = "I" Then
                strSql = _
                "select '' as code,'--Please Select ID Type--' as SHOW  " & _
                "from SYSIBM.SYSDUMMY1 " & _
                "UNION  " & _
                "select A.code, A.code||' : '||A.value as SHOW  " & _
                "from db2.frcmtbcd A " & _
                "  INNER JOIN " & _
                "    ( " & _
                "     SELECT SWIFTTCD FROM FRCMTBCD " & _
                "     WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
                "       AND TYPE = 'T003' " & _
                "       AND CODE IN (" & strSubQueryResult2 & ") " & _
                "       ANd SCBCODE IS NOT NULL " & _
                "     ORDER BY SWIFTTCD DESC " & _
                "     FETCH FIRST 1 ROW ONLY " & _
                "    ) B " & _
                "  ON A.SWIFTTCD = B.SWIFTTCD " & _
                "where Type = 'T003'  " & _
                "  and CODE IN  " & _
                "    (" & strSubQueryResult2 & ")  " & _
                "and (scbcode is not null)  " & _
                "order by code"

            Else
                Dim strSubQueryResult4 As String = loadTabIdentifi_SubQueryResult("4")
                strSql = _
                "select '' as code,'--Please Select ID Type--' as SHOW  " & _
                "from SYSIBM.SYSDUMMY1 " & _
                "union  " & _
                "select code, code||' : '||value as SHOW  " & _
                "from db2.frcmtbcd A " & _
                "  INNER JOIN " & _
                "   ( " & _
                "    SELECT SWIFTTCD FROM DB2.FRCMTBCD " & _
                "    WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
                "      AND TYPE = 'T003' " & _
                "      AND CODE IN  " & _
                "      ( " & strSubQueryResult4 & "" & _
                "      ) " & _
                "      AND SCBCODE IS NOT NULL " & _
                "    ORDER BY SWIFTTCD DESC " & _
                "    FETCH FIRST 1 ROW ONLY " & _
                "   ) B " & _
                "  ON A.SWIFTTCD = B.SWIFTTCD " & _
                "where Type = 'T003'  " & _
                "  and CODE IN  " & _
                "    (" & strSubQueryResult4 & " " & _
                "    )  " & _
                "  and (scbcode is not null)  " & _
                "order by code"
            End If

        Dim logger As New FORWEB_Logger(FORWEB_Logger.LogType.ActivityLog)
        logger.WriteLog(Chr(9) & "loadTabIdentifi" & strSql & Chr(9) & "******")
            If Not PublicFunc.PopulateLoadDDL(Me.ddlIdType, "code", "SHOW", strSql) Then
                cstext1 = "alert('Error!! List of ID Type Can not Load');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Function
            End If
        End If

        MultiView_addCustomer.ActiveViewIndex = 2
        loadTabIdentifi = True
        Me.Panel3.Visible = True
    End Function
    Private Function loadTabIdentifi_SubQueryResult(ByVal strOption As String) As String
        Dim strSQL As String = ""
        Dim strRslt As String = ""
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        If strOption = "1" Then
            '*** Bring it back [Select OTHINFORM...] => [Select code...]
            strSQL = _
            "Select code  " & _
            "from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "    ( " & _
            "     SELECT SWIFTTCD FROM FRCMTBCD " & _
            "     WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "       AND type = 'T004' " & _
            "       and scbcode in ('1','2') " & _
            "     ORDER BY SWIFTTCD DESC " & _
            "     FETCH FIRST 1 ROW ONLY " & _
            "    ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where Type = 'T004'  " & _
            "  and SCBCODE in ('1','2')"
        ElseIf strOption = "2" Then
            Dim strSubQueryResult1 As String = loadTabIdentifi_SubQueryResult("1")
            strSQL = _
            "SELECT VALUE   " & _
            "FROM DB2.FRCMTBCD A   " & _
            "  INNER JOIN " & _
            "   ( " & _
            "    SELECT SWIFTTCD FROM FRCMTBCD " & _
            "    WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "      AND TYPE = 'R001'   " & _
            "      AND FLAGUSE = 'Y'   " & _
            "      AND CODE in  " & _
            "        (" & strSubQueryResult1 & ") " & _
            "    ORDER BY SWIFTTCD DESC " & _
            "    FETCH FIRST 1 ROW ONLY " & _
            "   ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "WHERE TYPE = 'R001'   " & _
            "  AND FLAGUSE = 'Y'   " & _
            "  AND CODE in  " & _
            "    (" & strSubQueryResult1 & ")"
        '*** Bring it back [Select OTHINFORM...] => [Select code...]
        ElseIf strOption = "3" Then
            strSQL = _
            "Select code  " & _
            "from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "    ( " & _
            "     SELECT SWIFTTCD from FRCMTBCD " & _
            "     WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "       AND TYPE = 'T004' " & _
            "       AND SCBCODE IN ('3','4') " & _
            "     ORDER BY SWIFTTCD DESC " & _
            "     FETCH FIRST 1 ROW ONLY " & _
            "    ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where Type = 'T004'  " & _
            "  and SCBCODE in ('3','4')"
        ElseIf strOption = "4" Then
            Dim strSubQueryResult3 As String = loadTabIdentifi_SubQueryResult("3")
            strSQL = _
            "SELECT VALUE  " & _
            "FROM DB2.FRCMTBCD A " & _
            "  INNER JOIN " & _
            "   ( " & _
            "    SELECT SWIFTTCD FROM DB2.FRCMTBCD " & _
            "    WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "      AND TYPE = 'R001'  " & _
            "      AND FLAGUSE = 'Y'  " & _
            "      AND CODE in " & _
            "        (" & strSubQueryResult3 & " " & _
            "        )  " & _
            "      and (scbcode is not null)  " & _
            "    ORDER BY SWIFTTCD DESC " & _
            "    FETCH FIRST 1 ROW ONLY " & _
            "   ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "WHERE TYPE = 'R001'  " & _
            "  AND FLAGUSE = 'Y'  " & _
            "  AND CODE in " & _
            "    (" & strSubQueryResult3 & " " & _
            "    )"
        End If
        Return PublicFunc.getQueryResultInCSV(strSQL)
    End Function
    Public Function loadTabAccount() As Boolean
        '*** CMHI:69acb48f-30c5-4ad3-ac50-f0abee8f9b7a
        Dim strsql As String

        loadTabAccount = False
        Me.ButUpdateAcc.Enabled = False
        Me.ButCanAcc.Enabled = False

        Me.ButAddAcc.Enabled = True
        Me.ButClearAcc.Enabled = True

        Me.panel_gridAccount.Enabled = True
        Me.GridAccount.Enabled = True

        Me.ddlAcType.SelectedIndex = -1
        Me.ddlCurrency.SelectedIndex = -1
        Me.txtAcNO.Value = ""
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        If ddlAcType.Items.Count = 0 Then
            strsql = _
            "select '' as CODE,'--Please Select Account Type--' as SHOW  " & _
            "from SYSIBM.SYSDUMMY1 " & _
            "union  " & _
            "select code, code||':'||value as SHOW  " & _
            "from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "    ( " & _
            "      SELECT SWIFTTCD FROM FRCMTBCD " & _
            "      WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "        AND TYPE = 'T001' " & _
            "        AND FLAGUSE = 'Y' " & _
            "        and FRCMTBCD.OTHINFORM = 'W' " & _
            "      ORDER BY SWIFTTCD DESC " & _
            "      FETCH FIRST 1 ROW ONLY " & _
            "    ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where type = 'T001' and flaguse = 'Y'  " & _
            "  and othinform = 'W'  " & _
            "order by code"

            If Not PublicFunc.PopulateLoadDDL(Me.ddlAcType, "CODE", "SHOW", strsql) Then
                cstext1 = "alert('Error!! Can not Load Account Type.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Function
            End If
        End If

        If ddlCurrency.Items.Count = 0 Then
            strsql = _
            "select '' as CODE,'--Please Select Currency Code--' as SHOW " & _
            "from db2.host_currency " & _
            "union " & _
            "select cur_cd as CODE, cur_cd ||':'|| cur_name as SHOW " & _
            "from db2.host_currency " & _
            "where cur_cd not in ('US1','US2') " & _
            " AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
            "order by CODE "

            If Not PublicFunc.PopulateLoadDDL(Me.ddlCurrency, "CODE", "SHOW", strsql) Then
                cstext1 = "alert('Error!! Can not Load Currency Code.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Function
            End If
        End If

        '2008-02-07 :: edit main account just has 1 record
        If Not ACCDT Is Nothing Then
            If ACCDT.Rows.Count = 0 Then
                Me.ChkMain.Checked = True
                Me.ChkMain.Enabled = False
            Else
                Me.ChkMain.Enabled = True
            End If
        End If
        '*************************************************
        MultiView_addCustomer.ActiveViewIndex = 3
        loadTabAccount = True
        Me.Panel3.Visible = True
    End Function

    Public Function loadTabFee() As Boolean
        Dim strsql As String
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        loadTabFee = False

        '*******************Set Data to Default*******************
        Me.ButUpdateFee.Enabled = False
        Me.ButCancelFee.Enabled = False

        Me.ButAddFEE.Enabled = True
        Me.ButClearFEE.Enabled = True

        Me.GridFee.Enabled = True

        Me.ddlProdName.SelectedIndex = -1
        Me.ddlFeeType.SelectedIndex = -1

        '*******Clear Data in textbox and dropdownlist************
        If Me.ddlFeeName.Items.Count > 0 Then
            Me.ddlFeeName.DataSource = ""
            Me.ddlFeeName.DataBind()
            Me.ddlFeeName.Enabled = False

        End If

        Me.txtFeeMagin.Text = "0.0000000"
        Me.txtMinFee.Text = "0.00"
        Me.txtMaxFee.Text = "0.00"
        Me.txtMaxFee.Enabled = False
        Me.txtMinFee.Enabled = False
        Me.lbPercent.Visible = False
        Me.chkNoLimit.Enabled = False


        If Me.ddlProdName.Items.Count = 0 Then

            '***56100048 Ron SWIFTTCD on FRCMSFEE -007
            'strsql = " select '' as prodcd , '--Please Select Product Code--' as SHOW from db2.frcmprod a,db2.frcmsfee b union " & _
            '         " select a.prodcd , a.proddesc as SHOW from db2.frcmprod a,db2.frcmsfee b " & _
            '         " where a.prodcd = b.prodcd order by prodcd"
            strsql = _
            "select '' as prodcd , '--Please Select Product Code--' as SHOW " & _
            "from db2.frcmprod a,db2.frcmsfee b " & _
            "union " & _
            "select a.prodcd , a.proddesc as SHOW " & _
            "from db2.frcmprod a,db2.frcmsfee b " & _
            "where a.prodcd = b.prodcd " & _
            " AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
            "order by prodcd "

            If Not PublicFunc.PopulateLoadDDL(Me.ddlProdName, "prodcd", "SHOW", strsql) Then
                cstext1 = "alert('Error!! Can not Load Product Code.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Function
            End If
            ddlProdName.SelectedIndex = ddlProdName.Items.IndexOf(ddlProdName.Items.FindByValue("FORO"))
            Dim senderS As New Object
            Dim eE As New System.EventArgs
            ddlProdName_SelectedIndexChanged(senderS, eE)
        Else
            Dim senderS As New Object
            Dim eE As New System.EventArgs

            ddlProdName.SelectedIndex = ddlProdName.Items.IndexOf(ddlProdName.Items.FindByValue("FORO"))
            ddlProdName_SelectedIndexChanged(senderS, eE)
        End If


        If Me.ddlFeeType.Items.Count = 0 Then

            '***56100048 Ron
            'strsql = "select '' as CODE, '--Please Select Fee Type--' as SHOW from db2.frcmtbcd where type = 'T002' and flaguse = 'Y' union " & _
            '         " select code as CODE, value as SHOW from db2.frcmtbcd where type = 'T002' and flaguse = 'Y' order by CODE"

            strsql = "select '' as CODE, '--Please Select Fee Type--' as SHOW from db2.frcmtbcd where type = 'T002' and flaguse = 'Y' union " & _
                     " select code as CODE, value as SHOW from db2.frcmtbcd " & _
                     " where type = 'T002' and flaguse = 'Y' " & _
                     " AND SWIFTTCD = '" & PublicFunc.UseThisSWIFTCD("type = 'T002' and flaguse = 'Y' ", concur.SWIFTCODE) & "' " & _
                     " order by CODE"

            If Not PublicFunc.PopulateLoadDDL(Me.ddlFeeType, "CODE", "SHOW", strsql) Then
                cstext1 = "alert('Error!! Can not Load Fee Type.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Function
            End If
        End If
        MultiView_addCustomer.ActiveViewIndex = 4
        loadTabFee = True
        Me.Panel3.Visible = True
    End Function

    Public Function loadTabRate() As Boolean
        '*** CMHI:b4bd748d-c107-47c9-93ca-884d848f6f85
        Dim strSql As String

        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)

        loadTabRate = False
        Me.ButUpdateRate.Enabled = False
        Me.ButCancelRate.Enabled = False

        Me.ButAddRate.Enabled = True
        Me.ButClearRate.Enabled = True

        Me.GridRate.Enabled = True

        Me.ddlRateProname.SelectedIndex = -1
        Me.ddlRateCurCode.SelectedIndex = -1
        Me.txtRateMargin.Text = "0.0000000"
        Me.txtRateMax.Text = "0.00"
        Me.txtRateMin.Text = "0.00"
        Me.RadioRateMargin.SelectedValue = "PLUS"

        If Me.ddlRateProname.Items.Count = 0 Then
            strSql = "select '' as CODE, '--Please Select Product Code--' as SHOW from db2.frcmprod union " & _
                     " select prodcd as CODE, proddesc as SHOW from db2.frcmprod order by CODE"
            If Not PublicFunc.PopulateLoadDDL(Me.ddlRateProname, "CODE", "SHOW", strSql) Then
                cstext1 = "alert('Error!! Can not Load Product Code.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Function
            End If
        End If

        If Me.ddlRateCurCode.Items.Count = 0 Then
            strSql = _
            "select '' as CODE,'--Please Select Currency Code--' as SHOW " & _
            "from db2.host_currency " & _
            "union " & _
            "select cur_cd as CODE, cur_cd ||':'|| cur_name as SHOW " & _
            "from db2.host_currency " & _
            "where cur_cd not in ('US1','US2') " & _
            " AND SWIFTTCD = '" & concur.SWIFTCODE & "' " & _
            "order by CODE "
            If Not PublicFunc.PopulateLoadDDL(ddlRateCurCode, "CODE", "SHOW", strSql) Then
                cstext1 = "alert('Error!! Can not Load Currency Code.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Function
            End If
        End If

        MultiView_addCustomer.ActiveViewIndex = 5
        loadTabRate = True
        Me.Panel3.Visible = True
    End Function
    Public Function LoadTabAddress() As Boolean
        '*** CMHI:035ff03c-a66d-4cd8-8912-d9ef0b751b48
        Dim strsql As String
        LoadTabAddress = False
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        If Me.ddlContryCode.Items.Count = 0 Then
            strsql = _
            "select '' as code,'','--Please Select Country Code--'  as SHOW  " & _
            "from SYSIBM.SYSDUMMY1 " & _
            "union  " & _
            "select code, value,code|| ' : ' || value as SHOW  " & _
            "from db2.frcmtbcd A " & _
            "  INNER JOIN " & _
            "  ( " & _
            "    SELECT SWIFTTCD FROM FRCMTBCD " & _
            "    WHERE SWIFTTCD IN ('','" & concur.SWIFTCODE & "') " & _
            "      AND TYPE = 'C003' " & _
            "      AND FLAGUSE = 'Y' " & _
            "    ORDER BY SWIFTTCD DESC " & _
            "    FETCH FIRST 1 ROW ONLY " & _
            "  ) B " & _
            "  ON A.SWIFTTCD = B.SWIFTTCD " & _
            "where type = 'C003' and flaguse = 'Y'  " & _
            "order by code"

            If Not PublicFunc.PopulateLoadDDL(Me.ddlContryCode, "CODE", "SHOW", strsql) Then
                cstext1 = "alert('Error!! Can not load ID Type.');"
                cs.RegisterStartupScript(cstype, csname1, cstext1, True)
                Exit Function
            End If
            Me.ddlContryCode.SelectedIndex = Me.ddlContryCode.Items.IndexOf(Me.ddlContryCode.Items.FindByValue(concur.ISO3166_1))
        End If

        If Trim(Me.ddlProvince.SelectedValue.ToString()) = "" Then
            Me.ddlDistrict.Enabled = False
        Else
            Me.ddlDistrict.Enabled = True
        End If

        If Me.ddlPostCode.Items.Count = 2 Then
            Me.ddlPostCode.Enabled = False
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        ElseIf Me.ddlPostCode.Items.Count = 1 Then
            If Trim(Me.ddlDistrict.SelectedValue.ToString()) = "" Then
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = False
                Me.txtPostCode.Value = ""
            Else
                Me.ddlPostCode.Enabled = False
                Me.txtPostCode.Visible = True
            End If
        Else
            Me.ddlPostCode.Enabled = True
            Me.txtPostCode.Visible = False
            Me.txtPostCode.Value = ""
        End If

        MultiView_addCustomer.ActiveViewIndex = 1
        Me.Panel3.Visible = True
        LoadTabAddress = True

    End Function
    Protected Sub Gridaccount_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridAccount.RowCreated
        If e.Row.RowType = DataControlRowType.DataRow Then
            If Not e.Row.RowState And DataControlRowState.Edit Then
                Dim L1 As ImageButton = e.Row.Cells(1).Controls(1)
                L1.Attributes.Add("onclick", "return confirm('Confirm to delete this account ?');")
            End If
        End If
    End Sub
    Protected Sub GridIdentification_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridIdentification.RowCreated
        If e.Row.RowType = DataControlRowType.DataRow Then
            If Not e.Row.RowState And DataControlRowState.Edit Then
                Dim L1 As ImageButton = e.Row.Cells(1).Controls(1)
                L1.Attributes.Add("onclick", "return confirm('Confirm to delete this record?');")
                'Dim Hid1 As HiddenField = e.Row.Cells(0).Controls(0)
            End If
        End If
    End Sub

    Protected Sub GridFee_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridFee.RowCreated
        If e.Row.RowType = DataControlRowType.DataRow Then
            If Not e.Row.RowState And DataControlRowState.Edit Then
                Dim L1 As ImageButton = e.Row.Cells(1).Controls(1)
                L1.Attributes.Add("onclick", "return confirm('Confirm to delete this record?');")
            End If
        End If
    End Sub
    Protected Sub GridRate_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridRate.RowCreated
        If e.Row.RowType = DataControlRowType.DataRow Then
            If Not e.Row.RowState And DataControlRowState.Edit Then
                Dim L1 As ImageButton = e.Row.Cells(1).Controls(1)
                L1.Attributes.Add("onclick", "return confirm('Confirm to delete this record?');")
            End If
        End If
    End Sub

    Protected Sub butRetiveAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles butRetiveAdd.Click
        Dim strPostCode As String = ""

        panel_SwiftAddr.Enabled = True
        Me.txtAddressL1.Value = Left(Me.txtAddressNo.Value.ToString() & " " _
                                & IIf(Me.txtMoo.Value.ToString() = "", "", " MOO " & Me.txtMoo.Value.ToString()) _
                                & IIf(Me.txtSoi.Value.ToString() = "", "", " SOI " & Me.txtSoi.Value.ToString()), 35)

        If Me.ddlDistrict Is Nothing Or Trim(Me.ddlDistrict.SelectedValue.ToString()) = "" Or ddlDistrict.Items.Count = 1 Then
            Me.txtAddressL2.Value = Left(IIf(Me.txtRoad.Value.ToString() = "", "", Me.txtRoad.Value.ToString() & " RD. ") _
                                    & "" & Me.txtSubDistrict.Value, 35)
        Else
            Me.txtAddressL2.Value = Left(IIf(Me.txtRoad.Value.ToString() = "", "", Me.txtRoad.Value.ToString() & " RD. ") _
                                    & "" & Me.txtSubDistrict.Value & " " & Me.ddlDistrict.SelectedItem.Text.ToString(), 35)
        End If

        If ddlProvince Is Nothing Or Trim(ddlProvince.SelectedValue.ToString()) = "" Then
            Me.txtAddressL3.Value = IIf(Trim(Me.ddlContryCode.SelectedValue.ToString()) = "TH", "THAILAND", _
                                    "" & IIf(Trim(Me.ddlContryCode.SelectedValue.ToString()) = "", "", _
                                    Mid(Trim(Me.ddlContryCode.SelectedItem.Text.ToString()), 6, Len(Trim(Me.ddlContryCode.SelectedItem.Text.ToString())) - 5)))
        Else

            If ddlPostCode Is Nothing Or ddlPostCode.Items.Count = 0 Then
                strPostCode = ""
            ElseIf ddlPostCode.Items.Count = 1 And ddlPostCode.Enabled = False Then
                strPostCode = Me.txtPostCode.Value
            Else
                If Me.ddlPostCode.SelectedItem.Text.ToString() = "--Please Select Postcode--" Then
                    strPostCode = ""
                Else
                    strPostCode = Me.ddlPostCode.SelectedItem.Text.ToString()
                End If
            End If

            Me.txtAddressL3.Value = Left(Me.ddlProvince.SelectedItem.Text.ToString() & " " & strPostCode & " " _
                                   & IIf(Trim(Me.ddlContryCode.SelectedValue.ToString()) = "TH", " THAILAND", _
                                    "" & IIf(Trim(Me.ddlContryCode.SelectedValue.ToString()) = "", "", _
                                    Mid(Trim(Me.ddlContryCode.SelectedItem.Text.ToString()), 6, Len(Trim(Me.ddlContryCode.SelectedItem.Text.ToString())) - 5))), 35)

        End If

        Me.txtAddressL1.Disabled = False
        Me.txtAddressL2.Disabled = False
        Me.txtAddressL3.Disabled = False

    End Sub

    Public Function chkAddAcc(ByVal strAccAdd As String) As Boolean

        Dim strSql
        Dim dtResultSet As DataSet
        'Dim dtRow As DataRow

        'FALSE ��� �� account ��� ****active***** (status = 'A','U') ����� customer ���� ����  �������ö add ��
        'TRUE ��� account ��� ****inactive**** (status = 'A','U') ����� customer ���� ����  ����ö add ��

        chkAddAcc = False
        Dim conn As OdbcConnection = connDB.getDBConn()

        If UCase(Trim(Session("optcusttype"))) = "I" Then
            strSql = " SELECT A.FORCUSTID,A.ACNO FROM DB2.FORLCUAC A " & _
                           " LEFT OUTER JOIN (SELECT FORCUSTID,CUSTSTATUS,CUSTIND FROM DB2.FORMCUST) AS B ON B.FORCUSTID = A.FORCUSTID  " & _
                           " WHERE B.CUSTSTATUS <> 'D' AND B.CUSTIND = 'I' AND RTRIM(A.ACNO) = '" & Trim(strAccAdd) & "' and A.forcustid <> '" & Trim(Session("CustSearch")) & "'"

            dtResultSet = connDB.RunQuerySql(strSql)
            If dtResultSet.Tables.Count > 0 Then
                If dtResultSet.Tables(0).Rows.Count > 0 Then
                    chkAddAcc = False
                    conn.Close()
                    Exit Function

                Else
                    chkAddAcc = True
                End If
            Else

            End If

            conn.Close()
        Else
            If Len(Trim(strAccAdd)) > 10 Then
                strSql = " SELECT A.FORCUSTID,A.ACNO FROM DB2.FORLCUAC A " & _
                         " WHERE RTRIM(A.ACNO) = '" & Trim(strAccAdd) & "' " & _
                         " and a.accurcd <> '" & Me.ddlCurrency.SelectedValue.ToString() & "'"

                dtResultSet = connDB.RunQuerySql(strSql)
                If dtResultSet.Tables.Count > 0 Then
                    If dtResultSet.Tables(0).Rows.Count > 0 Then
                        chkAddAcc = False
                        conn.Close()
                        Exit Function
                    Else
                        chkAddAcc = True
                    End If
                Else

                End If
                conn.Close()
            End If

            chkAddAcc = True
        End If

    End Function

    Public Function CheckCusProcess(ByVal strForCustid As String) As Boolean
        Dim strsql As String

        CheckCusProcess = False
        '2010-09-02
        'strsql = " select senid,procstat from db2.forwtran where " & _
        '                    " senid = '" & Trim(strForCustid) & "' and procstat not in ('SC','RJ','CC')" & _
        '                    " union all" & _
        '                    " select senid,procstat from db2.forotran where " & _
        '                    " senid = '" & Trim(strForCustid) & "' and procstat not in ('DL', 'RJ' , 'SC', 'CC')"

        'strsql = " select senid,procstat from db2.forwtran where " & _
        '                    " senid = '" & Trim(strForCustid) & "' and procstat not in ('SC','RJ','CC')" & _
        '                    " union all" & _
        '                    " select senid,procstat from db2.forotran where " & _
        '                    " senid = '" & Trim(strForCustid) & "' and procstat not in ('DL', 'RJ' , 'SC', 'CC','WS')"

        '2013-03-12 Tom : Add status for edit customer's profile
        'KWANG :: R53060089 
        'strsql = " select senid,procstat from db2.forwtran where " & _
        '                    " senid = '" & Trim(strForCustid) & "' and procstat not in ('SC','RJ','CC')" & _
        '                    " and senid not in (select senid from db2.forotran where procstat not in ('DL', 'RJ' , 'SC', 'CC','WS') )" & _
        '                    " union all" & _
        '                    " select senid,procstat from db2.forotran where " & _
        '                    " senid = '" & Trim(strForCustid) & "' and procstat not in ('DL', 'RJ' , 'SC', 'CC','WS')"
        strsql = " select senid,procstat from db2.forwtran where " & _
                            " senid = '" & Trim(strForCustid) & "' and procstat not in ('SC','RJ','CC','IN','WS')" & _
                            " and senid not in (select senid from db2.forotran where procstat not in ('DL','RJ','SC','CC','WS'))" & _
                            " union all" & _
                            " select senid,procstat from db2.forotran where " & _
                            " senid = '" & Trim(strForCustid) & "' and procstat not in ('DL','RJ','SC','CC','WS')"

        Dim dtResultSetSenId As New DataSet
        Dim connSenId As OdbcConnection = connDB.getDBConn()

        dtResultSetSenId = connDB.RunQuerySql(strsql)

        If dtResultSetSenId.Tables.Count > 0 Then
            If dtResultSetSenId.Tables(0).Rows.Count > 0 Then
                Me.Radio_typeCust.Enabled = False
                'Me.txtAcNO.Disabled = True
                Me.txtAddressL1.Disabled = True
                Me.txtAddressL2.Disabled = True
                Me.txtAddressL3.Disabled = True
                Me.txtAddressNo.Disabled = True
                Me.txtContactName1.Disabled = True
                Me.txtContactName2.Disabled = True
                Me.txtExt.Disabled = True
                Me.txtIdNumber.Disabled = True
                '2009-10-21
                Me.txtIdNumber.Disabled = True
                Me.txtFaxNo.Enabled = True
                Me.txtNote.Disabled = True
                Me.txtMoo.Disabled = True
                Me.txtRoad.Disabled = True
                Me.txtSoi.Disabled = True
                Me.PlaceName.Disabled = True
                Me.txtSubDistrict.Disabled = True
                Me.TextName1.Disabled = True
                Me.TextName2.Disabled = True
                Me.txtNameRM.Disabled = True
                Me.Panel_address.Enabled = False
                Me.panel_AddIden.Enabled = False
                Me.Panel_generalInfo.Enabled = False

                Me.Panel_Identification.Enabled = False
                '2010-09-02 :: 
                'Me.Panel_gridRate.Enabled = False
                'Me.Panel_SpecialFee.Enabled = False
                'Me.Panel_SpecialRate.Enabled = False
                Me.Panel1.Enabled = False
                Me.Panel2.Enabled = False
                Me.Panel4.Enabled = False
                Me.Panel5.Enabled = False

                CheckCusProcess = False
            Else
                CheckCusProcess = True
            End If
        Else
            CheckCusProcess = True
        End If

        connSenId.Close()
        Session("CheckCusProcess") = CheckCusProcess
    End Function
    Public Function ChkAccBeforeUpdate(ByVal strFORCUSTID As String) As Boolean
        Dim strSql As String
        Dim ResultSetAcc As DataSet = Nothing
        Dim dtRow As DataRow
        Dim updateAcc As DataTable
        Dim i As Integer


        ChkAccBeforeUpdate = True

        If Session("ACCDT") Is Nothing Then Exit Function
        updateAcc = Session("ACCDT")

        Try
            '2010-09-02
            '   strSql = " select a.senac from db2.forwdrac a  " & _
            '" left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
            '" where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('SC','RJ','CC') " & _
            '" union all " & _
            '" select a.dracno from db2.foropaid a " & _
            '" left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
            '" where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('DL','RJ','SC','CC') " & _
            '" union all " & _
            '" select a.dracno from db2.FOROFEDT a " & _
            '" left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
            '" where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('DL','RJ','SC','CC')"

            'strSql = " select a.senac from db2.forwdrac a  " & _
            '         " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('SC','RJ','CC') " & _
            '         " union all " & _
            '         " select a.dracno from db2.foropaid a " & _
            '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
            '         " union all " & _
            '         " select a.dracno from db2.FOROFEDT a " & _
            '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')"
            '2013-03-12 Tom : Add status for edit customer's profile
            ''Kwang R53060089 
            'strSql = " select a.senac from db2.forwdrac a  " & _
            '         " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('SC','RJ','CC') " & _
            '         " and b.senid not in (select senid from db2.forotran where procstat not in ('DL', 'RJ' , 'SC', 'CC','WS') )" & _
            '         " union all " & _
            '         " select a.dracno from db2.foropaid a " & _
            '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
            '         " union all " & _
            '         " select a.dracno from db2.FOROFEDT a " & _
            '         " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
            '         " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')"
            strSql = " select a.senac from db2.forwdrac a  " & _
                     " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                     " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('SC','RJ','CC','IN','WS') " & _
                     " and b.senid not in (select senid from db2.forotran where procstat not in ('DL','RJ','SC','CC','WS') )" & _
                     " union all " & _
                     " select a.dracno from db2.foropaid a " & _
                     " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                     " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
                     " union all " & _
                     " select a.dracno from db2.FOROFEDT a " & _
                     " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                     " where b.senid = '" & Trim(strFORCUSTID) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')"

            Dim ResultSet As DataSet = connDB.RunQuerySql(strSql)
            If ResultSet.Tables.Count > 0 Then
                For Each dtRow In ResultSet.Tables(0).Rows
                    '����� update customer ����������¡�������� �������ҧ update customer ��� �� ��¡�÷�� ���¡�� customer ����� �ѧ��鹵�ͧ ��������� ������ step ���� 
                    '�� Session("CheckCusProcess") = True ��� �͹�á�������� ��������� customer �������� select �ա �� �� ����������ش����
                    If Session("CheckCusProcess") = True Then
                        Session("CheckCusProcess") = False
                        ChkAccBeforeUpdate = False
                        Exit Function
                    End If

                    If (ChkAccBeforeUpdate = False) Then Exit For

                    Dim strTranAcc As String = Trim(dtRow.Item(0))
                    '*******Step1 :: >>>>> Check � FORLCUAC <<<<<<<<<<<<<
                    strSql = "select acno,actype,accurcd from db2.forlcuac where forcustid = '" & Trim(strFORCUSTID) & "'" & _
                             " and acno = '" & Trim(strTranAcc) & "'"

                    ResultSetAcc = connDB.RunQuerySql(strSql)
                    'acno[0],actype[1],accurcd[2]
                    If ResultSetAcc.Tables.Count > 0 Then
                        '�óշ���� account ����� � table FORLCUAC ��ͧ check ��� currency ��� account type ����͹�Ѻ� data table ACCDT
                        Dim dtRow2 As DataRow
                        'dtRow2 = ResultSetAcc.Tables(0).Rows(0)
                        For Each dtRow2 In ResultSetAcc.Tables(0).Rows
                            For i = 0 To updateAcc.Rows.Count - 1
                                If updateAcc.Rows(i).Item(1) = Trim(strTranAcc) Then
                                    If updateAcc.Rows(i).Item(5) <> Trim(dtRow2.Item(1)) Or _
                                       updateAcc.Rows(i).Item(6) <> Trim(dtRow2.Item(2)) Then
                                        ChkAccBeforeUpdate = False
                                    Else
                                        ChkAccBeforeUpdate = True
                                    End If
                                    Exit For
                                Else
                                    ChkAccBeforeUpdate = False
                                End If
                            Next
                        Next


                    Else
                        '*******Step1 :: >>>>> Check � ACCDT (�ó� add ����) <<<<<<<<<<<<<
                        For i = 0 To updateAcc.Rows.Count - 1
                            If updateAcc.Rows(i).Item(1) = Trim(strTranAcc) Then
                                ChkAccBeforeUpdate = True
                                Exit For
                            Else
                                ChkAccBeforeUpdate = False
                            End If
                        Next
                    End If
                Next

            End If

        Catch odbce As OdbcException
            ChkAccBeforeUpdate = False
        Catch ex As Exception
            Return ChkAccBeforeUpdate
        End Try

        Return ChkAccBeforeUpdate

    End Function
    Public Function chkMainAcc(ByVal strChangeAcc As String) As Boolean

        Dim strsql As String
        Dim dtAcc As DataTable
        Dim i As Integer

        dtAcc = Session("ACCDT")
        If dtAcc.Rows.Count > 0 Then
            For i = 0 To dtAcc.Rows.Count - 1

                If i = Session("mintRowAcc") Then GoTo StepNext_i
                If dtAcc.Rows(i).Item(4) = "Y" Then
                    Dim tmpAccount As String = dtAcc.Rows(i).Item(1).ToString()
                    '2010-09-02
                    'strsql = " select a.senac from db2.forwdrac a  " & _
                    '            " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                    '            " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                    '            " and a.senac = '" & Trim(tmpAccount) & "' " & _
                    '            " union all " & _
                    '            " select a.dracno from db2.foropaid a " & _
                    '            " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                    '            " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC') " & _
                    '            " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                    '            " union all " & _
                    '            " select a.dracno from db2.FOROFEDT a " & _
                    '            " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                    '            " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC')" & _
                    '            " and a.dracno = '" & Trim(tmpAccount) & "' "

                    'strsql = " select a.senac from db2.forwdrac a  " & _
                    '            " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                    '            " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                    '            " and a.senac = '" & Trim(tmpAccount) & "' " & _
                    '            " union all " & _
                    '            " select a.dracno from db2.foropaid a " & _
                    '            " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                    '            " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
                    '            " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                    '            " union all " & _
                    '            " select a.dracno from db2.FOROFEDT a " & _
                    '            " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                    '            " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')" & _
                    '            " and a.dracno = '" & Trim(tmpAccount) & "' "
                    'Kwang R53060089
                    strsql = " select a.senac from db2.forwdrac a  " & _
                                " left outer join (select senid,forref,procstat from db2.forwtran ) as b on b.forref = a.forref " & _
                                " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('SC','RJ','CC') " & _
                                " and b.senid not in (select senid from db2.forotran where procstat not in ('DL', 'RJ' , 'SC', 'CC','WS') )" & _
                                " and a.senac = '" & Trim(tmpAccount) & "' " & _
                                " union all " & _
                                " select a.dracno from db2.foropaid a " & _
                                " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                                " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS') " & _
                                " and a.dracno = '" & Trim(tmpAccount) & "' " & _
                                " union all " & _
                                " select a.dracno from db2.FOROFEDT a " & _
                                " left outer join (select senid,procstat,forref from db2.forotran ) as b on b.forref = a.forref " & _
                                " where b.senid = '" & Trim(Session("strCustid")) & "' and b.procstat not in ('DL','RJ','SC','CC','WS')" & _
                                " and a.dracno = '" & Trim(tmpAccount) & "' "

                    Dim dtResultSetSenId As New DataSet
                    Dim connSenId As OdbcConnection = connDB.getDBConn()
                    Dim blnCanUpdate As Boolean

                    dtResultSetSenId = connDB.RunQuerySql(strsql)

                    If dtResultSetSenId.Tables.Count > 0 Then
                        If dtResultSetSenId.Tables(0).Rows.Count > 0 Then
                            If Trim(strChangeAcc) <> Trim(tmpAccount) Then
                                blnCanUpdate = False
                                Exit Function
                            Else
                                blnCanUpdate = True
                            End If
                        Else
                            blnCanUpdate = True
                        End If
                    Else
                        blnCanUpdate = True
                    End If

                    connSenId.Close()


                End If
StepNext_i:
            Next
        End If

        '***********************************************************************************************
        chkMainAcc = True

    End Function

    Public Function chkIdUnique(ByVal strIDAdd As String, ByVal strIdType As String) As Boolean

        Dim strSql
        Dim dtResultSet As DataSet

        chkIdUnique = False
        Dim conn As OdbcConnection = connDB.getDBConn()

        strSql = " SELECT A.FORCUSTID,A.IDNO FROM DB2.FORLCUID A " & _
                 " LEFT OUTER JOIN (SELECT FORCUSTID,CUSTSTATUS,CUSTIND FROM DB2.FORMCUST) AS B ON B.FORCUSTID = A.FORCUSTID  " & _
                 " WHERE B.CUSTSTATUS <> 'D' AND RTRIM(A.IDNO) = '" & Trim(strIDAdd) & "' " & _
                 " AND A.IDTYPE = '" & strIdType & "'" & _
                 " and A.forcustid <> '" & Trim(Session("CustSearch")) & "'"

        dtResultSet = connDB.RunQuerySql(strSql)
        If dtResultSet.Tables.Count > 0 Then
            If dtResultSet.Tables(0).Rows.Count > 0 Then
                chkIdUnique = False
                conn.Close()
                Exit Function

            Else
                chkIdUnique = True
            End If
        Else

        End If

        conn.Close()


    End Function

    Protected Sub ButSaveWait_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButSaveWait.Click
        'AddCustomer("Wait")
        Session("WAIT") = "TRUE"
        Session("SearchFor") = "WAITING"
        AddCustomer()
    End Sub


    Protected Sub ddlFeeName_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFeeName.SelectedIndexChanged
        Dim strsql As String
        Dim concur As FORWEB_Concurrency = CType(Session("concurrencyInfo"), FORWEB_Concurrency)
        strsql = "select case remcur when '000' then '' else remcur end as CODE,case remcur when '000' then '' else remcur end as SHOW from db2.frcmsfee where prodcd = '" & Trim(Me.ddlProdName.SelectedValue.ToString()) & "'" & _
                 " and feecd  = '" & Trim(Me.ddlFeeName.SelectedValue.ToString()) & "' AND SWIFTTCD = '" & concur.SWIFTCODE & "' "
        Me.ddlCurrencyBYfeecd.DataSource = ""
        Me.ddlCurrencyBYfeecd.DataBind()

        If Not PublicFunc.PopulateLoadDDL(Me.ddlCurrencyBYfeecd, "CODE", "SHOW", strsql) Then
            cstext1 = "alert('Error!! Feename should be filled.');"
            cs.RegisterStartupScript(cstype, csname1, cstext1, True)
        End If
        If ddlCurrencyBYfeecd.Items.Count > 0 Then
            Me.ddlCurrencyBYfeecd.SelectedIndex = -1
            ddlCurrencyBYfeecd.Enabled = True

        Else
            Me.ddlCurrencyBYfeecd.DataSource = ""
            Me.ddlCurrencyBYfeecd.DataBind()
            Me.ddlCurrencyBYfeecd.Enabled = False
        End If


    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub



    Protected Sub chkNoLimit_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkNoLimit.CheckedChanged
        If Me.chkNoLimit.Checked = True Then
            Me.txtMaxFee.Text = Format(CDec("999999999999999.99"), "0.00")
            Me.txtMaxFee.Enabled = False
        Else
            Me.txtMaxFee.Text = "0.00"
            Me.txtMaxFee.Enabled = True
        End If
        'Format(CDec(txtMinFee.Text.ToString()), "##,##0.00")
    End Sub
    Protected Sub GridOBJ5_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GridOBJ5.SelectedIndexChanging
        Dim strObjCode As String

        Dim row As GridViewRow = GridOBJ5.Rows(e.NewSelectedIndex)
        strObjCode = Trim(row.Cells(1).Text)
        Me.txtSelectObj.Text = strObjCode
        Me.LabelDisObj.Text = row.Cells(2).Text
        GridOBJ5.Visible = True
    End Sub

    'kwang ::R53060089
    Public Function GetAppcode(ByVal strForCustID) As Boolean
        Dim strSql As String
        Dim dtResultSet2 As DataSet
        Dim conn As OdbcConnection = connDB.getDBConn()

        GetAppcode = False
        strSql = " SELECT DISTINCT SENID FROM DB2.FORWTRAN " & _
                 " WHERE SENID = '" & strForCustID & "' AND APPCODE = 'BCMS'"

        dtResultSet2 = connDB.RunQuerySql(strSql)

        'PIK : 2015-11-06 : fixed fault start
        'If dtResultSet2.Tables.Count > 0 Then GetAppcode = True
        If dtResultSet2.Tables.Count > 0 Then
            If dtResultSet2.Tables(0).Rows.Count > 0 Then
                GetAppcode = True

            Else
                GetAppcode = False
            End If
        End If
        'PIK : 2015-11-06 : fixed fault  end
        conn.Close()
    End Function


    Protected Sub chkSendRCPT_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSendRCPT.CheckedChanged

    End Sub
	
	
	 '2020-08-28 : Support AD Authen
    Private Function getLDAPURL() As String
        Dim strsql As String

        'Initial return value
        getLDAPURL = ""

        Try
            strsql = "select value from db2.frcmtbcd where type = 'A001' and code = 'AD0001' "
            Dim ResultSet As DataSet = connDB.RunQuerySql(strsql)

            If ResultSet.Tables(0).Rows.Count > 0 Then
                Dim rowURL As DataRow
                For Each rowURL In ResultSet.Tables(0).Rows
                    getLDAPURL = Trim(rowURL.Item(0).ToString)
                Next
            End If

        Catch odbce As OdbcException
            'Response.Redirect("~/DisplayMsg.aspx?type=Inquiry URL failed.!!!&page=Inquiry")
        Catch ex As Exception
            'Response.Redirect("~/DisplayMsg.aspx?type=Inquiry URL failed.!!!&page=Inquiry")
        End Try

    End Function
	
	
	 '2020-08-28 : Support AD Authen
    Private Function getDomain() As String
        Dim strsql As String

        'Initial return value
        getDomain = ""

        Try
            strsql = "select value from db2.frcmtbcd where type = 'A001' and code = 'AD0002' "
            Dim ResultSet As DataSet = connDB.RunQuerySql(strsql)

            If ResultSet.Tables(0).Rows.Count > 0 Then
                Dim rowURL As DataRow
                For Each rowURL In ResultSet.Tables(0).Rows
                    getDomain = Trim(rowURL.Item(0).ToString)
                Next
            End If

        Catch odbce As OdbcException
            'Response.Redirect("~/DisplayMsg.aspx?type=Inquiry URL failed.!!!&page=Inquiry")
        Catch ex As Exception
            'Response.Redirect("~/DisplayMsg.aspx?type=Inquiry URL failed.!!!&page=Inquiry")
        End Try

    End Function

    'P630017-07 PII : Robin : Feb-2021 : Start
    Private Sub ProcessPIIlog(ByRef strErrMsg As String)
        If Session("SearchFor") <> "INQUIRY" Then Exit Sub
        'siteNode.Title
        Dim tempVarPII As String
        tempVarPII = ""

        ' Customer Detail
        'Customer Name  SWNAME1 SWNAME2
        tempVarPII = Me.TextName1.Value & IIf(Trim(Me.TextName2.Value) <> "", " " & Me.TextName2.Value, "")
        If tempVarPII <> "" Then
            Call InqDetailPiiLog(strErrMsg, PublicFunc.DetName.detName, tempVarPII)
            tempVarPII = ""
        End If
        'comment P630017-07 PII : Robin : March-2021
        ''Identification
        'Dim tmpStrArr As String()
        'For Each gridDet As DataRow In Mdt.Rows
        '    tempVarPII = Trim(gridDet.Item(1).ToString()) 'ID TYPE
        '    tmpStrArr = tempVarPII.Split(":")
        '    If UBound(tmpStrArr) = 1 Then
        '        tempVarPII = Trim(tmpStrArr(1))
        '        If tempVarPII <> "" Then
        '            tempVarPII = tempVarPII & "|" & Trim(gridDet.Item(2).ToString()) 'ID NUMBER
        '            Call InqDetailPiiLog(strErrMsg, PublicFunc.DetName.detIdentification, tempVarPII)
        '            tempVarPII = ""
        '        End If
        '    End If
        'Next
        ''Account
        'For Each gridDet As DataRow In ACCDT.Rows
        '    tempVarPII = Trim(gridDet.Item(1).ToString()) 'Account No
        '    If tempVarPII <> "" Then
        '        Call InqDetailPiiLog(strErrMsg, PublicFunc.DetName.detAccountNo, tempVarPII)
        '        tempVarPII = ""
        '    End If
        'Next


        tempVarPII = vbNullString


        'P630017-07 PII : Robin : Feb-2021 : End
    End Sub
    Private Sub InqDetailPiiLog(ByRef strErrMsg As String, ByVal inCriteria As PublicFunc.DetName, ByVal inValue As String)
        If inValue = "" Then Exit Sub
        Dim fldDetail As String, srcName As String
        fldDetail = ""
        srcName = "Inquiry - Customer"
        Call PublicFunc.GetDetailName(inCriteria, fldDetail)
        Call PublicFunc.InsertPIILog("FOR", "FORWEB OSB", srcName, "2", Session("strUserID"), fldDetail, inValue, strErrMsg)
        fldDetail = vbNullString
        srcName = vbNullString
    End Sub

    Protected Sub ddlContactBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlContactBy.SelectedIndexChanged
        'START xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Code Copied from FORWEB TH Version,
        If ddlContactBy.SelectedValue = "E" Then
            chkRcvByEmail.Checked = True
            chkRcvAdv.Checked = True
        End If
        'END - SR3280 
    End Sub

    Protected Sub chkRcvByEmail_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkRcvByEmail.CheckedChanged
        'START xx.01.2022 - SR3280 - Autosendmail FRC OSB - Robin - Code Copied from FORWEB TH Version,
        If chkRcvByEmail.Checked = True Then
            ddlContactBy.SelectedValue = "E"
        End If
        'END - SR3280 
    End Sub
End Class
